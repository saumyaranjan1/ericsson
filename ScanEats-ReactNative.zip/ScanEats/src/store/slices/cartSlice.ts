import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { CartItem, Table, Deal } from '../../types';

interface CartState { items: CartItem[]; table: Table | null; orderType: 'dine-in' | 'takeaway'; deal: Deal | null; specialNotes: string; }

const cartSlice = createSlice({
  name: 'cart',
  initialState: { items: [], table: null, orderType: 'dine-in', deal: null, specialNotes: '' } as CartState,
  reducers: {
    addToCart: (s, a: PayloadAction<CartItem>) => {
      const idx = s.items.findIndex(i => i.menuItem.id === a.payload.menuItem.id && i.selectedVariation?.id === a.payload.selectedVariation?.id);
      if (idx >= 0) { s.items[idx].quantity += a.payload.quantity; s.items[idx].totalPrice += a.payload.totalPrice; }
      else s.items.push(a.payload);
    },
    removeFromCart: (s, a: PayloadAction<number>) => { s.items.splice(a.payload, 1); },
    updateQuantity: (s, a: PayloadAction<{ index: number; qty: number }>) => {
      const item = s.items[a.payload.index];
      if (item) { const u = item.totalPrice / item.quantity; item.quantity = a.payload.qty; item.totalPrice = u * a.payload.qty; }
    },
    setTable: (s, a: PayloadAction<Table | null>) => { s.table = a.payload; },
    setOrderType: (s, a: PayloadAction<'dine-in' | 'takeaway'>) => { s.orderType = a.payload; },
    setDeal: (s, a: PayloadAction<Deal | null>) => { s.deal = a.payload; },
    setNotes: (s, a: PayloadAction<string>) => { s.specialNotes = a.payload; },
    clearCart: () => ({ items: [], table: null, orderType: 'dine-in' as const, deal: null, specialNotes: '' }),
  },
});

export const { addToCart, removeFromCart, updateQuantity, setTable, setOrderType, setDeal, setNotes, clearCart } = cartSlice.actions;
export default cartSlice.reducer;
