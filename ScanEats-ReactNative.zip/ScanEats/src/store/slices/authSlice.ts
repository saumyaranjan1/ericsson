import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { User, Restaurant } from '../../types';

interface AuthState { user: User | null; restaurant: Restaurant | null; slug: string; isLoading: boolean; error: string | null; }

const authSlice = createSlice({
  name: 'auth',
  initialState: { user: null, restaurant: null, slug: '', isLoading: true, error: null } as AuthState,
  reducers: {
    setUser: (s, a: PayloadAction<User | null>) => { s.user = a.payload; },
    setRestaurant: (s, a: PayloadAction<Restaurant | null>) => { s.restaurant = a.payload; },
    setSlug: (s, a: PayloadAction<string>) => { s.slug = a.payload; },
    setLoading: (s, a: PayloadAction<boolean>) => { s.isLoading = a.payload; },
    setError: (s, a: PayloadAction<string | null>) => { s.error = a.payload; },
    logout: () => ({ user: null, restaurant: null, slug: '', isLoading: false, error: null }),
  },
});

export const { setUser, setRestaurant, setSlug, setLoading, setError, logout } = authSlice.actions;
export default authSlice.reducer;
