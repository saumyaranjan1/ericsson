import { createSlice, PayloadAction } from '@reduxjs/toolkit';

const themeSlice = createSlice({
  name: 'theme',
  initialState: { isDarkMode: false, primaryColor: '#FF6B35', language: 'en' },
  reducers: {
    toggleDarkMode: (s) => { s.isDarkMode = !s.isDarkMode; },
    setPrimaryColor: (s, a: PayloadAction<string>) => { s.primaryColor = a.payload; },
    setLanguage: (s, a: PayloadAction<string>) => { s.language = a.payload; },
  },
});

export const { toggleDarkMode, setPrimaryColor, setLanguage } = themeSlice.actions;
export default themeSlice.reducer;
