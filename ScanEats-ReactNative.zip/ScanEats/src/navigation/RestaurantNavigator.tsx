import React from 'react';
import { createDrawerNavigator } from '@react-navigation/drawer';
import DashboardScreen from '../screens/restaurant/DashboardScreen';
import POSScreen from '../screens/restaurant/POSScreen';
import OrderManagementScreen from '../screens/restaurant/OrderManagementScreen';
import MenuManagementScreen from '../screens/restaurant/MenuManagementScreen';
import TableManagementScreen from '../screens/restaurant/TableManagementScreen';
import QRGeneratorScreen from '../screens/restaurant/QRGeneratorScreen';
import SalesAnalyticsScreen from '../screens/restaurant/SalesAnalyticsScreen';
import SettingsScreen from '../screens/restaurant/SettingsScreen';

const Drawer = createDrawerNavigator();

export default function RestaurantNavigator() {
  return (
    <Drawer.Navigator screenOptions={{ drawerActiveTintColor: '#FF6B35' }}>
      <Drawer.Screen name="Dashboard" component={DashboardScreen} />
      <Drawer.Screen name="POS" component={POSScreen} />
      <Drawer.Screen name="Orders" component={OrderManagementScreen} />
      <Drawer.Screen name="Menu" component={MenuManagementScreen} />
      <Drawer.Screen name="Tables" component={TableManagementScreen} />
      <Drawer.Screen name="QR Codes" component={QRGeneratorScreen} />
      <Drawer.Screen name="Analytics" component={SalesAnalyticsScreen} />
      <Drawer.Screen name="Settings" component={SettingsScreen} />
    </Drawer.Navigator>
  );
}
