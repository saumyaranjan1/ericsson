import React from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import OwnerDashboardScreen from '../screens/owner/OwnerDashboardScreen';
import RestaurantListScreen from '../screens/owner/RestaurantListScreen';
import SubscriptionScreen from '../screens/owner/SubscriptionScreen';

const Stack = createNativeStackNavigator();

export default function OwnerNavigator() {
  return (
    <Stack.Navigator>
      <Stack.Screen name="OwnerDashboard" component={OwnerDashboardScreen} options={{ title: 'Owner Panel' }} />
      <Stack.Screen name="RestaurantList" component={RestaurantListScreen} />
      <Stack.Screen name="Subscriptions" component={SubscriptionScreen} />
    </Stack.Navigator>
  );
}
