import React, { useEffect } from 'react';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { authService } from '../services/authService';
import { setUser, setLoading } from '../store/slices/authSlice';
import { ActivityIndicator, View } from 'react-native';

// Import screens (see screen files)
import SlugEntryScreen from '../screens/auth/SlugEntryScreen';
import LoginScreen from '../screens/auth/LoginScreen';
import RegisterScreen from '../screens/auth/RegisterScreen';
import CustomerNavigator from './CustomerNavigator';
import RestaurantNavigator from './RestaurantNavigator';
import OwnerNavigator from './OwnerNavigator';

const Stack = createNativeStackNavigator();

export default function AppNavigator() {
  const { user, isLoading } = useSelector((s: RootState) => s.auth);
  const dispatch = useDispatch();

  useEffect(() => {
    const unsub = authService.onAuthStateChanged(async (fbUser) => {
      if (fbUser) { const u = await authService.getUser(fbUser.uid); dispatch(setUser(u)); }
      else dispatch(setUser(null));
      dispatch(setLoading(false));
    });
    return unsub;
  }, []);

  if (isLoading) return <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}><ActivityIndicator size="large" color="#FF6B35" /></View>;

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {!user ? (
        <>
          <Stack.Screen name="SlugEntry" component={SlugEntryScreen} />
          <Stack.Screen name="Login" component={LoginScreen} />
          <Stack.Screen name="Register" component={RegisterScreen} />
        </>
      ) : (
        <>
          {(user.role === 'customer') && <Stack.Screen name="CustomerApp" component={CustomerNavigator} />}
          {(['admin','manager','staff'].includes(user.role)) && <Stack.Screen name="RestaurantApp" component={RestaurantNavigator} />}
          {(user.role === 'owner') && <Stack.Screen name="OwnerApp" component={OwnerNavigator} />}
        </>
      )}
    </Stack.Navigator>
  );
}
