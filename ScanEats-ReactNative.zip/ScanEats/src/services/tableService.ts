import { db } from './firebase';
import { Table } from '../types';

export const tableService = {
  subscribeTables(branchId: string, cb: (tables: Table[]) => void) {
    return db.collection('tables').where('branchId', '==', branchId).orderBy('number')
      .onSnapshot(snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() } as Table))));
  },
  async addTable(table: Omit<Table, 'id'>) { return (await db.collection('tables').add(table)).id; },
  async updateTable(id: string, data: Partial<Table>) { await db.collection('tables').doc(id).update(data); },
  async deleteTable(id: string) { await db.collection('tables').doc(id).delete(); },
  async getTableByQR(qrCode: string): Promise<Table | null> {
    const snap = await db.collection('tables').where('qrCode', '==', qrCode).limit(1).get();
    return snap.empty ? null : { id: snap.docs[0].id, ...snap.docs[0].data() } as Table;
  },
};
