import { db } from './firebase';
import { Order } from '../types';

export const orderService = {
  async createOrder(order: Omit<Order, 'id'>): Promise<string> {
    const ref = await db.collection('orders').add({ ...order, createdAt: new Date(), updatedAt: new Date() });
    if (order.tableId) {
      await db.collection('tables').doc(order.tableId).update({ status: 'occupied', currentOrderId: ref.id });
    }
    return ref.id;
  },

  async updateOrder(id: string, data: Partial<Order>) {
    await db.collection('orders').doc(id).update({ ...data, updatedAt: new Date() });
  },

  async updateOrderStatus(id: string, status: Order['status']) {
    await db.collection('orders').doc(id).update({ status, updatedAt: new Date() });
    if (status === 'completed' || status === 'cancelled') {
      const order = await db.collection('orders').doc(id).get();
      const tableId = order.data()?.tableId;
      if (tableId) await db.collection('tables').doc(tableId).update({ status: 'available', currentOrderId: null });
    }
  },

  subscribeOrders(restaurantId: string, branchId: string | null, cb: (orders: Order[]) => void) {
    let q: any = db.collection('orders').where('restaurantId', '==', restaurantId).orderBy('createdAt', 'desc');
    if (branchId) q = q.where('branchId', '==', branchId);
    return q.onSnapshot((snap: any) => cb(snap.docs.map((d: any) => ({ id: d.id, ...d.data() } as Order))));
  },

  subscribeCustomerOrders(customerId: string, cb: (orders: Order[]) => void) {
    return db.collection('orders').where('customerId', '==', customerId).orderBy('createdAt', 'desc')
      .onSnapshot(snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() } as Order))));
  },

  async generateToken(restaurantId: string, branchId: string): Promise<string> {
    const today = new Date().toISOString().split('T')[0];
    const ref = db.collection('tokenCounters').doc(branchId + '_' + today);
    const doc = await ref.get();
    const count = doc.exists ? (doc.data()?.count || 0) + 1 : 1;
    await ref.set({ count, date: today });
    return 'TKN-' + count.toString().padStart(4, '0');
  },
};
