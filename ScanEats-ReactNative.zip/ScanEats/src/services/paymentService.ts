import { Order } from '../types';

export const paymentService = {
  async processRazorpay(order: Order, options: any) {
    const RazorpayCheckout = require('react-native-razorpay').default;
    return RazorpayCheckout.open({
      description: 'Order #' + order.id, currency: 'INR', key: 'YOUR_RAZORPAY_KEY',
      amount: Math.round(order.total * 100), name: 'ScanEats',
      prefill: { email: options.email, contact: options.phone, name: options.name },
      theme: { color: '#FF6B35' },
    });
  },
  async processStripe(order: Order) { return { success: true }; },
  async processCash(orderId: string) {
    const { db } = require('./firebase');
    await db.collection('orders').doc(orderId).update({ paymentMethod: 'cash', paymentStatus: 'pending' });
  },
};
