import messaging from '@react-native-firebase/messaging';

export const notificationService = {
  async requestPermission() {
    const s = await messaging().requestPermission();
    return s === messaging.AuthorizationStatus.AUTHORIZED || s === messaging.AuthorizationStatus.PROVISIONAL;
  },
  async getToken() { try { return await messaging().getToken(); } catch { return null; } },
  onMessage(cb: (msg: any) => void) { return messaging().onMessage(cb); },
  onNotificationOpened(cb: (msg: any) => void) { return messaging().onNotificationOpenedApp(cb); },
};
