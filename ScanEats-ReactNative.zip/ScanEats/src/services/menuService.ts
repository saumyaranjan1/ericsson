import { db } from './firebase';
import { Category, MenuItem } from '../types';

export const menuService = {
  subscribeCategories(restaurantId: string, cb: (cats: Category[]) => void) {
    return db.collection('categories').where('restaurantId', '==', restaurantId)
      .where('isActive', '==', true).orderBy('sortOrder')
      .onSnapshot(snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() } as Category))));
  },

  subscribeMenuItems(restaurantId: string, cb: (items: MenuItem[]) => void) {
    return db.collection('menuItems').where('restaurantId', '==', restaurantId)
      .where('isAvailable', '==', true)
      .onSnapshot(snap => cb(snap.docs.map(d => ({ id: d.id, ...d.data() } as MenuItem))));
  },

  async addCategory(cat: Omit<Category, 'id'>) { return (await db.collection('categories').add(cat)).id; },
  async updateCategory(id: string, data: Partial<Category>) { await db.collection('categories').doc(id).update(data); },
  async addMenuItem(item: Omit<MenuItem, 'id'>) { return (await db.collection('menuItems').add(item)).id; },
  async updateMenuItem(id: string, data: Partial<MenuItem>) { await db.collection('menuItems').doc(id).update(data); },
  async deleteMenuItem(id: string) { await db.collection('menuItems').doc(id).delete(); },

  async searchItems(restaurantId: string, query: string): Promise<MenuItem[]> {
    const snap = await db.collection('menuItems').where('restaurantId', '==', restaurantId).where('isAvailable', '==', true).get();
    const q = query.toLowerCase();
    return snap.docs.map(d => ({ id: d.id, ...d.data() } as MenuItem)).filter(i => i.name.toLowerCase().includes(q));
  },
};
