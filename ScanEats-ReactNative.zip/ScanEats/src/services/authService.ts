import { auth, db } from './firebase';
import { User } from '../types';

export const authService = {
  async login(email: string, password: string): Promise<User> {
    const cred = await auth().signInWithEmailAndPassword(email, password);
    const doc = await db.collection('users').doc(cred.user.uid).get();
    return { id: cred.user.uid, ...doc.data() } as User;
  },

  async register(data: { email: string; password: string; name: string; phone: string; role: User['role']; restaurantId?: string }): Promise<User> {
    const cred = await auth().createUserWithEmailAndPassword(data.email, data.password);
    const user: Omit<User, 'id'> = {
      email: data.email, name: data.name, phone: data.phone, role: data.role,
      restaurantId: data.restaurantId, loyaltyPoints: 0, createdAt: new Date(),
    };
    await db.collection('users').doc(cred.user.uid).set(user);
    return { id: cred.user.uid, ...user };
  },

  async logout() { await auth().signOut(); },

  async getUser(uid: string): Promise<User | null> {
    const doc = await db.collection('users').doc(uid).get();
    return doc.exists ? ({ id: uid, ...doc.data() } as User) : null;
  },

  onAuthStateChanged(cb: (user: any) => void) { return auth().onAuthStateChanged(cb); },
};
