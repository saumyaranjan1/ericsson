export const lightColors = {
  bg: '#FFFFFF', surface: '#F8F9FA', primary: '#FF6B35', secondary: '#004E89',
  text: '#1A1A2E', textSecondary: '#6C757D', border: '#E9ECEF',
  success: '#28A745', warning: '#FFC107', error: '#DC3545',
  veg: '#22C55E', nonVeg: '#EF4444', card: '#FFFFFF', shadow: 'rgba(0,0,0,0.1)',
};

export const darkColors = {
  bg: '#121212', surface: '#1E1E1E', primary: '#FF6B35', secondary: '#5BA3D9',
  text: '#E8E8E8', textSecondary: '#A0A0A0', border: '#333333',
  success: '#4ADE80', warning: '#FBBF24', error: '#F87171',
  veg: '#22C55E', nonVeg: '#EF4444', card: '#252525', shadow: 'rgba(0,0,0,0.3)',
};
