export const spacing = { xs: 4, sm: 8, md: 12, base: 16, lg: 20, xl: 24, xxl: 32 };
export const radius = { sm: 6, md: 10, lg: 14, xl: 20, full: 9999 };
