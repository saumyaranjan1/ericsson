export interface User {
  id: string;
  email: string;
  name: string;
  phone: string;
  role: 'customer' | 'admin' | 'manager' | 'staff' | 'owner';
  restaurantId?: string;
  branchId?: string;
  loyaltyPoints?: number;
  avatar?: string;
  createdAt: Date;
}

export interface Restaurant {
  id: string;
  name: string;
  slug: string;
  ownerId: string;
  logo?: string;
  coverImage?: string;
  description: string;
  address: string;
  phone: string;
  email: string;
  currency: Currency;
  taxConfig: TaxConfig[];
  themeSettings: ThemeSettings;
  isActive: boolean;
  subscription: Subscription;
  branches: Branch[];
  createdAt: Date;
}

export interface Branch {
  id: string;
  restaurantId: string;
  name: string;
  address: string;
  phone: string;
  tables: Table[];
  isActive: boolean;
}

export interface Table {
  id: string;
  branchId: string;
  number: number;
  capacity: number;
  qrCode: string;
  status: 'available' | 'occupied' | 'reserved';
  currentOrderId?: string;
}

export interface Category {
  id: string;
  restaurantId: string;
  name: string;
  image?: string;
  sortOrder: number;
  isActive: boolean;
}

export interface MenuItem {
  id: string;
  restaurantId: string;
  categoryId: string;
  name: string;
  description: string;
  price: number;
  image?: string;
  isVeg: boolean;
  isFeatured: boolean;
  isAvailable: boolean;
  variations: Variation[];
  extras: Extra[];
  preparationTime?: number;
}

export interface Variation { id: string; name: string; price: number; }
export interface Extra { id: string; name: string; price: number; }

export interface CartItem {
  menuItem: MenuItem;
  quantity: number;
  selectedVariation?: Variation;
  selectedExtras: Extra[];
  specialInstructions?: string;
  totalPrice: number;
}

export interface Order {
  id: string;
  restaurantId: string;
  branchId: string;
  tableId?: string;
  tableNumber?: number;
  customerId?: string;
  customerName?: string;
  items: OrderItem[];
  subtotal: number;
  taxAmount: number;
  discount: number;
  total: number;
  status: OrderStatus;
  type: 'dine-in' | 'takeaway';
  tokenNumber?: string;
  paymentMethod?: 'cash' | 'card' | 'razorpay' | 'stripe' | 'paypal' | 'paystack';
  paymentStatus: 'pending' | 'paid' | 'refunded';
  loyaltyPointsEarned?: number;
  loyaltyPointsRedeemed?: number;
  dealId?: string;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export type OrderStatus = 'pending' | 'confirmed' | 'preparing' | 'ready' | 'served' | 'completed' | 'cancelled';

export interface OrderItem {
  menuItemId: string;
  name: string;
  price: number;
  quantity: number;
  variation?: string;
  extras: string[];
  specialInstructions?: string;
}

export interface Deal {
  id: string;
  restaurantId: string;
  code: string;
  description: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minOrderAmount?: number;
  maxDiscount?: number;
  validFrom: Date;
  validTo: Date;
  isActive: boolean;
}

export interface Currency { code: string; symbol: string; position: 'before' | 'after'; }
export interface TaxConfig { id: string; name: string; rate: number; isInclusive: boolean; }
export interface ThemeSettings { primaryColor: string; secondaryColor: string; isDarkMode: boolean; fontFamily: string; logoUrl?: string; }
export interface Subscription { id: string; plan: 'free' | 'basic' | 'pro' | 'enterprise'; status: 'active' | 'expired' | 'cancelled'; startDate: Date; endDate: Date; maxBranches: number; maxTables: number; }
export interface LoyaltyConfig { pointsPerCurrencyUnit: number; redemptionRate: number; isEnabled: boolean; }
