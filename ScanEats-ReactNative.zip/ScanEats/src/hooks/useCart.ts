import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { MenuItem, Variation, Extra, CartItem } from '../types';
import { addToCart, removeFromCart, updateQuantity, setDeal, clearCart, setOrderType } from '../store/slices/cartSlice';

export const useCart = () => {
  const cart = useSelector((s: RootState) => s.cart);
  const restaurant = useSelector((s: RootState) => s.auth.restaurant);
  const dispatch = useDispatch();

  const addItem = (item: MenuItem, qty: number, variation?: Variation, extras: Extra[] = [], notes?: string) => {
    const base = variation?.price || item.price;
    const ext = extras.reduce((s, e) => s + e.price, 0);
    dispatch(addToCart({ menuItem: item, quantity: qty, selectedVariation: variation, selectedExtras: extras, specialInstructions: notes, totalPrice: (base + ext) * qty }));
  };

  const subtotal = cart.items.reduce((s, i) => s + i.totalPrice, 0);
  const taxRate = restaurant?.taxConfig?.[0]?.rate || 0;
  const taxAmount = subtotal * (taxRate / 100);
  const discount = cart.deal ? (cart.deal.discountType === 'percentage' ? Math.min(subtotal * (cart.deal.discountValue / 100), cart.deal.maxDiscount || Infinity) : cart.deal.discountValue) : 0;
  const total = subtotal + taxAmount - discount;
  const itemCount = cart.items.reduce((s, i) => s + i.quantity, 0);

  return {
    items: cart.items, table: cart.table, orderType: cart.orderType, deal: cart.deal,
    subtotal, taxAmount, discount, total, itemCount,
    addItem, removeItem: (i: number) => dispatch(removeFromCart(i)),
    updateQty: (i: number, q: number) => dispatch(updateQuantity({ index: i, qty: q })),
    applyDeal: (d: any) => dispatch(setDeal(d)),
    changeOrderType: (t: 'dine-in' | 'takeaway') => dispatch(setOrderType(t)),
    clear: () => dispatch(clearCart()),
  };
};
