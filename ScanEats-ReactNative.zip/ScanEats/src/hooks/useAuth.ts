import { useCallback } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from '../store';
import { authService } from '../services/authService';
import { setUser, setLoading, setError, logout as logoutAction } from '../store/slices/authSlice';
import { clearCart } from '../store/slices/cartSlice';

export const useAuth = () => {
  const { user, restaurant, isLoading, error } = useSelector((s: RootState) => s.auth);
  const dispatch = useDispatch();

  const login = useCallback(async (email: string, password: string) => {
    dispatch(setLoading(true));
    try { const u = await authService.login(email, password); dispatch(setUser(u)); return u; }
    catch (e: any) { dispatch(setError(e.message)); throw e; }
    finally { dispatch(setLoading(false)); }
  }, [dispatch]);

  const register = useCallback(async (data: any) => {
    dispatch(setLoading(true));
    try { const u = await authService.register(data); dispatch(setUser(u)); return u; }
    catch (e: any) { dispatch(setError(e.message)); throw e; }
    finally { dispatch(setLoading(false)); }
  }, [dispatch]);

  const logout = useCallback(async () => {
    await authService.logout(); dispatch(logoutAction()); dispatch(clearCart());
  }, [dispatch]);

  return { user, restaurant, isLoading, error, login, register, logout };
};
