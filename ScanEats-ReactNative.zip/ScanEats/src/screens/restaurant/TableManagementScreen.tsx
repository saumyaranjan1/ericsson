import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function TableManagementScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Table Management</Text>
      {/* TODO: Implement full Table Management screen - see main artifact for complete code */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8F9FA', padding: 16 },
  title: { fontSize: 24, fontWeight: '700', color: '#1A1A2E' },
});
