import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

export default function LoyaltyPointsScreen() {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>Loyalty Points</Text>
      {/* TODO: Implement full Loyalty Points screen - see main artifact for complete code */}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#F8F9FA', padding: 16 },
  title: { fontSize: 24, fontWeight: '700', color: '#1A1A2E' },
});
