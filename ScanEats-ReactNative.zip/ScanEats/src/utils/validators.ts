export const validateEmail = (e: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e);
export const validatePhone = (p: string) => /^\+?[\d\s-]{10,}$/.test(p);
export const validatePassword = (p: string) => p.length >= 6;
export const validateSlug = (s: string) => /^[a-z0-9-]+$/.test(s);
