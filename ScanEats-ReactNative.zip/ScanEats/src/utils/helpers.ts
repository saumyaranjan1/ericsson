export const formatCurrency = (amt: number, sym = '$', pos: 'before' | 'after' = 'before') =>
  pos === 'before' ? sym + amt.toFixed(2) : amt.toFixed(2) + sym;

export const formatDate = (d: Date | any) => (d instanceof Date ? d : new Date(d)).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
export const formatTime = (d: Date | any) => (d instanceof Date ? d : new Date(d)).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });

export const generateQRData = (slug: string, branchId: string, tableId: string) => `scaneats://${slug}/branch/${branchId}/table/${tableId}`;

export const parseQRData = (qr: string) => {
  const m = qr.match(/scaneats:\/\/(.+)\/branch\/(.+)\/table\/(.+)/);
  return m ? { slug: m[1], branchId: m[2], tableId: m[3] } : null;
};

export const getOrderStatusColor = (s: string) => ({ pending: '#FFC107', confirmed: '#17A2B8', preparing: '#FF6B35', ready: '#28A745', served: '#6F42C1', completed: '#6C757D', cancelled: '#DC3545' }[s] || '#999');
export const getOrderStatusIcon = (s: string) => ({ pending: 'clock-outline', confirmed: 'check', preparing: 'pot-steam', ready: 'bell-ring', served: 'silverware-fork-knife', completed: 'check-circle', cancelled: 'close-circle' }[s] || 'help-circle');
