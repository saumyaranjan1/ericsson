export const ORDER_STATUS_FLOW = ['pending', 'confirmed', 'preparing', 'ready', 'served', 'completed'] as const;
export const PAYMENT_METHODS = ['cash', 'razorpay', 'stripe', 'paypal', 'paystack'] as const;
export const SUBSCRIPTION_PLANS = ['free', 'basic', 'pro', 'enterprise'] as const;
