# 🍽 ScanEats - React Native

QR Menu Maker & Contactless Table Ordering System with POS

## Features
- Multi-Restaurant (slug-based routing)
- QR Code Scanning & Generation
- Dine-In & Takeaway with Token Numbers
- Point of Sale (POS) System
- Real-time Order Management (Firestore)
- Payment Gateways (RazorPay, Stripe, Cash)
- Veg/Non-Veg & Featured Items
- Deals, Vouchers & Loyalty Points
- Sales Analytics & Reporting
- Dark/Light Mode & Multi-Language (i18n)
- Push Notifications (FCM)
- Branch & Table Management
- Staff Role Management (Admin/Manager/Staff)
- Owner Panel for Multi-Restaurant Control
- Subscription Management

## Setup

```bash
# 1. Install dependencies
npm install

# 2. Configure Firebase
# - Create project at https://console.firebase.google.com
# - Add google-services.json to android/app/
# - Add GoogleService-Info.plist to ios/
# - Copy .env.example to .env and fill in keys

# 3. iOS setup
cd ios && pod install && cd ..

# 4. Run
npx react-native run-ios
npx react-native run-android
```

## Architecture
```
App.tsx → Navigation (role-based) → Screens → Redux → Services → Firebase
```

## Tech Stack
- React Native 0.74
- TypeScript
- Firebase (Auth, Firestore, Storage, FCM)
- Redux Toolkit
- React Navigation 6
- react-native-camera-kit (QR scanning)
- react-native-qrcode-svg (QR generation)
- Payment: RazorPay, Stripe
