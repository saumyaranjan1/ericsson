export const  GetRuleGroupData = 
[    
    {
        "data": {
        "id": "5eb4f42b32662545dc2f0eff",
        "name": "uniqueName",
        "purpose": "SelectApps",
        "description": "allows-selection-of-apps",
        "enterpriseIds": [
            "e1",
            "e2",
            "e3"
        ],
        "version": null,
        "rules_filename": null,
        "rules_count": 0,
        "gridId": null
}}]




