import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { dasboardRoutingModule } from './dasboard-routing.module';
import { dasboardComponent } from './dasboard.component';
@NgModule({
  declarations: [dasboardComponent],
  imports: [
    CommonModule,
    dasboardRoutingModule
  ],
})
export class DasboardModule { }
