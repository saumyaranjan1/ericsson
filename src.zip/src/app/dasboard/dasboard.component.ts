import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dasboar',
  templateUrl: './dasboard.component.html',
  styleUrls: ['./dasboard.component.less']
})
export class dasboardComponent implements OnInit {

  pageType: any;
  constructor() { }
  ngOnInit() {
     if(atob(JSON.parse(sessionStorage.getItem('loginMember'))) =='saumyaranjan.nanda@ril.com'){
      this.pageType=true;
    }else{
      this.pageType=false;
    }
  }
   
}
