import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { IConfigResponse } from './app';

@Injectable()
export class AppConfigService {

  configData : IConfigResponse; 

  constructor(private http: HttpClient) { }

  /**
   *
   *  Reading Config data from Config JSON File.
   * 
   */

  public load() {
    const jsonFile = `assets/config/config.json`;
    return new Promise<void>((resolve, reject) => {
      this.http.get(jsonFile).toPromise().then((response: IConfigResponse) => {
        this.configData = response;
        this.configData['getBaseUrl'] = 'http://' + response['ip'] + ':' + response['port'];
        resolve();
      }).catch((response: any) => {
        reject(`Could not load file '${jsonFile}': ${JSON.stringify(response)}`);
      });
    });
  }

}
