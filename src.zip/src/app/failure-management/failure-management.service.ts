import { Injectable } from '@angular/core';
import { InterceptorService } from './../shared/services/interceptor.service'
import { DeleteIntercepterService } from '../shared/services/delete-ajax-method.service';

@Injectable()
export class FailureManagementService {

  constructor(private interceptor: InterceptorService,
              private deleteIntercepterService: DeleteIntercepterService) { }

    getrecordbyFilters(request) {
      return this.interceptor.httpCall('post', 'getrecordbyFilters',request);
    }

    retryBycorelationId(request) {
      return this.interceptor.httpCall('post', 'retryBycorelationId',request);
    }

    retryByFilter(request){
       return this.interceptor.httpCall('post', 'retryByFilter',request);
    }

    getDistinctValuesOfField(request){
      return this.interceptor.httpCall('get', 'getDistinctValuesOfField',request);
   }

   getTotalCount(){
    return this.interceptor.httpCall('get', 'getTotalCount');
   }
}
