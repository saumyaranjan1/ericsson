import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { FailureManagementService } from './failure-management.service';
import { ServerPaginationTableComponent } from
  '../shared/components/server-pagination-table/server-pagination-table.component';
import { DataService } from '../shared/services/data.service';
import { AngularMultiSelect } from 'angular2-multiselect-dropdown';

@Component({
  selector: 'app-failure-management',
  templateUrl: './failure-management.component.html',
  styleUrls: ['./failure-management.component.less']
})
export class FailureManagementComponent implements OnInit {
  @ViewChild(ServerPaginationTableComponent, { static: false }) child: ServerPaginationTableComponent;
  @ViewChild('failureMgmtErrorJsonModalContent', { static: true }) failureMgmtErrorJsonModalContent: ElementRef;
  failureTableView = false;
  refreshList = [];
  filterChec;
  pageIndex;
  coppyError=true;
  modalConfig = {
    sige: { sm: 'sm', lg: 'lg' }
  };
  deviceFailureInfo: any;
  constructor(private ngbModal: NgbModal, private failureManagementService: FailureManagementService,
    private dataService: DataService
  ) { }
  data = {
    data: [],
    totalCount: 0,
    eid: '',
    tableName: 'imei',
    serverFilter: true,
    columns: [
      {
        displayName: 'NAME',
        key: 'exceptionName',
        filter: '',
        filterRowEvent: true,
        filterData: []
      },
      {
        displayName: 'Error code',
        key: 'errorCode',
        filter: '',
        filterRowEvent: true,
        filterData: []
      }, {
        displayName: 'Error message',
        key: 'errorMessage',
        filter: '',
        filterRowEvent: true,
        filterData: []
      },
      //  {
      //   displayName: 'Correlation Id',
      //   key: 'correlationId',
      //   filter: '',
      //   filterRowEvent: true,
      //   filterData: []
      // },
      {
        displayName: 'Request type',
        key: 'requestType',
        filter: '',
        filterRowEvent: true,
        filterData: []
      },
      {
        displayName: 'Business name',
        key: 'businessName',
        filter: '',
        filterRowEvent: true,
        filterData: []
      }, {
        displayName: 'Service name',
        key: 'serviceName',
        filter: '',
        filterRowEvent: true,
        filterData: []
      },
      {
        displayName: 'Time stamp',
        key: 'createdDate',
        filter: '',
        filterRowEvent: false,
        filterData: []
      }
     ],

    tableHeader: 'Failure Management',
    tabelTooltip: 'Failure Management',
    tableLabel: '',
    tableActions: {
      search: false,
      add: false,
      view: true,
      delete: true,
      deleteAction: false,
      edit: true,
      showCheck: true,
      aboutTable: true,
      exportToCsv: true,
    }
  };

  ngOnInit() {
    let param = {}
    param['queryParam'] = {
      'rpp': 10,
      'pageNo': 1
    }
    param['bodyParams'] = {}
    this.getPageRecord(param);
  }


  getTotalCount() {
    this.failureManagementService.getTotalCount().subscribe(res => {
      if (res) {
        this.data.totalCount = res.data;
      }
    });

  }

  /** get Paginated data **/
  paramData = {
    'pageNum': 0
  }
  getPaginatedData(event) {
    let param = {}
    delete event.tablename;
    param['queryParam'] = event;
    param['bodyParams'] = this.filterChec ? this.filterObject : {}
    this.paramData = event;
    this.getPageRecord(param);
  }

  /** get recordby Filters data **/

  getPageRecord(param) {
    this.failureManagementService.getrecordbyFilters(param).subscribe(res => {
      if (res) {
        this.paramData = param.queryParam;
        this.data.data = res.data;
        this.getTotalCount()
        this.data.data.forEach(item => {
          item['checked'] = false;
        });
        this.child.filterData = this.data.data;
      }
    });
  }

  getFilterPageRecord(param) {
    this.failureManagementService.getrecordbyFilters(param).subscribe(res => {
      if (res) {

      }
    });
  }

  filterValuePerField(events) {
    let param = {
      'EnumKey': events
    }
    this.failureManagementService.getDistinctValuesOfField(param).subscribe(res => {
      if (res) {
        this.data.columns.forEach(item => {
          if (item.key == events) {
            let filterCheckData = [];
            res.data.forEach((item, key) => {
              if (item) {
                filterCheckData.push({ 'id': key, 'value': item, 'check': false });
              }
            });
            filterCheckData.forEach((innerItem, key) => {
              for (const key in this.filterObject) {
                if (innerItem.value == this.filterObject[key]) {
                  innerItem.check = true;
                }
              }
            });
            item.filterData = filterCheckData;
          }
        });

      }
    });
  }
  viewData: any;
  devicedetails = {};
  flaterObjec = [];
  viewFailureManagement(event,errorjson?) {
    this.viewData = event;
    this.devicedetails = JSON.parse(event.requestRecord)
    if (this.devicedetails) {
      for (const key in this.devicedetails) {

        if (typeof this.devicedetails[key] === "object") {

          if (this.devicedetails[key].length > 0) {
            var extra = this.devicedetails[key][0];
            delete this.devicedetails[key];
          } else {
            var extra = this.devicedetails[key];
          }
          for (const key in extra) {
            this.devicedetails[key] = extra[key];
          }
          delete this.devicedetails[key];
        }
      }
    }
    if(errorjson){
      this.openModal(
        this.failureMgmtErrorJsonModalContent,
        this.modalConfig.sige.sm,
        event
      );
    }else{
      this.failureTableView = true;
    }
    
    
  }


  copyErrorJsonClick(event){
    this.viewFailureManagement(event,true);
  }


  backButton($event) {
    this.pageIndex = this.paramData.pageNum;
    this.refreshList = [];
    this.failureTableView = false;
  }

  checkBoxCheck(event) {
    if (event.checked) {
      this.refreshList.push(event.row.correlationId);
    } else {
      this.refreshList.forEach((item, correlationId) => {
        if (event.row.correlationId == item) {
          this.refreshList.splice(correlationId, 1);
        }
      });
    }
  }

  selectaAllCheck(event) {
    if (event) {
      this.refreshList = [];
      this.data.data.forEach(item => {
        this.refreshList.push(item.correlationId);
        this.data.data.forEach(item => {
          item['checked'] = true;
        });
      });
    } else {
      this.refreshList = [];
      this.data.data.forEach(item => {
        item['checked'] = false;
      });
    }
  }

  reloaderClick() {
    let param = {
      'correlationIds': this.refreshList
    }
    if (!this.filterChec || this.refreshList.length > 0) {
      this.failureManagementService.retryBycorelationId(param).subscribe(res => {
        if (res) {
          this.dataService.broadcast('alert', {
            type: 'success',
            message: this.refreshList.length + ' ' + `Record Resolved Successfully`
          });
          this.refreshList = [];
          this.filterObject = {};
          this.resetData();
        }
      });
    } else {
      let param = {}
      param['queryParam'] = {
        'rpp': 10,
        'pageNo': 1
      }
      param['bodyParams'] = this.filterObject;
      this.failureManagementService.retryByFilter(param).subscribe(res => {
        if (res) {
          this.filterChec = false;
          this.dataService.broadcast('alert', {
            type: 'success',
            message: `Record Resolved Successfully`
          });
          this.refreshList = [];
          this.filterObject = {};
          this.resetData();
        }
      });
    }
  }

  resetData() {
    let param = {}
    param['queryParam'] = {
      'rpp': 10,
      'pageNo': 1
    }
    param['bodyParams'] = {}
    this.getPageRecord(param);

  }

  filterObject = {};
  filterSelecta(event) {
    this.filterChec = event.ckecked;
    if (this.filterChec) {
      this.filterObject[event.key] = event.data.value
    } else {
      delete this.filterObject[event.key];
    }

    let param = {}
    param['queryParam'] = {
      'rpp': 10,
      'pageNo': 1
    }
    param['bodyParams'] = this.filterObject;
    this.getPageRecord(param);
  }

  openModal(content, size, event?) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }

  openFailureMgmtErrorJsonModal(event) {
    this.openModal(
      this.failureMgmtErrorJsonModalContent,
      this.modalConfig.sige.sm,
      event
    );
  }
  closeModel(close) {
    close('Cross click');
  }

  replaceSlash(value) {
    return value;
  }

}

