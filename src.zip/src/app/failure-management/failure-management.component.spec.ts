import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FailureManagementComponent } from './failure-management.component';

describe('FailureManagementComponent', () => {
  let component: FailureManagementComponent;
  let fixture: ComponentFixture<FailureManagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FailureManagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FailureManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
