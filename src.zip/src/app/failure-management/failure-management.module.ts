import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FailureManagementRoutingModule } from './failure-management-routing.module';
import { SharedModule } from './../shared/shared.module';
import { FailureManagementComponent } from './failure-management.component';
import { FailureManagementService } from './failure-management.service';


@NgModule({
  declarations: [FailureManagementComponent],
  imports: [
    CommonModule,
    FailureManagementRoutingModule,
    SharedModule
  ],
  providers: [FailureManagementService],
})
export class FailureManagementModule { }
