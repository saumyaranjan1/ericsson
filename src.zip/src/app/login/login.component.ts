import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LoginService } from './login.service';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { UserService } from './../shared/services/user.service';
import { DataService } from './../shared/services/data.service';
import { EnumsService } from './../shared/services/enums.service';
import { AppConfigService } from '../app-config.service';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { SpinnerService } from '../shared/services/spinner.service';
import { reduce } from 'rxjs/operators';
import { EnterpriseConfigurationsService } from '../data-flow/enterprise-configurations.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.less']
})
export class LoginComponent implements OnInit {
  loginReq = {
    grant_type: 'password',
    username: '',
    password: '',
    evt: 'LS',
    scp: 'api',
    client_id: 'test',
    client_secret: 'test'
  };
  alertSubs: any;
  alert: any;
  partnerIds:any;
  rememberMe = false;
  returnUrl: string;
  partnerId;
  configId;
  msg = 'One time pssword is sent to your mobile.Please enter the 6 digit password here to login.OTP expires in 15 mins.';
  forgetPasswordLinkClicked = false;
  privateVar;
  dashBoardExists = false;
  dashBoardRoute;
  constructor(
    private loginService: LoginService,
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService,
    private dataService: DataService,
    private acs: AppConfigService,
    private cms: CommonMethodsService,
    private modalService: NgbModal,
    private spinnerService: SpinnerService,
    private ngbModal: NgbModal,
    private ecs: EnterpriseConfigurationsService
  ) {}

  ngOnInit() {
    this.privateVar = this.acs.configData['private'];
    this.alertSubs = this.dataService.on('alert', this.displayAlert);
    this.getRememberCredentials();
    const returnUrl = this.route.snapshot.queryParams['returnUrl'] || null;
    if(returnUrl) {
     const returnUrlArray =  returnUrl.split('?');
     this.returnUrl = returnUrlArray[0];
     if(returnUrlArray[1]) {
      const configIdArray = returnUrlArray[1].split('=');
      this.configId = configIdArray[1] || null;
     }
     
    } else {
      this.returnUrl = null;
    }
    this.partnerId = this.route.snapshot.queryParams['partnerId'] || '';
   // this.configId = this.route.snapshot.queryParams['configId'] || '';
    if (this.partnerId) {
      this.dataService.setLocalStorage('partnerId', JSON.stringify(this.partnerId));
    }
    if (this.configId) {
       this.dataService.setLocalStorageAsStringify(
        'partnerBasedConsumerLoginId',
        btoa(this.configId)
      );
    }
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.modalService.dismissAll();
      }
    });
  }

  login() {
   const req = this.cms.deepCopyOfObject(this.loginReq);
   req.username = req.username;
   req.password = this.cms.encryptData(this.loginReq.password, this.acs.configData['encryptKeyForSha256']);
  // const dPassword = this.cms.decryptData(req['password'], this.acs.getEncryptKeyForSha256());
   this.loginService.login(req, this.privateVar).subscribe(
      res => {
        if (res) {
          this.dataService.setLocalStorageAsStringify1(
            'loginMember',
            btoa(this.loginReq.username)
          );
          if (this.rememberMe) {
            const rememberMeObj = {
              username: btoa(this.loginReq.username),
              password: btoa(this.loginReq.password) 
            };
            this.dataService.setBtoaLocalStorage1(
              'rememberMe',
              rememberMeObj
            );
            }
          const logInTime = new Date();
          res.loginTime=Math.floor(logInTime.getTime() / 1000.0);
          //es.expires_in=res.expires_in/2;
          this.dataService.setLocalStorage('user', JSON.stringify(res));
          this.dataService.setLocalStorage('refresh_token', JSON.stringify(res.refresh_token));
          this.dataService.setLocalStorage('login_user_name', JSON.stringify(this.loginReq.username));

          /** use for IOT Data Explorer  */
          // this.dataService.setLocalStorage('update-password', JSON.stringify(true));
          // this.router.navigate(['/main/reference']);
          
          if (!res.lastLoginTime) {
            this.dataService.setLocalStorage('update-password', JSON.stringify(true));
            this.router.navigate(['/main/update-password']);
           } else {
            this.getUserPrivileges();
             //this.getPartnereIds();
            //this.validateIsDirectEnterpriseOrNot();
           // this.router.navigate(['/main/user-onboard']);
          }
        } else {
          this.loginReq.username = '';
          this.loginReq.password = '';
          this.rememberMe = !this.rememberMe;
          this.getRememberCredentials();
        }
      },
      error => {
        this.loginReq.username = '';
        this.loginReq.password = '';
        this.rememberMe = !this.rememberMe;
        this.getRememberCredentials();
      } 
    );
  }
  closeAlert() {
    this.alert = null;
  }

  openModal(content) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: 'sm'
      })
      .result.then(result => {}, reason => {});
  }

  displayAlert = res => {
    this.alert = res;
    setTimeout(() => {
      this.alert = null;
      this.spinnerService.toggleSpinner(0);
    }, 4000);
  }

  rememberMeClick = () => {
    if (!this.rememberMe) {
      this.dataService.removeStorage('rememberMe');
    }
  }

  getRememberCredentials() {
    if (localStorage.getItem('rememberMe')) {
      const rememberMeDetils = this.dataService.getAtobLocalStorage1('rememberMe');
      this.loginReq.username = atob(rememberMeDetils['username']);
      this.loginReq.password = atob(rememberMeDetils['password']);
      this.rememberMe = true;
    }
  }
  previlageAccessError(){
    this.dataService.broadcast('alert', {
      type: 'danger',
      message: `You don't have any module access, Please contact Administrator!`
    });
  }

  getUserPrivileges(sourceOfRequest?) {
    this.loginService.getUserMenus().subscribe(res => {
      if (res.data) {
        this.dataService.setBtoaLocalStorage('role', res.data.name);
        this.dataService.setBtoaLocalStorage('category', res.data.category);
        this.dataService.setBtoaLocalStorage('roleId', res.data.roleId);
        let previlageAccess = [];
        if(res.data.groups) {
          res.data.groups.forEach(item => {
            if(item._id == 'DBOARD') {
              this.dashBoardExists = true;
              this.dashBoardRoute = item._id.toLowerCase();
            }
            if(item.subsequent) {
              item.subsequent.forEach(mod=> {
                if(mod.subsequent) {
                  mod.subsequent.forEach(sub => {
                    previlageAccess.push(sub);
                  });
                } else {
                  previlageAccess.push(mod);
                }
               
              });
            }
          });
        }
        
        this.dataService.setBtoaLocalStorage('previlages', previlageAccess);

          if (previlageAccess.length > 0) {
           if(this.configId && this.returnUrl){
              this.dataService.setLocalStorage('fromLoginScreen', JSON.stringify(true));
              // this.router.navigate(['/main/user-onboard']);
              this.router.navigate([this.returnUrl]);
            } else {
          //  if(sourceOfRequest && sourceOfRequest == 'PBE' ) {
          //  this.router.navigate(['/commingsoon']);
          //   } else {
              if(this.returnUrl){
                this.router.navigate([this.returnUrl]);
               }else{

                /**
                 * Verifying Dash Board Module has the access or not, If they have we are redirecting there
                 */
                 if(this.dashBoardExists) {
                  this.router.navigate(['/main/' + this.dashBoardRoute]);
                 } else {
                  const moduleCode = previlageAccess[0].moduleCode;
                  this.router.navigate(['/main/' + moduleCode.toLowerCase()]);
                 }     
               }
          // }
          }
           } else {
            this.dataService.broadcast('alert', {
              type: 'danger',
              message: `You don't have any module access, Please contact Administrator!`
            });
          }
      }
    });
  }

  forgotPassword(){
    if(this.loginReq.username ==null ||  this.loginReq.username=='' ||  this.loginReq.username == undefined){
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: `Please enter Username to use Forgot Password`
      });
    }
    else{
      if(this.forgetPasswordLinkClicked) {
        this.dataService.broadcast('alert', {
          type: 'danger',
          message: `Mail already sent to your registered emailId, please verify.`
        });
      } else {
        const _req = { 
          loginId: this.loginReq.username,
          passwordType:'portal'      
        };
        this.loginService.forgotPassword(_req).subscribe(
          res => {
            this.forgetPasswordLinkClicked = true;
            this.dataService.broadcast('alert', {
              type: 'success',
              message: res.message
            });
           
          },
          error => {
           
          }
        );
      }

    }
  }
  
  

  getPartnereIds() {
    this.loginService.getPartnerIds().subscribe(res => {
      if (res) {
        this.partnerIds = res;
        this.validateIsDirectEnterpriseOrNot();
      }
    });
  }

  validateIsDirectEnterpriseOrNot() {
     this.loginService.validateIsDirectEnterpriseOrNot(true).subscribe( result => {
      if(result) {
        if( result.sourceOfRequest == 'NPBE') {
          if(result.partnerId) {
            this.dataService.setLocalStorage('partnerId', JSON.stringify(result.partnerId));
            this.dataService.setLocalStorage('loginPartnerId', JSON.stringify(result.partnerId));
          }

          if(result.partnerIds) {
            this.partnerIds.forEach(element => {
              result.partnerIds.forEach(innerElement => {
                if((element.partnerType=="FIXED"  || element.partnerType=="CO") && element.partnerId==innerElement){
                  this.dataService.setLocalStorage('partnerId', JSON.stringify(innerElement))
                  this.dataService.setLocalStorage('loginPartnerId', JSON.stringify(innerElement));
                }
              });
            });
            // result.partnerIds.forEach(partnerId => {
            //   if(partnerId.startsWith('DC')) {
            //     this.dataService.setLocalStorage('partnerId', JSON.stringify(partnerId));
            //   }
            // });
          }
        }
        
        this.dataService.setLocalStorage('hqBpId', JSON.stringify(result.hqBpId));
        this.dataService.setLocalStorage('loginHqBpId', JSON.stringify(result.hqBpId));
        this.dataService.setLocalStorage('partnerName', JSON.stringify(result.hqBpName)); 
        this.dataService.setLocalStorage('admin', JSON.stringify(result.admin));       
        this.dataService.setLocalStorage('sourceOfRequest', JSON.stringify(result.sourceOfRequest));
       // this.dataService.setLocalStorage('svcCode', JSON.stringify(result.userId));
        this.getSvcData();
        this.getUserPrivileges(result.sourceOfRequest);
       
       }
    },error => {
      this.getUserPrivileges();
    } )
  }
  getSvcData() {
    var svcParam = {
      'hqBpId':  this.dataService.getParseFromSession('hqBpId'),
      'partnerIds': [this.dataService.getParseFromSession('partnerId')]
    };

    this.ecs.getSvcData(svcParam).subscribe(result => {
      this.dataService.setLocalStorage('svcCode', JSON.stringify(result[0].svcCode));
    });
  }
 }
