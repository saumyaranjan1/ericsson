import { Injectable } from '@angular/core';
import { InterceptorService } from './../shared/services/interceptor.service';
import { DataService } from '../shared/services/data.service';

@Injectable()
export class LoginService {

  constructor(private interceptor: InterceptorService,
    private dataService: DataService) { }
  login(request, privateVar) {
    request.jioUtils = true;
    return this.interceptor.httpCall('post', privateVar ? 'privateLogin' : 'publicLogin', request, true);
  }

  privileges(request) {
    return this.interceptor.httpCall('get', 'getUserPrivileges', request);
  }

  getAccessScreen() {
    return this.interceptor.httpCall('get', 'aceessScreen');
  }
  getUserPrivileges() {
    return this.interceptor.httpCall('get', 'getUserPrivileges');
  }
  getUserMenus() {
    return this.interceptor.httpCall('get', 'getUserMainMenus');
  }

  forgotPassword(request) {
    return this.interceptor.httpCall('get', 'forgotPassword', request);
  }
  
  validateIsDirectEnterpriseOrNot(donotShowError) {
    const request = {
      email: this.dataService.getAtobLocalStorage('category')=='ADMIN'?this.dataService.getParseAndAtob('loginEmail'):this.dataService.getParseAndAtob('loginMember'),
      jioUtils: true,
      donotShowError: donotShowError
    };
    return this.interceptor.httpCall('get', 'getDirectPartnerInfo', request);
  }

  getPartnerIds() {
    return this.interceptor.httpCall('get', 'getPartnerIds');
  }

}
