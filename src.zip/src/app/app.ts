/**
 * 
 * Structure of the Config JSON file
 * 
 */

export interface IConfigResponse {
    ip: string,
    port: number,
    kibanaUrl: string,
    mangoUrl: string,
    encryptKeyForSha256: string
    maxStremGroupCount: number,
    showSvcCode: boolean,
    provision: boolean,
    private: boolean,
    svcCodes: [],
    getBaseUrl: string,
    maxIdleSessionTime: number
}
