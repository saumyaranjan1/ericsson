import { Injectable } from '@angular/core';
import { InterceptorService } from './../shared/services/interceptor.service';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class TacCodeService {

  constructor(private interceptor: InterceptorService) { }

  
  /**
   * Get Tac Code Details
   */
  getTacCodeDetail() {
    return this.interceptor.httpCall('get', 'getTacCodeDetail');
  }

  /**
   * Get View Data
   */
  getViewData(action) {
    const params = { extraParams: '/' + action };
    return this.interceptor.httpCall('get', 'getTacCodeViewData', params);
  }

  /**
   * Error List
   */
  getErrorData() {
    return this.interceptor.httpCall('get', 'getTacCodeErrorData');
  }

  getDownloadFile(action) {
    const params = { extraParams: '/' + action,responseType : 'blob' };
    return this.interceptor.httpCall('get', 'getTacDownloadFile', params);
  }

  /**
   * Upload File
   */
  uploadFileData(action) {
    return this.interceptor.httpCall('post', 'uploadTacFile', action);
  }

  getHistoryData() {
    return this.interceptor.httpCall('get', 'getHistoryData');
  }
}
