import { Injectable } from '@angular/core';
import { animationFrameScheduler } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TacCodeEnumService {
  public static DATA = {
    data: [],
    columns: [
      {
        displayName: 'Tac Id',
        key: 'tacId',
        filter: ''
      },
      {
        displayName: 'Marketing Name',
        key: 'marketingName',
        filter: ''
      },
      {
        displayName: 'Manufacturer',
        key: 'manufacturer',
        filter: ''
      },
      {
        displayName: 'Allocation Date',
        key: 'allocationDate',
        filter: ''
      },
      {
        displayName: 'Brand Name',
        key: 'brandName',
        filter: ''
      }, {
        displayName: 'Model Name',
        key: 'modelName',
        filter: ''
      }, {
        displayName: 'OS',
        key: 'os',
        filter: ''
      }, {
        displayName: 'Device Type',
        key: 'deviceType',
        filter: ''
      },
    ],
    actions: [
      {
        type: 'view',
        title: 'view'
      }
    ],
    actionsLabel: '',
    tableHeader: 'Tac Code Management',
    refreshHeader: 'Tac Code Management View History',
    refreshValue: "Last Uploaded By : ",
    uploadValue: 'New Upload : None',
    validationError:false,
    tableActions: {
      add: false,
      search: true,
      dropdown: false,
      exportToCsv: true,
      showCheck: false,
      refreshData: true,
      upload: true
    }
  };


  public static HISTORY_DATA = {
    data: [],
    columns: [
      {
        displayName: 'Uploaded BY',
        key: 'createdBy',
        filter: ''
      },
      {
        displayName: 'Uploaded On',
        key: 'createdOn',
        filter: 'dateWithTime'
      },
      {
        displayName: 'Number Of Tac Codes',
        key: 'tacCnt',
        filter: ''
      },
      {
        displayName: 'Uploaded File',
        key: 'downloadkey',
        filter: ''
      },
    ],
    actions: [
      {
        type: 'view',
        title: 'view'
      }
    ],
    actionsLabel: '',
    tableHeader: 'Tac Code Management : History',
    refreshHeader: 'Tac Code Management View History',
    refreshValue: "Last Uploaded By : ",
    tableActions: {
      add: false,
      search: true,
      dropdown: false,
      exportToCsv: true,
      showCheck: false,
      refreshData: false,
      upload: false
    }
  };

  public static ERROR_DATA = {
    data: [],
    columns: [
      {
        displayName: 'Tac Id',
        key: 'tacId',
        filter: ''
      },
      {
        displayName: 'Marketing Name',
        key: 'marketingName',
        filter: ''
      },
      {
        displayName: 'Manufacturer',
        key: 'manufacturer',
        filter: ''
      },
      {
        displayName: 'Allocation Date',
        key: 'allocationDate',
        filter: ''
      },
      {
        displayName: 'Brand Name',
        key: 'brandName',
        filter: ''
      }, {
        displayName: 'Model Name',
        key: 'modelName',
        filter: ''
      }, {
        displayName: 'OS',
        key: 'os',
        filter: ''
      }, {
        displayName: 'Device Type',
        key: 'deviceType',
        filter: ''
      },
    ],
    actions: [
     
    ],
    actionsLabel: '',
    tableHeader: 'Error observed in following tag codes',
    tableActions: {
      add: false,
      search: true,
      dropdown: false,
      exportToCsv: true,
      showCheck: false,
      refreshData: false,
      upload: false
    }
  };


  public static tacCodeCsvHeader =
    'TAC|Marketing Name|Manufacturer|Bands|5G Bands|LPWAN|Allocation Date|Country Code|Fixed Code|Manufacturer Code|Radio Interface|Brand Name|Model Name|Operating System|NFC|Bluetooth|WLAN|Device Type|OEM|Removable UICC|Removable EUICC|NonRemovable UICC|NonRemovable EUICC|Simslot|Imeiquantitysupport|Domain|Label\n';

}
