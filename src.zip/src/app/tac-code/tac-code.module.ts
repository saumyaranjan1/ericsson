import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TacCodeComponent } from './tac-code.component';
import { SharedModule } from '../shared/shared.module';
import { TacCodeRoutingModule } from './tac-code-routing.module';


@NgModule({
  declarations: [TacCodeComponent],
  imports: [
    CommonModule,
    SharedModule,
    TacCodeRoutingModule
  ],
  providers: []
})
export class TacCodeModule { }
