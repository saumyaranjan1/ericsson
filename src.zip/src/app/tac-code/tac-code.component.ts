import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { TacCodeEnumService } from './tac-code-enum.service';
import { TacCodeService } from './tac-code.service';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../shared/services/data.service';
import { HttpEvent, HttpEventType } from '@angular/common/http';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { SpinnerService } from '../shared/services/spinner.service';
import * as jsonURL from "./../../assets/dropdown-json/dropdown.json";

@Component({
  selector: 'app-tac-code',
  templateUrl: './tac-code.component.html',
  styleUrls: ['./tac-code.component.less']
})
export class TacCodeComponent implements OnInit {
  @ViewChild('addTacModalContent', { static: true }) addTacModalContent: ElementRef;
  uploadedFile;
  uploadedFileName;
  uplodBtn = true;
  fileExtension;
  fileSubmitReq;
  tacCodeList = TacCodeEnumService.DATA;
  historyData = TacCodeEnumService.HISTORY_DATA;
  errorData = TacCodeEnumService.ERROR_DATA;
  errorListStatus = false;
  tableHeaderActions = {
    add: true,
    search: true,
    exportToCsv: true,
    dropDown: false
  };
  isView = false;
  isError = false;
  isHistory = false;
  createTacFormGroup: FormGroup;
  event;
  columns = TacCodeEnumService.DATA.columns;
  tableHeader = TacCodeEnumService.DATA.tableHeader;
  actionsObj = {
    actionsLabel: TacCodeEnumService.DATA.actionsLabel,
    actions: TacCodeEnumService.DATA.actions
  };
  hideListTable = false;
  constructor(
    private tcs: TacCodeService,
    private spinnerService: SpinnerService,
    private DataService: DataService,
    private fb: FormBuilder,
    private ngbModal: NgbModal,
  ) { }

  ngOnInit() {
    this.getTacCodeLIst();
    this.getErrorCodeList();
  }

  /**
   * Spinner Start
   */
  spinnerStart() {
    this.spinnerService.toggleSpinner(1);
  }

  /**
  * Spinner End
  */
  spinnerEnd() {
    this.spinnerService.toggleSpinner(0);
  }

  /**
   * Export to csv file
   */
  async exportDataToCsv() {
    this.spinnerService.toggleSpinner(1);
    let csv = TacCodeEnumService.tacCodeCsvHeader;
      if (this.tacCodeList && this.tacCodeList.data && this.tacCodeList.data.length > 0) {
        let csvArray = [];
        csvArray = this.tacCodeList.data;
        csvArray.forEach((row) => {
          csv += row['id'] ? row['id']+"|" : ''+"|";
          csv += row['marketingName'] ? row['marketingName']+"|" : ''+"|";
          csv += row['manufacturer'] ? row['manufacturer']+"|" : ''+"|";
          csv += row['bands'] ?   row['bands'].replace(/,/g, '-')+"|" : ''+"|";
          csv += row['gBand'] ? row['gBand']+"|" : ''+"|";
          csv += row['lpwan'] ? row['lpwan']+"|" : ''+"|";
          csv += row['allocationDate'] ? row['allocationDate']+"|" : ''+"|";
          csv += row['countryCode'] ? row['countryCode']+"|" : ''+"|";
          csv += row['fixedCode'] ? row['fixedCode']+"|" : ''+"|";
          csv += row['manufacturer'] ? row['manufacturer']+"|" : ''+"|";
          csv += row['radioInterface'] ? row['radioInterface']+"|" : ''+"|";
          csv += row['brandName'] ? row['brandName']+"|" : ''+"|";
          csv += row['modelName'] ? row['modelName']+"|" : ''+"|";
          csv += row['os'] ? row['os']+"|" : ''+"|";
          csv += row['nfc'] ? row['nfc']+"|" : ''+"|";
          csv += row['bluetoothCapability'] ? row['bluetoothCapability']+"|" : ''+"|";
          csv += row['wlan'] ? row['wlan']+"|" : ''+"|";
          csv += row['deviceType'] ? row['deviceType']+"|" : ''+"|";
          csv += row['oem'] ? row['oem']+"," : ''+",";
          csv += row['removableSimCard'] ? row['removableSimCard']+"|" : ''+"|";
          csv += row['removableEsim'] ? row['removableEsim']+"|" : ''+"|";
          csv += row['nonRemovableUICC'] ? row['nonRemovableUICC']+"|" : ''+"|";
          csv += row['nonRemovableEUICC'] ? row['nonRemovableEUICC']+"|" : ''+"|";
          csv += row['simSlot'] ? row['simSlot']+"|" : ''+"|";
          csv += row['imeiQuantity'] ? row['imeiQuantity']+"|" : ''+"|";
          csv += row['domain'] ? row['domain']+"|" : ''+"|";
          csv += row['label'] ? row['label']+"|" : '';
          csv += '\n';
        });
      } 
      const hiddenElement = document.createElement('a');
        hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
        hiddenElement.target = '_blank';
        hiddenElement.download = 'tac_code_of_list.csv';
        hiddenElement.click();
        this.spinnerService.toggleSpinner(0);
    }
  

  /**
   * Get Tac Code Data
   */
  getTacCodeLIst() {
    this.spinnerStart();
    let tacCodeData = [];
    const userData = this.DataService.getParseAndAtob(
      'loginMember'
    ).split('@')[0].replace('.', ' ');
    this.tacCodeList.refreshValue = userData ? 'Last Uploaded By : ' + userData : 'Last Uploaded By :';
    this.tacCodeList.uploadValue = 'New Upload : None';
    this.tcs.getTacCodeDetail().subscribe(
      res => {
        this.spinnerEnd();
        if (res) {
          tacCodeData = res.map(data => {
            data.tacId = data.id;
            data.status = data.status;
            return data;
          });
        };
        this.tacCodeList.data = tacCodeData;
      },
      error => {
        this.tacCodeList.data = [];
        this.failureCase(error);
      }
    );
  }

  /**
   * Get Error code list
   */
  getErrorCodeList(){
    this.spinnerStart();
    const userData = this.DataService.getParseAndAtob(
      'loginMember'
    ).split('@')[0].replace('.', ' ');
    this.tcs.getErrorData().subscribe(
      res => {
        this.spinnerEnd();
        if (res && res.length > 0) {
          this.errorListStatus = true;
          this.tacCodeList.uploadValue = '2020/08/08'+'<br />';
          this.tacCodeList.uploadValue += userData ?  'By : '+userData +'<br />': ''+",";
          this.tacCodeList.validationError  = true;
        }else{
          this.errorListStatus = false;
          this.tacCodeList.uploadValue = 'New Upload : None'+'<br />';
          this.tacCodeList.uploadValue += 'By : '+userData ? 'By : '+ userData : '';
          this.tacCodeList.validationError  = false;
        }
      },
      error => {
        this.tacCodeList.uploadValue = 'New Upload : None'+'<br />';
        this.tacCodeList.uploadValue += 'By : '+userData ? 'By : '+ userData : '';
        this.errorListStatus = false;
        this.tacCodeList.validationError  = false;
        this.failureCase(error);
      }
    );
  }

  getErrorData(){
    let errorData = [];
    this.hideTable();
    this.spinnerStart();
    this.isView = false;
    this.isError = true;
    this.isHistory = false;
    const userData = this.DataService.getParseAndAtob(
      'loginMember'
    ).split('@')[0].replace('.', ' ');
    this.tcs.getErrorData().subscribe(res => {
      this.spinnerEnd();
      if (res) {
        errorData = res.map(data => {
          data.tacId = data.id;
          data.downloadkey = data.fileName;
          data.createdBy = userData ? userData : '-';
          return data;
        });
      };
      this.errorData.data = errorData;
    },
      error => {
        this.errorData.data = [];
        this.failureCase(error);
      }
    );
  }

  hideTable() {
    this.hideListTable = !this.hideListTable;
    if (!this.hideListTable) {
      this.isView = false;
      this.isError = false;
      this.isHistory = false;
    }
  }

  getHistoryData() {
    let historyDaya = [];
    this.hideTable();
    this.spinnerStart();
    this.isView = false;
    this.isError = false;
    this.isHistory = true;
    const userData = this.DataService.getParseAndAtob(
      'loginMember'
    ).split('@')[0].replace('.', ' ');
    this.tcs.getHistoryData().subscribe(res => {
      this.spinnerEnd();
      if (res) {
        historyDaya = res.map(data => {
          data.tacId = data.tacId;
          data.downloadkey = data.fileName;
          data.createdBy = userData ? userData : '-';
          return data;
        });
      };
      this.historyData.data = historyDaya;
    },
      error => {
        this.historyData.data = [];
        this.failureCase(error);
      }
    );
  }

  /**
   * View Data
   **/
  viewData(event) {
    this.hideTable();
    this.isView = !this.isView;
    this.isError = false;
    this.isHistory = false;
    this.tcs.getViewData(event.tacId).subscribe(result => {
      this.event = result;
    },
      error => {
        this.event = '';
        this.failureCase(error);
      });
  }

  fileEvent($event) {
    this.uploadedFile = $event.target.files[0];
    this.uploadedFileName = this.uploadedFile.name;
    const dotPos = this.uploadedFile.name.lastIndexOf('.');
    if (this.uploadedFile.name.lastIndexOf('.') > 0) {
      this.fileExtension = this.uploadedFile.name.substring(
        dotPos + 1,
        this.uploadedFile.name.length
      );
    }
    if (this.fileExtension.toLowerCase() === 'csv') {
      this.createTacFormGroup.controls.uploadFile.setValidators([
        Validators.required,
        this.fileSizeValidator(this.uploadedFile)
      ]);
      this.createTacFormGroup.controls.uploadFile.setValue(
        this.uploadedFileName
      );
      this.fileSubmitReq = new FormData();
      this.fileSubmitReq.append('file', this.uploadedFile);
    }
  }


  closeModel(close) {
    close('Cross click');
  }

  submitForm(form, close) {
    if (form.valid) {
      this.uplodBtn = false;
      this.closeModel(close);
      this.spinnerStart();
      this.tcs.uploadFileData(this.fileSubmitReq).subscribe(
        result => {
          this.uplodBtn = true;
          this.spinnerEnd();
          this.DataService.broadcast('alert', {
            type: 'success',
            message: 'Upload successfully'
          });
          this.getTacCodeLIst();
          this.getErrorCodeList();
          this.closeModel(close);
        },
        error => {
          this.uplodBtn = true
          this.fileSubmitReq = new FormData();
          this.fileSubmitReq.append('file', this.uploadedFile);
          this.failureCase(error);
        }
      );
    }
  }

  openAddConfigModal() {
    this.createTacCodeForm();
    this.openModel(this.addTacModalContent, event, 'sm');
  }
  downloadTacFile(event) {
    this.spinnerStart();
    if (event && event.gridId && event.gridId && event.fileName) {
      this.tcs.getDownloadFile(event.gridId).subscribe(result => {
        this.spinnerEnd();
        // It is necessary to create a new blob object with mime-type explicitly set
            // otherwise only Chrome works like it should
            var newBlob = new Blob([result], { type: "application/csv" });

            // IE doesn't allow using a blob object directly as link href
            // instead it is necessary to use msSaveOrOpenBlob
            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                window.navigator.msSaveOrOpenBlob(newBlob);
                return;
            }

            // For other browsers: 
            // Create a link pointing to the ObjectURL containing the blob.
            const data = window.URL.createObjectURL(newBlob);

            var link = document.createElement('a');
            link.href = data;
            link.download = event.fileName;
            // this is necessary as link.click() does not work on the latest firefox
            link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

            setTimeout(function () {
                // For Firefox it is necessary to delay revoking the ObjectURL
                window.URL.revokeObjectURL(data);
                link.remove();
            }, 100);
      },
        error => {
          this.failureCase(error);
        });
    }
  }

  fileSizeValidator(files) {
    return function(control: FormControl) {
      // return (control: AbstractControl): { [key: string]: any } | null => {
      const file = control.value;
      if (file) {
        var path = file.replace(/^.*[\\\/]/, "");
        const fileSize = files.size;
        const fileSizeInKB = Math.round(fileSize / 1024);
        if (fileSizeInKB >= 200000) {
          return {
            fileSizeValidator: true
          };
        } else {
          return null;
        }
      }
      return null;
    };
  }


  createTacCodeForm(event?) {
    this.createTacFormGroup = this.fb.group({
      uploadFile: [event ? event.uploadFile : '', Validators.required],
    })
  }

  openModel(content, event, size) {
    this.ngbModal
      .open(content, {
        windowClass: "jio-modal config-push-popup",
        size: size,
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }


  /** 
  * Failure Case
  **/
  failureCase(error) {
    this.spinnerService.toggleSpinner(0);
    this.DataService.broadcast('alert', {
      type: 'danger',
      message: error && error.error ? error.error.errorDetails : 'Network error please try again'
    });
  }

}
