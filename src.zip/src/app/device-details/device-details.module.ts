import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './../shared/shared.module';
import { DeviceDetailsRoutingModule } from './device-details-routing.module';
import { DeviceDetailsComponent } from './device-details.component';
import { DeviceDetailsService } from './device-details.service';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    DeviceDetailsRoutingModule
  ],
  declarations: [DeviceDetailsComponent],
  providers : [DeviceDetailsService]
})
export class DeviceDetailsModule { }
