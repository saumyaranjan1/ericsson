import { Component, OnInit } from '@angular/core';
import {
  trigger,
  state,
  style,
  animate,
  transition
} from '@angular/animations';
// import { relative } from 'path';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { EnumsService } from '../shared/services/enums.service';
import { DeviceDetailsService } from './device-details.service';

@Component({
  selector: 'app-device-details',
  templateUrl: './device-details.component.html',
  styleUrls: ['./device-details.component.less'],
  animations: [
    trigger('toSearchState', [
      state(
        'default',
        style({
          transform: 'scale(1)'
        })
      ),
      state(
        'search',
        style({
          transform: 'scale(1)',
          'padding-top': '5%'
        })
      ),
      transition('*=>default', animate('300ms')),
      transition('*=>search', animate('3000ms'))
    ])
  ]
})
export class DeviceDetailsComponent implements OnInit {
  dropDownsList = ['imei', 'plmid'];
  toSearchState = 'default';
  formatName = 'SplitWord';
  searchType = '';
  searchValue = '';
  error = '';
  show: Boolean = false;
  
  defaultPlaceHolder = EnumsService.ERROR.DEFAULT_VALUES;
  deviceStrings = EnumsService.DEVICE_STRINGS;
  keys;
  displyDeviceObject;
  searchTypeRequired = false;
  constructor(private cms: CommonMethodsService,
    private deviceDetailsService: DeviceDetailsService,
    ) { }

  ngOnInit() {}

 

  changeState(data: any, searchType) {
    
    if (data === 'default') {
      this.searchType = '';
      this.searchValue = '';
      this.error = '';
      this.toSearchState = data;
    } else {
      this.searchType = searchType;
      
      if (searchType === 'imei') {
        
        if (this.searchValue) {
         
          if (this.cms.isNumber(this.searchValue)) {
            const length = this.cms.findLength(this.searchValue);
            if (length === 15 || length === 16) {
              this.removeError();
              this.getDeviceInfo(data, this.searchValue);
            } else {
              this.error = EnumsService.ERROR.IMEI;
            }
          } else {
            this.error = EnumsService.ERROR.NUMBER;
          }
        } else {
          this.removeError();
        }
      } else {
        if (this.searchValue) {
          if (this.cms.alphaNumeric(this.searchValue)) {
            if (this.searchValue.length <= 17 ) {
              this.getDeviceInfo(data, this.searchValue);
            } else {
              this.error = EnumsService.ERROR.PLMID_LENGTH;
            }
          } else {
            this.error = EnumsService.ERROR.PLMID;
          }
        } else {
          this.removeError();
        }
      }
    }
  }

  backButton($event){
    this.show = false;
  }
  removeError(event?) {
    if (this.searchType) {
      this.searchTypeRequired = false;
      if (this.searchValue) {
        if (event && event.code === 'Enter') {
        } else {
          this.error = '';
        }
      } else {
        this.error = this.defaultPlaceHolder;
      }
    } else {
      this.searchTypeRequired = true;
      this.error = EnumsService.ERROR.IMEI_PLMID;
    }
  }
  removeSelectedData() {
    this.error = '';
    this.searchValue = '';
    this.toSearchState = 'default';
    this.searchTypeRequired = false;
  }


  deviceType(imsi){
    return imsi.substr(6, 1)=='6'? 'NBIOT':'WBIOT'
  }

  getDeviceInfo(data, value) {
    this.toSearchState = 'default';
    const isNumber = this.cms.isNumber(value);
    const obj =
      isNumber && this.searchType === 'imei'
        ? { imei: value }
        : { plmid: value };
   
   this.deviceDetailsService.getDeviceInfo(obj).subscribe((result) => {
        if (result.data) {
          this.show = !this.show;           
         this.displyDeviceObject = this.deviceDetailsService.getDisplayObject(result.data);
         this.keys = Object.keys(this.displyDeviceObject);
         this.toSearchState = data; 
         console.log(this.displyDeviceObject)
      }
    });
  }
}
