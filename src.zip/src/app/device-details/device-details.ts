export interface DeviceDetails {
}
