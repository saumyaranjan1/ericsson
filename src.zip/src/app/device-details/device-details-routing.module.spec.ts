import { DeviceDetailsRoutingModule } from './device-details-routing.module';

describe('DeviceDetailsRoutingModule', () => {
  let deviceDetailsRoutingModule: DeviceDetailsRoutingModule;

  beforeEach(() => {
    deviceDetailsRoutingModule = new DeviceDetailsRoutingModule();
  });

  it('should create an instance', () => {
    expect(deviceDetailsRoutingModule).toBeTruthy();
  });
});
