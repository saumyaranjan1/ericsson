import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';
import { CommonMethodsService } from '../shared/methods/common-methods';

@Injectable({
  providedIn: 'root'
})
export class DeviceDetailsService {

  constructor(private cms: CommonMethodsService,
    private interceptor: InterceptorService) { }

  getDeviceInfo(request) {
    return this.interceptor.httpCall('get', 'deviceInfo', request);
  }
  getDisplayObject(deviceData) {
    if (deviceData['plan'] && typeof deviceData['plan'] === 'object' && deviceData['plan'] !== null) {
      deviceData['planCode'] = deviceData['plan'].code;
      deviceData['planName'] = deviceData['plan'].name;
      deviceData['planDescription'] = deviceData['plan'].description;
      if(deviceData['plan'].startDate){
        deviceData['planStartDate'] = this.cms.getTimeFromEpcohToCsv(deviceData['plan'].startDate);
      }
      else{
        deviceData['planStartDate']='';
      }
      if(deviceData['plan'].endDate){
        deviceData['planEndDate'] = this.cms.getTimeFromEpcohToCsv(deviceData['plan'].endDate);
      }else{
        deviceData['planEndDate']='';
      }
    }
    if (deviceData['deviceData'] && JSON.parse(deviceData['deviceData'])) {
      deviceData['deviceData'] = JSON.parse(deviceData['deviceData']);
      if (typeof deviceData['deviceData'] === 'object' && deviceData['deviceData'] !== null) {
        deviceData['make'] = deviceData['deviceData'].make;
        deviceData['model'] = deviceData['deviceData'].model;
        deviceData['year'] = deviceData['deviceData'].year;
        deviceData['registrationNumber'] = deviceData['deviceData'].registrationNumber;
        deviceData['fuelType'] = deviceData['deviceData'].fuelType;
      }
    }
    const finalOBject = this.cms.deepCopyOfObject(deviceData);
    delete finalOBject.plan;
    delete finalOBject.deviceData;
    return finalOBject;
  }
}
