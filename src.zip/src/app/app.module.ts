import { BrowserModule, Title } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { JwtModule } from '@auth0/angular-jwt';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { APP_INITIALIZER } from '@angular/core';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { SharedModule } from './shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DataService } from './shared/services/data.service';
import { AppConfigService } from './app-config.service';
import { BasicAuthHtppInterceptorService } from './shared/authGuard/basic-auth-htpp-interceptor.service';
 

export function getToken() {
   return sessionStorage.getItem('user') ? sessionStorage.getItem('user')['tkn'] : '';
};

@NgModule({
  declarations: [AppComponent],
  imports: [
    BrowserModule,
    AppRoutingModule,
    JwtModule.forRoot({
      config: {
        tokenGetter: getToken
      }
    }),
    SharedModule,
    BrowserAnimationsModule
  ],
  providers: [
    AppConfigService,
    DataService,
    Title,    
    {
      provide: APP_INITIALIZER,
      useFactory: (config: AppConfigService) => () => config.load(),
      deps: [AppConfigService],
      multi: true
    },
    { provide: HTTP_INTERCEPTORS,
       useClass: BasicAuthHtppInterceptorService,
       multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
