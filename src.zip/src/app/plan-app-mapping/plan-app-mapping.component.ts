import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { IPlanAppFormData } from './plan-app-mapping';
import { PlanAppMappingService } from './plan-app-mapping.service';
import { ApplicationService } from '../application/application.service';
import { EnumsService } from '../shared/services/enums.service';
import { DataService } from '../shared/services/data.service';
import { InlinePagenationTableComponent } from '../shared/components/inline-pagenation-table/inline-pagenation-table.component';
import { UserService } from '../shared/services/user.service';
import { HttpHeaders } from '@angular/common/http';



@Component({
  selector: 'app-plan-app-mapping',
  templateUrl: './plan-app-mapping.component.html',
  styleUrls: ['./plan-app-mapping.component.less']
})
export class PlanAppMappingComponent implements OnInit {
  @ViewChild(InlinePagenationTableComponent, { static: false }) child: InlinePagenationTableComponent;
  @ViewChild('mapPlanAndApp', { static: true }) mapPlanAndApp: ElementRef;
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  mapPlanAndAppForm: FormGroup;
  configModalOptionMode = null;
  modalConfig = {
    create: { headerText: 'Map Plan And App', primeBtnText: 'Map' },
    edit: { headerText: 'Edit Map Plan And App', primeBtnText: 'Update' },
    view: { headerText: 'View of Plan Mapping' },
    sige: { sm: 'sm', lg: 'lg' }
  };
  planAndAppInfo;
  newRowData: any;
  deleatParam: any;
  showParam: any;
  editabelField = false;
  data = {
    data: [],
    columns: [
      {
        displayName: 'plan code',
        key: 'code',
        filter: '',
        input: true,
        dropdown: false,
        textArea: false,
        save: true,
        editvalue: true
      },
      {
        displayName: 'plan mapping name',
        key: 'name',
        filter: '',
        input: true,
        dropdown: false,
        textArea: false,
        save: true,
        editvalue: true
      },
      {
        displayName: 'plan app mapping description',
        key: 'description',
        filter: '',
        input: false,
        dropdown: false,
        textArea: true,
        save: true,
        editvalue: true
      },
      {
        displayName: 'App Name',
        key: 'appName',
        filter: '',
        input: false,
        dropdown: false,
        textArea: false,
        save: true,
        editvalue: true,
        matSelect: true
      }
    ],

    actions: [
      // {
      //   type: 'save',
      //   title: 'Save Label',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'edit',
      //   title: 'Edit Application',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'delete',
      //   title: 'Delete Application',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'times',
      //   title: 'Cancel',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // }
    ],
    actionsLabel: 'Actions',
    tableHeader: 'Plan And Application Mapping',
    tableActions: {
      // search: true,
      // add: true,
      // delete: true,
      // edit: true,
      // save: true,
      // times: true
    }
  };
  appList = [];
  selectedApps = [];
  modelName = [];
  dropdownSettings = EnumsService.MULTI_SELECT_DROPDOWN_OPTIONS;
  actionsArr;
  constructor(private formBuilder: FormBuilder,
    private ngbModal: NgbModal,
    private cms: CommonMethodsService,
    private planAppService: PlanAppMappingService,
    private appService: ApplicationService,
    private userService: UserService,
    private dataService: DataService) { }

  ngOnInit() {
    this.appFormBlock();
    setTimeout(() => {
      this.getPlanAppMapDetails();
      // this.getApplicationDetails();
    });
  }


  appFormBlock(event?) {
    this.selectedApps = [];
    if (event) {
      this.appList.forEach(element => {
        if (event.appList && event.appList.includes(element.id)) {
          this.selectedApps.push(element);
        }
      });
    }
    this.mapPlanAndAppForm = this.formBuilder.group({
      'code': [event ? event.code : null, Validators.required],
      'name': [event ? event.name : null, Validators.required],
      'description': [event ? event.description : null, [Validators.required, Validators.maxLength(1024)]],
      'appList': [event ? this.selectedApps : null, [Validators.required]]
    });
  }
  addMapPlanAndApp(option) {
    this.configModalOptionMode = option.mode;
    this.appFormBlock();
    this.dropdownSettings.disabled = false;
    //this.openModal(this.mapPlanAndApp, this.modalConfig.sige.lg);
  }

  editMapPlanAndApp(event, option) {
    this.configModalOptionMode = option.mode;
    this.appFormBlock(event);
    if (option.mode === 'view') {
      this.mapPlanAndAppForm.disable();
      this.dropdownSettings.disabled = true;
    } else {
      this.dropdownSettings.disabled = false;
    }
    this.openModal(this.mapPlanAndApp, this.modalConfig.sige.lg);
  }

  openModal(content, size, event?) {
    this.showParam = event.name;
    this.planAndAppInfo = event;
    this.deleatParam = event.code
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }

  openDeleteModal(event) {
    this.showParam = event.name;
    this.deleatParam = event.code
    this.openModal(
      this.deleteConfirmModalContent,
      this.modalConfig.sige.sm,
      event
    );
  }

  closeModel(close) {
    close('Cross click');
  }

  submitForm(event) {
    this.createMapAndApp(event.data, event.action);
  }

  applist = []
  singleSeletChange(event) {
    this.applist = [];
    event.row.forEach(element => {
      this.applist.push(element.id);
    });
  }

  createMapAndApp(data, action) {
    // const newArray = [];
    // data.appName.showItem.map(item => {
    //   newArray.push(item.id);
    // });

    var appIds=[]
    this.newRowData.appName.showItem.forEach(element => {
      appIds.push(element.id)
    });
    this.applist=this.applist.length>0?this.applist:appIds;
    const newdata = {
      'code': data.code,
      'name': data.name,
      'description': data.description,
      'appList': this.applist
    }
    const _req = {};
    if (action) {
      _req['url'] = 'planMapRegistration';
      _req['method'] = 'post';
    } else {
      _req['url'] = 'updatePlanMap';
      _req['method'] = 'put';
    }
    this.planAppService.createPlanAppMap(_req, newdata).subscribe(res => {
      if (!action) {
        this.dataService.broadcast('alert', {
          type: 'success',
          message: `Update successfully!`
        });
      } else {
        this.dataService.broadcast('alert', {
          type: 'success',
          message: `Save successfully!`
        });
      }
      this.applist = [];
      this.getPlanAppMapDetails();
      this.child.cancelEdit(data);
      this.child.submit = false;
    });
  }

  getPlanAppMapDetails() {
    this.getActions();
    this.planAppService.getPlanAppMapDetails().subscribe(res => {
      if (res) {
        this.data.data = res;
        this.setId();
        this.child.updateEditCache('notEdit');
        this.getApplicationDetails();
      }
    });
  }
  getActions() {
    const _module = EnumsService.PLAN_APP_UI_API;

    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe(prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

      this.data.tableActions = this.actionsArr;
      this.data.tableActions['search'] = this.actionsArr.headerRights.search;
      this.data.tableActions['add'] = this.actionsArr.headerRights.add;
      this.data.tableActions['delete'] = this.actionsArr.headerRights.delete;
      this.data.actions = this.actionsArr.actionsArray;

    });
  }
  setId() {
    this.data.data.forEach(function (item, key) {
      item["id"] = key;
    });
  }



  getApplicationDetails() {
    this.appService.getApplicationDetails().subscribe(res => {
      if (res) {
        this.appList = [];
        res.map(item => {
          this.appList.push({ id: item.appId, itemName: item.appName, appType: item.appType });
        });
        this.data.data.map((item, key) => {
          this.selectedApps = [];
          this.modelName = [];
          this.appList.map((element, key) => {
            if ((item.appList && item.appList.includes(element.id)) || element.appType=='SYSTEM_DEFAULT') {
              this.selectedApps.push(element);
              this.modelName.push(element.itemName);
             }
          });
          item['appName'] = {};
          item['appName']['showItem'] = this.selectedApps;
          item['appName']['model'] = this.modelName;
          item['appName']['values'] = this.appList;
          item['appName']['multySelect'] = true;
        });

      }
    });
  }


  getnewRowData(event) {
    this.editabelField = false;
    this.newRowData = {
      'code': '',
      'name': '',
      'description': '',
      'appName': {},
      'newRow': true
    };
   
    this.newRowData.appName.values = this.appList;
    this.newRowData.appName.showItem = [];
    this.newRowData.appName.model = [];
    this.appList.map((element, key) => {
      if (element.appType=='SYSTEM_DEFAULT') {
        this.newRowData.appName.showItem.push(element);
        this.newRowData.appName.model.push(element.itemName);
       }
    });
     this.newRowData.appName.multySelect = true;
 
    this.data.data.splice(0, 0, this.newRowData);
    this.child.updateEditCache('edit');
  }


  deleteApp(close) {

    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      body: {
        "planCode": this.deleatParam
      }
    }
    this.planAppService.deletePlanAppMap(options).subscribe((res: any) => {
      this.getPlanAppMapDetails();
      this.closeModel(close);
    });
  }
}


