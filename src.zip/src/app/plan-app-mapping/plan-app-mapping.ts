export interface IPlanAppFormData {
    code: string;
    name: string;
    description: string;
    appName: string;
    appList: {id: string; itemName: string}[];
}
