import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { PlanAppMappingComponent } from './plan-app-mapping.component';

const routes: Routes = [{ path: '', component: PlanAppMappingComponent }];


@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  declarations: [],
  exports : [RouterModule]
})
export class PlanAppMappingRoutingModule { }
