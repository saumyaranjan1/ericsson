import { PlanAppMappingRoutingModule } from './plan-app-mapping-routing.module';

describe('PlanAppMappingRoutingModule', () => {
  let planAppMappingRoutingModule: PlanAppMappingRoutingModule;

  beforeEach(() => {
    planAppMappingRoutingModule = new PlanAppMappingRoutingModule();
  });

  it('should create an instance', () => {
    expect(planAppMappingRoutingModule).toBeTruthy();
  });
});
