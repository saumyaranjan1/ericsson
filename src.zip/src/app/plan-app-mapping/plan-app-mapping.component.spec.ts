import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanAppMappingComponent } from './plan-app-mapping.component';

describe('PlanAppMappingComponent', () => {
  let component: PlanAppMappingComponent;
  let fixture: ComponentFixture<PlanAppMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanAppMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanAppMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
