import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class PlanAppMappingService {

  constructor(private interceptorService: InterceptorService) { }

  getPlanAppMapDetails() {
    return this.interceptorService.httpCall('get', 'getPlanMappingDetails');
  }
  createPlanAppMap(data, request) {
    return this.interceptorService.httpCall(data.method, data.url, request);
  }
  deletePlanAppMap(request) {
    const param = {
      'data': request,
      'isdelete': true
    }
    return this.interceptorService.httpCall('delete', 'deletePlanMap', param);
  }
}
