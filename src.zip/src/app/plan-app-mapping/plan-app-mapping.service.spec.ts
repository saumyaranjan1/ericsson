import { TestBed } from '@angular/core/testing';

import { PlanAppMappingService } from './plan-app-mapping.service';

describe('PlanAppMappingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PlanAppMappingService = TestBed.get(PlanAppMappingService);
    expect(service).toBeTruthy();
  });
});
