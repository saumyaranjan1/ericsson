import { PlanAppMappingModule } from './plan-app-mapping.module';

describe('PlanAppMappingModule', () => {
  let planAppMappingModule: PlanAppMappingModule;

  beforeEach(() => {
    planAppMappingModule = new PlanAppMappingModule();
  });

  it('should create an instance', () => {
    expect(planAppMappingModule).toBeTruthy();
  });
});
