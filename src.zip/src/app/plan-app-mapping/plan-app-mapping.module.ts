import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { PlanAppMappingRoutingModule } from './plan-app-mapping-routing.module';
import { PlanAppMappingComponent } from './plan-app-mapping.component';
import { PlanAppMappingService } from './plan-app-mapping.service';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { ApplicationService } from '../application/application.service';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    PlanAppMappingRoutingModule,
    AngularMultiSelectModule
  ],
  declarations: [PlanAppMappingComponent],
  providers: [PlanAppMappingService, ApplicationService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PlanAppMappingModule { }
