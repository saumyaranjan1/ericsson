import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  ChangeDetectionStrategy,
  ChangeDetectorRef
} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { forkJoin } from 'rxjs';
import { DataService } from './../shared/services/data.service';
import { UserService } from './../shared/services/user.service';
import { EnumsService } from './../shared/services/enums.service';
import { ReferenceService } from './reference.service';

import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { SpinnerService } from '../shared/services/spinner.service';
import { ServerPaginationTableComponent } from 
'../shared/components/server-pagination-table/server-pagination-table.component';


@Component({
  selector: 'app-devices',
  templateUrl: './reference.component.html',
  styleUrls: ['./reference.component.less']
})
export class ReferenceComponent implements OnInit {
  @ViewChild('showExplorerData', { static: false }) showExplorerData: ElementRef;
  @ViewChild(ServerPaginationTableComponent,{ static: false }) child: ServerPaginationTableComponent;

  showtable=true;
  searchType;
  searchIMEI;
  searchData;
  SearchSVC;
  SearchDeviceType;
  showDeviceInput=false;
  enterpriseInput;
  devicetypeInput;
  eventData;
  modalConfig = {
    create: { headerText: 'Create New Partner', primeBtnText: 'Create' },
    edit: { headerText: 'Edit Partner', primeBtnText: 'Update' },
    sige: { sm: 'sm', lg: 'lg' }
  };
  dropDownsList=[{'key': 'imei','value': 'Search with IMEI'},
  {'key': 'svc','value': 'Search with SVC Code'},
  {'key': 'device','value': 'Search with Device Type'}];
  searchValue;
  ngOnInit() {
   }
  constructor(private ngbModal: NgbModal,private referanceService :ReferenceService ) {}
  
   openModal(content: any, size, event?: any) {
     this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        keyboard: false
      })
      .result.then(result => {}, reason => {});
  }

  
  closeModel(close: any) {
    close('Cross click');
  }

  outerHeader=[]
  outerValue=[]
  normalLoops=[];
  extHeader=[];
  extValue=[];
  outerKey;
  extKey;

  viewExplorerData(event){
    let param={
       'id': event.id,
       'eid':  event.eid
     }
     this.referanceService.getEventsdetail(param).subscribe(res=> {
      if(res){
        this.extHeader=[];
        this.extValue=[];
        this.eventData=res;
        this.outerKey='events'
        const extdata=[];
        if(this.eventData.events[0].ext !== null || this.eventData.events[0].ext !== undefined){
          extdata.push( this.eventData.events[0].ext)
          delete  this.eventData.events[0].ext;
        }
        this.normalLoops.push( this.eventData.events[0]);
        this.normalLoops.forEach(item => {
          this.outerHeader = Object.keys(item);
          this.outerValue =  Object["values"](item);
        });
        extdata.forEach(item => {
          if(item){
            this.extHeader = Object.keys(item);
            this.extValue =  Object["values"](item);
          }
         });
        this.eventData= this.eventData.events;
        this.openModal(this.showExplorerData, this.modalConfig.sige.lg);
       }
    });
  }
  getPaginatedData(event){
    this.searchData=[];
    this.searchData.push(this.searchValue);
    const param={
      page:event.pageNum,
      size:event.rpp,
      sortBy:'tms',
      direction:'DESC'
     };
    if(event.tablename=='imei'){
      param['did']= this.searchData;
        this.gaeImeiPageNatioNData(param);
     }else if(event.tablename=='svc'){
       param['svc']= this.searchData;
       this.gaeSvcPageNatioNData(param);
    }else if(event.tablename=='device') {
      param['device']= this.searchData;
      this.getRefDeviceData(param);
    }
  }
 
  gaeImeiPageNatioNData(param){
    this.referanceService.getRefDidData(param).subscribe(res=> {
      if(res){
        this.data.data=res.events;
        this.data.eid=res.eid;
        this.data.data.forEach(item => {
          item['eid']=this.data.eid;
          if( item.evt=='AL'){
            item.evt='Alert'
          }else if(item.evt=='EV'){
            item.evt='Event'
          }else if(item.evt=='GPS'){
            item.evt='Location'
          }
        });
        }
        this.child.filterData=this.data.data;
    });
  }

  gaeSvcPageNatioNData(param){
    this.referanceService.getRefSVCData(param).subscribe(res=> {
      if(res){
       this.svcData.data=res.events;
       this.svcData.eid=res.eid;
       this.svcData.data.forEach(item => {
         if(item.did){
           item['pld']=item.did;
         }
       });
  
         var imei=[];
         this.svcData.data.forEach(item => {
           imei.push(item.pld);
         });
          var imeiList=[...new Set(imei)];
          var filterImeiData=[];
          imeiList.forEach((item,key) => {
            if(item){
             filterImeiData.push({'id':key,'value':item});
            }
             
           });
         this.svcData.columns[0].filterData= filterImeiData;
  
         this.svcData.data.forEach(item => {
         item['eid']=this.svcData.eid;
         if( item.evt=='AL'){
           item.evt='Alert'
         }else if(item.evt=='EV'){
           item.evt='Event'
         }else if(item.evt=='GPS'){
           item.evt='Location'
         }
       });
       }
        this.child.filterData=this.svcData.data;
     });
  }

  changeState(){
    this.searchData=[];
    this.searchData.push(this.searchValue);
    const param={
      page:1,
      size: 10,
      sortBy:'tms',
      direction:'DESC'
     };
    this.showtable=!this.showtable;
    if(this.searchType=='imei'){
      param['did']= this.searchData;
      this.getRefDidData(param);
    }else if(this.searchType=='svc'){
       param['svc']= this.searchData;
       this.getRefSVCData(param);
    }else if(this.searchType=='device') {
      param['device']= this.searchData;
      this.getRefDeviceData(param);
    }
  }

  removeSelectedData(event){
  this.searchValue='';
   if(event==='device'){
    this.showDeviceInput=true;
   }else{
    this.showDeviceInput=false;
   }
  }

  backButton(event){
    this.showtable=true;
    this.searchIMEI=false;
    this.SearchSVC=false;
    this.SearchDeviceType=false;
  }

  data = {
    data: [],
    totalCount:0,
    eid:'',
    tableName:'imei',
    columns: [
      {
        displayName: 'Event Type',
        key: 'evt',
        filter: '',
        filterRowEvent:true,
        filterData:[{'id':0,'value':'Alert','check':false}
        ,{'id':1,'value':'Event','check':false} 
        ,{'id':2,'value':'Location','check':false}],
      },
      {
        displayName: 'Timestamp',
        key: 'tms',
        filter: '',
        filterRowEvent:false
      }
     ],
    
    tableHeader: 'JIO Iot Data Explorer',
    tabelTooltip:'This is the index page of JIO Iot Data Explorer',
    tableLabel:'' ,
    tableActions: {
      search: false,
      add: false,
      view: true,
      delete: true,
      deleteAction:false,
      edit: true,
      showCheck:false,
      aboutTable:true,
      exportToCsv:true
    }
  };

  svcData = {
    data: [],
    totalCount:0,
    eid:'',
    tableName:'svc',
    columns: [
      {
        displayName: 'PLMID/IMEI',
        key: 'pld',
        filter: '',
        filterRowEvent:true,
        filterShow:false,
        filterData:[]
      },
      {
        displayName: 'Event Type',
        key: 'evt',
        filter: '',
        filterRowEvent:true,
        filterShow:false,
        filterData:[{'id':0,'value':'Alert','check':false},
        {'id':1,'value':'Event','check':false}
      ,{'id':2,'value':'Location','check':false}
      ],
      },
      {
        displayName: 'Timestamp',
        key: 'tms',
        filter: '',
        filterRowEvent:false
      }
     ],
    
    tableHeader: 'JIO Iot Data Explorer',
    tabelTooltip:'This is the index page of JIO Iot Data Explorer',
    tableLabel:'',
    tableActions: {
      search: false,
      add: false,
      view: true,
      delete: true,
      deleteAction:false,
      edit: true,
      showCheck:false,
      aboutTable:true,
      exportToCsv:true
    }
  };


  deviceData = {
    data: [],
    totalCount:0,
    eid:'',
    tableName:'device',
    columns: [
      {
        displayName: 'IMEI',
        key: 'did',
        filter: '',
        filterRowEvent:true,
        filterShow:false,
        filterData:[]
      },
      {
        displayName: 'Event Type',
        key: 'evt',
        filter: '',
        filterRowEvent:true,
        filterShow:false,
        filterData:[{'id':0,'value':'Alert','check':false},
        {'id':1,'value':'Event','check':false}
      ,{'id':2,'value':'Location','check':false}
      ],
      },
      {
        displayName: 'Timestamp',
        key: 'tms',
        filter: '',
        filterRowEvent:false
      }
     ],
    
    tableHeader: 'JIO Iot Data Explorer',
    tabelTooltip:'This is the index page of JIO Iot Data Explorer',
    tableLabel:'Device data for SVC Code: SVC_A',
    tableActions: {
      search: false,
      add: false,
      view: true,
      delete: true,
      deleteAction:false,
      edit: true,
      showCheck:false,
      aboutTable:true,
      exportToCsv:true
    }
  };

  exportDataToCsv(event){
    console.log(event);
  }

    clear(){
    this.searchType = '';
    this.searchValue = '';
    this.enterpriseInput='';
    this.devicetypeInput='';
   } 
  getRefDidData(param){
      this.referanceService.getRefDidData(param).subscribe(res=> {
      if(res){
        this.searchIMEI=true;
        this.data.tableLabel='Device data for imei:' + param.did;
        this.data.data=res.events;
        this.data.totalCount=res.totalCount;
        this.data.eid=res.eid;
        this.data.data.forEach(item => {
          item['eid']=this.data.eid;
          if( item.evt=='AL'){
            item.evt='Alert'
          }else if(item.evt=='EV'){
            item.evt='Event'
          }else if(item.evt=='GPS'){
            item.evt='Location'
          }
        });
        }
    });
  }

  getRefSVCData(param){
    this.referanceService.getRefSVCData(param).subscribe(res=> {
     if(res){
      this.SearchSVC=true;
      this.svcData.tableLabel='Device data for SVC Code:' + param.svc;
      this.svcData.data=res.events;
      this.svcData.totalCount=res.totalCount;
      this.svcData.eid=res.eid;

      this.svcData.data.forEach(item => {
        if(item.did){
          item['pld']=item.did;
        }
      });
 
        var imei=[];
        this.svcData.data.forEach(item => {
          imei.push(item.pld);
        });
         var imeiList=[...new Set(imei)];
         var filterImeiData=[];
         imeiList.forEach((item,key) => {
           if(item){
            filterImeiData.push({'id':key,'value':item});
           }
            
          });
        this.svcData.columns[0].filterData= filterImeiData;
 
        this.svcData.data.forEach(item => {
        item['eid']=this.svcData.eid;
        if( item.evt=='AL'){
          item.evt='Alert'
        }else if(item.evt=='EV'){
          item.evt='Event'
        }else if(item.evt=='GPS'){
          item.evt='Location'
        }
      });
      }
   });
  }

  getRefDeviceData(param){
    this.referanceService.getRefDeviceData(param).subscribe(res=> {
     if(res){
      this.SearchDeviceType=true;
       this.deviceData.data = res.events;
       this.deviceData.totalCount=res.totalCount;
      }
   });
  }

}
