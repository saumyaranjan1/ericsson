import { Injectable } from '@angular/core';
import { InterceptorService } from './../shared/services/interceptor.service'
import { DeleteIntercepterService } from '../shared/services/delete-ajax-method.service';

@Injectable()
export class ReferenceService {

  constructor(private interceptor: InterceptorService,
              private deleteIntercepterService: DeleteIntercepterService) { }

    getRefDidData(request) {
      return this.interceptor.httpCall('get', 'getRefDidData',request);
    }

    getRefSVCData(request) {
      
      return this.interceptor.httpCall('get', 'getRefSVCData',request);
    }

    getRefDeviceData(request){
       return this.interceptor.httpCall('get', 'getRefDeviceData',request);
    }

    getEventsdetail(request){
      return this.interceptor.httpCall('get', 'getEventsdetail',request);
   }
}
