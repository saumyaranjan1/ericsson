import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ReferenceComponent } from './reference.component';
import { AggregateviewerComponent } from './aggregateviewer/aggregateviewer.component';
import { DrilldownviewerComponent } from './drilldownviewer/drilldownviewer.component';


const routes: Routes = [{ path: 'iotdataexplorer', component: ReferenceComponent },
                        { path: 'drilldownviewer', component: DrilldownviewerComponent },
                        { path: 'aggregateviewer', component: AggregateviewerComponent }
 ];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReferenceRoutingModule { }
