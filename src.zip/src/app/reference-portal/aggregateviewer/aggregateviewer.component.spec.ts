import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AggregateviewerComponent } from './aggregateviewer.component';

describe('AggregateviewerComponent', () => {
  let component: AggregateviewerComponent;
  let fixture: ComponentFixture<AggregateviewerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AggregateviewerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AggregateviewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
