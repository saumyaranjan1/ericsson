import { Component, OnInit } from '@angular/core';
import { AppConfigService } from 'src/app/app-config.service';

@Component({
  selector: 'app-aggregateviewer',
  templateUrl: './aggregateviewer.component.html',
  styleUrls: ['./aggregateviewer.component.less']
})
export class AggregateviewerComponent implements OnInit {


  mongoUrl: string;

  constructor(private appConfigService: AppConfigService) { }

  ngOnInit() {
    const configData = this.appConfigService;
    this.mongoUrl=configData['mangoUrl'];
    this.aggregatePopup();
  }

  aggregatePopup(){
    window.open( 
    this.mongoUrl, "_blank"); 
   }
}
