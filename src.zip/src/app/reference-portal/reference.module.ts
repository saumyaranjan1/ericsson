import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from './../shared/shared.module';
import { ReferenceRoutingModule } from './reference-routing.module';
import { ReferenceComponent } from './reference.component';
import { ReferenceService } from './reference.service';
import { DrilldownviewerComponent } from './drilldownviewer/drilldownviewer.component';
import { AggregateviewerComponent } from './aggregateviewer/aggregateviewer.component';

@NgModule({
  imports: [
    CommonModule,
    ReferenceRoutingModule,
    SharedModule
  ],
  providers: [ReferenceService],
  declarations: [ReferenceComponent, DrilldownviewerComponent, AggregateviewerComponent]
})
export class ReferenceModule { }
