import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DrilldownviewerComponent } from './drilldownviewer.component';

describe('DrilldownviewerComponent', () => {
  let component: DrilldownviewerComponent;
  let fixture: ComponentFixture<DrilldownviewerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DrilldownviewerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DrilldownviewerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
