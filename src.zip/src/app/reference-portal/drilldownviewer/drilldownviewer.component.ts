import { Component, OnInit } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { ViewChild,Output, EventEmitter,ElementRef, Input } from '@angular/core';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { AppConfigService } from 'src/app/app-config.service';

@Component({
  selector: 'app-drilldownviewer',
  templateUrl: './drilldownviewer.component.html',
  styleUrls: ['./drilldownviewer.component.less']
})
export class DrilldownviewerComponent implements OnInit {
  @ViewChild('kibanaData', { static: false }) kibanaData: ElementRef;

  kibanaUrl: string ;
  urlSafe: SafeResourceUrl;
  constructor( private sanitizer: DomSanitizer,
    private ngbModal: NgbModal ,
    private appConfigService: AppConfigService) {
   }

  modalConfig = {
    create: { headerText: 'Create New Partner', primeBtnText: 'Create' },
    edit: { headerText: 'Edit Partner', primeBtnText: 'Update' },
    sige: { sm: 'sm', lg: 'lg' }
  };
  
   openModal(content: any, size, event?: any) {
    this.ngbModal
     .open(content, {
       windowClass: 'kibana',
       size: size,
       keyboard: false
     })
     .result.then(result => {}, reason => {});
 }
 
  ngOnInit() {
    const configData = this.appConfigService;
    this.kibanaUrl=configData['kibanaUrl'];
  }

  ngAfterViewInit() {
    this.drilDownPopup();
  }

  closeModel(close: any) {
  close('Cross click');
  }
  
   drilDownPopup(){
    this.urlSafe= this.sanitizer.bypassSecurityTrustResourceUrl(this.kibanaUrl);
    this.openModal(this.kibanaData, this.modalConfig.sige.lg);
   }

}
