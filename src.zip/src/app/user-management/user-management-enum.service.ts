import { Injectable } from '@angular/core';
import { EnumsService } from '../shared/services/enums.service';
@Injectable()
export class UserMangmetEnumsService {
  public static userMangmetDisplayData = {
    pushPullList: 'Please choose either one or both',
    category: 'User Type', // Mandaoty and move to first
    dbTables: 'DB Table',
    dbKeyspace: 'DB KeySpace',
    dbUsername: 'DB Username',
    dbPassword: 'DB Password',
    dbRequired: 'Database Related Info',
    ipHostNumber: 'IP Host Number',
    sessionKeyType: 'Session Key Type',
    password: 'Login Password', // Mandatory
    sn: 'SN', // Mandatory
    userName: 'Login Name', // Mandatory
    vendorCode: 'Vendor Code', // mandatory
    status: 'User Status', // Mandoatory for push and pull
    tokenExpiry: 'Auth Token Expiry Time', // optional
    tableRotationReq: 'Table Rotation Req',
    role: 'Role', // Mandatory
    authorizedEnterprises: 'Authorized Enterprises', // optional
    isSharedTokenAccess: 'Shared token access',

    // Push Fileds
    pushApiUrl: 'Push Api Url',
    pushLoginData: 'Push Login Data',
    pushLoginUrl: 'Push Login Url',
    pushLoginPwd: 'Push Login Password',
    authRequired: 'Authentication Req',
    ackApiUrl: 'Push Acknowledment URL', // optional
    pushBackReq: 'Push Back Req',
    pushBackTopic: 'Push Back Topic', // Optional
    accessToken: 'Access Token',
    userRoleId: 'User role id',
    partnerId: 'Partner Id', // optional
    topic: 'Topic',
    retryThreshold: 'Retry Threshold', // Optional

    firstName: 'First Name',
    lastName: 'Last Name',
    manager: 'Manager'
  };
  public static radioButtonList = [
    {
      name: 'Yes',
      value: true
    },
    {
      name: 'No',
      value: false
    }
  ];
  public static radioButtonPushPullList = [
    {
      name: 'Push',
      value: true
    },
    {
      name: 'Pull',
      value: false
    }
  ];
  public static checkBoxPushPullList = [
    {
      name: 'Push',
      value: false
    },
    {
      name: 'Pull',
      value: false
    }
  ];
  public static approvedDataList = {
    data: [],
    columns: [
      {
        displayName: 'User Name',
        key: 'userName',
        filter: '',
        input: true,
        dropdown: false,
        textArea:false,
        singleSelect:false,
        showOnEdit:false,
        editvalue:false
      },
      {
        displayName: 'User type',
        key: 'configTypeSelect',
        filter: 'uppercase',
        input: false,
        dropdown: false,
        textArea:false,
        singleSelect:true,
        showOnEdit:false,
        editvalue:true
      },
      {
        displayName: 'role',
        key: 'roleObj',
        filter: 'uppercase',
        input: false,
        dropdown: false,
        textArea:false,
        singleSelect:true,
        showOnEdit:false,
        editvalue:true
      },
      {
        displayName: 'Status',
        key: 'statusList',
        filter: 'uppercase',
        input: false,
        dropdown: false,
        textArea:false,
        singleSelect:true,
        showOnEdit:false,
        editvalue:true
      },
      {
        displayName: 'firstName',
        key: 'firstName',
        filter: 'uppercase',
        input: true,
        dropdown: false,
        textArea:false,
        singleSelect:false,
        showOnEdit:false,
        editvalue:false,
        isReadOnly:true
      },
      {
        displayName: 'lastName',
        key: 'lastName',
        filter: 'uppercase',
        input: true,
        dropdown: false,
        textArea:false,
        singleSelect:false,
        showOnEdit:false,
        editvalue:false,
        isReadOnly:true,
        isNotRequired:true
      },
      {
        displayName: 'manager name',
        key: 'managerObj',
        filter: 'uppercase',
        input: false,
        dropdown: true,
        textArea:false,
        singleSelect:false,
        showOnEdit:false,
        editvalue:true
      }
    ],
    actions: [ 
      ],
    actionsLabel: 'Actions',
    tableHeader: 'User Management',
    tableActions: {
      search: true,
      add: true,
      delete: true,
      edit: true,
      save: true,
      times: true,
      dropDown:true
    },
    total: 0,
    headerDropdownList: [],
    moduleName: EnumsService.USERMGMT
  };
  public static pendingDataList = {
    data: [],
    columns: [
      {
        displayName: 'User Name',
        key: 'name',
        filter: 'titlecase'
      },
      {
        displayName: 'Vender Code',
        key: 'vendorCode',
        filter: 'uppercase'
      },
      {
        displayName: 'SN',
        key: 'sn',
        filter: 'titlecase'
      }
    ],
    actions: [],
    actionsLabel: 'Actions',
    tableHeader: '',
    tableActions: {}
  };
  public static modelConfig = {
    create: {
      headerText: 'Add User',
      primeBtnText: 'Create',
      secondaryBtnText: 'Submit'
    },
    edit: {
      headerText: 'Edit User',
      primeBtnText: 'Update',
      secondaryBtnText: 'Submit'
    },
    view: { headerText: 'View User', primeBtnText: 'Close' },
    approve: { headerText: 'Approve/Reject User', primeBtnText: 'Close' }
  };
  public static addUserValues = {
    user: {
      dbtables: {
        keyspace: '',
        username: '',
        table: '',
        password: ''
      },
      ip: [''],
      userName: '',
      password: '',
      sn: '',
      status: '',
      tokenexpiry: '',
      tableRotationReq: 'true',
      vendorCode: '',
      authorizedEnterprises: [''],
      isSharedToken: 'true',
      roleId: '',
      categoryId: '',
      comment: '',
      sessionKeyType: ''
    },
    push: {
      partnerId: '',
      topic: [''],
      pushReq: [
        {
          pushLoginUrl: '',
          pushApiUrl: '',
          loginData: '',
          loginPwd: '',
          authReq: 'true',
          pushBackReq: '',
          pushBackTopic: '',
          accessToken: '',
          ackApiUrl: ''
        }
      ],
      retryThreshold: ''
    },
    createdby: '',
    updatedby: ''
  };
  constructor() {}
}
