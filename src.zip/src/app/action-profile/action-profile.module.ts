import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { SharedModule } from '../shared/shared.module';
import { ActionProfileRoutingModule } from './action-profile-routing.module';
import { ActionProfileComponent } from './action-profile.component';
import { ActionProfileService } from './action-profile.service';

@NgModule({
  imports: [
    CommonModule,
    ActionProfileRoutingModule,
    AngularMultiSelectModule,
    SharedModule
  ],
  providers: [ActionProfileService],
  declarations: [ActionProfileComponent]
})
export class ActionProfileModule { }
