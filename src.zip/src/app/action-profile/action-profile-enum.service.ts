import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ActionProfileEnumService {
  public static DATA = {
    data: [],
    columns: [
      {
        displayName: 'Profile Name',
        key: 'name',
        filter: ''
      },
      {
        displayName: 'Profile Type',
        key: 'profileType',
        filter: ''
      },
      {
        displayName: 'Description',
        key: 'description',
        filter: ''
      },
      {
        displayName: 'Version',
        key: 'number',
        filter: ''
      },
      {
        displayName: 'Version Description',
        key: 'versiondescription',
        filter: ''
      },
      {
        displayName: 'Resource Action',
        key: 'action',
        filter: ''
      },
    ],
    actions: [
       {
        type: 'edit',
        title: 'edit'
      },
      {
        type: 'view',
        title: 'view'
      },
      {
        type: 'delete',
        title: 'Delete'
      }
    ],
    actionsLabel: 'Actions',
    tableHeader: 'Action Profile',
    deleteFlag:true,
    showGridCheckBox:true,
     tableActions: {
      add: true,
      search: true,
      dropdown: true
    }
  };

  public static COMPLETED_SAVED_STATUS = 'saved';
  public static NEW_RECORD_STATUS = 'add';
  public static EDIT_SAVED_STATUS = 'edit';
  public static ADD_ACCESSS_STATUS = 'addaction';
}



