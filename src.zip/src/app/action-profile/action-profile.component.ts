import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  ChangeDetectionStrategy
} from '@angular/core';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl,
  FormArray
} from '@angular/forms';
import { ActionProfileService } from './action-profile.service';
import { ActionProfileEnumService } from './action-profile-enum.service';
import { DataService } from '../shared/services/data.service';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { forkJoin } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { SpinnerService } from '../shared/services/spinner.service';
import { HeaderService } from './../main/header/header.service';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';
import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';

@Component({
  selector: 'app-action-profile',
  templateUrl: './action-profile.component.html',
  styleUrls: ['./action-profile.component.less']
})
export class ActionProfileComponent implements OnInit {
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;

  constructor(
    private cms: CommonMethodsService,
    private ngbModal: NgbModal,
    private http: HttpClient,
    public router: Router,
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private aps: ActionProfileService,
    private userService: UserService,
    private SpinnerService: SpinnerService,
    private dataService: DataService,
    private HeaderService: HeaderService
  ) { }
  tableHeader = ActionProfileEnumService.DATA.tableHeader;
  actionProfileForm: FormGroup;
  createNewActionProfileForm: FormGroup;
  errorMessage: string;
  tableHeaderActions = {};
  deleteFlag = ActionProfileEnumService.DATA.deleteFlag;
  showGridCheckBox = ActionProfileEnumService.DATA.showGridCheckBox;
  columns = ActionProfileEnumService.DATA.columns;
  actionsArr: any;
  event;
  headerDropdownList;
  data = {
    page: 1,
    total: 1,
    data: []

  };
  actionsObj = {
    actionsLabel: ActionProfileEnumService.DATA.actionsLabel,
    actions: ActionProfileEnumService.DATA.actions
  };
  hideListTable = false;
  isCreateNew = false;
  isEdit = false;
  isView = false;
  ProfileTypeList = [{ id: "jnops", name: 'Jnops' }, { id: "provisioning", name: 'Provisioning' }];
  scopeList = [{ id: "all", name: 'ALL' }, { id: "limited", name: 'Limited' }, { id: "notApplicable", name: 'Not Applicable' }];
  ActionTypeList = [{ id: "devices", name: 'Devices' }, { id: "apps", name: 'Apps' }, { id: "firmware", name: 'Firmware' }];
  MethodList = [{ id: "POST", name: 'POST' }, { id: "PUT", name: 'PUT' }, { id: "GET", name: 'GET' }, { id: "DELETE", name: 'DELETE' }];
  searchFilter;
  filterSearch = "";
  uriList = [];
  /**
   * Get Initial Data
   **/
  ngOnInit() {
    this.tableHeaderActions['add'] = true;
    this.tableHeaderActions['deleteAction'] = true;
    this.tableHeaderActions['provisionsearch'] = true;
    this.tableHeaderActions['provisiondropDown'] = true;
    this.getDropDownData();
    this.searchFilter = [{ key: 'name', }];
    this.getURLList();
  }
  getURLList() {
    this.aps.getUrlList().subscribe(
      result => {
        this.SpinnerService.toggleSpinner(0);
        if (result && result.items && result.items.length > 0) {
          this.uriList = result.items.map(data => {
            return data;
          });
        }
      },
      error => {
        this.uriList = [];
        this.displayErrorMsg(error);
      }
    );
  }
  createForm() {
    this.actionProfileForm = this.fb.group({
      users: this.fb.array([
        this.fb.group({
          resourceActionType: [null, [Validators.required]],
          scope: [null, [Validators.required]],
          method: [null, [Validators.required]],
          name: [null, [Validators.required, Validators.maxLength(200)]],
          description: [null, [Validators.required, Validators.maxLength(200)]],
          uri: [null, [Validators.required]],
          type: ['add']
        })
      ])
    });
  }

  initUserRow(item?, actionItem?): FormGroup {
    if (item || actionItem) {
      return this.fb.group({
        resourceActionType: [item && item.resourceType ? item.resourceType : null, [Validators.required]],
        scope: [item && item.scope ? item.scope : null, [Validators.required]],
        method: [actionItem && actionItem.apis && actionItem.apis.length > 0 ? actionItem.apis[0].methods : null, [Validators.required]],
        name: [actionItem && actionItem.name ? actionItem.name : null, [Validators.required, Validators.maxLength(200)]],
        description: [actionItem && actionItem.description ? actionItem.description : null, [Validators.required, Validators.maxLength(200)]],
        uri: [actionItem && actionItem.apis && actionItem.apis.length > 0 ? actionItem.apis[0].uri : null, [Validators.required]],
        type: ['saved']
      })
    } else {
      return this.fb.group({
        resourceActionType: [null, [Validators.required]],
        scope: [null, [Validators.required]],
        method: [null, [Validators.required]],
        name: [null, [Validators.required, Validators.maxLength(200)]],
        description: [null, [Validators.required, Validators.maxLength(200)]],
        uri: [null, [Validators.required]],
        type: ['add']
      });

    }


  }

  addNewActionProfile(event) {
    this.isCreateNew = !this.isCreateNew;
    this.isEdit = false;
    this.isView = false;
    this.hideTable();
    this.createProfileFormBlock(event);
  }

  /**
   * Form Group
   */
  createProfileFormBlock(event) {
    this.createNewActionProfileForm = this.fb.group({
      actionsProfileId: [event && event.actionsProfileId ? event.actionsProfileId : ''],
      name: [event && event.name ? event.name : '', Validators.required],
      profileType: [event && event.profileType ? event.profileType : '', Validators.required],
      versionnumber: [event && event.versionnumber ? event.versionnumber : '', Validators.required],
      versiondescription: [event && event.versiondescription ? event.versiondescription : '', Validators.required],
      description: [event && event.description ? event.description : '', Validators.required]
    });
  }

  viewEditActions(event) {
    this.actionProfileForm = this.fb.group({
      users: this.fb.array([])
    });

    this.createAddEditForm(event);
  }

  createAddEditForm(event: any) {
    const usersArray = <FormArray>this.actionProfileForm.controls['users'];
    if (event && event.resourceActions && event.resourceActions.length > 0) {
      event.resourceActions.forEach(item => {
        if (item && item.actions && item.actions.length > 0) {
          item.actions.forEach(actionItem => {
            usersArray.push(this.initUserRow(item, actionItem));
          });
        }
      });
    }
  }

  deleteActionProfile(event) {
    this.event = event;
    this.openModal(this.deleteConfirmModalContent, 'sm');
  }

  openModal(content, size) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal user-onboard',
        size,
        backdrop: 'static',
        keyboard: false
      })
      .result.then(
        result => { },
        reason => { }
      );
  }
  closeModal(close) {
    this.filterSearch = "";
    close('Cross click');
  }

  deleteProfile(close) {
    this.aps.deleteActionProfile(this.event.actionsProfileId).subscribe(result => {
      this.SpinnerService.toggleSpinner(0);
      this.dataService.broadcast('alert', {
        type: 'success',
        message: 'Delete successfully'
      });
      const event = { limit: 10, offset: 0 }
      this.getData(event);
      this.closeModal(close);
    },
      error => {
        this.displayErrorMsg(error);
      });
  }

  submitForm(form, profileActionForm) {
    if (form.valid && (profileActionForm === undefined || profileActionForm == '')) {
      let resourceActions = [];
      const requestParams = {
        "name": form && form.value && form.value.name,
        "description": form && form.value && form.value.description,
        "profileType": form && form.value && form.value.profileType,
        "version": {
          "description": form && form.value && form.value.versiondescription,
          "number": form && form.value && form.value.versionnumber,
        },
        "resourceActions": resourceActions,
        actionsProfileId: form.value.actionsProfileId
      }
      this.SpinnerService.toggleSpinner(1);
      this.aps.addActionProfile(requestParams).subscribe(
        result => {
          this.SpinnerService.toggleSpinner(0);
          this.hideTable();
          let params = { "limit": 10, "offset": 0 };
          this.getData(params);
        },
        error => {
          this.SpinnerService.toggleSpinner(0);
        }
      );
    } else if (form.valid && profileActionForm.valid) {
      let resourceActions = [];
      let uniqueArr = [];
      const response = this.checkActionIsBlankOrNOt();
      if (response) {
        if (profileActionForm && profileActionForm.value && profileActionForm.value.users
          && profileActionForm.value.users.length > 0) {
          profileActionForm.value.users.forEach(element => {
            uniqueArr.push({ 'resourceType': element.resourceActionType, 'scope': element.scope });
          });
          resourceActions = this.removeDuplicates(uniqueArr, 'resourceType');
          resourceActions.forEach(element => {
            element['actions'] = []
            profileActionForm.value.users.forEach(actionItem => {
              if (element.resourceType === actionItem.resourceActionType && element.scope === actionItem.scope) {
                element['actions'].push({
                  name: actionItem.name,
                  description: actionItem.description,
                  apis: [
                    {
                      "description": "",
                      "methods": actionItem.method,
                      "uri": actionItem.uri,
                      "containsPattern": '',
                      "pattern": ""
                    }
                  ]
                })
              }
            });
          });
        }
        const requestParams = {
          "name": form && form.value && form.value.name,
          "description": form && form.value && form.value.description,
          "profileType": form && form.value && form.value.profileType,
          "version": {
            "description": form && form.value && form.value.versiondescription,
            "number": form && form.value && form.value.versionnumber,
          },
          "resourceActions": resourceActions,
          actionsProfileId: form.value.actionsProfileId
        }
        this.SpinnerService.toggleSpinner(1);
        this.aps.addActionProfile(requestParams).subscribe(
          result => {
            this.SpinnerService.toggleSpinner(0);
            this.hideTable();
            let params = { "limit": 10, "offset": 0 };
            this.getData(params);
          },
          error => {
            this.SpinnerService.toggleSpinner(0);
          }
        );
      }
    } else {
      this.cms.validateAllFormFields(form);
    }
  }

  removeUserRow(rowIndex: number): void {
    const usersArray = <FormArray>this.actionProfileForm.controls['users'];
    usersArray.removeAt(rowIndex);
  }

  saveRowData(rowIndex, form) {
    if (form.valid) {
      if (this.actionProfileForm && this.actionProfileForm.controls['users'] && this.actionProfileForm.controls['users']) {
        this.setProfileValue(this.actionProfileForm.controls['users'], form, rowIndex, 'add');
        this.filterSearch = "";
      }
    } else {
      this.cms.validateAllFormFields(form);
    }

  }

  setProfileValue(formControl, form, rowIndex, rowType) {
    Object.keys(formControl.controls).forEach(field => {
      if (rowIndex == field && rowType === 'add') {
        formControl.get(field).setValue({
          resourceActionType: form.value.users[rowIndex].resourceActionType
          , type: ActionProfileEnumService.COMPLETED_SAVED_STATUS,
          scope: form.value.users[rowIndex].scope,
          name: form.value.users[rowIndex].name,
          description: form.value.users[rowIndex].description,
          uri: form.value.users[rowIndex].uri,
          method: form.value.users[rowIndex].method,

        });
        //formControl.get(field).disable();
      }
      if (rowIndex == field && rowType === 'edit') {
        formControl.get(field).setValue({
          resourceActionType: form.value.users[rowIndex].resourceActionType
          , type: ActionProfileEnumService.NEW_RECORD_STATUS,
          scope: form.value.users[rowIndex].scope,
          name: form.value.users[rowIndex].name,
          description: form.value.users[rowIndex].description,
          uri: form.value.users[rowIndex].uri,
          method: form.value.users[rowIndex].method,
        });
        formControl.get(field).enable();
      }
    });
  }


  removeDuplicates(originalArray, prop) {
    var newArray = [];
    var lookupObject = {};
    for (var i in originalArray) {
      lookupObject[originalArray[i][prop]] = originalArray[i];
    }
    for (i in lookupObject) {
      newArray.push(lookupObject[i]);
    }
    return newArray;
  }


  editData(event) {
    if (event) {
      event['versionnumber'] = event.version && event.version.number ? event.version.number : '';
      event['versiondescription'] = event.version && event.version.description ? event.version.description : '';
    }
    this.isCreateNew = false;
    this.isEdit = true;
    this.isView = false;
    this.hideTable();
    this.createProfileFormBlock(event);
    if (event && event.resourceActions) {
      this.viewEditActions(event);
    }
  }

  viewData(event) {
    if (event) {
      event['versionnumber'] = event.version && event.version.number ? event.version.number : '';
      event['versiondescription'] = event.version && event.version.description ? event.version.description : '';
    }
    this.isCreateNew = false;
    this.isEdit = false;
    this.isView = true;
    this.hideTable();
    this.createProfileFormBlock(event);
    if (event && event.resourceActions) {
      this.viewEditActions(event);
    }
  }

  getDropDownData() {
    return new Promise((resolve, reject) => {
      this.http.get('assets/dropdown-json/dropdown.json').subscribe((response: any) => {
        this.headerDropdownList = response.actionProfiledropdown;
        resolve(true);
      });
    });
  }

  getData(obj) {
    let params = { limit: obj.limit, offset: obj.offset };
    this.SpinnerService.toggleSpinner(1);
    let dataList = [];
    this.aps.getActionProfileData(params).subscribe(
      result => {
        this.SpinnerService.toggleSpinner(0);
        if (result && result.items && result.items.length > 0) {
          dataList = result.items.map(data => {
            data.number = data.version && data.version.number ? data.version.number : '';
            data.versiondescription = data.version && data.version.description ? data.version.description : '';
            data.action = data.resourceActions && data.resourceActions.length > 0 ?
              "resource Type = " + data.resourceActions[0].resourceType +
              " scope = " + data.resourceActions[0].scope : '';
            return data;
          });
        }
        this.data = {
          page: obj.page,
          total: result && result.totalCount ? result.totalCount : 0,
          data: dataList
        };
      },
      error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.displayErrorMsg(error);
      }
    );
  }

  getDataBySearch(data) {
    let dataList = [];
    let obj;
    obj = this.aps.getObject(data);
    obj.limit = 10;
    obj.offset = 0;
    this.SpinnerService.toggleSpinner(1);
    this.aps.getActionProfileData(obj).subscribe(
      result => {
        this.SpinnerService.toggleSpinner(0);
        if (result && result.items && result.items.length > 0) {
          dataList = result.items.map(data => {
            data.number = data.version && data.version.number ? data.version.number : '';
            data.versiondescription = data.version && data.version.description ? data.version.description : '';
            data.action = data.resourceActions && data.resourceActions.length > 0 ?
              "resource Type = " + data.resourceActions[0].resourceType +
              " scope = " + data.resourceActions[0].scope : '';
            return data;
          });
        }
        this.data = {
          page: obj.page,
          total: result && result.totalCount ? result.totalCount : 0,
          data: dataList
        };
      },
      error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.displayErrorMsg(error);
      }
    );
  }

  displayErrorMsg(error) {
    this.SpinnerService.toggleSpinner(0);
    this.dataService.broadcast('alert', {
      type: 'danger',
      message: error && error.error && error.error.errorDetails ? error.error.errorDetails :
        error && error.error && error.error.message ? error.error.message : 'Network error please try again'
    });
  }


  hideTable() {
    this.hideListTable = !this.hideListTable;
    if (!this.hideListTable) {
      this.isCreateNew = false;
      this.isEdit = false;
      this.isView = false;
      if (this.actionProfileForm) {
        (<FormArray>this.actionProfileForm.get('users')).clear();
        this.actionProfileForm.reset();
      }
    }
  }


  addNewActionRow(index) {
    const usersArray = <FormArray>this.actionProfileForm.controls['users'];
    const selectedValue = usersArray.value[index];
    const response = this.checkActionIsBlankOrNOt();
    if (response) {
      usersArray.push(this.actionUserRow(selectedValue));
    }
  }

  editRowData(rowIndex, form) {
    if (this.actionProfileForm && this.actionProfileForm.controls['users'] && this.actionProfileForm.controls['users']) {
      this.setProfileValue(this.actionProfileForm.controls['users'], form, rowIndex, 'edit');
    }
  }

  actionUserRow(selectedValue) {
    if (this.actionProfileForm) {
      return this.fb.group({
        resourceActionType: [selectedValue['resourceActionType'], [Validators.required]],
        type: ['addaction'],
        scope: [selectedValue['scope'], [Validators.required]],
        method: [null, [Validators.required]],
        name: [null, [Validators.required, Validators.maxLength(200)]],
        description: [null, [Validators.required, Validators.maxLength(200)]],
        uri: [null, [Validators.required]],
      });
    }
  }

  checkActionIsBlankOrNOt() {
    if (this.actionProfileForm && this.actionProfileForm.value && this.actionProfileForm.value['users']) {
      const checkValueRecord = this.actionProfileForm.value['users'].filter(data => {
        return (data.resourceActionType === null || data.resourceActionType === '' || data.scope === '' || data.scope === null);
      });
      const checkTypeRecord = this.actionProfileForm.value['users'].filter(data => {
        return data.type === ActionProfileEnumService.NEW_RECORD_STATUS || data.type === ActionProfileEnumService.EDIT_SAVED_STATUS
          || data.type === ActionProfileEnumService.ADD_ACCESSS_STATUS;
      });
      if (checkValueRecord && checkValueRecord.length > 0) {
        this.dataService.broadcast('alert', {
          type: 'error',
          message: 'Please fill the details first'
        });
        return false;
      }
      if (checkTypeRecord && checkTypeRecord.length > 0) {
        this.dataService.broadcast('alert', {
          type: 'error',
          message: 'Please Save the record first!'
        });
        return false;
      }
      return true;
    }
  }

  addNewResouceAction() {
    if (this.actionProfileForm) {
      const response = this.checkActionIsBlankOrNOt();
      if (response) {
        const usersArray = <FormArray>this.actionProfileForm.controls['users'];
        usersArray.push(this.initUserRow());
      }
    } else {
      this.createForm();
    }
  }
}
