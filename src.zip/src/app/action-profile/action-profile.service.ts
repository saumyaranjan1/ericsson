import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';

@Injectable()
export class ActionProfileService {

  constructor(private interceptor: InterceptorService) { }
  /**
   * Get Action Profile Data
   */
  getActionProfileData(request) {
    return this.interceptor.httpCall('get', 'getActionProfile', request);
  }
  
  deleteActionProfile(id) {
    let params = {};
    params['extraParams'] = "?id="+id;
    return this.interceptor.httpCallReturn('delete', 'deleteActionProfile', params);

  }

  getUrlList() {
    return this.interceptor.httpCall('get', 'getUrlList');
  }
  addActionProfile(request) {
    if(request.actionsProfileId){
      request['extraParams'] =  "?id="+request.actionsProfileId;
      return this.interceptor.httpCall('patch', 'updateActionProfile', request);
    }else{
      delete request.actionsProfileId;
      return this.interceptor.httpCall('post', 'addActionProfile', request);
    }
    
  }

  getObject(request) {
    const key = request['dropDownValue'].trim();
    const value = request['searchKey'].trim();
    const dataObj = {};
    if (request.dropDownValue.trim() === 'osname') {
      dataObj['platformName'] = new Array(request.searchKey);
    } else if (request.dropDownValue === 'domain') {
      dataObj['domains'] = new Array(request.searchKey);
    } else if (request.dropDownValue.trim() === 'devicemodel') {
      let deviceSpace = request.searchKey.split(" ");
      let deviceName = "";
      let vendorName = "";
      let deviceModalParams = {};
      if (deviceSpace && deviceSpace[0]) {
        deviceName = deviceSpace[0];
      } if (deviceSpace && deviceSpace[1]) {
        vendorName = deviceSpace[1];
      }
      deviceModalParams = { name: vendorName, vendor: deviceName };
      //dataObj['deviceModels'] = new Array(deviceModalParams);
      dataObj['deviceModels'] = request['searchKey'].trim();
    } else {
      dataObj[key] = new Array(value);
    }
    return dataObj;
  }

  
}


