import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RoleManagementAbacComponent } from './role-management-abac.component';
import { RoleManagementAbacRoutingModule } from './role-management-abac-routing.module'
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [RoleManagementAbacComponent],
  imports: [
    CommonModule,
    RoleManagementAbacRoutingModule,
    SharedModule
  ]
})
export class RoleManagementAbacModule { }
