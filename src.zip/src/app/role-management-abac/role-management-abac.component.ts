import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { RoleManagementAbacEnumService } from './role-management-abac-enum.service';
import { RoleManagementAbacService } from './role-management-abac.service'
import { SpinnerService } from '../shared/services/spinner.service';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
import { DataService } from '../shared/services/data.service';
@Component({
  selector: 'app-role-management-abac',
  templateUrl: './role-management-abac.component.html',
  styleUrls: ['./role-management-abac.component.less']
})
export class RoleManagementAbacComponent implements OnInit {
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('deleteGroupConfirmModalContent', { static: true }) deleteGroupConfirmModalContent: ElementRef;
  @ViewChild('deletePreveldgeConfirmModalContent', { static: true }) deletePreveldgeConfirmModalContent: ElementRef;
  @ViewChild('displayImageModalContent', { static: true }) displayImageModalContent: ElementRef;

  showToolTip;
  tabNo = 0;
  showHeader = false;
  showSubChildToolTip;
  event;
  insideIndex = 0;
  insideSubIndex = 0;
  moduleIndex = 0;
  categoryChildArea;
  headerName;
  headerModelName;
  headerMainInsideModelName;
  headerMainModelName;
  addLabelSection;
  addModelLabelSection;
  addInsideModelLabelSection;
  moduleName = [];
  subModules = [];
  showChildToolTip;
  privilegType = 'group'
  addChildUrl = true;
  uploadedFile;
  uploadedFileName;
  fileExtension;
  fileSubmitReq;
  roleCategoriesList
  groupId;
  indexForUrl;
  moduleId;
  createUrlForm: FormGroup;
  webRoleList = ['TRUE', 'FALSE'];
  methods = ['POST', 'GET', 'PUT', 'DELETE', 'PATCH'];
  urlType = ['ENTERPRISE', 'DEVICE', 'NONE'];
  status = ['ACTIVE', 'INACTIVE'];
  isAdd = false;
  isEdit = false;

  constructor(
    private fb: FormBuilder,
    private commonMethodsService: CommonMethodsService,
    private roleManagementAbacService: RoleManagementAbacService,
    private dataService: DataService,
    private ngbModal: NgbModal,
    private SpinnerService: SpinnerService
  ) { }

  ngOnInit() {
    this.getModuleHeader();
    this.getRoleCategories();
  }
  addNewItem() {
    this.showToolTip = !this.showToolTip;
  }

  deleteGroup() {
    this.event = this.moduleName[this.tabNo];
    this.openModel(this.deleteGroupConfirmModalContent, event);
  }
  deletePriviledge(prililedge, module, moduleIndex, type, priviledgeIndex, insideIndex, insideSubIndex?) {
    this.event = prililedge;
    this.event['groupId'] = module.groupId;
    this.event['moduleId'] = module.moduleCode;
    this.moduleIndex = moduleIndex;
    this.privilegType = type;
    this.indexForUrl = priviledgeIndex;
    this.insideIndex = insideIndex;
    this.insideSubIndex = insideSubIndex;
    this.openModel(this.deletePreveldgeConfirmModalContent, event);
  }
  deleteGroupPriviledge(prililedge, index, type) {
    this.event = prililedge;
    this.indexForUrl = index;
    this.privilegType = type;
    this.event['groupId'] = this.moduleName[this.tabNo].id;
    this.openModel(this.deletePreveldgeConfirmModalContent, event);
  }
  deleteUrlChild(event, moduleIndex, type, insideIndex, insideSubIndex?) {
    this.event = event;
    this.privilegType = type;
    this.moduleIndex = moduleIndex;
    this.insideIndex = insideIndex;
    this.insideSubIndex = insideSubIndex
    this.openModel(this.deleteConfirmModalContent, event);
  }
  deleteModule(close) {
    this.roleManagementAbacService.deleteModuleList({ groupId: this.event.groupId, moduleId: this.event.moduleCode }).subscribe(res => {
      this.SpinnerService.toggleSpinner(0);
      if (this.privilegType == 'module') {
        this.subModules.splice(this.moduleIndex, 1);
      } if (this.privilegType == 'insideModule') {
        this.subModules[this.moduleIndex].children.splice(this.insideIndex, 1);
      } if (this.privilegType == 'insideSubModule') {
        this.subModules[this.moduleIndex].children[this.insideIndex].children.splice(this.insideSubIndex, 1);
      }
      this.closeModel(close);
    }, error => {
      this.failureCase(error);
    });
  }

  /**
   * Error Response
   */
  failureCase(error) {
    this.SpinnerService.toggleSpinner(0);
    this.dataService.broadcast('alert', {
      type: 'danger',
      message: error.error && error.error.errorDetails ? error.error.errorDetails : error.error && error.error.error
        ? error.error.error : 'Network error please try again'
    });
  }

  deleteActualGroup(close) {
    this.roleManagementAbacService.deleteGroupList({ groupId: this.event.id }).subscribe(res => {
      this.SpinnerService.toggleSpinner(0);
      this.moduleName.splice(this.tabNo, 1);
      this.tabNo = 0;
      this.addLabelSection = false;
      if (this.moduleName.length > 0) {
        this.showHeader = true;
        this.addLabelSection = false;
        this.addModelLabelSection = false;
        this.addInsideModelLabelSection = false;
        this.groupId = this.moduleName[0].id;
        this.headerName = this.moduleName[0].groupName;
      }
      this.closeModel(close);
    }, error => {
      this.failureCase(error);
    });
  }
  deleteActualPriviledge(close) {
    let params = {};
    if (this.event.moduleId) {
      params = { previlegeId: this.event.privilegeId, groupId: this.event.groupId, moduleId: this.event.moduleId };
    } else {
      params = { previlegeId: this.event.privilegeId, groupId: this.event.groupId };
    }
    this.roleManagementAbacService.deletePriviledgeList(params).subscribe(res => {
      this.SpinnerService.toggleSpinner(0);
      if (this.privilegType == 'group') {
        this.moduleName[this.tabNo]['privileges'].splice(this.indexForUrl, 1);
      } else if (this.privilegType == 'module') {
        this.subModules[this.moduleIndex]['privileges'].splice(this.indexForUrl, 1);
      } else if (this.privilegType == 'insideModule') {
        this.subModules[this.moduleIndex].children[this.insideIndex]['privileges'].splice(this.indexForUrl, 1);
      } else if (this.privilegType == 'insideSubModule') {
        this.subModules[this.moduleIndex].children[this.insideIndex].children[this.insideSubIndex]['privileges'].splice(this.indexForUrl, 1);
      }
      this.closeModel(close);
    }, error => {
      this.failureCase(error);
    });
  }

  closeModel(close) {
    close('Cross click');
  }

  openModel(content, event) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: 'sm',
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }
  addHeader() {
    if (this.moduleName.length > 0) {
      this.addLabelSection = true;
      this.addModelLabelSection = false;
      this.addInsideModelLabelSection = false;
      this.showToolTip = false;
      this.headerModelName = "";
      this.headerMainModelName = "";
      this.isAdd = true;
      this.isEdit = false;
    } else {
      this.showHeader = !this.showHeader;
      this.addLabelSection = true;
      this.addModelLabelSection = false;
      this.addInsideModelLabelSection = false;
      this.showToolTip = false;
      this.isAdd = true;
      this.isEdit = false;
    }
  }
  editGroup() {
    this.isAdd = false;
    this.isEdit = true;
    this.addLabelSection = true;
    this.addModelLabelSection = false;
    this.addInsideModelLabelSection = false;
    this.headerModelName = this.moduleName[this.tabNo].groupName;
  }

  editModel(modelIndex) {
    this.isAdd = false;
    this.isEdit = true;
    this.addLabelSection = false;
    this.headerMainModelName = this.subModules[modelIndex].moduleName;
    this.subModules[modelIndex]['showEdit'] = true;
    this.addModelLabelSection = false;
    this.addInsideModelLabelSection = false;
  }

  editInsideModel(modelIndex, insideModelIndex) {
    this.isAdd = false;
    this.isEdit = true;
    this.moduleIndex = modelIndex;
    this.insideIndex = insideModelIndex;
    this.addLabelSection = false;
    this.addModelLabelSection = false;
    this.addInsideModelLabelSection = true;
    this.subModules[modelIndex].children[insideModelIndex]['showEdit'] = true;
    this.headerMainInsideModelName = this.subModules[modelIndex].children[insideModelIndex].moduleName;
  }

  editInsideSubModel(modelIndex, insideModelIndex, insideSubIndex) {
    this.isAdd = false;
    this.isEdit = true;
    this.moduleIndex = modelIndex;
    this.insideIndex = insideModelIndex;
    this.insideSubIndex = insideSubIndex;
    this.addLabelSection = false;
    this.addModelLabelSection = false;
    this.addInsideModelLabelSection = true;
    this.subModules[modelIndex].children[insideModelIndex].children[insideSubIndex]['showEdit'] = true;
    this.headerMainInsideModelName = this.subModules[modelIndex].children[insideModelIndex].children[insideSubIndex].moduleName;
  }

  closeHeader() {
    this.addLabelSection = false;
    this.addModelLabelSection = false;
    this.addInsideModelLabelSection = false;
    this.headerModelName = "";
    this.headerMainModelName = "";
    this.headerMainInsideModelName = "";
    this.isAdd = false;
    this.isEdit = false;
    this.fileSubmitReq = '';
  }

  closeModuleHeader(module, index) {
    this.addLabelSection = false;
    this.addModelLabelSection = false;
    this.addInsideModelLabelSection = false;
    this.headerModelName = "";
    this.headerMainModelName = "";
    this.headerMainInsideModelName = "";
    this.isAdd = false;
    this.isEdit = false;
    this.subModules[index]['showEdit'] = false;
  }
  closeInsideHeader(insideModule, modelIndex, insideModelIndex) {
    this.addLabelSection = false;
    this.addModelLabelSection = false;
    this.addInsideModelLabelSection = false;
    this.headerModelName = "";
    this.headerMainModelName = "";
    this.headerMainInsideModelName = "";
    this.isAdd = false;
    this.isEdit = false;
    this.subModules[modelIndex].children[insideModelIndex]['showEdit'] = false;
  }

  saveHeader() {
    if (this.headerModelName && this.fileSubmitReq && this.isAdd) {
      this.roleManagementAbacService.addHeaderRole(this.fileSubmitReq, this.headerModelName.trim()).subscribe(res => {
        this.SpinnerService.toggleSpinner(0);
        res['privileges'] = [];
        this.addLabelSection = false;
        this.addModelLabelSection = false;
        this.addInsideModelLabelSection = false;
        this.headerModelName = "";
        this.headerMainModelName = "";
        this.headerMainInsideModelName = "";
        this.moduleName.push(res);
        this.isAdd = false;
        this.isEdit = false;
        this.showHeader = true;
        if (!this.headerName) {
          this.headerName = res.groupName;
        }
        this.moduleName[this.tabNo].groupName = this.headerName;
        //this.moduleName[this.tabNo + 1]['privileges'] = [];
        this.groupId = res.id;
        this.fileSubmitReq = '';
        //this.getModuleHeader();
      }, error => {
        //this.failureCase(error);
      });
    } else if (this.headerModelName && !this.fileSubmitReq && (this.isAdd)) {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: 'Please upload header image'
      });
      return false;
    } else if (this.headerModelName && this.isEdit) {
      this.roleManagementAbacService.updateHeaderRole(this.fileSubmitReq ? this.fileSubmitReq : {}, this.headerModelName, this.moduleName[this.tabNo].id).subscribe(res => {
        this.SpinnerService.toggleSpinner(0);
        this.addLabelSection = false;
        this.addModelLabelSection = false;
        this.addInsideModelLabelSection = false;
        this.headerModelName = "";
        this.headerMainModelName = "";
        this.headerMainInsideModelName = "";
        this.isAdd = false;
        this.isEdit = false;
        this.showHeader = true;
        this.headerName = res.groupName;
        this.moduleName[this.tabNo].groupName = this.headerName;
        this.groupId = res.id;
      }, error => {
        //this.failureCase(error);
      })
    } else {
      return false;
    }

  }

  saveModelHeader(module, modelIndex) {
    if (module.moduleName && !this.fileSubmitReq && (this.isAdd)) {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: 'Please upload module image'
      });
      return false;
    } else {
      this.roleManagementAbacService.updateHeaderModel(this.fileSubmitReq ? this.fileSubmitReq : {}, module.moduleName, this.subModules[modelIndex].moduleCode).subscribe(res => {
        this.SpinnerService.toggleSpinner(0);
        this.headerModelName = "";
        this.headerMainModelName = "";
        this.headerMainInsideModelName = "";
        this.addLabelSection = false;
        this.addModelLabelSection = false;
        this.addInsideModelLabelSection = false;

        this.subModules[modelIndex].moduleName = res.moduleName;
        this.subModules[modelIndex].moduleCode = res.moduleId;
        this.subModules[modelIndex].addheader = false;
        this.subModules[modelIndex].showEdit = false;
        this.isAdd = false;
        this.isEdit = false;
      }, error => {
        //  this.failureCase(error);
      })
    }
  }

  saveInsideModelHeader(insideModule, modelIndex, insideIndex) {
    if (insideModule.moduleName && !this.fileSubmitReq && (this.isAdd)) {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: 'Please upload sub module image'
      });
      return false;
    } else {
      this.roleManagementAbacService.updateHeaderModel(this.fileSubmitReq ? this.fileSubmitReq : {}, insideModule.moduleName, this.subModules[modelIndex].children[insideIndex].moduleCode).subscribe(res => {
        this.SpinnerService.toggleSpinner(0);
        this.subModules[modelIndex].children[insideIndex]['moduleId'] = res.moduleId;
        this.subModules[modelIndex].children[insideIndex]['moduleCode'] = res.moduleId;
        this.subModules[modelIndex].children[insideIndex]['name'] = res.moduleName;
        this.subModules[modelIndex].children[insideIndex]['showEdit'] = false;
        this.subModules[modelIndex].children[insideIndex].addheader = false;
        this.isAdd = false;
        this.isEdit = false;
        this.addLabelSection = false;
        this.addModelLabelSection = false;
        this.addInsideModelLabelSection = false;
      }, error => {
        // this.failureCase(error);
      })
    }
  }


  saveInsideSubModelHeader(insideModule, modelIndex, insideIndex, insideSubIndex) {
    if (insideModule.moduleName && !this.fileSubmitReq && (this.isAdd)) {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: 'Please upload sub module image'
      });
      return false;
    } else {
      this.roleManagementAbacService.updateHeaderModel(this.fileSubmitReq ? this.fileSubmitReq : {}, insideModule.moduleName, this.subModules[modelIndex].children[insideIndex].children[insideSubIndex].moduleCode).subscribe(res => {
        this.SpinnerService.toggleSpinner(0);
        this.subModules[modelIndex].children[insideIndex].children[insideSubIndex]['moduleId'] = res.moduleId;
        this.subModules[modelIndex].children[insideIndex].children[insideSubIndex]['moduleCode'] = res.moduleId;
        this.subModules[modelIndex].children[insideIndex].children[insideSubIndex]['name'] = res.moduleName;
        this.subModules[modelIndex].children[insideIndex].children[insideSubIndex]['showEdit'] = false;
        this.subModules[modelIndex].children[insideIndex].children[insideSubIndex].addheader = false;
        this.isAdd = false;
        this.isEdit = false;
        this.addLabelSection = false;
        this.addModelLabelSection = false;
        this.addInsideModelLabelSection = false;
      }, error => {
        // this.failureCase(error);
      })
    }
  }

  saveChildHeader(moduleIndex, insideModuleIndex) {
    if (this.subModules[moduleIndex].children[insideModuleIndex].moduleName == '' || this.subModules[moduleIndex].children[insideModuleIndex].moduleName == null) {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: 'Please Add Category child'
      });
      return false;
    } else {
      var param = {
        'groupId': this.groupId,
        'childModuleName': this.subModules[moduleIndex].children[insideModuleIndex].moduleName,
        'moduleId': this.subModules[moduleIndex].moduleCode
      }
      this.roleManagementAbacService.addChildHeaderChild(param).subscribe(res => {
        res = res.reverse();
        this.SpinnerService.toggleSpinner(0);
        this.subModules[moduleIndex].children[insideModuleIndex]['moduleId'] = res && res.length > 0 ? res[0].moduleId : '';
        this.subModules[moduleIndex].children[insideModuleIndex]['moduleCode'] = res && res.length > 0 ? res[0].moduleId : '';
        this.subModules[moduleIndex].children[insideModuleIndex]['name'] = res && res.length > 0 ? res[0].moduleName : '';
        this.subModules[moduleIndex].children[insideModuleIndex].addheader = false;
      }, error => {
        this.failureCase(error);
      });

    }
  }

  saveSubChildHeader(moduleIndex, insideModuleIndex, insideSubIndex) {
    if (this.subModules[moduleIndex].children[insideModuleIndex].children[insideSubIndex].moduleName == ''
      || this.subModules[moduleIndex].children[insideModuleIndex].children[insideSubIndex].moduleName == null) {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: 'Please Add Category child'
      });
      return false;
    } else {
      var param = {
        'groupId': this.groupId,
        'childModuleName': this.subModules[moduleIndex].children[insideModuleIndex].children[insideSubIndex].moduleName,
        'moduleId': this.subModules[moduleIndex].children[insideModuleIndex].moduleCode
      }
      this.roleManagementAbacService.addChildHeaderChild(param).subscribe(res => {
        res = res.reverse();
        this.SpinnerService.toggleSpinner(0);
        this.subModules[moduleIndex].children[insideModuleIndex].children[insideSubIndex]['moduleId'] = res && res.length > 0 ? res[0].moduleId : '';
        this.subModules[moduleIndex].children[insideModuleIndex].children[insideSubIndex]['moduleCode'] = res && res.length > 0 ? res[0].moduleId : '';
        this.subModules[moduleIndex].children[insideModuleIndex].children[insideSubIndex]['name'] = res && res.length > 0 ? res[0].moduleName : '';
        this.subModules[moduleIndex].children[insideModuleIndex].children[insideSubIndex].addheader = false;
      }, error => {
        this.failureCase(error);
      });

    }
  }

  saveCategoryHeader(moduleIndex) {
    if (this.subModules[moduleIndex].moduleName == '' || this.subModules[moduleIndex].moduleName == null) {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: 'Please Add Category child'
      });
      return false;
    } else {
      var param = {
        'groupId': this.groupId,
        'moduleName': this.subModules[moduleIndex].moduleName
      }
      this.roleManagementAbacService.addHeaderChild(param).subscribe(res => {
        this.SpinnerService.toggleSpinner(0);
        this.subModules[moduleIndex].moduleCode = res.moduleId;
        this.subModules[moduleIndex].addheader = false;
        this.subModules[moduleIndex].showEdit = false;
      }, error => {
        //   this.failureCase(error);
      });
    }
  }

  closeSubHeaderHeader(index) {
    this.subModules[index].addheader = false;
    this.subModules.splice(index, 1);
  }

  closeInsideSubHeaderHeader(moduleIndex, insideModuleIndex) {
    this.subModules[moduleIndex].children[insideModuleIndex].addheader = false;
    this.subModules[moduleIndex].children.splice(insideModuleIndex, 1);
  }


  fetchNews(event) {
    //var tabNo = parseInt(event.nextId.charAt(event.nextId.length - 1));
    var tabNo = parseInt(event.nextId);
    this.tabNo = tabNo;
    this.isAdd = false;
    this.isEdit = false;
    this.headerName = this.moduleName[tabNo].groupName;
    this.groupId = this.moduleName[tabNo].id;
    this.addLabelSection = false;
    this.addModelLabelSection = false;
    this.addInsideModelLabelSection = false;
    this.headerModelName = "";
    this.headerMainModelName = "";
    this.headerMainInsideModelName = "";
    this.getChildModule();
  }

  getModuleHeader() {
    this.roleManagementAbacService.getGroupList().subscribe(res => {
      this.SpinnerService.toggleSpinner(0);
      res.data.map(value => {
        value['privileges'] = [];
      })
      this.moduleName = res.data
      if (this.moduleName.length > 0) {
        this.showHeader = true;
        this.addLabelSection = false;
        this.addModelLabelSection = false;
        this.addInsideModelLabelSection = false;
        this.headerName = res.data[0].groupName;
        this.groupId = res.data[0].id;
        this.getChildModule();
      }
    }, error => {
      // this.failureCase(error);
    });
  }

  getRoleCategories() {
    this.roleManagementAbacService.getRoleCategories().subscribe(res => {
      this.SpinnerService.toggleSpinner(0);
      this.roleCategoriesList = res.data
    }, error => {
      //  this.failureCase(error);
    });
  }

  getChildModule() {
    this.subModules = [];
    var param = {
      'groupId': this.groupId
    }
    this.roleManagementAbacService.getChildModules(param).subscribe(res => {
      this.SpinnerService.toggleSpinner(0);
      if (res.data.length > 0) {
        res.data.forEach((element, index) => {
          this.subModules.push({
            'groupId': this.groupId,
            'moduleName': element.name,
            'addheader': false,
            'moduleCode': element.code,
            'showEdit': false,
            'privileges': [],
            'children': []
          });
          element['moduleCode'] = element.code;
          this.getChildHeaderData(element, index)
        });
      } else {
        this.subModules = [];
      }
    }, error => {
      //this.failureCase(error);
    });
  }


  fileEvent($event) {
    this.uploadedFile = $event.target.files[0];
    this.uploadedFileName = this.uploadedFile.name;
    const dotPos = this.uploadedFile.name.lastIndexOf('.');
    if (this.uploadedFile.name.lastIndexOf('.') > 0) {
      this.fileExtension = this.uploadedFile.name.substring(
        dotPos + 1,
        this.uploadedFile.name.length
      );
    }
    if (this.fileExtension.toLowerCase() === 'jpg' || this.fileExtension.toLowerCase() === 'jpeg'
      || this.fileExtension.toLowerCase() === 'png') {
      this.fileSubmitReq = new FormData();
      this.fileSubmitReq.append('image', this.uploadedFile);
    }


  }

  addCategoryHeader() {
    this.showChildToolTip = !this.showChildToolTip;
  }

  addSubCategoryHeader(index) {

    this.subModules[index]['showSubChildToolTip'] = !this.subModules[index]['showSubChildToolTip']

    //this.showSubChildToolTip = !this.showSubChildToolTip;
  }

  addInsideSubCategoryHeader(moduleIndex, insideMouleIndex) {
    this.subModules[moduleIndex].children[insideMouleIndex]['showSubChildToolTip'] = !this.subModules[moduleIndex].children[insideMouleIndex]['showSubChildToolTip']
  }

  addInsideSubSubCategoryHeader(moduleIndex, insideMouleIndex, insideSubIndex) {
    this.subModules[moduleIndex].children[insideMouleIndex].children[insideSubIndex]['showSubChildToolTip'] = !this.subModules[moduleIndex].children[insideMouleIndex].children[insideSubIndex]['showSubChildToolTip']
  }

  addCategoryChild() {
    this.categoryChildArea = true;
    this.showChildToolTip = false;
    this.subModules.push({
      'groupId': this.groupId,
      'moduleName': '',
      'addheader': true,
      'moduleCode': '',
      'privileges': [],
      'showEdit': false,
      'children': []
    });
  }

  addModelCategoryChild(index) {
    this.categoryChildArea = true;
    this.showChildToolTip = false;
    this.subModules[index].showSubChildToolTip = false;
    this.subModules[index].children.push({
      'groupId': this.groupId,
      'moduleName': '',
      'addheader': true,
      'moduleCode': '',
      'privileges': [],
      'showEdit': false,
      'children': []
    });
  }

  addInsideCategoryChild(moduleIndex, insideMouleIndex) {
    this.categoryChildArea = true;
    this.showChildToolTip = false;
    this.subModules[moduleIndex].children[insideMouleIndex]['showSubChildToolTip'] = false;
    this.subModules.push({
      'groupId': this.groupId,
      'moduleName': '',
      'addheader': true,
      'moduleCode': '',
      'privileges': [],
      'showEdit': false,
    });
  }
  addInsideSubCategoryChild(moduleIndex, insideMouleIndex) {
    this.categoryChildArea = true;
    this.showChildToolTip = false;
    this.subModules[moduleIndex].children[insideMouleIndex]['showSubChildToolTip'] = false;
    this.subModules[moduleIndex].children[insideMouleIndex]['children'].push({
      'groupId': this.groupId,
      'moduleName': '',
      'addheader': true,
      'moduleCode': '',
      'privileges': [],
      'showEdit': false,
    });
  }

  addUrlChild(module, index, type) {
    this.addChildUrl = false;
    const reg = '(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?';
    this.createUrlForm = this.fb.group({
      header: [this.headerName, Validators.required],
      //child1: [module && module.moduleName ? module.moduleName : null, Validators.required],
      child1: [module && module.moduleName ? module.moduleName : 'Index'],
      privName: [null, Validators.required],
      isWebRole: [null, Validators.required],
      urlType: [null, Validators.required],
      method: [null, Validators.required],
      category: [null, Validators.required],
      status: [null, Validators.required],
      // uri: [null, [Validators.required, Validators.pattern(reg)]]
      uri: [null, Validators.required]
    });
    this.privilegType = type;
    this.moduleId = module && module.moduleCode ? module.moduleCode : '';
    this.indexForUrl = index
  }

  displayImage() {
    this.openModel(this.displayImageModalContent, event);
  }

  editUrlChild(module, prililedgeData, index, type, moduleIndex, insideIndex, insideSubIndex?) {
    this.addChildUrl = false;
    const reg = '(https?://)?([\\da-z.-]+)\\.([a-z.]{2,6})[/\\w .-]*/?';
    this.createUrlForm = this.fb.group({
      header: [this.headerName, Validators.required],
      child1: [module && module.moduleName ? module.moduleName : 'Index', Validators.required],
      privName: [prililedgeData.privName, Validators.required],
      isWebRole: [prililedgeData.isWebRole == true ? 'TRUE' : 'FALSE', Validators.required],
      urlType: [prililedgeData.urlType, Validators.required],
      method: [prililedgeData.method, Validators.required],
      category: [prililedgeData.category, Validators.required],
      status: [prililedgeData.status, Validators.required],
      //uri: [prililedgeData.uri, [Validators.required, Validators.pattern(reg)]],
      uri: [prililedgeData.uri, Validators.required],
      privilegeId: [prililedgeData.privilegeId]
    });
    this.privilegType = type;
    this.moduleId = module && module.moduleCode ? module.moduleCode : '';
    this.indexForUrl = index;
    this.insideIndex = insideIndex;
    this.moduleIndex = moduleIndex;
    this.insideSubIndex = insideSubIndex;
  }

  openClosePriviledgePopup(moduleIndex, index) {
    this.subModules[moduleIndex]['privileges'][index].priviledgeActive = !this.subModules[moduleIndex]['privileges'][index].priviledgeActive;
  }
  openCloseInsidePriviledgePopup(moduleIndex, insideModuleIndex, index) {
    this.subModules[moduleIndex].children[insideModuleIndex]['privileges'][index].priviledgeActive = !this.subModules[moduleIndex].children[insideModuleIndex]['privileges'][index].priviledgeActive;
  }
  openCloseGroupPriviledgePopup(index) {
    this.moduleName[this.tabNo]['privileges'][index].priviledgeActive = !this.moduleName[this.tabNo]['privileges'][index].priviledgeActive;
  }

  getChildHeaderData(module, index) {
    var param = {
      'moduleId': module.moduleCode
    }

    this.roleManagementAbacService.getChildGridList(param).subscribe(res => {
      this.SpinnerService.toggleSpinner(0);
      if (res.privileges && res.privileges.length > 0) {
        res.privileges.map(value => {
          value['prililedge'] = false;
          value['priviledgeActive'] = false;
        })
        this.subModules[index]['privileges'] = res.privileges;
      }
      if (res.children && res.children.length > 0) {
        res.children.map(value => {
          value['addheader'] = false;
          value['groupId'] = this.groupId;
          value['moduleName'] = value.name;
          value['moduleCode'] = value.code;
          value['privileges'] = [];
          value['children'] = [];
          value['showEdit'] = false;
        })
        this.subModules[index]['children'] = res.children;
      }
    }, error => {
      //this.failureCase(error);
    });
  }

  getInsideChildHeaderData(module, moduleIndex, index) {
    var param = {
      'moduleId': module.moduleCode
    }

    this.roleManagementAbacService.getChildGridList(param).subscribe(res => {
      this.SpinnerService.toggleSpinner(0);
      if (res.privileges && res.privileges.length > 0) {
        res.privileges.map(value => {
          value['prililedge'] = false;
          value['priviledgeActive'] = false;
        })
        this.subModules[moduleIndex].children[index]['privileges'] = res.privileges;
      }
      if (res.children && res.children.length > 0) {
        res.children.map(value => {
          value['addheader'] = false;
          value['groupId'] = this.groupId;
          value['moduleName'] = value.name;
          value['moduleCode'] = value.code;
          value['privileges'] = [];
          value['showEdit'] = false;
        })
        this.subModules[moduleIndex].children[index]['children'] = res.children;
      }
    }, error => {
      //this.failureCase(error);
    });
  }

  getSubInsideChildHeaderData(module, moduleIndex, index, insideSubIndex) {
    var param = {
      'moduleId': module.moduleCode
    }

    this.roleManagementAbacService.getChildGridList(param).subscribe(res => {
      this.SpinnerService.toggleSpinner(0);
      if (res.privileges && res.privileges.length > 0) {
        res.privileges.map(value => {
          value['prililedge'] = false;
          value['priviledgeActive'] = false;
        })
        this.subModules[moduleIndex].children[index].children[insideSubIndex]['privileges'] = res.privileges;
      }
      if (res.children && res.children.length > 0) {
        res.children.map(value => {
          value['addheader'] = false;
          value['groupId'] = this.groupId;
          value['moduleName'] = value.name;
          value['moduleCode'] = value.code;
          value['privileges'] = [];
          value['showEdit'] = false;
        })
        this.subModules[moduleIndex].children[index].children[insideSubIndex]['children'] = res.children;
      }
    }, error => {
      //this.failureCase(error);
    });
  }

  getGroupPrivileg() {
    var param = {
      'id': this.moduleName[this.tabNo].id
    }
    this.roleManagementAbacService.getGroupPrivileg(param).subscribe(res => {
      this.SpinnerService.toggleSpinner(0);
      if (res.privileges && res.privileges.length > 0) {
        res.privileges.map(value => {
          value['prililedge'] = false;
          value['priviledgeActive'] = false;
        });
        this.moduleName[this.tabNo]['privileges'] = res.privileges;
      } else {
        this.moduleName[this.tabNo]['privileges'] = [];
      }
    }, error => {
      //this.failureCase(error);
    });
  }


  submitForm() {
    var param = {};
    var header = {};
    if (this.createUrlForm.valid) {
      param['privName'] = this.createUrlForm.controls['privName'].value.trim();
      param['isWebRole'] = this.createUrlForm.controls['isWebRole'].value == "TRUE" ? true : false;
      param['urlType'] = this.createUrlForm.controls['urlType'].value;
      param['method'] = this.createUrlForm.controls['method'].value;
      param['category'] = this.createUrlForm.controls['category'].value;
      param['status'] = this.createUrlForm.controls['status'].value;
      param['uri'] = this.createUrlForm.controls['uri'].value;
      param['isDefault'] = false;
      header['groupId'] = this.groupId;
      header['moduleId'] = this.moduleId;
      header['previlegeId'] = this.createUrlForm.controls['privilegeId'] && this.createUrlForm.controls['privilegeId'].value ?
        this.createUrlForm.controls['privilegeId'].value : '';
      if (this.createUrlForm.controls && this.createUrlForm.controls['privilegeId'] && this.createUrlForm.controls['privilegeId'].value) {
        this.roleManagementAbacService.updateUrlChild(param, header).subscribe(res => {
          this.SpinnerService.toggleSpinner(0);
          this.addChildUrl = true;
          if (this.privilegType == 'group') {
            this.moduleName[this.tabNo].privileges[this.indexForUrl] = res;
          } else if (this.privilegType == 'module') {
            this.subModules[this.moduleIndex].privileges[this.indexForUrl] = res;
          } else if (this.privilegType == 'insideModule') {
            this.subModules[this.moduleIndex].children[this.insideIndex].privileges[this.indexForUrl] = res;
          } else if (this.privilegType == 'insideSubModule') {
            this.subModules[this.moduleIndex].children[this.insideIndex].children[this.insideSubIndex].privileges[this.indexForUrl] = res;
          }
        }, error => {
          //this.failureCase(error);
        });
      } else {
        this.roleManagementAbacService.addUrlChild(param, header).subscribe(res => {
          this.SpinnerService.toggleSpinner(0);
          this.addChildUrl = true;
          if (this.privilegType == 'group') {
          } else if (this.privilegType == 'module') {
          } else if (this.privilegType == 'insideModule') {
          } else if (this.privilegType == 'insideSubModule') {
          }
        }, error => {
          //this.failureCase(error);
        });
      }
    } else {
      this.commonMethodsService.validateAllFormFields(this.createUrlForm);
    }
  }


  cancelClick() {
    this.addChildUrl = true;
  }

  setDefaultURL(module, moduleIndex, event, type, insideIndex, insideSubIndex?) {
    const privilegeData = module.privileges.filter(data => {
      return data.privilegeId === event;
    });
    if (privilegeData && privilegeData.length > 0) {
      this.privilegType = type;
      let params = { isDefault: true, previlegeId: privilegeData[0].privilegeId, groupId: module.groupId };
      this.roleManagementAbacService.setDefaultPriviledgeList(params).subscribe(res => {
        this.SpinnerService.toggleSpinner(0);
        if (this.privilegType == 'module') {
          const index = this.subModules[moduleIndex].privileges.findIndex(x => x.privilegeId === privilegeData[0].privilegeId);
          this.subModules[moduleIndex].privileges[index].isDefault = true;
        } if (this.privilegType == 'insideModule') {
          const index = this.subModules[moduleIndex].children[insideIndex].privileges.findIndex(x => x.privilegeId === privilegeData[0].privilegeId);
          this.subModules[moduleIndex].children[insideIndex].privileges[index].isDefault = true;;
        } if (this.privilegType == 'insideSubModule') {
          const index = this.subModules[moduleIndex].children[insideIndex].children[insideSubIndex].privileges.findIndex(x => x.privilegeId === privilegeData[0].privilegeId);
          this.subModules[moduleIndex].children[insideIndex].children[insideSubIndex].privileges[index].isDefault = true;;
        }
        this.closeModel(close);
      }, error => {
        // this.failureCase(error);
      });
    };
  }

}
