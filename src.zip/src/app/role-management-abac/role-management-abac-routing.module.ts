import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RoleManagementAbacComponent } from './role-management-abac.component';

const routes: Routes = [{ path: '', component: RoleManagementAbacComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RoleManagementAbacRoutingModule { }