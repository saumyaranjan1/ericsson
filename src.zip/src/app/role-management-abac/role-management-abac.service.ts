import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class RoleManagementAbacService {

  constructor(private interceptor: InterceptorService) { }

  addHeaderRole(request, header) {
    request.extraQueryParams = '?groupName' + '=' + header;
    return this.interceptor.httpCall('post', 'addHeaderRole', request);
  }

  deleteModuleList(request) {
    let params = {};
    params['extraParams'] = "?groupId=" + request.groupId + "&moduleId=" + request.moduleId;
    return this.interceptor.httpCallReturn('delete', 'deleteModuleList', params);
  }

  deleteGroupList(request) {
    let params = {};
    params['extraParams'] = "?groupId=" + request.groupId;
    return this.interceptor.httpCallReturn('delete', 'deleteGroupList', params);
  }

  deletePriviledgeList(request) {
    let params = {};
    if (request.moduleId) {
      params['extraParams'] = "?previlegeId=" + request.previlegeId + '&groupId=' + request.groupId + '&moduleId=' + request.moduleId;
    } else {
      params['extraParams'] = "?previlegeId=" + request.previlegeId + '&groupId=' + request.groupId;
    }
    return this.interceptor.httpCallReturn('delete', 'deletePriviledgeList', params);
  }

  setDefaultPriviledgeList(request) {
    let params = { isDefault: request.isDefault };
    params['extraParams'] = "?previlegeId=" + request.previlegeId + '&groupId=' + request.groupId;
    return this.interceptor.httpCall('put', 'setDefaultPriviledgeList', params);
  }

  updateHeaderRole(request, header, id) {
    request.extraParams = '?groupName=' + header + '&id=' + id;
    return this.interceptor.httpCall('put', 'updateHeaderRole', request);
  }

  updateHeaderModel(request, header, id) {
    request.extraParams = '?moduleName=' + header + '&moduleId=' + id;
    return this.interceptor.httpCall('put', 'updateModuleHeaderRole', request);
  }

  addHeaderChild(request) {
    request.extraQueryParams = '?groupId' + '=' + request.groupId + '&moduleName=' + request.moduleName;
    return this.interceptor.httpCall('post', 'addGroupChildHeader', request);
  }

  addChildHeaderChild(request) {
    request.extraQueryParams = '?childModuleName' + '=' + request.childModuleName + '&moduleId=' + request.moduleId + "&groupId=" + request.groupId;
    return this.interceptor.httpCall('post', 'addGroupSubChildHeader', request);
  }

  getGroupList() {
    let params = { size: 500, skip: 0 };
    return this.interceptor.httpCall('get', 'getHeaderGroups', params);
  }

  getChildModules(request) {
    return this.interceptor.httpCall('get', 'getChildModule', request);
  }

  getRoleCategories() {
    return this.interceptor.httpCall('get', 'getRoleCategories');
  }

  addUrlChild(request, header) {
    if (header.moduleId) {
      request.extraQueryParams = '?groupId=' + header.groupId + '&moduleId=' + header.moduleId;
    } else {
      request.extraQueryParams = '?groupId=' + header.groupId;
    }
    return this.interceptor.httpCall('post', 'addUrlChild', request);
  }
  updateUrlChild(request, header) {
    request.extraParams = '?groupId=' + header.groupId + '&previlegeId=' + header.previlegeId;
    return this.interceptor.httpCall('put', 'updateUrlChild', request);
  }

  getChildGridList(request) {
    return this.interceptor.httpCall('get', 'getChildGridList', request);
  }

  getGroupPrivileg(request) {
    return this.interceptor.httpCall('get', 'getGroupPrivileg', request);
  }
}



