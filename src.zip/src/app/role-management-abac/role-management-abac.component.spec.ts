import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RoleManagementAbacComponent } from './role-management-abac.component';

describe('UserManagementAbacComponent', () => {
  let component: RoleManagementAbacComponent;
  let fixture: ComponentFixture<RoleManagementAbacComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RoleManagementAbacComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RoleManagementAbacComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
