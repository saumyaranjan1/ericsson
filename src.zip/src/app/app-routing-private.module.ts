import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SelectivePreloadingStrategyService } from './selective-preloading-strategy.service';
import { AuthGuardService as AuthGuard } from './shared/authGuard/auth-guard.service';
import { LoginAuthGuardService  as LoginAuthGuard } from './shared/authGuard/login-auth-guard.service';

const routes: Routes = [
  {
    path: 'login',
    loadChildren : () => import('./login/login.module').then(mod => mod.LoginModule),
    data: { preload: true, delay: false },
    canActivate: [LoginAuthGuard]
  },
  {
    path: 'main',
    loadChildren : () => import('./main/main.module').then(mod => mod.MainModule),
    canActivate: [AuthGuard],
    data: {
      breadcrumb: { label: 'Main', route: 'main',
      title: 'Main Module' }
    },
  },
  {
    path: 'forgot-password',
    loadChildren : () => import('./forgot-password/forgot-password.module').then(mod => mod.ForgotPasswordModule),
    
  },
  {
    path: 'access-denied',
   loadChildren : () => import('./access-denied/access-denied.module').then(mod => mod.AccessDeniedModule),
   canActivate: [AuthGuard]
   },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: '**', redirectTo: '/access-denied', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes,
    {
      enableTracing: false, // <-- debugging purposes only
      preloadingStrategy: SelectivePreloadingStrategyService,
      useHash: true
    }
    )],
  exports: [RouterModule]
})
export class AppRoutingModule {
 
}
