import { TestBed } from '@angular/core/testing';

import { ConfigPushService } from './config-push.service';

describe('ConfigPushService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ConfigPushService = TestBed.get(ConfigPushService);
    expect(service).toBeTruthy();
  });
});
