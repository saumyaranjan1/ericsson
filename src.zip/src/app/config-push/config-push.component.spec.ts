import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConfigPushComponent } from './config-push.component';

describe('ConfigPushComponent', () => {
  let component: ConfigPushComponent;
  let fixture: ComponentFixture<ConfigPushComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConfigPushComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConfigPushComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
