import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { ConfigPushEnumService } from './config-push-enum.service';
import { ConfigPushService } from './config-push.service';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl
} from '@angular/forms';
import { DynamicFormComponent } from '../shared/components/dynamic-form/dynamic-form.component';
import { VendorService } from './../vendor/vendor.service';
import { forkJoin } from 'rxjs';
import { SpinnerService } from '../shared/services/spinner.service';
import { DataService } from '../shared/services/data.service';
import { SoftwareManagementService } from './../software-management/software-management.service';
import { CommonMethodsService } from '../shared/methods/common-methods';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';
import { HeaderService } from './../main/header/header.service';
import { URLSearchParams } from 'url';
import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';
import { HostListener } from '@angular/core';


@Component({
  selector: 'app-config-push',
  templateUrl: './config-push.component.html',
  styleUrls: ['./config-push.component.less']
})
export class ConfigPushComponent implements OnInit {
  @ViewChild('configModalContent', { static: true }) configModalContent: ElementRef;
  @ViewChild('addConfigModalContent', { static: true }) addConfigModalContent: ElementRef;
  @ViewChild('configProfileNameChangeModalContent', { static: true }) configProfileNameChangeModalContent: ElementRef;
  @ViewChild('configInstallModalContent', { static: true }) configInstallModalContent: ElementRef;
  @ViewChild('selectDevicesModalContent', { static: true }) selectDevicesModalContent: ElementRef;
  @ViewChild('selectEnterpriseModalContent', { static: true }) selectEnterpriseModalContent: ElementRef;
  @ViewChild('DynamicFormComponent', { static: false }) DynamicFormComponent: ElementRef;
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  @HostListener('window:scroll', ['$event'])

  columns = ConfigPushEnumService.DATA.columns;
  deleteFlag = ConfigPushEnumService.DATA.deleteIcon;
  showGridCheckBox = ConfigPushEnumService.DATA.showGridCheckBox;
  deviceModalsColumns = ConfigPushEnumService.DEVICE_MODELS_COLUMNS;
  headerDropdownList;
  domainInfo = [];
  pageSize = 1;
  selectedEnterpriseList = [];
  selectedValue;
  actionsObj = {
    actionsLabel: ConfigPushEnumService.DATA.actionsLabel,
    actions: ConfigPushEnumService.DATA.actions
  };
  diffDays;
  scheduleType = false;
  event;
  itemList = [];
  selectedItems = [];
  //today's date   
  todayDate: Date = new Date();
  selectAllDevices;
  notSelectAnyDevices;
  deviceModelsListCount;
  deviceModelsList = [];
  selectedDeviceModal = [];
  tableHeader = ConfigPushEnumService.DATA.tableHeader;
  zones;
  startTime = '';
  endTime = '';

  selectedDeviceIds = [];
  deviceModelView = true;
  currentPageOfDeviceModal = 1;
  installModels;
  selectedDevicesCount = 0;
  tableHeaderActions = {
    add: true,
    provisionsearch: true,
    exportToCsv: false,
    provisiondropDown: true
  }
  data = {
    page: 1,
    total: 1,
    data: []
  };
  configModalOptionMode = null;
  modalConfig = {
    create: { headerText: 'New Profile', primeBtnText: 'Save' },
    edit: { headerText: 'Edit Config', primeBtnText: 'Save' },
    view: { headerText: 'View Config', primeBtnText: 'Update' }
  };
  domainParams;
  showEnterpriseList = false;
  configData;
  viewenterpriseIds = []; //View enterprise ID
  enterpriseIdsArray = []; //EnterPrise Dropdown
  installSoftwareDetails;
  installSoftwareForm: FormGroup;
  dynamicData;
  deleteConfigData;
  filterSearch: any;
  searchFilter: any;
  configureData;
  configAllDetails;
  deviceModelsView = '';
  createConfigFormGroup: FormGroup;
  configureValue = '';
  targetDevices;
  targetDevicesList = ['All', 'By Domain', 'By Device Group', 'By Device'];
  serverIntiatedSelected: string;
  serverIntiatedList: string[] = ['None', 'Immediate', 'Urgent (cancel running operations)', 'Scheduled'];
  foods = [
    { value: 'steak-0', viewValue: 'Steak' },
    { value: 'pizza-1', viewValue: 'Pizza' },
    { value: 'tacos-2', viewValue: 'Tacos' }
  ];
  installType;
  domainList = [
    {
      name: 'Domain1',
      showChild: false,
      childList: [
        {
          name: 'Model 1'
        },
        {
          name: 'Model 2'
        }
      ]
    },
    {
      name: 'Domain2',
      showChild: false,
      childList: [
        {
          name: 'Model 3'
        },
        {
          name: 'Model 4'
        }
      ]
    },
    {
      name: 'Domain 3',
      showChild: false,
      childList: [
        {
          name: 'Model 5'
        },
        {
          name: 'Model 6'
        }
      ]
    }
  ];
  selectedDeviceNames = [];
  actionsArr: any;
  constructor(private cps: ConfigPushService,
    private ngbModal: NgbModal,
    public router: Router,
    public vendorService: VendorService,
    private fb: FormBuilder,
    private SpinnerService: SpinnerService,
    private DataService: DataService,
    private sms: SoftwareManagementService,
    private userService: UserService,
    private cms: CommonMethodsService,
    private http: HttpClient,
    private HeaderService: HeaderService,
    private dataService: DataService) { }

  ngOnInit() {
    this.domainParams = this.HeaderService.getSelectedDomain();
    this.getDomainInfo();
    this.getDropDownData();
    this.searchFilter = [{ key: 'hqBpName', }];
  }

  setStartTime(event) {
    this.startTime = event;
  }

  setEndTime(event) {
    this.endTime = event;
  }

  changeDomain(event) {
    let domainValue;
    const domainData = this.domainInfo.filter(data => {
      return data.id === event.value;
    });
    if (domainData && domainData.length > 0) {
      domainValue = { id: domainData[0].id, name: domainData[0].name };
      this.domainParams = { id: domainData[0].id, name: domainData[0].name };
    }
    this.HeaderService.setDomain(domainValue);
    let params = { "limit": 10, "offset": 0, domain: this.domainParams };
    this.getData(params);
  }


  getDomainInfo() {
    this.HeaderService.getDomainInfo().subscribe(result => {
      let domainData = [];
      if (result) {
        domainData = result;
        if (domainData && domainData.length > 0) {
          const selectedDomain = this.HeaderService.getSelectedDomain();
          if (selectedDomain && selectedDomain.id) {
            this.selectedValue = selectedDomain.id;
            this.domainParams = { name: selectedDomain.name, id: selectedDomain.id }
          } else {
            const deviceData = { id: domainData[0].domainId, name: domainData[0].domainName };
            this.HeaderService.setToStorage('domain', deviceData);
            this.selectedValue = domainData[0].domainId;
            this.domainParams = { name: domainData[0].domainName, id: domainData[0].domainId }
          }
          domainData.forEach(value => {
            this.domainInfo.push({ id: value.domainId, name: value.domainName });
          });
        }
      }
    }, error => {
    });
  }

  /**
   * Get Actions for FirmWare module
   */

  getActions() {
    const _module = EnumsService.PSCONF;
    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe(prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

      const actionsArray = this.actionsArr.actionsArray.filter((obj) => {
        return (
          obj.disableIconProp !== false &&
          obj.type !== 'add'
        );
      });
      this.tableHeaderActions = this.actionsArr.headerRights;
      this.tableHeaderActions['exportToCsv'] = false;
      this.tableHeaderActions['provisiondropDown'] = true;
      this.tableHeaderActions['provisionsearch'] = true;
      this.tableHeaderActions['deleteAction'] = false;
      this.actionsObj.actions = actionsArray;
      this.actionsObj.actions.forEach(element => {
        if (element.type == "install") {
          element.title = 'Install Config provisioning service';
        }
      });

    });
  }
  getDropDownData() {
    return new Promise((resolve, reject) => {
      this.http.get('assets/dropdown-json/dropdown.json').subscribe((response: any) => {
        this.headerDropdownList = response.configpushdropdown;
        resolve(true);
      });
    });
  }
  openAddConfigModal() {
    this.configModalOptionMode = 'create';
    this.showEnterpriseList = false;
    this.selectedEnterpriseList = [];
    this.deviceModelView = true;
    this.configAllDetails = '';
    this.createConfigForm();
    this.enterpriseIdsArray = [];
    this.filterSearch = '';
    this.pageSize = 1;
    this.getEnterPriseId();
    this.openModel(this.addConfigModalContent, event, 'lg');
  }
  selectEnterprise() {
    this.openModel(this.selectEnterpriseModalContent, event, 'sm');
  }
  enableChildList(item) {
    item.showChild = !item.showChild;
  }
  selectDevices(event, data) {
    if (event.checked) {
      this.selectedDeviceModal = [];
      this.selectedDeviceModal.push(data.name);

      const selcetedDevicesIds = this.selectedDeviceNames.filter(selectedDevice => {
        return selectedDevice.model === data.name;
      });
      this.selectedDevicesCount = selcetedDevicesIds.length;
      this.deviceModelsList = [];
      event.mode = "device";
      this.openModel(this.selectDevicesModalContent, event, 'lg');
      this.getDeviceModels(1);
    } else {

    }

  }

  saveSelectedModals(close) {
    if (this.installModels) {
      const selectedModal = this.installModels[this.installModels.findIndex(deviceModal => deviceModal.name == this.selectedDeviceModal[0])];
      const selcetedDevicesCount = this.selectedDeviceNames.filter(data => {
        return data.model === selectedModal['name'];
      });

      if (this.notSelectAnyDevices) {
        selectedModal['indeterminate'] = false;
        selectedModal['checked'] = false;
      } else if (this.selectAllDevices) {
        if (selcetedDevicesCount.length === this.deviceModelsListCount) {
          selectedModal['indeterminate'] = false;
          selectedModal['checked'] = true;
        } else {
          selectedModal['indeterminate'] = true;
          selectedModal['checked'] = false;
        }
      } else {
        selectedModal['indeterminate'] = true;
        selectedModal['checked'] = false;
      }
    }

    this.closeModel(close);
  }

  getDeviceModels(page) {
    this.currentPageOfDeviceModal = page;
    const req = {
      deviceModelNames: this.selectedDeviceModal,
      limit: 5,
      offset: (page - 1) * 5
    };
    this.getDeviceDetailsAssociatedWithDeviceModel(req);
  }

  getDeviceDetailsAssociatedWithDeviceModel(req) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = this.domainParams;
      req['domainName'] = this.domainParams.name;
    }
    this.cps.getDeviceDetailsAssociatedWithDeviceModel(req, params).subscribe(
      result => {
        const res = result;
        this.deviceModelsList = res.deviceRepresentationInfo.map(device => {
          const deviceArray = device.status.terminal.split('.');
          device.status = deviceArray[1];
          if (this.selectedDeviceIds.includes(device.deviceDescription.deviceId)) {
            device.selected = true;
          } else {
            device.selected = false;
          }
          return device;
        });
        this.deviceModelsListCount = res.totalCount;
        this.selectAllDevices = this.deviceModelsList.every(device => {
          return device.selected === true;
        });
        this.notSelectAnyDevices = this.deviceModelsList.every(device => {
          return device.selected !== true;
        });
        this.SpinnerService.toggleSpinner(0);
      },
      error => {
        this.failureCase(error);
      }
    );
  }
  selcetAllDevices(event) {
    this.deviceModelsList.map(device => {
      device.selected = event.checked;
    });
    this.checkAllSelectdOrNotForDevices();
  }
  removeSelectedDevice() {
    this.installModels = [];
    this.selectedDeviceIds = [];
    this.selectedDeviceNames = [];
    this.selectedDevicesCount = 0;
    this.deviceModelsListCount = 0;
  }
  checkAllSelectdOrNotForDevices() {
    this.deviceModelsList.forEach(device => {
      if (device.selected) {
        if (!this.selectedDeviceIds.includes(device.deviceDescription.deviceId)) {
          this.selectedDevicesCount++;
          this.selectedDeviceIds.push(device.deviceDescription.deviceId);
          this.selectedDeviceNames.push({ model: device.deviceDescription.model, id: device.deviceDescription.deviceId });
        }
      } else {
        if (this.selectedDeviceIds.includes(device.deviceDescription.deviceId)) {
          this.selectedDevicesCount--;
          const index = this.selectedDeviceIds.indexOf(device.deviceDescription.deviceId);
          const deviceNameIndex = this.selectedDeviceNames.findIndex(selectedDevice => selectedDevice.id === device.deviceDescription.deviceId);
          this.selectedDeviceIds.splice(index, 1);
          this.selectedDeviceNames.splice(deviceNameIndex, 1);
        }
      }
    });
    this.selectAllDevices = this.deviceModelsList.every(device => {
      return device.selected === true;
    });
    this.notSelectAnyDevices = this.deviceModelsList.every(device => {
      return device.selected !== true;
    });
  }
  settings = {
    text: "",
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    classes: "myclass custom-class config-enterprise-dropdown",
    primaryKey: "alpha3Code",
    labelKey: "name",
    noDataLabel: "Search Enterprise...",
    enableSearchFilter: true
  };


  getEmptyData(obj) {
    this.data = {
      page: 1,
      total: 0,
      data: []
    };
  }

  getData(obj) {
    this.getActions();
    this.getDeviceSettings();
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = { "limit": obj.limit, "offset": obj.offset, domainName: this.domainParams.name };
    } else {
      params = { "limit": obj.limit, "offset": obj.offset }
    }
    this.SpinnerService.toggleSpinner(1);
    this.cps.getConfigDetails(params).subscribe(
      res => {
        this.SpinnerService.toggleSpinner(0);
        const configData = res.data.items.map(data => {
          data.versionName = data.versions && data.versions[0] ?
            data.versions[0].name + ((data.versions && data.versions.length > 1) ? '(' + (data.versions.length - 1) + ')' : '') : '';
          data.modals = data.deviceModels;
          return data;
        });

        this.data = {
          page: obj.page ? obj.page : 1,
          total: res.data && res.data.totalCount ? res.data.totalCount : 0,
          data: configData
        };
      },
      error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
      }
    );
  }

  getDataBySearch(data) {
    let obj;
    obj = this.cps.getObject(data);
    this.SpinnerService.toggleSpinner(1);
    obj.limit = 10;
    obj.offset = 0;
    this.domainParams = this.HeaderService.getSelectedDomain();
    if (this.domainParams) {
      obj.domainName = this.domainParams.name;
    }
    this.cps.getConfigDetails(obj).subscribe(
      res => {
        this.SpinnerService.toggleSpinner(0);
        if (res) {
          const configData = res.data.items.map(data => {
            data.modals = data.deviceModels;
            return data;
          });

          this.data = {
            page: 1,
            total: res.data.totalCount,
            data: configData
          };
        }
      },
      error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
      }
    );
  }

  differenceInDays() {
    if (this.installSoftwareForm.value.campaignStartTime && this.installSoftwareForm.value.campaignEndTime) {
      if (new Date(this.installSoftwareForm.value.campaignEndTime) > new Date(this.installSoftwareForm.value.campaignStartTime)) {
        this.diffDays = this.cms.dateDiffIndays(this.installSoftwareForm.value.campaignStartTime, this.installSoftwareForm.value.campaignEndTime)
      } else {
        this.diffDays = "";
      }

    }
  }

  getDeviceSettings() {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params['domainId'] = this.domainParams.id;
      params['domainName'] = this.domainParams.name;
    }
    this.cps.getDeviceSettings(params).subscribe(result => {
      this.SpinnerService.toggleSpinner(0);
      if (result && result.data && result.data.deviceSettings) {
        this.configureData = result.data.deviceSettings;
      }
    }, error => {
      this.SpinnerService.toggleSpinner(0);
    });
  }


  changeViewMore() {
    this.deviceModelView = !this.deviceModelView;
  }

  getSpecificProfileDetails(event) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    this.configData = {};
    let propertyData = [];
    let device = "";
    let params = {};
    if (this.domainParams) {
      params = { "id": event.id, "domainId": this.domainParams.id, "domainName": this.domainParams.name };
    } else {
      params = { "id": event.id };
    }
    this.SpinnerService.toggleSpinner(1);
    this.cps.getSpecificProfile(params).subscribe(
      res => {
        this.SpinnerService.toggleSpinner(0);
        if (res) {
          if (res.data && res.data.deviceSettings && res.data.deviceSettings[0].deviceModelRepresentations.length > 0) {
            const deviceArr = [];
            res.data.deviceSettings[0].deviceModelRepresentations.forEach(element => {
              device = element.platformRepresentation.name + ' ' + element.vendor + ' ' + element.name;
              deviceArr.push(device);
            });
            const deviceModelsView = deviceArr.toString();
            this.deviceModelsView = deviceModelsView.replace(/,/g, "\n");
            propertyData = this.cps.createDynamicForm(res.data.deviceSettings[0].propertyList, event.actionType);
          }
          this.configData = res.data;
          this.configData.actionType = event.actionType;
          this.configData.dynamicData = propertyData;
          event.enterpriseIds = [];
          res.data.enterpriseIds.forEach(element => {
            element['itemName'] = element.name;
            event.enterpriseIds.push(element)
          });
          this.configData.name = event.name;
          this.createConfigForm(event);
          this.openModel(this.configModalContent, event, 'lg');
          this.getEnterPriseId();
        }
      },
      error => {
        this.SpinnerService.toggleSpinner(0);
      }
    );


  }

  viewConfig(event) {
    this.event = event;
    this.configModalOptionMode = 'view';
    this.getSpecificProfileDetails(event);
    this.deviceModelView = true;
    //this.openModel(this.configModalContent, event, 'lg');
  }

  editConfig(event) {
    this.getSpecificProfileDetails(event);
    this.deviceModelView = true;
    this.configModalOptionMode = 'edit';
    this.enterpriseIdsArray = [];
    this.filterSearch = '';
    this.pageSize = 1;

  }

  deleteConfig(event) {
    this.deleteConfigData = event;
    this.openModel(this.deleteConfirmModalContent, event, 'sm');
  }

  selectAllDecide(event) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = this.domainParams;
    }
    let deviceNames = [];
    if (event.checked) {
      if (this.installModels && this.installModels.length > 0) {
        this.installModels.map(element => {
          element['indeterminate'] = false;
          element['checked'] = true;
          deviceNames.push(element.name);
          return element;
        });
        const req = {
          deviceModelNames: deviceNames
        };
        this.cps.getDeviceDetailsAssociatedWithDeviceModel(req, params).subscribe(
          result => {
            const res = this.successCase(result);
            this.deviceModelsList = res.deviceRepresentationInfo.map(device => {
              const deviceArray = device.status.terminal.split('.');
              device.status = deviceArray[1];
              device.selected = true;
              this.selectedDevicesCount++;
              this.selectedDeviceIds.push(device.deviceDescription.deviceId);
              this.selectedDeviceNames.push({ model: device.deviceDescription.model, id: device.deviceDescription.deviceId });
              return device;
            });
            this.deviceModelsListCount = res.totalCount;
            this.selectAllDevices = this.deviceModelsList.every(device => {
              return device.selected === true;
            });
            this.notSelectAnyDevices = this.deviceModelsList.every(device => {
              return device.selected !== true;
            });
          },
          error => {
            this.failureCase(error);
          }
        );
      }
    } else {
      if (this.installModels && this.installModels.length > 0) {
        this.installModels.map(element => {
          element['indeterminate'] = false;
          element['checked'] = false;
          return element;
        });
      }
      if (this.deviceModelsList && this.deviceModelsList.length > 0) {
        this.selectedDeviceIds = [];
        this.selectedDeviceNames = [];
        this.selectedDevicesCount = 0;
        this.deviceModelsListCount = 0;
        this.selectAllDevices = this.deviceModelsList.every(device => {
          return device.selected === false;
        });
        this.notSelectAnyDevices = this.deviceModelsList.every(device => {
          return device.selected !== false;
        });
      }

    }
  }

  installConfig(event) {
    this.event = event;
    this.diffDays = "";
    this.scheduleType = false;
    this.removeSelectedDevice();
    this.installSoftwareFormBlock();
    if (event.deviceModels) {
      this.installModels = event.deviceModels.map(element => {
        element['indeterminate'] = false;
        element['checked'] = false;
        return element;
      });
      this.configModalOptionMode = 'install';
      this.openModel(this.configInstallModalContent, event, 'lg');
    } else {
      this.installModels = [];
    }
    let params = {};
    if (this.domainParams) {
      params = this.domainParams;
    }
    this.installSoftwareDetails = event;
    this.cps.getDefaultTimeZones(params).subscribe(result => {
      this.SpinnerService.toggleSpinner(0);
      const res = result.data ? result.data : [];
      this.zones = res;
    }, error => {
      this.SpinnerService.toggleSpinner(0);
    });

  }

  changeServerStatus(event) {
    if (event && event.value && event.value === 'scheduled') {
      this.scheduleType = true;
    } else {
      this.scheduleType = false;
    }
  }

  installSoftwareFormBlock() {
    this.installSoftwareForm = this.fb.group({
      modal: [''],
      targetDevices: 'All',
      campaignRetries: ['3'],

      campaignPriority: 'REGULAR',

      successMessage: '',

      failureMessage: '',

      isDraft: false,

      isServerInitiated: false,

      serverInitiatedInTimeZone: 'Asia/Kolkata',//Default India

      serverInitiatedFromTime: '',

      serverInitiatedToTime: '',

      campaignStartTime: '',

      campaignEndTime: '',
      downloadFromTime: '',
      downloadToTime: '',
      networkUsage: '',
      wifiExpirationDate: '',
      wifiExpirationTime: '',
      Quota: '',
      Timeframe: '',
      quotaType: '',
      timeFrameType: ''
    });
  }

  openModel(content, event, size) {
    let className = "jio-modal config-push-popup";
    if (event && event.mode === "device") {
      className = "jio-modal config-device-popup"
    }
    this.ngbModal
      .open(content, {
        windowClass: className,
        size: size,
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }
  selectSingleOne(event, model) {
    return (model.selected = event.checked);
  }
  closeModel(close) {
    close('Cross click');
  }
  getConfigureDataSelection(data) {
    let obj = {};
    let params = {
      actionType: data.value.actionType,
      description: data.value.description,
      name: data.value.name
    }
    this.domainParams = this.HeaderService.getSelectedDomain();
    if (this.domainParams) {
      obj = {
        domainId: this.domainParams.id,
        domainName: this.domainParams.name,
        deviceId: data.value.id,
      };
    } else {
      obj = {
        deviceId: data.value.id,
      };
    }
    this.SpinnerService.toggleSpinner(1);
    this.cps.getDeviceSetting(obj).subscribe(result => {
      this.configAllDetails = result && result.data ? result.data : '';
      this.configAllDetails.shortDescription = params.description;
      this.configAllDetails.description = params.name;
      this.configAllDetails.actionType = params.actionType;
      this.configAllDetails.method = params.actionType + ' ' + params.name;
      this.configAllDetails.deviceDetails = '';
      if (this.configAllDetails.deviceModelRepresentations
        && this.configAllDetails.deviceModelRepresentations.length > 0) {
        const deviceArr = [];
        this.configAllDetails.deviceModelRepresentations.forEach(element => {
          const device = element.platformRepresentation.name + ' ' + element.vendor + ' ' + element.name;
          deviceArr.push(device);
        });
        const deviceDetails = deviceArr.toString();
        this.configAllDetails.deviceDetails = deviceDetails.replace(/,/g, "\n");

      }
      if (this.configAllDetails.propertyList && this.configAllDetails.propertyList.length > 0) {
        this.configAllDetails.dynamicData = this.cps.createDynamicForm(this.configAllDetails.propertyList, this.configAllDetails.actionType);
      }
      this.SpinnerService.toggleSpinner(0);

    },
      error => {
        this.SpinnerService.toggleSpinner(0);
      });
  }
  editProfileName() {
    this.openModel(this.configProfileNameChangeModalContent, event, 'sm');
  }
  successCase(result) {
    if (result.status === 200 || result.status === 201 || result.status === 202) {
      return result.body.data || result.body;
    }
  }
  failureCase(error) {
    this.SpinnerService.toggleSpinner(0);
    this.DataService.broadcast('alert', {
      type: 'danger',
      message: error && error.error && error.error.errorDetails ? error.error.errorDetails :
        error && error.error && error.error.message ? error.error.message :
          error ? error : 'Network error please try again'
    });
  }
  submitForm(form, button, close) {
    if (form.valid) {
      this.installSoftwareWithDevices(button, close);
    } else {
      this.cms.validateAllFormFields(form);
    }
  }
  installSoftwareWithDevices(button, close) {
    this.SpinnerService.toggleSpinner(1);
    const req = {
      deviceIds: this.selectedDeviceIds,
      profileIds: [this.event.id],

      isDraft: (button == 'executeSave' ? true : false),

      description: 'ConfigInstall_' + this.event.domains + '_' + this.DataService.getParseAndAtob('loginMember') + '_' + new Date()
    };
    if (this.installSoftwareForm.value.isServerInitiated == 'None') {
      req['isServerInitiated'] = false;
    }
    if (this.installSoftwareForm.value.isServerInitiated == 'immediate') {
      req['isServerInitiated'] = true;
    }

    if (this.installSoftwareForm.value.isServerInitiated == 'scheduled') {
      req['isServerInitiated'] = true;
      req['serverInitiatedInTimeZone'] = this.installSoftwareForm.value.serverInitiatedInTimeZone;
      req['serverInitiatedFromTime'] = this.installSoftwareForm.value.serverInitiatedFromTime ? this.cms.convertTime12to24(this.installSoftwareForm.value.serverInitiatedFromTime) : '';
      req['serverInitiatedToTime'] = this.installSoftwareForm.value.serverInitiatedToTime ? this.cms.convertTime12to24(this.installSoftwareForm.value.serverInitiatedToTime) : '';
    }

    if (this.installSoftwareForm.value.campaignRetries) {
      req['campaignRetries'] = this.installSoftwareForm.value.campaignRetries;
    }


    if (this.installSoftwareForm.value.campaignPriority) {
      req['campaignPriority'] = this.installSoftwareForm.value.campaignPriority;
    }

    if (this.installSoftwareForm.value.successMessage) {
      req['successMessage'] = this.installSoftwareForm.value.successMessage;
    }
    if (this.installSoftwareForm.value.failureMessage) {

      req['failureMessage'] = this.installSoftwareForm.value.failureMessage;
    }

    if (this.installSoftwareForm.value.campaignStartTime) {
      req['campaignStartTime'] = this.cms.getEpochTimeForInstallStartDayAndTime(this.installSoftwareForm.value.campaignStartTime, this.startTime);
    }

    if (this.installSoftwareForm.value.campaignEndTime) {
      req['campaignEndTime'] = this.cms.getEpochTimeForInstallStartDayAndTime(this.installSoftwareForm.value.campaignEndTime, this.endTime);
    }
    if (this.installSoftwareForm.value.downloadFromTime) {
      req['downloadFromTime'] = this.cms.convertTime12to24(this.installSoftwareForm.value.downloadFromTime);
    }
    if (this.installSoftwareForm.value.downloadToTime) {
      req['downloadToTime'] = this.cms.convertTime12to24(this.installSoftwareForm.value.downloadToTime);
    }
    if (this.installSoftwareForm.value.networkUsage) {
      req['networkUsage'] = this.installSoftwareForm.value.networkUsage;
    }
    if (this.installSoftwareForm.value.wifiExpirationDate) {
      req['wifiExpirationDate'] = this.cms.getEpochTimeForInstallStartDay(this.installSoftwareForm.value.wifiExpirationDate);
      if (this.installSoftwareForm.value.wifiExpirationTime) {
        let dateTimeepoch = this.cms.getEpochFromDateAndTime(this.installSoftwareForm.value.wifiExpirationDate, this.installSoftwareForm.value.wifiExpirationTime);
        req['wifiExpirationDate'] = dateTimeepoch;
      }
    }
    if (this.installSoftwareForm.value.Quota) {
      if (this.installSoftwareForm.value.quotaType == 'MB') {
        req['Quota'] = this.installSoftwareForm.value.Quota * 1024;
      } else {
        req['Quota'] = this.installSoftwareForm.value.Quota;
      }

    }
    if (this.installSoftwareForm.value.Timeframe) {

      if (this.installSoftwareForm.value.timeFrameType == 'hours') {
        req['Timeframe'] = this.installSoftwareForm.value.Timeframe * 60;
      } else {
        req['Timeframe'] = this.installSoftwareForm.value.Timeframe;
      }
    }
    this.domainParams = this.HeaderService.getSelectedDomain();
    if (this.domainParams) {
      req['domain'] = this.domainParams;
    }
    this.cps.installSoftwareWithDevices(req).subscribe(
      result => {
        this.SpinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        this.DataService.broadcast('alert', {
          type: 'success',
          message: 'Install successfully'
        });
        const obj = { limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 };
        this.getData(obj);
        this.closeModel(close);
      },
      error => {
        this.failureCase(error);
      }
    );
  }
  createConfigForm(event?) {
    if (this.configModalOptionMode === 'view' || this.configModalOptionMode === 'edit') {
      let enterpriseIdsArr = [];
      this.selectedEnterpriseList = [];
      event.enterpriseIds.forEach(enterPriseId => {
        enterpriseIdsArr.push(enterPriseId.name);
        this.selectedEnterpriseList.push({ hqBpId: enterPriseId.id, hqBpName: enterPriseId.name })
      });
      event.enterpriseIds = this.selectedEnterpriseList;
      this.viewenterpriseIds = enterpriseIdsArr;
    }
    this.createConfigFormGroup = this.fb.group({
      id: [{ value: event && event.id ? event.id : '', disabled: event && event.mode === 'view' ? true : false }],
      profileName: [event ? event.name : '', Validators.required],
      profileDescription: [event ? event.description : '', Validators.required],
      specificProfileId: [event ? event.id : '', this.configModalOptionMode !== 'edit' ? Validators.required : ''],
      enterpriseIds: [{ value: event && event.enterpriseIds ? event.enterpriseIds : '', disabled: event && event.mode === 'view' ? true : false }, Validators.required]
    })
  }
  setConfigName(event, close) {
    if (this.createConfigFormGroup.get('profileName').value) {
      this.createConfigFormGroup.get('profileName').setValue(this.createConfigFormGroup.get('profileName').value);
      this.configData.name = this.createConfigFormGroup.get('profileName').value;
      this.closeModel(close);
    }

  }
  submitConfigForm(form, close) {
    const formData = form.value;
    let enterpriseIds = [];
    const id = this.createConfigFormGroup.get('id').value;
    const profileName = this.createConfigFormGroup.get('profileName').value;
    const profileDescription = this.createConfigFormGroup.get('profileDescription').value;
    const specificProfileId = this.createConfigFormGroup.get('specificProfileId').value;
    if (this.createConfigFormGroup.controls.enterpriseIds && this.createConfigFormGroup.controls.enterpriseIds.value
      && this.createConfigFormGroup.controls.enterpriseIds.value.length > 0) {
      this.createConfigFormGroup.controls.enterpriseIds.value.forEach(element => {
        enterpriseIds.push({ "id": element.hqBpId, "name": element.hqBpName });
      });
    }
    this.filterSearch = "";
    const submitData = {
      id: id, profileName: profileName, profileDescription: profileDescription,
      specificProfileId: specificProfileId, formData: form, enterpriseIds: enterpriseIds
    };
    if (this.createConfigFormGroup.valid && form) {
      if (id) {
        this.updateConfigPush(submitData, close);
      } else {
        this.addConfigPush(submitData, close);
      }
    }
  }

  updateConfigPush(params, close) {
    const actionType = this.configData.actionType ? this.configData.actionType : '';
    const deviceSettingName = this.configData.deviceSettings &&
      this.configData.deviceSettings[0] &&
      this.configData.deviceSettings[0].name ? this.configData.deviceSettings[0].name : '';
    let propertyArr = [];
    let postParams = {};
    if (this.configData.deviceSettings && this.configData.deviceSettings[0] && this.configData.deviceSettings[0].propertyList
      && this.configData.deviceSettings[0].propertyList.length > 0) {
      propertyArr = this.cps.getPostPropertyList(this.configData.deviceSettings[0].propertyList, params.formData, actionType);
    }
    this.domainParams = this.HeaderService.getSelectedDomain();
    if (this.domainParams) {
      postParams = {
        domain: this.domainParams,
        "name": params.profileName,
        "description": params.profileDescription,
        //  "actionType": actionType,
        //  "deviceSettingName": deviceSettingName,
        "property": propertyArr,
        enterpriseIds: params.enterpriseIds,
        id: params.id,

      }
    } else {
      postParams = {
        "name": params.profileName,
        "description": params.profileDescription,
        // "actionType": actionType,
        //  "deviceSettingName": deviceSettingName,
        "property": propertyArr,
        enterpriseIds: params.enterpriseIds,
        id: params.id
      }
    }
    this.SpinnerService.toggleSpinner(1);
    this.cps.updateConfigProfile(postParams).subscribe(
      res => {
        this.SpinnerService.toggleSpinner(0);
        if (res) {
          this.DataService.broadcast('alert', {
            type: 'success',
            message: 'Update successfully'
          });
          const obj = { limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 };
          this.getData(obj);
          this.closeModel(close);
        }
      },
      error => { this.failureCase(error); }
    );
  }

  addConfigPush(params, close) {
    const actionType = this.configAllDetails.actionType ? this.configAllDetails.actionType : '';
    const deviceSettingName = this.configAllDetails.description ? this.configAllDetails.description : '';
    let propertyArr = [];
    if (this.configAllDetails.propertyList && this.configAllDetails.propertyList.length > 0) {
      propertyArr = this.cps.getPostPropertyList(this.configAllDetails.propertyList, params.formData, actionType);
    }
    const postParams = {
      "domain": this.domainParams,
      "name": params.profileName,
      "description": params.profileDescription,
      "actionType": actionType,
      "deviceSettingName": deviceSettingName,
      "property": propertyArr,
      enterpriseIds: params.enterpriseIds
    }
    this.SpinnerService.toggleSpinner(1);
    this.cps.createConfigProfile(postParams).subscribe(
      res => {
        this.SpinnerService.toggleSpinner(0);
        if (res) {
          // this.DataService.broadcast('alert', {
          //   type: 'success',
          //   message: 'Saved successfully'
          // });  
          const obj = { limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 };
          this.getData(obj);
          this.closeModel(close);
        }
      },
      error => { this.failureCase(error); }
    );
  }

  deleteProfile(event, close) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = { id: event.id };
    if (this.domainParams) {
      params['domain'] = this.domainParams;
    }
    this.SpinnerService.toggleSpinner(1);
    this.cps.deleteProfile(params).subscribe(
      res => {
        if (res) {
          this.DataService.broadcast('alert', {
            type: 'success',
            message: 'Delete successfully'
          });
          this.SpinnerService.toggleSpinner(0);
          const obj = { limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 };
          this.getData(obj);
          this.closeModel(close);
        }
      },
      error => { this.failureCase(error); }
    );
  }
  getEnterPriseId(page?) {
    let obj;
    if (page) {
      let pageOffset = this.pageSize * 200;
      this.pageSize = this.pageSize + 1;
      obj = { limit: 200, offset: pageOffset, page: this.pageSize, pageNum: this.pageSize, rpp: 200 };
    } else {
      obj = { limit: 200, offset: 0, page: 1, pageNum: 1, rpp: 200 };
    }
    const totalEnterPriseCount = this.cps.getTotalCountEnterprises();
    const totalEnterpriseResult = this.cps.getVendorList(obj);
    this.SpinnerService.toggleSpinner(0);
    forkJoin([totalEnterPriseCount, totalEnterpriseResult]).subscribe(results => {
      this.SpinnerService.toggleSpinner(0);
      if (results[1] && results[1].data && results[1].data.length > 0) {
        this.enterpriseIdsArray = this.enterpriseIdsArray.concat(results[1].data);
        this.enterpriseIdsArray.forEach(element => {
          if (this.selectedEnterpriseList && this.selectedEnterpriseList.length > 0) {
            this.selectedEnterpriseList.forEach(inneerElement => {
              if (element.hqBpId == inneerElement.hqBpId) {
                element['isCheck'] = true;
              }
            });
          }
        });
        this.SpinnerService.toggleSpinner(0);
      } else {
        this.SpinnerService.toggleSpinner(0);
      }
    }, error => {
      this.SpinnerService.toggleSpinner(0);
      this.enterpriseIdsArray = [];
    });
  }

  searchWithEnterpriseName(evt) {
    if (evt.target.value) {
      this.filterSearch = evt.target.value;
      const obj = { hqBpName: evt.target.value };
      this.enterpriseIdsArray = [];
      const totalEnterpriseResult = this.cps.getEnterpriseSearchName(obj);
      this.SpinnerService.toggleSpinner(1);
      forkJoin([totalEnterpriseResult]).subscribe(results => {
        this.SpinnerService.toggleSpinner(0);
        if (results[0] && results[0].data && results[0].data.length > 0) {
          this.enterpriseIdsArray = results[0].data;
          this.enterpriseIdsArray.forEach(element => {
            if (this.selectedEnterpriseList && this.selectedEnterpriseList.length > 0) {
              this.selectedEnterpriseList.forEach(inneerElement => {
                if (element.hqBpId == inneerElement.hqBpId) {
                  element['isCheck'] = true;
                }
              });
            }
          });
          this.SpinnerService.toggleSpinner(0);
        } else {
          this.SpinnerService.toggleSpinner(0);
        }
      }, error => {
        this.SpinnerService.toggleSpinner(0);
        this.enterpriseIdsArray = [];
      });
    } else {
      this.enterpriseIdsArray = [];
      this.filterSearch = '';
      this.pageSize = 1;
      this.getEnterPriseId();
    }
  }
  changeData() {
    this.selectedItems = [];
  }
  showCheckList() {
    this.enterpriseIdsArray.forEach(element => {
      this.selectedEnterpriseList.forEach(inneerElement => {
        if (element.hqBpId == inneerElement.hqBpId) {
          element.isCheck = true;
        }
      });
    });
    // this.filterSearch = '';
    this.showEnterpriseList = !this.showEnterpriseList;
  }

  onItemDeSelect(event) {
    this.enterpriseIdsArray.forEach(element => {
      if (event == element.hqBpId) {
        element.isCheck = false;
      }
    });

    this.selectedEnterpriseList.forEach((element, keyId) => {
      if (event == element.hqBpId) {
        this.selectedEnterpriseList.splice(keyId, 1);
      }
    });
    this.setEnterpriseValue();
  }

  setEnterpriseValue() {
    this.createConfigFormGroup.patchValue({
      enterpriseIds: this.selectedEnterpriseList,
      id: this.createConfigFormGroup.controls['id'].value,
      profileDescription: this.createConfigFormGroup.controls['profileDescription'].value,
      profileName: this.createConfigFormGroup.controls['profileName'].value,
      specificProfileId: this.createConfigFormGroup.controls['specificProfileId'].value
    });
  }

  closeMultiselectField(event) {
    if (event.target) {
      if (event.target.id !== 'multiselectList' && event.target.id !== 'multiselecthevron') {
        this.showEnterpriseList = false;
      }
    }
  }

  checkEnterprise(event, hqBpId) {
    if (event.checked) {
      this.enterpriseIdsArray.forEach((element, keyId) => {
        if (hqBpId == element.hqBpId) {
          if (this.enterpriseIdsArray && this.enterpriseIdsArray[keyId] && this.enterpriseIdsArray[keyId].isCheck) {
            this.enterpriseIdsArray[keyId].isCheck = true;
          }
          this.selectedEnterpriseList.push(element);
        }
      });
    } else {
      this.selectedEnterpriseList.forEach((element, keyId) => {
        if (hqBpId == element.hqBpId) {
          if (this.enterpriseIdsArray && this.enterpriseIdsArray[keyId] && this.enterpriseIdsArray[keyId].isCheck) {
            this.enterpriseIdsArray[keyId].isCheck = false;
          }
          this.selectedEnterpriseList.splice(keyId, 1);
        }
      });
    }
    this.setEnterpriseValue();
  }
  fetchMore(event) {
    if (event > 0 && this.filterSearch == '') {
      if (this.enterpriseIdsArray.length == this.pageSize * 200) {
        this.getEnterPriseId(event);
      }
    }
  }
}
