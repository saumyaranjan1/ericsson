import { Injectable } from '@angular/core';
import { InterceptorService } from './../shared/services/interceptor.service';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class ConfigPushService {

  constructor(private interceptor: InterceptorService) { }
  getConfigDetails(request) {
    return this.interceptor.httpCall('get', 'getConfigDetails', request);
  }
  createConfigProfile(request) {
    return this.interceptor.httpCall('post', 'createConfigProfile', request);
  }
  updateConfigProfile(request) {
    request.extraParams = request.id;
    request.extraParams = '?id='+request.id;
    return this.interceptor.httpCall('put', 'updateConfigProfile', request);
  }
  getDeviceSettings(action) {
    let params = {};
    if(action.domainId && action.domainName){ 
      params['extraParams'] = "?domainId="+action.domainId+"&domainName="+action.domainName;
    }
    return this.interceptor.httpCall('get', 'getDeviceSettings', params);
  }
  getDefaultTimeZones(request) {
    let params = {};
    if(request && request.name && request.id){
      params['extraParams'] = "?domainName="+request.name;
    }
    return this.interceptor.httpCall('get', 'defaultConfigTimeZones',params);
  }

  getEnterpriseSearchName(request) {
    return this.interceptor.httpCall('get', 'getConfigEnterpriseSearchName', request);
  }

  getDeviceSetting(action) {
    let params = {};
    if(action.domainId && action.domainName){ 
      params['extraParams'] = "?id="+action.deviceId+"&domainId="+action.domainId+"&domainName="+action.domainName;
    }else{
      params['extraParams'] = "?id="+action.deviceId;
    }
    return this.interceptor.httpCall('get', 'getDeviceSetting', params);
  }
  getSpecificProfile(action) {
    let params = {};
    if(action.domainId && action.domainName){
     // params = { extraParams: '/' + action.id+"?domainId="+action.domainId+"&domainName="+action.domainName};  
     params['extraParams'] = "?domainName="+action.domainName+"&id="+action.id;
    }
    else{
      params = { extraParams: '/' + action.id};
    }
    return this.interceptor.httpCall('get', 'getSpecificProfile', params);
  }
  deleteProfile(domainDetails) {
    let params = {};
    if(domainDetails.domain.id && domainDetails.domain.name){
      params['extraParams'] = "?id="+domainDetails.id+"&domainName="+domainDetails.domain.name+"&domainId="+domainDetails.domain.id;
    }else{
      params['extraParams'] = "?id="+domainDetails.id;

    }
    return this.interceptor.httpCallReturn('delete', 'deleteProfile', params);
  }
  installSoftwareWithDevices(request) {
    return this.interceptor.httpCallReturn('post', 'installProfilePackage', request);
   }
   
  getPostPropertyList(profileArr, selectedValue,actionType) {
    let propertiesArr = [];
    let description = "";
    profileArr.forEach(ProfileData => {
      for (let selectedName in selectedValue) {
        if (ProfileData.name === selectedName && selectedValue[ProfileData.name]) {
          if(ProfileData.type === 'LIST'){
            const getDescription = ProfileData.valueOptions.filter(value => value.value === selectedValue[ProfileData.name]);
            if(getDescription && getDescription.length > 0){
              description = getDescription[0].description;
            }else{
              description =  ProfileData.description;
            }
          }else{
            description =  ProfileData.description;
          }
          if(actionType === 'GET'){
            propertiesArr.push({ name: ProfileData.name});
          }else{
            propertiesArr.push({ name: ProfileData.name, value: selectedValue[ProfileData.name], description:description});
          }
         
        }
      }
      
    });
    return propertiesArr;
  }
  getObject(request) {
    const key = request['dropDownValue'].trim();
    const value = request['searchKey'].trim();
    const dataObj = {};
    if (request.dropDownValue.trim() === 'name') {
      dataObj['names'] = new Array(request.searchKey);
    }else if (request.dropDownValue.trim() === 'customsetting') {
      dataObj['customSettingNames'] = new Array(request.searchKey);
    }else if (request.dropDownValue.trim() === 'devicemodel') {
      let deviceSpace =  request.searchKey.split(" ");
      let deviceName = "";
      let vendorName = "";
      let deviceModalParams = {};
      if(deviceSpace && deviceSpace[0]){
        deviceName = deviceSpace[0];
      } if(deviceSpace && deviceSpace[1]){
        vendorName = deviceSpace[1];
      }
      deviceModalParams =  {name:vendorName , vendor:deviceName};
      dataObj['deviceModels'] = new Array(deviceModalParams);
    }else{
      dataObj[key] = new Array(value);
    }
      return dataObj;
    }
  


  getTotalCountEnterprises() {
    return this.interceptor.httpCall('get', 'getConfigTotalCountEnterprises');
  }
  
  getVendorList(request) {
    return this.interceptor.httpCall('get', 'getConfigEnterpriseList', request);
  }

  /**
   * Get Domain Info
   */
  getDomainData(){
    let _res = sessionStorage.getItem('domain');
    return JSON.parse(_res);
  }

  createDynamicForm(fieldArr,actionType) {
    const dynamicArr = [];
    fieldArr.forEach(fieldVal => {
      if (fieldVal.type === "STRING" && fieldVal.valueOptions === null) {
        let validation = [];
        let value = fieldVal.value;
        if(actionType === 'GET' && fieldVal.defaultValue === null){
          value = fieldVal.name;
        }else if(actionType === 'GET' && fieldVal.defaultValue){
          value = fieldVal.defaultValue;
        }else if(actionType !== 'GET' && fieldVal.defaultValue){
          value = fieldVal.defaultValue;
        }
       // if (fieldVal.mandatory && (fieldVal.value === null || fieldVal.value === "") && actionType !== 'GET') {
          if (fieldVal.mandatory  && actionType !== 'GET') {
          validation = [
            {
              "name": "required",
              "validator": Validators.required,
              "message": fieldVal.name + " Required"
            }
          ];
        } else {
          validation = validation;
        }
        dynamicArr.push({
          "type": "input",
          "label": fieldVal.displayName,
          "inputType": "text",
          "name": fieldVal.name,
          "value": value,
          "inputClassName": 'col-sm-6',
          "validations": validation,
          "description":fieldVal.description,
          "disable":actionType === 'GET' ? true : false
        });
      } else if (fieldVal.type === "LIST") {
        let optionArrValue = [];
        let validation = [];
        if (fieldVal.mandatory && (fieldVal.value === null || fieldVal.value === "")) {
          validation = [
            {
              "name": "required",
              "validator": Validators.required,
              "message": fieldVal.name + " Required"
            }
          ];
        } else {
          validation = validation;
        }
        if (fieldVal.valueOptions !== null) {
          let optionArr = [];
          fieldVal.valueOptions.forEach(element => {
            optionArr.push({ key: element.description, value: element.value ,description:element.description});
          });
          optionArrValue = optionArr;
        } else {
          optionArrValue = [];
        }
        dynamicArr.push({
          "type": "select",
          "label": fieldVal.displayName,
          "name": fieldVal.name,
          "value": fieldVal.value,
          "options": optionArrValue,
          "validations": validation,
          "description":fieldVal.description,
          "inputClassName": 'col-sm-6'
        });
      }
    });
    return dynamicArr;
  }

  getDeviceDetailsAssociatedWithDeviceModel(request,params) {
    return this.interceptor.httpCall('get', 'getConfigDevices', request);
    }
}
