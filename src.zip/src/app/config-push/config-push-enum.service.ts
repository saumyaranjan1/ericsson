import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ConfigPushEnumService {
  public static DATA = {
    data: [],
    columns: [
        {
            displayName: 'Name',
            key: 'name',
            filter: ''
          },
          {
            displayName: 'Description',
            key: 'description',
            filter: ''
          },
          {
            displayName: 'type',
            key: 'actionType',
            filter: ''
          },
          {
            displayName: 'custom settings',
            key: 'customSettingName',
            filter: ''
          },
          {
            displayName: 'device models',
            key: 'modals',
            filter: ''
          }
    ],
    actions: [
    ],
    actionsLabel: 'Actions',
    tableHeader: 'Config Provision',
    deleteIcon:true,
    showGridCheckBox:true,
    tableActions: {
      add: false,
      provisionsearch: true,
      provisiondropDown: true,
      exportToCsv: false
    }
  };

  public static UPDATEFILE_COLUMNS = [
    {
      displayName: 'versions',
      key: 'name',
      filter: ''
    },
    {
      displayName: 'file',
      key: 'model',
      filter: ''
    },
    {
      displayName: 'size(kb)',
      key: 'model',
      filter: ''
    },
    {
      displayName: 'device models',
      key: 'model',
      filter: ''
    },
    {
      displayName: 'tools',
      key: 'model',
      filter: ''
    },
    {
      displayName: 'device details',
      key: 'model',
      filter: ''
    },
    {
      displayName: 'creation time',
      key: 'model',
      filter: ''
    }
  ];

  public static DEVICE_MODELS_COLUMNS =
  [
        {
          displayName: 'DEVICE IMEI',
          key: 'name',
          filter: ''
        },
        {
          displayName: 'DOMAIN',
          key: 'model',
          filter: ''
        },
        {
          displayName: 'STATUS',
          key: 'model',
          filter: ''
        }
      ];

      public static HEADER_DROPDOWN_LIST = ['type','description'];
      public static ROUTE_NAME = "/main/psconf";
}
