export interface ConfigPush {
}
