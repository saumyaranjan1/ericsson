import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConfigPushComponent } from './config-push.component';
import { SharedModule } from '../shared/shared.module';
import { ConfigPushRoutingModule } from './config-push-routing.module';
import {VendorService} from './../vendor/vendor.service'


@NgModule({
  declarations: [ConfigPushComponent],
  imports: [
    CommonModule,
    SharedModule,
    ConfigPushRoutingModule
  ],
  providers: [VendorService]
})
export class ConfigPushModule { }
