import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MainRoutingModule } from './main-routing.module';
import { MainComponent } from './main.component';
import { SharedModule } from '../shared/shared.module';
import { MainService } from './main.service';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { SidenavComponent } from './sidenav/sidenav.component';
import { LoginService } from '../login/login.service';

@NgModule({
  declarations: [MainComponent, HeaderComponent, FooterComponent, SidenavComponent],
  imports: [
    MainRoutingModule,
    CommonModule,
    SharedModule
  ],
  providers: [MainService,LoginService],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ]
})
export class MainModule { }
