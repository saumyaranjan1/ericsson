import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './main.component';
import { AuthGuardService } from '../shared/authGuard/auth-guard.service';

const routes: Routes = [{
  path: '',
  component: MainComponent,
  canActivateChild: [AuthGuardService],
  children: [
    {
      path: 'user-onboard',
      loadChildren: () => import('../old-user-onboard/user-onboard.module').then(mod => mod.UserOnboardModule),
      data: {
        breadcrumb: {
          label: 'Consumer OnBoarding', route: 'user-onboard',
          title: 'Consumer OnBoarding'
        }
      }
    },
    {
      path: 'cuscfg',
      loadChildren: () => import('../data-flow/enterprise-configurations.module').then(mod => mod.EnterpriseConfigurationsModule),
      data: {
        breadcrumb: {
          label: 'Device Details',
          route: 'device-details'
        }
      }
    },
    {
      path: 'cfgjob',
      loadChildren: () => import('../work-flow-status-details/automation-task-details.module').then(mod => mod.AutomationTaskDetailsModule),
      data: {
        breadcrumb: {
          label: 'Customer Configuration Jobs',
          route: 'cfgjob',
          title: 'Customer Configuration Jobs'
        }
      }
    }, {
      path: 'reports',
      loadChildren: () => import('../reference-portal/reference.module').then(mod => mod.ReferenceModule),
      data: {
        breadcrumb: { label: 'Reference Portal', route: 'reference', title: 'reference Portal' }
      }
    },
    {
      path: 'success',
      loadChildren: () => import('../success/success.module').then(mod => mod.SuccessModule),
      data: {
        breadcrumb: { label: 'success', route: 'success' }
      }
    },
    {
      path: 'dboard',
      loadChildren: () => import('../dasboard/dasboard.module').then(mod => mod.DasboardModule),
      data: {
        breadcrumb: {
          label: 'Dasboard', route: 'dboard',
          title: 'Dasboard'
        }
      }
    },
    {
      path: 'update-password',
      loadChildren: () => import('../update-password/update-password.module').then(mod => mod.UpdatePasswordModule),
      data: {
        breadcrumb: { label: 'update-password', route: 'update-password' }
      }
    },
    {
      path: 'action-profile',
      loadChildren: () => import('../action-profile/action-profile.module').then(mod => mod.ActionProfileModule),
      data: {
        breadcrumb: { label: 'Action Profile', route: 'action-profile' }
      }
    },
    {
      path: 'usrmnt',
      loadChildren: () => import('../user-management-abac/user-management-abac.module').then(mod => mod.UserManagementAbacModule),
      data: {
        breadcrumb: { label: 'User Management ABAC', route: 'usrmnt' }
      }
    },
    {
      path: 'rolmnt',
      loadChildren: () => import('../role-category/role-category.module').then(mod => mod.RoleCategoryModule),
      data: {
        breadcrumb: { label: 'Role Category', route: 'rolmnt' }
      }
    },
    {
      path: 'urlmnt',
      loadChildren: () => import('../role-management-abac/role-management-abac.module').then(mod => mod.RoleManagementAbacModule),
      data: {
        breadcrumb: { label: 'Role Management ABAC', route: 'urlmnt' }
      }
    }

  ]
}];


@NgModule({
  declarations: [],
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class MainRoutingModule { }
