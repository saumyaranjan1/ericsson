import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainComponent } from './main.component';
import { AuthGuardService } from '../shared/authGuard/auth-guard.service';

const routes: Routes = [{
  path: '',
  component: MainComponent,
  canActivateChild: [AuthGuardService],
  children: [
    {
      path: 'user-onboard',
      loadChildren: () => import('../old-user-onboard/user-onboard.module').then(mod => mod.UserOnboardModule),
      data: {
        breadcrumb: {
          label: 'Consumer OnBoarding', route: 'user-onboard',
          title: 'Consumer OnBoarding'
        }
      }
    },
    {
      path: 'update-password',
      loadChildren: () => import('../update-password/update-password.module').then(mod => mod.UpdatePasswordModule),
      data: {
        breadcrumb: { label: 'update-password', route: 'update-password' }
      }
    },
    {
      path: 'cuscfg',
      loadChildren: () => import('../data-flow/enterprise-configurations.module').then(mod => mod.EnterpriseConfigurationsModule),
      data: {
        breadcrumb: {
          label: 'Device Details',
          route: 'device-details'
        }
      }
    },
    {
      path: 'cfgjob',
      loadChildren: () => import('../work-flow-status-details/automation-task-details.module').then(mod => mod.AutomationTaskDetailsModule),
      data: {
        breadcrumb: {
          label: 'Customer Configuration Jobs',
          route: 'cfgjob',
          title: 'Customer Configuration Jobs'
        }
      }
    }, {
      path: 'reports',
      loadChildren: () => import('../reference-portal/reference.module').then(mod => mod.ReferenceModule),
      data: {
        breadcrumb: { label: 'Reference Portal', route: 'reference', title: 'reference Portal' }
      }
    },
    {
      path: 'success',
      loadChildren: () => import('../success/success.module').then(mod => mod.SuccessModule),
      data: {
        breadcrumb: { label: 'success', route: 'success' }
      }
    },
    {
      path: 'dboard',
      loadChildren: () => import('../dasboard/dasboard.module').then(mod => mod.DasboardModule),
      data: {
        breadcrumb: {
          label: 'Dasboard', route: 'dboard',
          title: 'Dasboard'
        }
      }
    },
    {
      path: 'usrmgm',
      loadChildren: () => import('../user-management/user-management.module').then(mod => mod.UserManagementModule),
      data: {
        breadcrumb: {
          label: 'User Management',
          route: 'usrmgm',
          title: 'User Management Access'
        }
      }
    },
    {
      path: 'rolmgm',
      loadChildren: () => import('../role-management/role-management.module').then(mod => mod.RoleManagementModule),
      data: {
        breadcrumb: {
          label: 'Role Management',
          route: 'rolmgm',
          title: 'Role Management Access'
        }
      }
    },
    {
      path: 'fms_ui_api',
      loadChildren: () => import('../failure-management/failure-management.module').then(mod => mod.FailureManagementModule),
      data: {
        breadcrumb: { label: 'Failure Management', route: 'fms_ui_api', title: 'Failure Management' }
      }
    },
    {
      path: 'app_ui_api',
      loadChildren: () => import('../application/application.module').then(mod => mod.ApplicationModule),
      data: {
        breadcrumb: { label: 'Application', route: 'app_ui_api' }
      }
    },
    {
      path: 'diagnosis_ui_api',
      loadChildren: () => import('../diagnosis/diagnosis.module').then(mod => mod.DiagnosisModule),
      data: {
        breadcrumb: { label: 'diagnosis Details', route: 'diagnosis_ui_api', title: 'Diagnosis Portal' }
      }
    },
    {
      path: 'psapps',
      loadChildren: () => import('../software-management/software-management.module').then(mod => mod.SoftwareManagementModule),
      data: {
        breadcrumb: {
          label: 'Software Management', route: 'psapps',
          title: 'Software Management'
        }
      }
    },
    {
      path: 'campps',
      loadChildren: () => import('../campaign-management/campaign-management.module').then(mod => mod.CampaignManagementModule),
      data: {
        breadcrumb: {
          label: 'Campaign Management', route: 'campps',
          title: 'Campaign Management'
        }
      }
    },
    {
      path: 'psconf',
      loadChildren: () => import('../config-push/config-push.module').then(mod => mod.ConfigPushModule),
      data: {
        breadcrumb: {
          label: 'Campaign Management', route: 'psconf',
          title: 'Campaign Management'
        }
      }
    },
    {
      path: 'partner_ui_api',
      loadChildren: () => import('../partner/partner.module').then(mod => mod.PartnerModule),
      data: {
        breadcrumb: { label: 'Partner', route: 'partner_ui_api' }
      }
    },

    {
      path: 'job-details',
      loadChildren: () => import('../job-details/job-details.module').then(mod => mod.JobDetailsModule),
      data: {
        breadcrumb: {
          label: 'Job Details',
          route: 'job-details'
        }
      }
    },
    {
      path: 'b2b_ui_api',
      loadChildren: () => import('../vendor/vendor.module').then(mod => mod.VendorModule),
      data: {
        breadcrumb: { label: 'Enterprise B2B', route: 'b2b_ui_api' }
      }
    },
    {
      path: 'devices',
      loadChildren: () => import('../devices/devices.module').then(mod => mod.DevicesModule),
      data: {
        breadcrumb: { label: 'Devices', route: 'devices' }
      }
    },
    {
      path: 'plan_app_ui_api',
      loadChildren: () => import('../plan-app-mapping/plan-app-mapping.module').then(mod => mod.PlanAppMappingModule),
      data: {
        breadcrumb: { label: 'Plan App Mapping', route: 'plan_app_ui_api' }
      }
    },
    {
      path: 'b2c-devices',
      loadChildren: () => import('../b2c-device/b2c-device.module').then(mod => mod.B2cDeviceModule),
      data: {
        breadcrumb: { label: 'B2C Devices', route: 'b2c-devices' }
      }
    },
    {
      path: 'b2c_ui_api',
      loadChildren: () => import('../b2c/b2c.module').then(mod => mod.B2cModule),
      data: {
        breadcrumb: { label: 'B2C', route: 'b2c_ui_api' }
      }
    },
    {
      path: 'domain_details_ui_api',
      loadChildren: () => import('../domain/domain.module').then(mod => mod.DomainModule),
      data: {
        breadcrumb: { label: 'Domain Details', route: 'domain_details_ui_api' }
      }
    }, {
      path: 'plan_profile_ui_api',
      loadChildren: () => import('../plan-profile-mapping/plan-profile-mapping.module').then(mod => mod.PlanProfileMappingModule),
      data: {
        breadcrumb: {
          label: 'Plan Profile Mapping',
          route: 'plan_profile_ui_api'
        }
      }
    },
    {
      path: 'device_details_ui_api',
      loadChildren: () => import('../device-details/device-details.module').then(mod => mod.DeviceDetailsModule),
      data: {
        breadcrumb: {
          label: 'Device Details',
          route: 'device_details_ui_api'
        }
      }
    },
    {
      path: 'rule-engine',
      loadChildren: () => import('../rule-engine/rule-engine.module').then(mod => mod.RuleEngineModule),
      data: {
        breadcrumb: {
          label: 'Device Provisioning',
          route: 'rule-engine'
        }
      }
    },
    {
      path: 'autops',
      loadChildren: () => import('../rule-group-engine/rule-group-engine.module').then(mod => mod.RuleGroupEngineModule),
      data: {
        breadcrumb: {
          label: 'Device Provisioning',
          route: 'autops'
        }
      }
    },
    {
      path: 'title_ui_api',
      loadChildren: () => import('../label-management/label-management.module').then(mod => mod.LabelManagementModule),
      data: {
        breadcrumb: { label: 'label Management', route: 'title_ui_api' }
      },
    },
    {
      path: 'cluster_ui_api',
      loadChildren: () => import('../cluster-management/cluster-management.module').then(mod => mod.ClusterManagementModule),
      data: {
        breadcrumb: { label: 'cluster Management', route: 'cluster_ui_api' }
      }
    },
    {
      path: 'psfirm',
      loadChildren: () => import('../firmware/firmware.module').then(mod => mod.FirmwareModule),
      data: {
        breadcrumb: { label: 'firmware', route: 'psfirm' }
      }
    },
    // {
    //   path: 'tac-code',
    //   loadChildren : () => import('../tac-code/tac-code.module').then(mod => mod.TacCodeModule),
    //   data: {
    //     breadcrumb: { label: 'taccode' , route: 'tac-code' }
    //   }
    // },
    {
      path: 'devcon',
      loadChildren: () => import('../model-dm-domain/model-dm-domain.module').then(mod => mod.ModelDmDomainModule),
      data: {
        breadcrumb: { label: 'Model DM Domain', route: 'devcon' }
      }
    },
    {
      path: 'rbconn',
      loadChildren: () => import('../domain-Management/domain-management.module').then(mod => mod.DomainManagementModule),
      data: {
        breadcrumb: { label: 'domain Management', route: 'rbconn' }
      }
    },
    {
      path: 'rbonbd',
      loadChildren: () => import('../device-onboarding-status/device-onboarding-status.module').then(mod => mod.DeviceOnBoardingModule),
      data: {
        breadcrumb: { label: 'Device Onboarding Status', route: 'rbonbd' }
      }
    },
    {
      path: 'strcfg',
      loadChildren: () => import('../partner-admin/partner-admin.module').then(mod => mod.PartnerAdminModule),
      data: {
        breadcrumb: { label: 'Partner Stream Flow', route: 'strcfg' }
      }
    },
    {
      path: 'action-profile',
      loadChildren: () => import('../action-profile/action-profile.module').then(mod => mod.ActionProfileModule),
      data: {
        breadcrumb: { label: 'Action Profile', route: 'action-profile' }
      }
    },
    
    {
      path: 'title_ui_api',
      loadChildren: () => import('../label-management/label-management.module').then(mod => mod.LabelManagementModule),
      data: {
        breadcrumb: { label: 'label Management', route: 'title_ui_api' }
      },
    },
    {
      path: 'cluster_ui_api',
      loadChildren: () => import('../cluster-management/cluster-management.module').then(mod => mod.ClusterManagementModule),
      data: {
        breadcrumb: { label: 'cluster Management', route: 'cluster_ui_api' }
      }
    },
    {
      path: 'psfirm',
      loadChildren: () => import('../firmware/firmware.module').then(mod => mod.FirmwareModule),
      data: {
        breadcrumb: { label: 'firmware', route: 'psfirm' }
      }
    },
    // {
    //   path: 'tac-code',
    //   loadChildren : () => import('../tac-code/tac-code.module').then(mod => mod.TacCodeModule),
    //   data: {
    //     breadcrumb: { label: 'taccode' , route: 'tac-code' }
    //   }
    // },
    {
      path: 'devcon',
      loadChildren: () => import('../model-dm-domain/model-dm-domain.module').then(mod => mod.ModelDmDomainModule),
      data: {
        breadcrumb: { label: 'Model DM Domain', route: 'devcon' }
      }
    },
    {
      path: 'rbconn',
      loadChildren: () => import('../domain-Management/domain-management.module').then(mod => mod.DomainManagementModule),
      data: {
        breadcrumb: { label: 'domain Management', route: 'rbconn' }
      }
    },
    {
      path: 'rbonbd',
      loadChildren: () => import('../device-onboarding-status/device-onboarding-status.module').then(mod => mod.DeviceOnBoardingModule),
      data: {
        breadcrumb: { label: 'Device Onboarding Status', route: 'rbonbd' }
      }
    },
    {
      path: 'strcfg',
      loadChildren: () => import('../partner-admin/partner-admin.module').then(mod => mod.PartnerAdminModule),
      data: {
        breadcrumb: { label: 'Partner Stream Flow', route: 'strcfg' }
      }
    },
    {
      path: 'action-profile',
      loadChildren: () => import('../action-profile/action-profile.module').then(mod => mod.ActionProfileModule),
      data: {
        breadcrumb: { label: 'Action Profile', route: 'action-profile' }
      }
    },
    {
      path: 'usrmnt',
      loadChildren: () => import('../user-management-abac/user-management-abac.module').then(mod => mod.UserManagementAbacModule),
      data: {
        breadcrumb: { label: 'User Management ABAC', route: 'usrmnt' }
      }
    },
    {
      path: 'rolmnt',
      loadChildren: () => import('../role-category/role-category.module').then(mod => mod.RoleCategoryModule),
      data: {
        breadcrumb: { label: 'Role Category', route: 'rolmnt' }
      }
    },
    {
      path: 'urlmnt',
      loadChildren: () => import('../role-management-abac/role-management-abac.module').then(mod => mod.RoleManagementAbacModule),
      data: {
        breadcrumb: { label: 'Role Management ABAC', route: 'urlmnt' }
      }
  },
  {
    path: 'title_ui_api',
    loadChildren : () => import('../label-management/label-management.module').then(mod => mod.LabelManagementModule),
    data: {
      breadcrumb: { label: 'label Management' , route: 'title_ui_api' }
    },
  }, 
  {
    path: 'cluster_ui_api',
    loadChildren : () => import('../cluster-management/cluster-management.module').then(mod => mod.ClusterManagementModule),
    data: {
      breadcrumb: { label: 'cluster Management' , route: 'cluster_ui_api' }
    } 
  },
  {
    path: 'psfirm',
    loadChildren : () => import('../firmware/firmware.module').then(mod => mod.FirmwareModule),
    data: {
      breadcrumb: { label: 'firmware' , route: 'psfirm' }
    }
  },
  // {
  //   path: 'tac-code',
  //   loadChildren : () => import('../tac-code/tac-code.module').then(mod => mod.TacCodeModule),
  //   data: {
  //     breadcrumb: { label: 'taccode' , route: 'tac-code' }
  //   }
  // },
  {
    path: 'devcon',
    loadChildren : () => import('../model-dm-domain/model-dm-domain.module').then(mod => mod.ModelDmDomainModule),
    data: {
      breadcrumb: { label: 'Model DM Domain' , route: 'devcon' }
    }
  },
  {
    path: 'rbconn',
    loadChildren : () => import('../domain-management/domain-management.module').then(mod => mod.DomainManagementModule),
    data: {
      breadcrumb: { label: 'domain Management' , route: 'rbconn' }
    }
  },
  {
    path: 'rbonbd',
    loadChildren : () => import('../device-onboarding-status/device-onboarding-status.module').then(mod => mod.DeviceOnBoardingModule),
    data: {
      breadcrumb: { label: 'Device Onboarding Status' , route: 'rbonbd' }
    }
  },
  {
    path: 'strcfg',
    loadChildren : () => import('../partner-admin/partner-admin.module').then(mod => mod.PartnerAdminModule),
    data: {
      breadcrumb: { label: 'Partner Stream Flow' , route: 'strcfg' }
    }
  },
  {
    path: 'action-profile',
    loadChildren : () => import('../action-profile/action-profile.module').then(mod => mod.ActionProfileModule),
    data: {
      breadcrumb: { label: 'Action Profile' , route: 'action-profile' }
    }
  },
  {
    path: 'user_mgm_abac',
    loadChildren : () => import('../user-management-abac/user-management-abac.module').then(mod => mod.UserManagementAbacModule),
    data: {
      breadcrumb: { label: 'User Management ABAC' , route: 'user_mgm_abac' }
    }
  }
]
}];

@NgModule({
  declarations: [],
  imports: [
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class MainRoutingModule { }
