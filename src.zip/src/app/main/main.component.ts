import { Component, OnInit } from '@angular/core';
import { DataService } from './../shared/services/data.service';

import { BnNgIdleService } from 'bn-ng-idle';
import { EnumsService } from '../shared/services/enums.service';
import { InterceptorService } from '../shared/services/interceptor.service';
import { Router } from '@angular/router';
import { AuthorizationService } from '../shared/authGuard/authorization.service';
import { SpinnerService } from '../shared/services/spinner.service';
import { AppConfigService } from '../app-config.service';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.less'],
  host: {
    '(window:resize)': 'onResize($event)'
  }
})
export class MainComponent implements OnInit {
  alertSubs: any;
  alert: any;
  toogleSideNavMenu = true;
  expandSideNav = false;
  pageWidth;
  mobileView;
  constructor(private dataService: DataService,
              private bnIdle: BnNgIdleService,
              private interceptor: InterceptorService,
              private router: Router,
              private authorizationService: AuthorizationService,
              private spinnerService: SpinnerService,
              private acs: AppConfigService) { }

  ngOnInit() {
    // if(!sessionStorage.getItem('previlages')) {
    //   sessionStorage.clear();
    //   this.router.navigate(['../login']);
    // } else {
      this.pageWidth=window.innerWidth;
      if(this.pageWidth <= 768){
        this.mobileView=true;
      }else{
        this.mobileView=false;
      }
      this.alertSubs = this.dataService.on('alert', this.displayAlert);
    //  this.checkTOkenExpiry();
      this.bnIdle.startWatching(this.acs.configData.maxIdleSessionTime * 60).subscribe((res) => {
        if (res) {
          this.interceptor.deleteStorageData();
          this.router.navigate(['../login']);
        }
      });
    //}
  }

  onResize(event){
    this.pageWidth=window.innerWidth;
    if(this.pageWidth <= 1020){
      this.mobileView=true;
    }else{
      this.mobileView=false;
    }
  }

  checkTOkenExpiry() {
    const myDate = new Date(); // Your timezone!
    const currentEpcohTime = Math.floor(myDate.getTime() / 1000.0);
    const loginEpcohTime = this.authorizationService.getLoginTime();
    const diff = (currentEpcohTime - loginEpcohTime) / 60;
    if (EnumsService.MAX_SESSION_TIMEOUT_IN_MIN <= diff) {
      this.interceptor.deleteStorageData();
    }
  }

  closeAlert() {
    this.alert = null;
  }

  displayAlert = (res) => {
    this.alert = res;
    setTimeout(() => {
      this.alert = null;
      this.spinnerService.toggleSpinner(0);
   }, 4000);
  }

  toogleSideNav(event?) {
    this.toogleSideNavMenu = !this.toogleSideNavMenu;
  }

  expandSideNavFun() {
    this.expandSideNav = !this.expandSideNav;
  }

}
