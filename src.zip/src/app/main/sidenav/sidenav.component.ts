import { Component, OnInit,ViewChild,Output, EventEmitter,ElementRef, Input } from '@angular/core';
import { LoginService } from '../../login/login.service';
import { UserService } from '../../shared/services/user.service';
import { Router } from '@angular/router';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { AppConfigService } from 'src/app/app-config.service';
import { DataService } from 'src/app/shared/services/data.service';
@Component({
  selector: 'app-sidenav',
  templateUrl: './sidenav.component.html',
  styleUrls: ['./sidenav.component.less']
})
export class SidenavComponent implements OnInit {
  @ViewChild('kibanaData', { static: false }) kibanaData: ElementRef;
  @ViewChild('mongoData', { static: false }) mongoData: ElementRef;

  sideNavList = [];
  sideCommonNavList = [];
  vendorOnBoardingList = [];
  showItem = true;
  isValid = true;  
  loggedUser: any;
  manageSelected = false;
  provisionSelected = false;
  roleManagementShow = false;
  repoSelect=false;
  manageList = [];
  rolesListArray = [];
  provisionList = [];
  t2rList = [];
  reportList=[];
  t2rSelected = false;

  // customer configuration related
  custConfigMgmtList = [];
  custConfigMgmtSelected = false;


  // Dashboard related
  dashboardList = [];
  dashboardSelected = true;

  kibanaUrl: string = "http://10.162.0.58:5601/app/kibana#/dashboards";
  mongoUrl: string = "http://10.162.1.5/login";

  urlSafe: SafeResourceUrl;
  mongoSafe: SafeResourceUrl;
  provision;
  dashBoardName;
  manageName;
  configName;
  t2rName;
  provisionName;
  subModulesList;
  subsequent;
  provisionSubMenu;
  configSubMenu;
  t2rSubMenu;



  @Output() toogleSideNav = new EventEmitter();
  @Output() expandSideNav = new EventEmitter();
  @Input() toogleSideNavMenuValue;
  constructor(private ngbModal: NgbModal,
              private loginService: LoginService,
              private userService: UserService,
              private sanitizer: DomSanitizer,
              private router: Router,
              private acs: AppConfigService,
              private dataService: DataService) { }

  ngOnInit() {
    this.loggedUser = this.userService.getLoggedUserName();
   
     // If they login first time don't show side navigation menu
     const firstTimeLogin = this.dataService.getLocalStorage('update-password');
     if(!firstTimeLogin) {
       this.getMenuLinks();
     }
  }
  manageSelectedFun() {
    this.manageSelected = !this.manageSelected;
    this.sidenav=false;
    this.provisionSelected=false;
    this.repoSelect=false;
    this.t2rSelected=false;
    this.dashboardSelected=false;
    this.custConfigMgmtSelected=false;
  }
  provisionSelectedFun() {
    this.provisionSelected = !this.provisionSelected;
    this.sidenav=false;
    this.manageSelected=false;
    this.repoSelect=false;
    this.t2rSelected=false;
    this.dashboardSelected=false;
    this.custConfigMgmtSelected=false;
 
  }
  t2rSelectFun() {
    this.t2rSelected = !this.t2rSelected;
    this.sidenav=false;
    this.manageSelected=false;
    this.repoSelect=false;
    this.provisionSelected=false;
    this.dashboardSelected=false;
    this.custConfigMgmtSelected=false;
  }

  repoSelectfun(){
    this.repoSelect=!this.repoSelect;
    this.manageSelected=false;
    this.t2rSelected=false;
    this.provisionSelected=false;
    this.dashboardSelected=false;
    this.custConfigMgmtSelected=false;
    this.sidenav=false;
  }

  // customer configuration related

  custConfigManagementSelected() {
    this.custConfigMgmtSelected = !this.custConfigMgmtSelected;
    this.sidenav=false;
    this.configSubMenu =false;
    this.manageSelected=false;
    this.t2rSelected=false;
    this.provisionSelected=false;
    this.dashboardSelected=false;
    this.repoSelect=false;
  }

    // Dashboard Section

    dashboardSelectedFun() {
      this.dashboardSelected = !this.dashboardSelected;
      this.manageSelected=false;
      this.t2rSelected=false;
      this.provisionSelected=false;
      this.custConfigMgmtSelected=false;
      this.repoSelect=false;
      this.sidenav=false;
     }


 
  sidenav=false;
  roleManagement() {
    this.roleManagementShow = !this.roleManagementShow;
   }
  gloablLinkClick(value, mainData?) {
    mainData.forEach(dataCheck => {
      dataCheck.show = false;
    });
    value.show = true; 
    if(value.subGroups) {
     this.sidenav=true;
     this.getSubModulelsData(value);
    } else {
      value.show = false;
      this.router.navigate([value.route]);
      this.clearAll(); 
    }
  }

  getSubModulelsData(value) {
    this.subModulesList = [];
    value.subGroups.forEach(subGroup => {
        this.subModulesList.push({moduleCode: subGroup.moduleCode, label: subGroup.moduleName, route: '/main/' + subGroup.moduleCode});
    });
  }

  getSubSquentData(value) {
    this.subsequent = [];
    value.subsequent.forEach(subGroup => {
        this.subsequent.push({moduleCode: subGroup.moduleCode, label: subGroup.moduleName, route: '/main/' + subGroup.moduleCode});
    });
  }
  provisionLinkClick() {
    // this.roleManagementShow = false;
    // this.manageSelected = true; 
  }
  liClick(moduleName, data?, mainData?) {
    mainData.forEach(dataCheck => {
      dataCheck.show = false;
    });
    if(data && data.subGroups) {
      data.show = true; 
      if(moduleName == 'custconfig') {
        this.configSubMenu = true;
      } else if(moduleName == 'provision') {
        this.provisionSubMenu = true;
      }  else if(moduleName == 't2r') {
        this.t2rSubMenu = true;
      }      
       this.getSubModulelsData(data);
     } else {
      this.router.navigate([data.route]);
       data.show = false; 
      this.clearAll();
     } 
  }
  clearAll() {
    this.provisionSelected = false;
       this.provisionSubMenu=false;
       this.custConfigMgmtSelected=false;
       this.configSubMenu = false;
       this.t2rSelected = false;
       this.t2rSubMenu = false;
       this.sidenav=false;
       this.manageSelected=false; 
  }
  redirectLink(url) {
    this.clearAll();
    this.router.navigate([url]);
  }
  getMenuLinks() {
    this.loginService.getUserMenus().subscribe(res => {
       if (res.data) {
          if(res.data.groups) {
             const userPrevilageAccess = res.data.groups;
             userPrevilageAccess.forEach(userPreAccess => { 

             // Reports Section
             if(userPreAccess._id == 'REPORT') {
              this.reportList = [];
              this.reportList.push({label: 'IOT Data Explorer', route: '/main/reference'})
            }  
            
            //Dashboard Section
            if(userPreAccess._id == 'DBOARD') {
              this.dashboardList = [];
              this.dashboardList.push({label: userPreAccess.groupName, route: '/main/'+ userPreAccess._id.toLowerCase()});
              this.dashBoardName = userPreAccess.groupName;
            }           

              if(userPreAccess.subsequent) {
                userPreAccess.subsequent.forEach(moduleInfo => {
                  
              const moduleCode = moduleInfo.moduleCode ? moduleInfo.moduleCode.toLowerCase() : '';
              const moduleName = moduleInfo.moduleName ? moduleInfo.moduleName : '';  
              
               


              // Manage Section
              if(userPreAccess._id == 'MANAGE') {
                this.manageName = userPreAccess.groupName;
                    // Role managemnt section
                    if(moduleInfo.moduleCode == 'ROLMGM') {
                     let subGroupArray = [];
                        if(moduleInfo.subModules) {
                          moduleInfo.subModules.forEach(subsequent => {
                            const subModuleCode = subsequent.subModuleCode.toLowerCase();

                            this.rolesListArray.push({
                              label: subsequent.subModuleName, 
                              route: '/main/' + moduleCode + '/'+ subModuleCode
                            });

                            subGroupArray.push({
                              moduleCode: moduleCode + '/'+ subModuleCode,
                              moduleName: subsequent.subModuleName
                            });

                          });
                        }
                      this.manageList.push({moduleCode: moduleCode, label: moduleName, route: '/main/' + moduleCode, subGroups: subGroupArray, show: false})
                    }if(moduleInfo.subsequent && moduleInfo.groupName) {
                      let subGroupArray = [];
                      moduleInfo.subsequent.forEach(subsequent => {
    
                        if(subsequent.moduleCode) {
                          const subModuleCode = subsequent.moduleCode.toLowerCase();
    
                          subGroupArray.push({
                            moduleCode: subModuleCode,
                            moduleName: subsequent.moduleName
                          }); 
                        }                  
                      });
                    this.manageList.push({label: moduleInfo.groupName, subGroups: subGroupArray, show: false})
                    }else {
                      this.manageList.push({moduleCode: moduleCode, label: moduleName, route: '/main/' + moduleCode, show: false});
                    }
              }

              // Config management Section
              if(userPreAccess._id == 'CONFIG') {
                this.configName = userPreAccess.groupName;
                if(moduleInfo.subsequent && moduleInfo.groupName) {
                  let subGroupArray = [];

                  moduleInfo.subsequent.forEach(subsequent => {

                    if(subsequent.moduleCode) {
                      const subModuleCode = subsequent.moduleCode.toLowerCase();

                      subGroupArray.push({
                        moduleCode: subModuleCode,
                        moduleName: subsequent.moduleName
                      }); 
                    }                  
                  });
                this.custConfigMgmtList.push({label: moduleInfo.groupName, subGroups: subGroupArray, show: false})
                } else {
                  this.custConfigMgmtList.push({label: moduleName, route: '/main/' + moduleCode, show: false})
                }
               
              }    
              
               // Trouble Shoot section
               if(userPreAccess._id == 'TSHOOT') {
                this.t2rName = userPreAccess.groupName;
                if(moduleInfo.subsequent && moduleInfo.groupName) {
                  let subGroupArray = [];

                  moduleInfo.subsequent.forEach(subsequent => {

                    if(subsequent.moduleCode) {
                      const subModuleCode = subsequent.moduleCode.toLowerCase();

                      subGroupArray.push({
                        moduleCode: subModuleCode,
                        moduleName: subsequent.moduleName
                      }); 
                    }                  
                  });
                this.t2rList.push({label: moduleInfo.groupName, subGroups: subGroupArray, show: false})
                } else {
                this.t2rList.push({label: moduleName, route: '/main/' + moduleCode})
                }
               }

               // Provision Section
              if(userPreAccess._id == 'PRVSON') {
                this.provisionName = userPreAccess.groupName;

                if(moduleInfo.subsequent && moduleInfo.groupName) {
                  let subGroupArray = [];

                  moduleInfo.subsequent.forEach(subsequent => {

                    if(subsequent.moduleCode) {
                      const subModuleCode = subsequent.moduleCode.toLowerCase();

                      subGroupArray.push({
                        moduleCode: subModuleCode,
                        moduleName: subsequent.moduleName
                      }); 
                    }                  
                  });
                this.provisionList.push({label: moduleInfo.groupName, subGroups: subGroupArray, show: false})
                } else {

                this.provisionList.push({label: moduleName, route: '/main/' + moduleCode})
                }
              }  

            }); 
          }


             });
           }
         }
     });
   }

   modalConfig = {
    create: { headerText: 'Create New Partner', primeBtnText: 'Create' },
    edit: { headerText: 'Edit Partner', primeBtnText: 'Update' },
    sige: { sm: 'sm', lg: 'lg' }
  };
  
   openModal(content: any, size, event?: any) {
    this.ngbModal
     .open(content, {
       windowClass: 'kibana',
       size: size,
       keyboard: false
     })
     .result.then(result => {}, reason => {});
 }

 closeModel(close: any) {
  close('Cross click');
}
 
   drilDownPopup(){
    this.urlSafe= this.sanitizer.bypassSecurityTrustResourceUrl(this.kibanaUrl);
     this.openModal(this.kibanaData, this.modalConfig.sige.lg);
   }

   aggregatePopup(){
    window.open( 
    this.mongoUrl, "_blank"); 
   }

    closeManageArea(){
      this.manageSelected=false;
      this.sidenav=false;
    }
    closeProvisionArea(){
        this.provisionSelected = false;
        this.provisionSubMenu = false;
    }
    closeConfigArea() {
      this.custConfigMgmtSelected=false;
      this.configSubMenu = false;
    }
    closet2rArea(){
      this.t2rSelected = false;
      this.t2rSubMenu = false;
    }
    closeReportArea(){
      this.repoSelect=false;
    }
}
