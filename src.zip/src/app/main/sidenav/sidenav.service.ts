import { Injectable } from '@angular/core';
import { InterceptorService } from '../../shared/services/interceptor.service';

@Injectable()
export class SidenavService {

   constructor(private interceptor: InterceptorService) { }

   getMenuLinks(request) {
    return this.interceptor.httpCall('get', 'sideMenuLinks', request);
   }
}
