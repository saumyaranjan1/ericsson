import { Injectable } from '@angular/core';
import { InterceptorService } from '../../shared/services/interceptor.service';
import { Subject, BehaviorSubject } from 'rxjs';
import { AppConfigService } from 'src/app/app-config.service';
import { UrlMappingsService } from 'src/app/shared/services/url-mappings.service';
import { HttpClient } from '@angular/common/http';
import { AuthorizationService } from 'src/app/shared/authGuard/authorization.service';

@Injectable({
  providedIn: 'root'
})
export class HeaderService {

  constructor(private interceptor: InterceptorService,
    private appConfig: AppConfigService,
    private UrlMap: UrlMappingsService,
    private http: HttpClient,
    private authorizationService: AuthorizationService) { }

  private myFunctionCallSource = new Subject();
  unsubscribe$ = new Subject();

  getDomainDropdownRole(value){
    const domainArr = ["main/autops","main/campps","main/psapps","main/psconf","main/psfirm"];
    if (domainArr.indexOf(value) > -1) {
        return true;
      } else {
        return false;
    }
  }



  logOut() {
    let request = {
      jioUtils : true
    };
    return this.interceptor.httpCall('post', 'logout', request);
  }

  setDomain(data){
    this.setToStorage('domain',data);
    this.myFunctionCallSource.next(data)
  }

  setToStorage(key,val){
    sessionStorage.setItem(key, JSON.stringify(val));
  }

  /**
   * Get Domain Info
   */
  getSelectedDomain(){
    let _res = sessionStorage.getItem('domain');
    return JSON.parse(_res);
  }

  getDomainInfo() {
    return this.interceptor.httpCall('get', 'getDomainInfo');
  }

  getDoamin$ = this.myFunctionCallSource.asObservable();
  
  domainRemove() {
    this.unsubscribe$.next(true);
    this.unsubscribe$.complete();
  }

  
/**
 * HTTP call to get the new Authization Token
 */
refreshToken() {
  const loginObj = {
    grant_type: 'refresh_token',
    client_id: 'test',
    client_secret: 'test',
    refresh_token: this.authorizationService.getRefreshToken()
  };
  const privateVar = this.appConfig.configData['private'];
  const serverUrl = this.appConfig.configData['getBaseUrl'];
  const url = serverUrl + this.UrlMap.getEndUrl(privateVar ? 'privateLogin' : 'publicLogin');
  return this.http.post(url, loginObj);
}
    

    
}
