import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { DataService } from '../../shared/services/data.service';
import { HeaderService } from './header.service';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { AppConfigService } from 'src/app/app-config.service';
import { AuthorizationService } from '../../shared/authGuard/authorization.service';
import { interval } from 'rxjs';
import { EnumsService } from '../../shared/services/enums.service';
import { UserService } from '../../shared/services/user.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.less']
})
export class HeaderComponent implements OnInit {
  title;
  loginMemberInfo = {
    loginId: '',
    lastLoginTime: ''
  };
  domainInfo = [];
  privateVar;
  domainDropdown = true;
  showMunuElements = false;
  category;
  showChangePlatformPassword = false;
  showChangepPortalPassword = false;
  constructor(private titleService: Title,
    private userService: UserService,
    private authorizationService: AuthorizationService,
    private dataService: DataService, private router: Router,
    private acs: AppConfigService,
    private headerService: HeaderService) { }

  ngOnInit() {
    this.title = 'Jio Portal';
    this.getActions();
    this.titleService.setTitle(this.title);
    this.getLoginMemberInfo();
    this.privateVar = this.acs.configData['private'];
    this.category = this.dataService.getAtobLocalStorage('category');
    this.refresh();
  }

  getActions() {
    const _module = EnumsService.PROFILE;

    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

    // API to get Previliages
    if(this.dataService.getAtobLocalStorage('roleId')){
      this.userService.getPreViliages(obj).subscribe(prev => {
        if (prev && prev.data && prev.data.privilege) {
          prev.data.privilege.forEach(element => {
            if (element.code == "JHCHPP") {
              this.showChangePlatformPassword = true;
            } else if (element.code == "JHCHWP") {
              this.showChangepPortalPassword = true;
            }
          });
        }
      });
    }
   
  }

  getLoginMemberInfo() {
    this.loginMemberInfo.lastLoginTime = this.dataService.getLocalStorage(
      'user'
    )
      ? this.dataService.getLocalStorage('user').lastLoginTime
      : null;
    this.loginMemberInfo.loginId = this.dataService.getParseAndAtob(
      'loginMember'
    ).split('@')[0].replace('.', ' ');
  }
  logOut() {
    sessionStorage.clear();
    this.router.navigate(['/login']);
  }
  changePassword(type) {
    this.dataService.setLocalStorage('passwordType', JSON.stringify(type));
    this.router
      .navigateByUrl('../main', { skipLocationChange: true })
      .then(() => this.router.navigate(['../main/update-password']));
  }

  /**
   * Refresh token calling half time of exp time provided by API 
   */
  refresh() {
    const expTimeInMinutes = this.authorizationService.getExpTimeInMinutes();
    interval(60000 * expTimeInMinutes)
      .subscribe((val) => {
        this.headerService.refreshToken().subscribe(
          res => {
            const logInTime = new Date();
            res['loginTime'] = logInTime.getTime();
            this.dataService.setLocalStorage('user', JSON.stringify(res));
          },
          error => {
            this.dataService.broadcast('alert', {
              type: 'danger',
              message: error.error || 'Refresh Token API Failed!'
            });
          }
        );
      });
  }
  showMenu() {
    this.showMunuElements = true;
  }
  closeMunuElements() {
    this.showMunuElements = false;
  }
}
