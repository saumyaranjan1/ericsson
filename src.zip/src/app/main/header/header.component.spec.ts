import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderComponent } from './header.component';
import {By} from '@angular/platform-browser';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HeaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have header-wrap class', () => {
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.firstChild.className).toEqual('header-wrap');
  });

  it('should not display the profile modal unless the button is clicked', () => {

    const compiled = fixture.debugElement.nativeElement;
    const dropDown = compiled.children[0].children[1].children[0];
    expect(dropDown).not.toContain('.show');
  });

});
