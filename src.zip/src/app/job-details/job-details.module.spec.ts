import { JobDetailsModule } from './job-details.module';

describe('JobDetailsModule', () => {
  let jobDetailsModule: JobDetailsModule;

  beforeEach(() => {
    jobDetailsModule = new JobDetailsModule();
  });

  it('should create an instance', () => {
    expect(jobDetailsModule).toBeTruthy();
  });
});
