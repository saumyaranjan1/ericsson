import { Injectable } from '@angular/core';
import { InterceptorService } from './../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class JobDetailsService {

  constructor(private interceptor: InterceptorService) { }

  getJobsList(version) {
    return this.interceptor.httpCall('get', version ? 'v2JobList' : 'jobList');
  }
  getJobDetails(request, version) {
    return this.interceptor.httpCall('get', version ? 'v2Jobdetails' :'jobdetails', request);
  }
  jobState(request, version) {
    return this.interceptor.httpCall('get', version ? 'v2JobState' :'jobState', request);
  }
  deleteJob(request, version) {
    return this.interceptor.httpCall('delete', version ? 'v2DeleteJob' :'deleteJob', request);
  }
}
