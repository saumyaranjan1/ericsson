import { JobDetailsRoutingModule } from './job-details-routing.module';

describe('JobDetailsRoutingModule', () => {
  let jobDetailsRoutingModule: JobDetailsRoutingModule;

  beforeEach(() => {
    jobDetailsRoutingModule = new JobDetailsRoutingModule();
  });

  it('should create an instance', () => {
    expect(jobDetailsRoutingModule).toBeTruthy();
  });
});
