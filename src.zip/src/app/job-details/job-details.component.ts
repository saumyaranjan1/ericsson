import { Component, OnInit,Input } from '@angular/core';
import { JobDetailsService } from './job-details.service';
import { EnumsService } from '../shared/services/enums.service';
import { DataService } from '../shared/services/data.service';
import { forkJoin } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-job-details',
  templateUrl: './job-details.component.html',
  styleUrls: ['./job-details.component.less']
})
export class JobDetailsComponent implements OnInit {
  @Input() versionTwo;
  searchData = [ {
    displayName: 'Job ID',
    key: 'itemName',
    filter: ''
  }];
  data = {
    data: [],
    innerData:[],
    columns: [
      {
        displayName: 'Job Name',
        key: 'itemName',
        filter: ''
      },
      {
        displayName: 'IMEI',
        key: 'imei',
        filter: ''
      },
      // {
      //   displayName: 'Service Status',
      //   key: 'servicestatus',
      //   filter: ''
      // },
      // {
      //   displayName: 'Plan Name',
      //   key: 'planname',
      //   filter: ''
      // },
      // {
      //   displayName: 'Description',
      //   key: 'jobDescription',
      //   filter: ''
      // },
      // {
      //   displayName: 'Status',
      //   key: 'status',
      //   filter: ''
      // },
      {
        displayName: 'Remarks',
        key: 'reason',
        filter: ''
      }
    ],
    actions: [],
    actionsLabel: 'Actions',
    tableHeader: 'Bulk Uploads',
    tableActions: {
      delete: true
    },
    totalCount: 0,
    pageNum: 1
  };
  successData = {
    data: [],
    columns: [
      {
        displayName: 'IMEI',
        key: 'imei'
      },
      {
        displayName: 'Reason',
        key: 'reason',
        filter: ''
      }
    ],
    tableHeader: 'Success Device Details',
    tableActions: {
      search: true,
      add: true,
      view: true,
      delete: true,
      edit: true
    }
  };
  failureData = {
    data: [],
    columns: [
      {
        displayName: 'IMEI',
        key: 'imei',
        filter: ''
      },
      {
        displayName: 'Reason',
        key: 'reason',
        filter: ''
      }
    ],
    tableHeader: 'Failure Device Details',
    tableActions: {
      search: true,
      add: true,
      view: true,
      delete: true,
      edit: true
    }
  };

  jobDetailsList = [];
  selectedJobDetailsList = [];
  progressResult = 0;
  dropdownSettingsForJob = EnumsService.SINGLE_SELECT_DROPDOWN_OPTIONS;
  selectedJobId;
  selectedJobName;
  sorting = {
    column: null,
    descending: false
  };

  constructor(private jobDetailsService: JobDetailsService,
    private dataService: DataService,
    public router: Router) { }

  ngOnInit() {
    this.getJobsList();
    this.dropdownSettingsForJob.text = 'Please Select Job';
  }

  getJobsList() {
    this.jobDetailsList = [];
    this.jobDetailsService.getJobsList(this.versionTwo).subscribe(res => {
      if (res) {
        res.map(resultData => {
          this.jobDetailsList.push({
            id: resultData.jobId,
            itemName: resultData.jobDescription,
            check: false,
            progressResult : Math.ceil((resultData.progressCount / resultData.totalCount) * 100),
            totalCount: resultData.totalCount
          });
        // this.data.data= this.jobDetailsList;
        });
      }
    });
  }


 showHideInnerTable(event,id,rowlength){

  this.jobDetailsList.forEach((item,key) => {
    if(item.id==id){
      item.check=!item.check;
    }else{
      item.check=false;
    }
    });
 }


  getJobDetails(event,index,rowlength) {
    this.showHideInnerTable(event,event.id,rowlength);
    if(event.check){
      const data = {};
      data['appendUserId'] = true;
      data['userId'] = event.id;
      this.selectedJobId = event.id;
      this.selectedJobName = event.itemName;
      const jobDetails = this.jobDetailsService.getJobDetails(data, this.versionTwo);
      data['appendUserId'] = true;
      const jobState = this.jobDetailsService.jobState(data, this.versionTwo);
      forkJoin([jobDetails, jobState]).subscribe(
        results => {
          if (results[0]) {
            this.failureData.data = results[0].failureList ? results[0].failureList : [];
            const succesArray = [];
            if (results[0].successList) {
              results[0].successList.map(item => {
                succesArray.push({ imei: item, reason: 'success'});
              });
            }
          this.successData.data = succesArray;
          succesArray.push(...this.failureData.data);
          this.data.data = succesArray;
           }
          if (results[1]) {
            this.progressResult = Math.ceil((results[1].progressCount / results[1].totalCount) * 100);
          }
          
          return data;  
        },
        error => {
          this.progressResult = 0;
          this.successData.data = [];
          this.failureData.data = [];
        }
      );
    }
    
  }

  deleteJob() {
    this.jobDetailsService.deleteJob(this.selectedJobId, this.versionTwo).subscribe(res => {
      this.dataService.broadcast('alert', {
        type: 'success',
        message: this.selectedJobName + ' is Deleted Successfully !'
      });
      this.router.navigateByUrl('../main/app_ui_api', { skipLocationChange: true }).then(() =>
        this.router.navigate(['../main/job-details']));
    });
  }

  pagination = {
    page: 0,
    startIndex: 0,
    countPerPage: EnumsService.paginationObj.recordsPerPage,
    maxSize: 5,
    displyedResults: 0,
    stratingNumberOfSelectedPage: 0
  };

  innerPagination = {
    page: 0,
    startIndex: 0,
    countPerPage: EnumsService.paginationObj.recordsPerPage,
    maxSize: 5,
    displyedResults: 0,
    stratingNumberOfSelectedPage: 0
  };

  changeSorting(columnName): void {
    const sort = this.sorting;
    if (sort.column === columnName) {
      sort.descending = !sort.descending;
    } else {
      sort.column = columnName;
      sort.descending = false;
    }
  }

}
