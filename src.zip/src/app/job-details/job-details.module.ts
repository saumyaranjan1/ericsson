import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from './../shared/shared.module';
import { JobDetailsRoutingModule } from './job-details-routing.module';
import { JobDetailsComponent } from './job-details.component';
import { JobDetailsService } from './job-details.service';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';

@NgModule({
  imports: [
    CommonModule,
    JobDetailsRoutingModule,
    SharedModule,
    AngularMultiSelectModule
  ],
  declarations: [JobDetailsComponent],
  providers: [JobDetailsService]
})
export class JobDetailsModule { }
