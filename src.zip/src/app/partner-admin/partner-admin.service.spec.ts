import { TestBed } from '@angular/core/testing';

import { PartnerAdminService } from './partner-admin.service';

describe('PartnerAdminService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PartnerAdminService = TestBed.get(PartnerAdminService);
    expect(service).toBeTruthy();
  });
});
