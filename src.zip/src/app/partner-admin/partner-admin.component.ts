import { Component, OnInit, ViewChild, ElementRef  } from '@angular/core';
import { PartnerAdminEnumsService } from './partner-admin-enum-service';
import { PartnerAdminService } from './partner-admin.service';
import { InlinePagenationTableComponent } from '../shared/components/inline-pagenation-table/inline-pagenation-table.component';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../shared/services/data.service';

import { UserService } from '../shared/services/user.service';
import { EnumsService } from '../shared/services/enums.service';

@Component({
  selector: 'app-partner-admin',
  templateUrl: './partner-admin.component.html',
  styleUrls: ['./partner-admin.component.less']
})
export class PartnerAdminComponent implements OnInit {

  @ViewChild(InlinePagenationTableComponent,{ static: false }) child: InlinePagenationTableComponent;
  @ViewChild('kafkaConsumerIpTemplate', { static: false }) kafkaConsumerIpTemplate: ElementRef;
  @ViewChild('errorTemplate', { static: false }) errorTemplate: ElementRef;
  data = {
    data: [],
    columns: [
      {
        displayName: 'Enterprise Name',
        key: 'hqbpName',
        filter: '',
        input: true,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:false,
        externalConsumerIps:false
      },
      {
        displayName: 'Partner ID',
        key: 'partnerId',
        filter: '',
        input: true,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:false,
        externalConsumerIps:false
      },
      {
        displayName: 'No.OF KAFKA TOPICS',
        key: 'noofTopics',
        filter: '',
        input: true,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:false,
        externalConsumerIps:false
      },
      {
        displayName: 'LIST OF KAFKA TOPICS',
        key: 'topics',
        filter: '',
        input: true,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:false,
        externalConsumerIps:false
      },
      {
        displayName: 'Status',
        key: 'status',
        filter: '',
        input: true,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:false,
        externalConsumerIps:false
      },
      {
        displayName: 'KAFKA CONSUMER IP',
        key: 'externalConsumerIps',
        filter: '',
        input: false,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:true,
        externalConsumerIps:true
      }
    ],
    actions: [],
    actionsLabel: 'Actions',
    tableHeader: 'Stream Consumer Enterprise Configuration',
    tableActions: {
    },
    total: 3,
    headerDropdownList: [],
    checkStatusBeforeEdit: true,
    moduleName: EnumsService.STRCFG
  };
  kafkaConsumerIpForm: FormGroup;
  selectedRowdata;
  originalDbDataOject;
  actionsArr;
  errorMessage;

  constructor(private pas: PartnerAdminService,
    private ngbModal: NgbModal,
    private fb: FormBuilder,
    private cms: CommonMethodsService,
    private userService: UserService,
    private dataService: DataService) { }

  ngOnInit() {
  }

  /**
   * 
   * Get Stream configurations informatio from DB
   * 
   */

  getStreamInfo(params){
    this.getActions();
    this.pas.getStreamInfo(params).subscribe(res => {
      if (res) {
        this.data.data = res.data;
        this.data.headerDropdownList = res.searchAttributes; 
        this.data.data.forEach( data => {
          data['topics'] =   data.streamConsumer ? data.streamConsumer.topics: [] ;
          data['externalConsumerIps'] =  data.streamConsumer && data.streamConsumer.externalConsumerIps ? data.streamConsumer.externalConsumerIps : [];
          data['noofTopics'] = data['topics'].length;
        });  
       this.originalDbDataOject = this.cms.deepCopyOfObject(this.data.data);     
       this.data.total = res.totalCount;
       this.child.updateEditCache('notEdit');
       }
    });
  }

  /**
   * 
   * Get Priviliges of logged in user to access strem config module
   * 
   */
  getActions(){
   const _module = EnumsService.STRCFG;
 // Form object to get the previliiages from server
 const obj = {
  moduleCode: _module,
  roleId: this.dataService.getAtobLocalStorage('roleId'),
  previliages: true
};
    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe( prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

    this.data.tableActions = this.actionsArr.headerRights;
    this.data.tableActions['dropDown'] = true;
    this.data.actions =  this.actionsArr.actionsArray;
    this.data.actions.push({
      type: 'addips',
      title: 'Add Ips',
      showIconProp: null,
      disableIconProp: true,
      negate: null
    });
      
    });
  }

  /**
   * 
   * 
   * Kafka Consumer IP from Block Intiation
   * 
   */

  getIpFormBlock(ip?) {
    this.kafkaConsumerIpForm = this.fb.group({
      ip: [
        '',
        [
          this.cms.patternValidator(
            /\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\.|$)){4}\b/,
            { isValidUrl: true }
          )
        ]
      ]
    });
  }

  /**
   * openIpModalForm to collect IPS
   */

  openIpModalForm(event) {
    this.selectedRowdata = event;
    this.getIpFormBlock();
    this.openModal(this.kafkaConsumerIpTemplate, 'sm');
  }

  /**
   * Open Modal
   */

  openModal(content, size) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal user-onboard',
        size,
        backdrop: 'static',
        keyboard: false
      })
      .result.then(
        result => {},
        reason => {}
      );
  }

  /**
   * 
   *  close Modal
   */
  closeModal(close) {
    // this.child.modalOpned = false;
    close('Cross click');
    this.errorMessage = '';
  }

  /**
   * Submit form with data
   */
  submitForm(form, close) { 
    if (form.valid) {
      this.data.data.forEach(info => {
        if(info.id == this.selectedRowdata.id) {
          if(!info['externalConsumerIps'].includes(form.value.ip)) {
            if(form.value.ip) {
               info['externalConsumerIps'].push(form.value.ip);
            }
          } else {
            this.dataService.broadcast('alert', {
              type: 'danger',
              message: `Please try with different IP`
             });
          }
        }
      });
      this.closeModal(close);
    } else {
      this.cms.validateAllFormFields(form);
    }
  }

  /**
   * Save form data in DB
   */
  saveFormData(event) {
    if(event.data.externalConsumerIps.length > 0) {

      //ComparingData With original object with Modified data, only if any ips are modified we have to send to DB other wise not required

      this.originalDbDataOject.forEach(element => {
        if(element.id == event.data.id) {

          // Comapring Two arrays
          if(!this.cms.arraysEqual(element.externalConsumerIps, event.data.externalConsumerIps)) {
            
            const data = {
              externalConsumerIps: event.data.externalConsumerIps,
              userServicesId: event.data.userServicesId,
              streamId: event.data.id
            };
            this.updateExternalConsumerIps(data, event);    
          }
        }
      }); 

    } else {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: `Atleast One Ip should be present`
       });
    }
  }

/**
 * Update Consumer IPs
 */

updateExternalConsumerIps(data, event){
  this.pas.updateStreamInfo(data).subscribe(res => {
    if (res) {
      this.dataService.broadcast('alert', {
        type: 'success',
        message: res.message
       });
      this.child.getPage(1);
      this.child.cancelEdit(event.data);
      this.child.submit=false;
     }
  });
 }

 /**
  * Show error template
  */
 showErrorTemplate(event) {
  this.errorMessage = `Modification is not allowed, as the privious request is under processing stage`;
  this.openModal(this.errorTemplate, 'sm');
 }

}


