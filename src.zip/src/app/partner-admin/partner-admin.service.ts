import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class PartnerAdminService {

  constructor(private interceptorService: InterceptorService) { }


  getStreamInfo(request) {
    return this.interceptorService.httpCall('get', 'getStreamInfo', request);
  }

  updateStreamInfo(request) {
    return this.interceptorService.httpCall('put', 'getStreamInfo', request);
  }
}
