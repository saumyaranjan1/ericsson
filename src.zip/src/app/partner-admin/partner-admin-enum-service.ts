import { Injectable } from '@angular/core';

@Injectable()
export class PartnerAdminEnumsService {
    
  public static partnerAdminData = {
    data: [],
    columns: [
      {
        displayName: 'Enterprise Name',
        key: 'enterpriseName',
        filter: '',
        input: true,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:false
      },
      {
        displayName: 'No.OF KAFKA TOPICS',
        key: 'noofTopics',
        filter: '',
        input: true,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:false
      },
      {
        displayName: 'LIST OF KAFKA TOPICS',
        key: 'topics',
        filter: '',
        input: true,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:false
      },
      {
        displayName: 'Status',
        key: 'status',
        filter: '',
        input: true,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:false
      },
      {
        displayName: 'KAFKA CONSUMER IP',
        key: 'kafkaIps',
        filter: '',
        input: true,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:false
      }
    ],
    actions: [ 
      ],
    actionsLabel: 'Actions',
    tableHeader: 'Stream Consumer Enterprise Configuration',
    tableActions: {
      search: true,
      add: false,
      delete: false,
      edit: true,
      save: true,
      times: true
    },
    total: 0
  };
  constructor() {}
}
