import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PartnerAdminComponent } from './partner-admin.component';
import { PartnerAdminRoutingModule } from './partner-admin-routing.module';
import { SharedModule } from '../shared/shared.module';
import { PartnerAdminService } from './partner-admin.service';



@NgModule({
  declarations: [PartnerAdminComponent],
  imports: [
    CommonModule,
    PartnerAdminRoutingModule,
    SharedModule
  ],
  providers: [PartnerAdminService]
})
export class PartnerAdminModule { }
