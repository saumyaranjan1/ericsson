import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserManagementAbacComponent } from './user-management-abac.component';
import {UserManagementAbacRoutingModule} from './user-management-abac-routing.module'
import { SharedModule } from '../shared/shared.module';


@NgModule({
  declarations: [UserManagementAbacComponent],
  imports: [
    CommonModule,
    UserManagementAbacRoutingModule,
    SharedModule
  ]
})
export class UserManagementAbacModule { }
