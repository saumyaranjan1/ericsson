import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserManagementAbacEnumService {
  public static DATA = {
    columns: [
      {
        displayName: 'First Name',
        key: 'userFullName',
        filter: ''
      },
      {
        displayName: 'Last Name',
        key: 'lastname',
        filter: ''
      },
      {
        displayName: 'Email',
        key: 'email',
        filter: ''
      },
      {
        displayName: 'Mobile',
        key: 'mobile',
        filter: ''
      },
      {
        displayName: 'Enterprise',
        key: 'enterprises',
        filter: ''
      },
      {
        displayName: 'Devices',
        key: 'devices',
        filter: ''
      },
      {
        displayName: 'Role Category',
        key: 'category',
        filter: ''
      },
      {
        displayName: 'Action',
        key: 'abacaction',
        filter: ''
      }
    ],
    actions: [
    ],
    showGridCheckBox:true,
    actionsLabel: '',
    tableHeader: 'User Management',
    tableActions: {
      add: true,
      search: true,
      dropdown: true
    },
  };
}



