import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserManagementAbacComponent } from './user-management-abac.component';

const routes: Routes = [{ path: '', component: UserManagementAbacComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserManagementAbacRoutingModule { }