import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class UserManagementAbacService {

  constructor(private interceptor: InterceptorService) { }

  getProfileUserList(request) {
    return this.interceptor.httpCall('post', 'getUserProfileData', request);
  }

  getUserProfileByID(request) {
    return this.interceptor.httpCall('get', 'getUserProfileByID', request);
  }
  
  getObject(request) {
    const key = request['dropDownValue'].trim();
    const value = request['searchKey'].trim();
    const dataObj = {};
    if (request.dropDownValue.trim() === 'deviceid') {
      let deviceSpace = request.searchKey.split(",");
      let deviceIds = [];
      if (deviceSpace && deviceSpace.length > 0) {
        deviceSpace.forEach(element => {
          deviceIds.push(element);
        });
      } else {
        deviceIds.push(deviceSpace);
      }
      dataObj['deviceIds'] = value;
    } else {
      dataObj['domain'] = value;
    }
    return dataObj;
  }

  saveProfileUserList(request, createOrEditUser) {
    if (createOrEditUser == 'Create') {
      return this.interceptor.httpCall('post', 'saveProfileUserList', request);
    } else if (!request.id) {
      return this.interceptor.httpCall('post', 'createProfileUserList', request);
    } else if (request.id) {
      request['extraParams'] = "?id=" + request.id;
      delete request.id
      return this.interceptor.httpCall('patch', 'saveProfileUserList', request);
    }

  }
  /**
     * Get Search User Management Details
     */
  getSearchUserProfileData(params) {
    return this.interceptor.httpCall('get', 'getSearchUserProfileData', params);
  }

  deleteProfileUserList(request) {
    let params = {};
    params['extraParams'] = "?id=" + request.id;
    return this.interceptor.httpCallReturn('delete', 'deleteProfileUserList', params);
  }

  getEnterpriseList(request) {
    return this.interceptor.httpCall('get', 'enterpriseList', request);
  }

  getDeviceList(request) {
    let params = {};
    params['extraParams'] = "/" + request.userId + "?rpp=500&pageNum=1";
    return this.interceptor.httpCall('get', 'getUserManagementDeviceList', params);
  }

  getRoleCategory() {
    return this.interceptor.httpCall('get', 'getRoleCategory');
  }
  getUserCategory(request) {
    return this.interceptor.httpCall('get', 'getUserCategory', request);
  }

  getEnterpriseSearchName(request) {
    return this.interceptor.httpCall('get', 'getUserManagementEnterpriseSearchName', request);
  }
  getTotalCountEnterprises() {
    return this.interceptor.httpCall('get', 'getUserManagementTotalCountEnterprises');
  }

  getVendorList(request) {
    return this.interceptor.httpCall('get', 'getUserManagementEnterpriseList', request);
  }

}



