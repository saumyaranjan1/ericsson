import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { UserManagementAbacEnumService } from './user-management-abac-enum.service';
import { UserManagementAbacService } from './user-management-abac.service'
import { SpinnerService } from '../shared/services/spinner.service';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { forkJoin } from 'rxjs';
import { DataService } from '../shared/services/data.service';

import { FormGroup, FormBuilder, Validators, FormControl, FormArray } from '@angular/forms';
@Component({
  selector: 'app-user-management-abac',
  templateUrl: './user-management-abac.component.html',
  styleUrls: ['./user-management-abac.component.less']
})
export class UserManagementAbacComponent implements OnInit {
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('mapModelsTemplate', { static: false }) mapModelsTemplate: ElementRef;
  @ViewChild('enterpriseTemplate', { static: false }) enterpriseTemplate: ElementRef;
  actionsObj = {
    actionsLabel: UserManagementAbacEnumService.DATA.actionsLabel,
    actions: UserManagementAbacEnumService.DATA.actions
  };
  data = {
    page: 1,
    total: 1,
    data: []
  };
  filterSearch: any;
  selectedEnterpriseList = [];
  submitRoleGroup = [];
  platformSelection = "";
  selectedRoleData: any;
  selectedEnterpriseModelsCount = 0;
  selectedModelsCount = 0;
  tableHeader = UserManagementAbacEnumService.DATA.tableHeader;
  showGridCheckBox = UserManagementAbacEnumService.DATA.showGridCheckBox;
  tableHeaderActions = {};
  userRoleList = [];
  paramObject;
  enterpriseIdsArray = []; //EnterPrise Dropdown
  userId;
  deviceList = [];
  showEnterpriseList = false;
  pageSize = 1;
  createOrEditUser;
  moduleroles = [];
  columns = UserManagementAbacEnumService.DATA.columns;
  reportList = [{ 'firstName': 'saumya', 'lastName': 'nanda', 'userId': '123' },
  { 'firstName': 'kkkk', 'lastName': 'aaaaa', 'userId': '1293' }
  ];
  roleCategoryList = [];
  enterpriseList = [{ 'hqBpId': '11111', 'hqBpName': 'jio' }, { 'hqBpId': '12345', 'hqBpName': 'harman' }];
  deleteUserData;
  userManagementGrid = true;
  addNewUserSection = false;
  userManagementAssignRole = false;
  createUserForm: FormGroup;
  groupIndex = 0;
  moduleIndex = 0;
  insideModuleIndex = 0;
  privilegeIndex = 0;
  userURLType = "ENTERPRISE";
  selectedURLType = 'preveledge';
  constructor(private fb: FormBuilder,
    private cms: CommonMethodsService,
    private ngbModal: NgbModal,
    private userManagementAbacService: UserManagementAbacService,
    private spinnerService: SpinnerService,
    private DataService: DataService) { }


  ngOnInit() {
    this.userId = this.DataService.getFromStorage('login_user_name');
    this.getActions();
  }

  showCheckList() {
    this.enterpriseIdsArray.forEach(element => {
      this.selectedEnterpriseList.forEach(inneerElement => {
        if (element.hqBpId == inneerElement.hqBpId) {
          element.isCheck = true;
        }
      });
    });
    // this.filterSearch = '';
    this.showEnterpriseList = !this.showEnterpriseList;
  }

  openModel(content, event) {
    this.deleteUserData = event;
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: 'sm',
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }

  /**
   * Spinner Start
   */
  spinnerStart() {
    this.spinnerService.toggleSpinner(1);
  }

  /**
  * Spinner End
  */
  spinnerEnd() {
    this.spinnerService.toggleSpinner(0);
  }

  getData(obj) {
    this.spinnerStart();
    //const params = { email: this.userId, "size": obj.limit, "page": obj.offset };
    const params = { "size": obj.limit, "page": obj.offset };
    let userManagementData = [];
    this.userManagementAbacService.getProfileUserList(params).subscribe(res => {
      if (res && res.data && res.data.length > 0) {
        userManagementData = res.data.map(data => {
          data.userFullName = data.firstName
          data.lastname = data.lastName
          data.email = data.email
          data.mobile = data.phone
          data.abacaction = false;
          data.actualEnterprise = data.enterprises.map(data => {
            data.hqBpId = data.entId
            data.hqBpName = data.name
            return data;
          });
          data.actualDevice = data.devices;
          data.actualCategory = data.category
          data.enterprises = Object.keys(data.enterprises).map(function (k) {
            return data.enterprises[k].name
          }
          ).join(",")
          data.devices = Object.keys(data.devices).map(function (k) { return data.devices[k] }).join(",")
          data.category = data.category && data.category.categoryName ? data.category.categoryName : ''
          data.showPopup = false;
          return data;
        });
      }
      this.data = {
        page: obj.page,
        total: res.totalCount,
        data: userManagementData
      };
      this.spinnerEnd();
    },
      error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.spinnerEnd();
      });
  }

  getDeviceList(userId) {
    let params = { rpp: 500, pageNum: 1, userId: userId };
    this.userManagementAbacService.getDeviceList(params).subscribe(res => {
      if (res && res.data) {
        res.data.map(data => {
          data.userId = userId;
          data.deviceId = data.deviceId
        })
        this.deviceList = this.deviceList.concat(res.data);
      }
    });
  }

  getRoleCategory() {
    this.userManagementAbacService.getRoleCategory().subscribe(res => {
      if (res && res.data) {
        this.roleCategoryList = res.data;
      }
    });
  }

  /**
   * Get Search Device Data
   */
  getDataBySearch(data) {
    this.spinnerStart();
    let obj;
    let userManagementData = [];
    obj = this.userManagementAbacService.getObject(data);
    obj.limit = 10;
    obj.offset = 0;
    this.userManagementAbacService.getSearchUserProfileData(obj).subscribe(
      res => {
        if (res && res.length > 0) {
          userManagementData = res.map(data => {
            data.userFullName = data.firstName
            data.lastname = data.lastName
            data.email = data.email
            data.mobile = data.phone
            data.abacaction = false;
            data.actualEnterprise = data.enterprises.map(data => {
              data.hqBpId = data.entId
              data.hqBpName = data.name
              return data;
            });
            data.actualDevice = data.devices;
            data.actualCategory = data.category
            data.enterprises = Object.keys(data.enterprises).map(function (k) {
              return data.enterprises[k].name
            }
            ).join(",")
            data.devices = Object.keys(data.devices).map(function (k) { return data.devices[k] }).join(",")
            data.category = data.category && data.category.categoryName ? data.category.categoryName : ''
            data.showPopup = false;
            return data;
          });
        }
        this.data = {
          page: obj.page,
          total: res.totalCount,
          data: userManagementData
        };
        this.spinnerEnd();
      },
      error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.spinnerEnd();
      }
    );
  }
  getEnterPriseId(page?) {
    let obj;
    if (page) {
      let pageOffset = this.pageSize * 200;
      this.pageSize = this.pageSize + 1;
      obj = { limit: 200, offset: pageOffset, page: this.pageSize, pageNum: this.pageSize, rpp: 200 };
    } else {
      obj = { limit: 200, offset: 0, page: 1, pageNum: 1, rpp: 200 };
    }
    const totalEnterPriseCount = this.userManagementAbacService.getTotalCountEnterprises();
    const totalEnterpriseResult = this.userManagementAbacService.getVendorList(obj);
    this.spinnerEnd();
    forkJoin([totalEnterPriseCount, totalEnterpriseResult]).subscribe(results => {
      this.spinnerEnd();
      if (results[1] && results[1].data && results[1].data.length > 0) {
        this.enterpriseIdsArray = this.enterpriseIdsArray.concat(results[1].data);
        this.enterpriseIdsArray.forEach(element => {
          if (this.selectedEnterpriseList && this.selectedEnterpriseList.length > 0) {
            this.selectedEnterpriseList.forEach(inneerElement => {
              if (element.hqBpId == inneerElement.hqBpId) {
                element['isCheck'] = true;
                //this.getDeviceList(element.userId);
              }
            });
          }
        });
        this.spinnerEnd();
      } else {
        this.spinnerEnd();
      }
    }, error => {
      this.spinnerEnd();
      this.enterpriseIdsArray = [];
    });
  }

  searchWithEnterpriseName(evt) {
    if (evt.target.value) {
      this.filterSearch = evt.target.value;
      const obj = { hqBpName: evt.target.value };
      this.enterpriseIdsArray = [];
      const totalEnterpriseResult = this.userManagementAbacService.getEnterpriseSearchName(obj);
      this.spinnerStart();
      forkJoin([totalEnterpriseResult]).subscribe(results => {
        this.spinnerEnd();
        if (results[0] && results[0].data && results[0].data.length > 0) {
          this.enterpriseIdsArray = results[0].data;
          this.enterpriseIdsArray.forEach(element => {
            if (this.selectedEnterpriseList && this.selectedEnterpriseList.length > 0) {
              this.selectedEnterpriseList.forEach(inneerElement => {
                if (element.hqBpId == inneerElement.hqBpId) {
                  element['isCheck'] = true;
                }
              });
            }
          });
          this.spinnerEnd();
        } else {
          this.spinnerEnd();
        }
      }, error => {
        this.spinnerEnd();
        this.enterpriseIdsArray = [];
      });
    } else {
      this.enterpriseIdsArray = [];
      this.filterSearch = '';
      this.pageSize = 1;
      this.getEnterPriseId();
    }
  }


  getActions() {
    this.tableHeaderActions['provisionsearch'] = false;
    this.tableHeaderActions['provisiondropDown'] = false;
    this.tableHeaderActions['add'] = true;
    this.actionsObj.actionsLabel = "";
    //this.actionsObj.actions = [{ type: "edit", title: "edit" }, { type: "delete", title: "delete" }];
    this.actionsObj.actions = [];
  }


  /**
   * Add New User
  */
  addNewUser(event, type, duplicateType?) {
    if (type == 'Update') {
      this.createOrEditUser = 'Next';
    } else {
      this.createOrEditUser = type;
    }
    this.addNewUserSection = true;
    this.selectedEnterpriseList = [];
    this.platformSelection = "";
    this.userManagementAssignRole = false;
    this.userManagementGrid = false;
    this.showEnterpriseList = false;
    this.selectedEnterpriseList = [];
    this.enterpriseIdsArray = [];
    this.deviceList = [];
    this.filterSearch = '';
    this.pageSize = 1;
    if (type == 'Update' || type == 'view') {
      let enterpriseIdsArr = [];
      this.selectedEnterpriseList = [];
      this.platformSelection = event.id
      event.actualEnterprise.forEach(enterPriseId => {
        enterpriseIdsArr.push({
          hqBpId: enterPriseId.hqBpId,
          hqBpName: enterPriseId.hqBpName
        })
        this.selectedEnterpriseList.push({
          hqBpId: enterPriseId.hqBpId, hqBpName: enterPriseId.hqBpName,
          id: enterPriseId.hqBpId, name: enterPriseId.hqBpName
        });
      });
      event.enterprises = this.selectedEnterpriseList;
    }
    this.getEnterPriseId();
    this.getRoleCategory();

    this.createUserForm = this.fb.group({
      displayName: [event ? event.firstName : null, Validators.required],
      lastname: [event ? event.lastname : null, Validators.required],
      email: [event ? event.email : null, [Validators.required, Validators.email, Validators.maxLength(50)]],
      mobileNumber: [event ? event.phone : null, [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern('^[0-9]*$')
      ]],
      enterprise: [event ? event.enterprises : null],
      category: [event ? event.actualCategory.categoryName : null, Validators.required],
      devices: [event ? event.actualDevice : null],
      id: [event ? event.id : null]
    });

    if (type == 'Update') {
      this.createUserForm.controls.email.disable();
    }
    if (duplicateType == 'duplicate') {
      this.createUserForm.controls.email.enable();
    }
  }

  duplicateUser(event, type) {
    const params = {
      enterprises: event.enterprises,
      actualEnterprise: event.actualEnterprise,
      actualCategory: event.actualCategory,
      actualDevice: event.actualDevice
    }
    this.updateUser(params, type)
  }

  /**
  * Update User
  */
  updateUser(event, type) {
    this.createUserForm = this.fb.group({
      targets: new FormArray([]),
    });
    this.addNewUser(event, 'Update', type)
  }

  /**
  * view  User
  */
  viewUser(event) {
    this.createUserForm = this.fb.group({
      targets: new FormArray([]),
    });
    this.addNewUser(event, 'view', '')
    this.createUserForm.controls.displayName.disable();
    this.createUserForm.controls.email.disable();
    this.createUserForm.controls.mobileNumber.disable();
    this.createUserForm.controls.lastname.disable();
    this.createUserForm.controls.devices.disable();
    this.createUserForm.controls.category.disable();
  }


  getTargetsValues(targets) {
    const len = this.targetsInfo.length;
    for (let index = len; index >= 0; index--) {
      this.targetsInfo.removeAt(index);
    }
    targets.forEach(service => {
      this.targetsInfo.push(this.fb.group({
        enterpriseId: new FormControl(service.enterpriseId, [Validators.required]),
        actionsProfileId: new FormControl(service.actionsProfileId, [Validators.required])
      }));
    });
    return this.targetsInfo;
  }

  get targetsInfo() { return this.createUserForm.controls['targets'] as FormArray; }

  // addTargets() {
  //   this.targetsInfo.push(this.fb.group({
  //     enterpriseId: new FormControl('', [Validators.required]),
  //     actionsProfileId: new FormControl('', [Validators.required])
  //   }));
  // }

  removeTargets(i: number) {
    this.targetsInfo.removeAt(i);
  }

  backButton() {
    this.addNewUserSection = false;
    this.userManagementGrid = true;
    this.userManagementAssignRole = false;
  }

  backToCreateButton() {
    this.addNewUserSection = true;
    this.userManagementGrid = false;
    this.userManagementAssignRole = false;
    if (this.createOrEditUser == 'view') {
      this.createOrEditUser = 'view';
    } else {
      this.createOrEditUser = 'Next';
    }

  }

  closeMultiselectField(event) {
    if (event.target) {
      if (event.target.id !== 'multiselectList' && event.target.id !== 'multiselecthevron') {
        this.showEnterpriseList = false;
      }
    }
  }

  openModal(content, size) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal user-onboard',
        size,
        backdrop: 'static',
        keyboard: false
      })
      .result.then(
        result => { },
        reason => { }
      );
  }
  closeModal(close) {
    close('Cross click');
  }

  openSelectionPopup(preveledgeItem, groupIndex, moduleIndex, privilegeIndex, type, insideModuleIndex) {
    this.groupIndex = groupIndex;
    this.moduleIndex = moduleIndex;
    this.selectedEnterpriseModelsCount = 0;
    this.selectedModelsCount = 0;
    this.privilegeIndex = privilegeIndex;
    this.userURLType = preveledgeItem.urlType;
    this.insideModuleIndex = insideModuleIndex;
    this.selectedURLType = type;
    if (type && type == 'grouppreveledge' && preveledgeItem.urlType == 'ENTERPRISE') {
      if (this.userRoleList[this.groupIndex]
        && this.userRoleList[this.groupIndex].privileges
        && this.userRoleList[this.groupIndex].privileges.length > 0
        && this.userRoleList[this.groupIndex].privileges[this.privilegeIndex].enterprises
        && this.userRoleList[this.groupIndex].privileges[this.privilegeIndex].enterprises.length > 0
      ) {
        if (this.createUserForm.value.enterprise && this.createUserForm.value.enterprise.length > 0) {
          this.createUserForm.value.enterprise.map(value => {
            value.selected = false;
          })
          this.createUserForm.value.enterprise.map(actualEnterprise => {
            this.userRoleList[this.groupIndex].privileges[this.privilegeIndex].enterprises.forEach(element => {
              if (actualEnterprise.hqBpId == element.entId) {
                actualEnterprise.selected = true;
                this.selectedEnterpriseModelsCount++;
              }
            });
          });
        }

      }
    }
    if (type && type == 'grouppreveledge' && preveledgeItem.urlType == 'DEVICE') {
      if (this.userRoleList[this.groupIndex]
        && this.userRoleList[this.groupIndex].privileges
        && this.userRoleList[this.groupIndex].privileges.length > 0
        && this.userRoleList[this.groupIndex].privileges[this.privilegeIndex].devices
        && this.userRoleList[this.groupIndex].privileges[this.privilegeIndex].devices.length > 0
      ) {
        if (this.createUserForm.value.devices && this.createUserForm.value.devices.length > 0) {
          this.createUserForm.value.devices.map(value => {
            value.selected = false;
          })
          this.createUserForm.value.devices.map(actualdevices => {
            this.userRoleList[this.groupIndex].privileges[this.privilegeIndex].devices.forEach(element => {
              if (actualdevices.deviceId == element.deviceId) {
                element.selected = true;
                this.selectedModelsCount++;
              }
            });
          });
        }

      }
    }
    if (type && type == 'insidemodulepreveledge' && preveledgeItem.urlType == 'ENTERPRISE') {
      if (this.userRoleList[this.groupIndex]
        && this.userRoleList[this.groupIndex].modules
        && this.userRoleList[this.groupIndex].modules.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].enterprises
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].enterprises.length > 0
      ) {
        if (this.createUserForm.value.enterprise && this.createUserForm.value.enterprise.length > 0) {
          this.createUserForm.value.enterprise.map(value => {
            value.selected = false;
          })
          this.createUserForm.value.enterprise.map(actualEnterprise => {
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].enterprises.forEach(element => {
              if (actualEnterprise.hqBpId == element.entId) {
                actualEnterprise.selected = true;
                this.selectedEnterpriseModelsCount++;
              }
            });
          });
        }

      }
    }
    if (type && type == 'insidemodulepreveledge' && preveledgeItem.urlType == 'DEVICE') {
      if (this.userRoleList[this.groupIndex]
        && this.userRoleList[this.groupIndex].modules
        && this.userRoleList[this.groupIndex].modules.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].devices
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].devices.length > 0
      ) {
        if (this.createUserForm.value.devices && this.createUserForm.value.devices.length > 0) {
          this.createUserForm.value.devices.map(value => {
            value.selected = false;
          })
          this.createUserForm.value.devices.map(actualdevices => {
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].devices.forEach(element => {
              if (actualdevices.deviceId == element.deviceId) {
                actualdevices.selected = true;
                this.selectedModelsCount++;
              }
            });
          });
        }

      }
    } if (type && type == 'preveledge' && preveledgeItem.urlType == 'DEVICE') {
      if (this.createUserForm.value.devices && this.createUserForm.value.devices.length > 0) {
        this.createUserForm.value.devices.map(value => {
          value.selected = false;
        })
      }
      //insideModule
      if (this.userRoleList[this.groupIndex]
        && this.userRoleList[this.groupIndex].modules
        && this.userRoleList[this.groupIndex].modules.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices.length > 0
      ) {
        if (this.createUserForm.value.devices && this.createUserForm.value.devices.length > 0) {
          this.createUserForm.value.devices.map(value => {
            value.selected = false;
          })
          this.createUserForm.value.devices.map(actualdevices => {
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices.forEach(element => {
              if (actualdevices.deviceId == element.deviceId) {
                actualdevices.selected = true;
                this.selectedModelsCount++;
              }
            });
          });
        }
      } else if (this.userRoleList[this.groupIndex]
        && this.userRoleList[this.groupIndex].modules
        && this.userRoleList[this.groupIndex].modules.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices.length > 0
      ) {
        if (this.createUserForm.value.devices && this.createUserForm.value.devices.length > 0) {
          this.createUserForm.value.devices.map(value => {
            value.selected = false;
          })
          this.createUserForm.value.devices.map(actualdevices => {
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices.forEach(element => {
              if (actualdevices.deviceId == element.deviceId) {
                actualdevices.selected = true;
                this.selectedModelsCount++;
              }
            });
          });
        }
      }
    }
    if (type && type == 'preveledge' && preveledgeItem.urlType == 'ENTERPRISE') {
      if (this.createUserForm.value.enterprise && this.createUserForm.value.enterprise.length > 0) {
        this.createUserForm.value.enterprise.map(value => {
          value.selected = false;
        })
      }
      //insideModule
      if (this.userRoleList[this.groupIndex]
        && this.userRoleList[this.groupIndex].modules
        && this.userRoleList[this.groupIndex].modules.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].enterprises
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].enterprises.length > 0
      ) {
        if (this.createUserForm.value.enterprise && this.createUserForm.value.enterprise.length > 0) {
          this.createUserForm.value.enterprise.map(value => {
            value.selected = false;
          })
          this.createUserForm.value.enterprise.map(actualEnterprise => {
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].enterprises.forEach(element => {
              if (actualEnterprise.hqBpId == element.entId) {
                actualEnterprise.selected = true;
                this.selectedEnterpriseModelsCount++;
              }
            });
          });
        }
      } else if (this.userRoleList[this.groupIndex]
        && this.userRoleList[this.groupIndex].modules
        && this.userRoleList[this.groupIndex].modules.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges.length > 0
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].enterprises
        && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].enterprises.length > 0
      ) {
        if (this.createUserForm.value.enterprise && this.createUserForm.value.enterprise.length > 0) {
          this.createUserForm.value.enterprise.map(value => {
            value.selected = false;
          })
          this.createUserForm.value.enterprise.map(actualEnterprise => {
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].enterprises.forEach(element => {
              if (actualEnterprise.hqBpId == element.entId) {
                actualEnterprise.selected = true;
                this.selectedEnterpriseModelsCount++;
              }
            });
          });
        }
      }
    }
    if (preveledgeItem.urlType == 'ENTERPRISE') {
      this.openModal(this.enterpriseTemplate, 'lg');
    } else if (preveledgeItem.urlType == 'DEVICE') {
      this.openModal(this.mapModelsTemplate, 'lg');
    }
  }

  openTabContent(item, i) {
    this.userRoleList.forEach((data, index) => {
      if (i == index) {
        data.isActive = true;
        if (data.privileges && data.privileges.length > 0) {
          data.privileges.map(mapValue => {
            mapValue.isActive = true
            return mapValue;
          })
        }
        if (data.modules && data.modules.length > 0) {
          data.modules.map(mapValue => {
            mapValue.isActive = true
            return mapValue;
          })
        }
      } else {
        data.isActive = false;
        if (data.privileges && data.privileges.length > 0) {
          data.privileges.map(mapValue => {
            mapValue.isActive = false
            return mapValue;
          })
        }
        if (data.modules && data.modules.length > 0) {
          data.modules.map(mapValue => {
            mapValue.isActive = false
            return mapValue;
          })
        }
      }
    })
  }

  getUserProfileByID(id, type) {
    let params = { id: id };
    this.userRoleList = [];
    this.userManagementAbacService.getUserProfileByID(params).subscribe(res => {
      if (res) {
        this.userRoleList = res.groups ? res.groups : [];
        this.userRoleList.map((data, index) => {
          data.isChecked = true;
          if (index == 0) {
            data.isActive = true;
          } else {
            data.isActive = false;
          }
          if (data && data.privileges && data.privileges.length > 0) {
            data.privileges.map(value => {
              value.isChecked = true
              value.privilegeId = value.prevId,
                value.priviledgeName = value.prevName,
                value.urlType = value.urlType
              value.enterprises = value.enterprises;
              value.devices = value.devices;
              if (index == 0) {
                value.isActive = true;
              } else {
                value.isActive = false;
              }
              return value;
            });

          }
          if (data.modules && data.modules.length > 0) {
            data.modules.map((moduleData) => {
              moduleData.isChecked = true;
              moduleData.isActive = true;
              // if (index == 0) {
              //   moduleData.isActive = true;
              // } else {
              //   moduleData.isActive = false;
              // }
              if (moduleData && moduleData.privileges && moduleData.privileges.length > 0) {
                moduleData.privileges.map(value => {
                  value.isChecked = true
                  value.privilegeId = value.prevId,
                    value.priviledgeName = value.prevName,
                    value.urlType = value.urlType
                  value.enterprises = value.enterprises;
                  value.devices = value.devices;
                  return value;
                });

              }

              moduleData['userPriviledge'] = moduleData.privileges && moduleData.privileges.length > 0 ? moduleData.privileges : '';
              if (moduleData.modules && moduleData.modules.length > 0) {
                moduleData.modules.map((insidemoduleData) => {
                  insidemoduleData.isChecked = true;
                  insidemoduleData.isActive = true;
                  // if (index == 0) {
                  //   insidemoduleData.isActive = true;
                  // } else {
                  //   insidemoduleData.isActive = false;
                  // }
                  if (insidemoduleData && insidemoduleData.privileges && insidemoduleData.privileges.length > 0) {
                    insidemoduleData.privileges.map(value => {
                      value.isChecked = true
                      value.privilegeId = value.prevId,
                        value.priviledgeName = value.prevName,
                        value.urlType = value.urlType
                      value.enterprises = value.enterprises;
                      value.devices = value.devices;
                      return value;
                    });

                  }

                  insidemoduleData['userPriviledge'] = insidemoduleData.privileges && insidemoduleData.privileges.length > 0 ? insidemoduleData.privileges : '';
                })
              }
            })

          }

        });
        this.selectedRoleData = this.userRoleList;
      }
    });
  }

  getUserCategory(categories, type) {
    let params = { categories: categories };
    this.userRoleList = [];
    this.userManagementAbacService.getUserCategory(params).subscribe(res => {
      if (res && res.length > 0) {
        this.userRoleList = res;
        this.userRoleList.map((data, index) => {
          data.isChecked = true;
          if (index == 0) {
            data.isActive = true;
          } else {
            data.isActive = false;
          }
          if (data && data.privileges && data.privileges.length > 0) {
            data.privileges.map(value => {
              value.isChecked = true
              value.privilegeId = value.prevId,
                value.priviledgeName = value.prevName,
                value.urlType = value.urlType
              value.enterprises = [];
              value.devices = [];
              if (index == 0) {
                value.isActive = true;
              } else {
                value.isActive = false;
              }
              return value;
            });

          }
          if (data.modules && data.modules.length > 0) {
            data.modules.map((moduleData) => {
              moduleData.isChecked = true;
              // if (index == 0) {
              //   moduleData.isActive = true;
              // } else {
              //   moduleData.isActive = false;
              // }
              moduleData.isActive = true;
              if (moduleData && moduleData.privileges && moduleData.privileges.length > 0) {
                moduleData.privileges.map(value => {
                  value.isChecked = true
                  value.privilegeId = value.prevId,
                    value.priviledgeName = value.prevName,
                    value.urlType = value.urlType
                  value.enterprises = [];
                  value.devices = [];
                  return value;
                });

              }

              moduleData['userPriviledge'] = moduleData.privileges ? moduleData.privileges : '';
              if (moduleData.modules && moduleData.modules.length > 0) {
                moduleData.modules.map((insidemoduleData) => {
                  insidemoduleData.isChecked = true;
                  // if (index == 0) {
                  //   insidemoduleData.isActive = true;
                  // } else {
                  //   insidemoduleData.isActive = false;
                  // }
                  insidemoduleData.isActive = true;
                  if (insidemoduleData && insidemoduleData.privileges && insidemoduleData.privileges.length > 0) {
                    insidemoduleData.privileges.map(value => {
                      value.isChecked = true
                      value.privilegeId = value.prevId,
                        value.priviledgeName = value.prevName,
                        value.urlType = value.urlType
                      value.enterprises = [];
                      value.devices = [];
                      return value;
                    });

                  }

                  insidemoduleData['userPriviledge'] = insidemoduleData.privileges ? insidemoduleData.privileges : '';
                })
              }
            })

          }

        });
        this.selectedRoleData = this.userRoleList;
      }
    });
  }

  submitForm(form, type) {
    if (form.valid && type == 'Next') {
      this.addNewUserSection = false;
      this.userManagementGrid = false;
      this.userManagementAssignRole = true;
      this.createOrEditUser = 'Finish';
      let deviceArr = [];
      if (this.createUserForm.value.devices && this.createUserForm.value.devices.length > 0) {
        this.createUserForm.value.devices.forEach(element => {
          if (element.deviceId == '' || element.deviceId == undefined)
            deviceArr.push({ deviceId: element })
        });
      }
      this.createUserForm.patchValue({ devices: deviceArr });
      this.getUserCategory(form.value.category, type);
    } if (form.valid && type == 'view') {
      this.addNewUserSection = false;
      this.userManagementGrid = false;
      this.userManagementAssignRole = true;
      this.createOrEditUser = 'view';
      let deviceArr = [];
      if (this.createUserForm.value.devices && this.createUserForm.value.devices.length > 0) {
        this.createUserForm.value.devices.forEach(element => {
          if (element.deviceId == '' || element.deviceId == undefined)
            deviceArr.push({ deviceId: element })
        });
      }
      this.createUserForm.patchValue({ devices: deviceArr });
      this.getUserProfileByID(form.value.id, type);
    } else if (form.valid && type == 'Finish') {
      this.submitRoleGroup = [];
      if (this.userRoleList && this.userRoleList.length > 0) {
        this.userRoleList.forEach((data, groupIndex) => {
          if (data.isChecked == true) {
            if (data.privileges && data.privileges.length > 0) {
              let groupPriviledge = [];
              data.privileges.forEach(priviledgeData => {
                if (priviledgeData.isChecked == true) {
                  if (priviledgeData.enterprises && priviledgeData.enterprises.length > 0) {
                    groupPriviledge.push(
                      {
                        prevId: priviledgeData.prevId,
                        prevName: priviledgeData.prevName,
                        urlType: priviledgeData.urlType,
                        enterprises: priviledgeData.enterprises
                      });
                  } else if (priviledgeData.devices && priviledgeData.devices.length > 0) {
                    let devieArr = [];
                    priviledgeData.devices.forEach(element => {
                      devieArr.push(element.deviceId);
                    });
                    groupPriviledge.push(
                      {
                        prevId: priviledgeData.prevId,
                        prevName: priviledgeData.prevName,
                        urlType: priviledgeData.urlType,
                        devices: devieArr
                      });
                  } else {
                    groupPriviledge.push(
                      {
                        prevId: priviledgeData.prevId,
                        prevName: priviledgeData.prevName,
                        urlType: priviledgeData.urlType
                      });
                  }

                }
              });
              this.submitRoleGroup.push({ groupId: data.groupId, groupName: data.groupName, modules: [], privileges: groupPriviledge });
            } else {
              this.submitRoleGroup.push({ groupId: data.groupId, groupName: data.groupName, modules: [] });
            }
          }
          if (data.modules && data.modules.length > 0) {
            data.modules.forEach((moduleData, moduleIndex) => {
              if (moduleData.isChecked == true) {
                if (moduleData.modules && moduleData.modules.length > 0) {
                  this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'].push(
                    {
                      moduleId: moduleData.moduleId,
                      moduleName: moduleData.moduleName,
                      privileges: [],
                      modules: []
                    });
                } else {
                  this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'].push(
                    {
                      moduleId: moduleData.moduleId,
                      moduleName: moduleData.moduleName,
                      privileges: []
                    });
                }

              }
              if (moduleData.modules && moduleData.modules.length > 0) {
                moduleData.modules.forEach((insideModule,insideIndex) => {
                  if (insideModule.isChecked == true) {
                    this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'][moduleIndex]['modules'].push(
                      {
                        moduleId: insideModule.moduleId,
                        moduleName: insideModule.moduleName,
                        privileges: []
                      });
                  }
                  if (insideModule.privileges && insideModule.privileges.length > 0) {
                    insideModule.privileges.forEach((priviledgeData, privilegeIndex) => {
                      if (priviledgeData.isChecked == true) {
                        if (priviledgeData.enterprises && priviledgeData.enterprises.length > 0) {
                          this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'][moduleIndex]['modules'][insideIndex]['privileges'].push(
                            {
                              prevId: priviledgeData.prevId,
                              prevName: priviledgeData.prevName,
                              urlType: priviledgeData.urlType,
                              enterprises: priviledgeData.enterprises
                            });
                        } else if (priviledgeData.devices && priviledgeData.devices.length > 0) {
                          let devieArr = [];
                          priviledgeData.devices.forEach(element => {
                            devieArr.push(element.deviceId);
                          });
                          this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'][moduleIndex]['modules'][insideIndex]['privileges'].push(
                            {
                              prevId: priviledgeData.prevId,
                              prevName: priviledgeData.prevName,
                              urlType: priviledgeData.urlType,
                              devices: devieArr
                            });
                        } else {
                          if (this.submitRoleGroup[this.submitRoleGroup.length - 1] &&
                            this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'] &&
                            this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'][moduleIndex] &&
                            this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'][moduleIndex]['modules'] &&
                            this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'][moduleIndex]['modules'][insideIndex] &&
                            this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'][moduleIndex]['modules'][insideIndex]['privileges']
                          )
                            this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'][moduleIndex]['modules'][insideIndex]['privileges'].push(
                              {
                                prevId: priviledgeData.prevId,
                                prevName: priviledgeData.prevName,
                                urlType: priviledgeData.urlType
                              });
                        }
                      }
                    })
                  }
                });
              }
              if (moduleData.privileges && moduleData.privileges.length > 0) {
                moduleData.privileges.forEach(priviledgeData => {
                  if (priviledgeData.isChecked == true) {
                    if (priviledgeData.enterprises && priviledgeData.enterprises.length > 0) {
                      this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'][this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'].length - 1]['privileges'].push(
                        {
                          prevId: priviledgeData.prevId,
                          prevName: priviledgeData.prevName,
                          urlType: priviledgeData.urlType,
                          enterprises: priviledgeData.enterprises
                        });
                    } else if (priviledgeData.devices && priviledgeData.devices.length > 0) {
                      let devieArr = [];
                      priviledgeData.devices.forEach(element => {
                        devieArr.push(element.deviceId);
                      });
                      this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'][this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'].length - 1]['privileges'].push(
                        {
                          prevId: priviledgeData.prevId,
                          prevName: priviledgeData.prevName,
                          urlType: priviledgeData.urlType,
                          devices: devieArr
                        });
                    } else {
                      this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'][this.submitRoleGroup[this.submitRoleGroup.length - 1]['modules'].length - 1]['privileges'].push(
                        {
                          prevId: priviledgeData.prevId,
                          prevName: priviledgeData.prevName,
                          urlType: priviledgeData.urlType
                        });
                    }
                  }
                })
              }
            })
          }
        });
      }
      const categoryData = this.roleCategoryList.filter(data => {
        return data.categoryName === form.value.category;
      });
      let categoryObj = {
        "categoryName": "",
        "status": "ACTIVE",
        "level": ''
      }
      if (categoryData && categoryData.length > 0) {
        categoryObj = {
          "categoryName": categoryData[0].categoryName,
          "status": categoryData[0].status,
          "level": categoryData[0].level
        }
      }
      let entrpirseArr = [];
      if (form.value.enterprise && form.value.enterprise.length > 0) {
        form.value.enterprise.forEach(data => {
          entrpirseArr.push({ entId: data.hqBpId, name: data.hqBpName });
        })
      }
      let devieArr = [];
      if (form.value.devices && form.value.devices.length > 0) {
        form.value.devices.forEach(element => {
          devieArr.push(element.deviceId);
        });
      }

      let param = {};
      if (form.value.id) {
        param = {
          "category": categoryObj,
          "devices": devieArr,
          "email": form.value.email,
          "enterprises": entrpirseArr,
          "firstName": form.value.displayName,
          "lastName": form.value.lastname,
          "phone": form.value.mobileNumber,
          "groups": this.submitRoleGroup,
          "id": form.value.id
        }
      } else {
        param = {
          "category": categoryObj,
          "devices": devieArr,
          "email": form.value.email,
          "enterprises": entrpirseArr,
          "firstName": form.value.displayName,
          "lastName": form.value.lastname,
          "phone": form.value.mobileNumber,
          "groups": this.submitRoleGroup
        }
      }
      this.userManagementAbacService.saveProfileUserList(param, this.createOrEditUser).subscribe(res => {
        this.addNewUserSection = false;
        this.userManagementGrid = true;
        this.userManagementAssignRole = false;
        let params = { "limit": 10, "offset": 0 };
        this.getData(params);
      });
    } else {
      this.cms.validateInnerFormFields(form);
    }
  }

  deleteItem(event) {
    this.openModel(this.deleteConfirmModalContent, event);
  }

  deleteUser(close) {
    this.spinnerService.toggleSpinner(0);
    this.userManagementAbacService.deleteProfileUserList({ 'id': this.deleteUserData.id }).subscribe(res => {
      if (res) {
        let params = { "limit": 10, "offset": 0 };
        this.getData(params);
        this.closeModel(close);
      }
    });
  }

  closeModel(close) {
    close('Cross click');
  }

  closeUserMenu() {
    this.addNewUserSection = false;
    this.userManagementGrid = true;
    this.userManagementAssignRole = false;
    let params = { "limit": 10, "offset": 0 };
    this.getData(params);
  }

  fetchMore(event) {
    if (event > 0 && this.filterSearch == '') {
      if (this.enterpriseIdsArray.length == this.pageSize * 200) {
        this.getEnterPriseId(event);
      }
    }
  }

  checkEnterprise(event, hqBpId) {
    if (event.checked) {
      this.enterpriseIdsArray.forEach((element, keyId) => {
        if (hqBpId == element.hqBpId) {
          if (this.enterpriseIdsArray && this.enterpriseIdsArray[keyId] && this.enterpriseIdsArray[keyId].isCheck) {
            this.enterpriseIdsArray[keyId].isCheck = true;
          }
          this.selectedEnterpriseList.push(element);
          this.createUserForm.patchValue({ devices: '' });
          this.platformSelection = element.userId;
          this.getDeviceList(element.userId);
        }
      });
    } else {
      this.selectedEnterpriseList.forEach((element, keyId) => {
        if (hqBpId == element.hqBpId) {
          if (this.enterpriseIdsArray && this.enterpriseIdsArray[keyId] && this.enterpriseIdsArray[keyId].isCheck) {
            this.enterpriseIdsArray[keyId].isCheck = false;
          }
          this.selectedEnterpriseList.splice(keyId, 1);
        }
      });
      if (this.deviceList && this.deviceList.length > 0) {
        const index = this.deviceList.findIndex(data => data.eid === hqBpId);
        this.deviceList.splice(index, 1);
      }
    }
    this.setEnterpriseValue();
  }

  setEnterpriseValue() {
    this.createUserForm.patchValue({
      enterprise: this.selectedEnterpriseList,
      displayName: this.createUserForm.controls['displayName'].value,
      id: this.createUserForm.controls['id'].value,
      lastname: this.createUserForm.controls['lastname'].value,
      email: this.createUserForm.controls['email'].value,
      mobileNumber: this.createUserForm.controls['mobileNumber'].value,
      category: this.createUserForm.controls['category'].value,
      devices: this.createUserForm.controls['devices'].value,
    });
  }

  onItemDeSelect(event) {
    this.enterpriseIdsArray.forEach(element => {
      if (event == element.hqBpId) {
        element.isCheck = false;
        if (this.deviceList && this.deviceList.length > 0) {
          this.deviceList.forEach(function (item, index, object) {
            if (item.eid === event) {
              //object.splice(index, 1);
            }
          });
          // const index = this.deviceList.findIndex(item => item.eid == event);
          //this.selectedEnterpriseModals.splice(index, 1);
        }
      }
    });

    this.selectedEnterpriseList.forEach((element, keyId) => {
      if (event == element.hqBpId) {
        this.selectedEnterpriseList.splice(keyId, 1);
      }
    });
    if (this.deviceList && this.deviceList.length > 0) {
      const index = this.deviceList.findIndex(data => data.eid === event);
      this.deviceList.splice(index, 1);
    }
    this.setEnterpriseValue();
  }

  selectSingleOne(event, model) {
    // if (event.checked) {
    //   if (this.userRoleList && this.userRoleList.length > 0) {
    //     this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices.push(model);
    //     this.selectedModelsCount++;

    //   }

    // } else {
    //   if (this.userRoleList && this.userRoleList.length > 0) {
    //     const index = this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices.findIndex(data => data === model);
    //     this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices.splice(index, 1);
    //     this.selectedModelsCount--;
    //   }
    // }
    if (event.checked) {
      if (this.userRoleList && this.userRoleList.length > 0) {
        if (this.selectedURLType && this.selectedURLType == 'grouppreveledge') {
          if (this.userRoleList[this.groupIndex]
            && this.userRoleList[this.groupIndex].privileges
            && this.userRoleList[this.groupIndex].privileges.length > 0) {
            this.userRoleList[this.groupIndex].privileges[this.privilegeIndex].devices.push({
              "deviceId": model.deviceId
            });
            this.selectedModelsCount++;
          }
        } else if (this.selectedURLType && this.selectedURLType == 'insidemodulepreveledge') {
          if (this.userRoleList[this.groupIndex]
            && this.userRoleList[this.groupIndex].modules
            && this.userRoleList[this.groupIndex].modules.length > 0
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules.length > 0
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges.length > 0) {
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].devices.push({
              "deviceId": model.deviceId
            });
            this.selectedModelsCount++;
          }
        } else {
          this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices.push({
            "deviceId": model.deviceId
          });
          this.selectedModelsCount++;
        }

      }

    } else {
      if (this.userRoleList && this.userRoleList.length > 0) {
        if (this.selectedURLType && this.selectedURLType == 'grouppreveledge') {
          if (this.userRoleList[this.groupIndex]
            && this.userRoleList[this.groupIndex].privileges
            && this.userRoleList[this.groupIndex].privileges.length > 0) {
            const index = this.userRoleList[this.groupIndex].privileges[this.privilegeIndex].devices.findIndex(data => data.deviceId === model.deviceId);
            this.userRoleList[this.groupIndex].privileges[this.privilegeIndex].devices.splice(index, 1);
            this.selectedModelsCount--;
          }
        } else if (this.selectedURLType && this.selectedURLType == 'insidemodulepreveledge') {
          if (this.userRoleList[this.groupIndex]
            && this.userRoleList[this.groupIndex].modules
            && this.userRoleList[this.groupIndex].modules.length > 0
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules.length > 0
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges.length > 0) {
            const index = this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].devices.findIndex(data => data.deviceId === model.deviceId);
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].devices.splice(index, 1);
            this.selectedModelsCount--;
          } else {
            const index = this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].devices.findIndex(data => data.deviceId === model.deviceId);
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].devices.splice(index, 1);
            this.selectedModelsCount--;
          }
        }
        else if (this.selectedURLType && this.selectedURLType == 'preveledge') {
          if (this.userRoleList[this.groupIndex]
            && this.userRoleList[this.groupIndex].modules
            && this.userRoleList[this.groupIndex].modules.length > 0
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules.length > 0
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges.length > 0) {
            const index = this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices.findIndex(data => data.deviceId === model.deviceId);
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices.splice(index, 1);
            this.selectedModelsCount--;
          } else {
            const index = this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices.findIndex(data => data.deviceId === model.deviceId);
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].devices.splice(index, 1);
            this.selectedModelsCount--;
          }
        }
      }
    }
  }

  selectSingleEnterpriseOne(event, model) {
    if (event.checked) {
      if (this.userRoleList && this.userRoleList.length > 0) {
        if (this.selectedURLType && this.selectedURLType == 'grouppreveledge') {
          if (this.userRoleList[this.groupIndex]
            && this.userRoleList[this.groupIndex].privileges
            && this.userRoleList[this.groupIndex].privileges.length > 0) {
            this.userRoleList[this.groupIndex].privileges[this.privilegeIndex].enterprises.push({
              "entId": model.hqBpId,
              "name": model.hqBpName
            });
            this.selectedEnterpriseModelsCount++;
          }
        } else if (this.selectedURLType && this.selectedURLType == 'insidemodulepreveledge') {
          if (this.userRoleList[this.groupIndex]
            && this.userRoleList[this.groupIndex].modules
            && this.userRoleList[this.groupIndex].modules.length > 0
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules.length > 0
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges.length > 0) {
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].enterprises.push({
              "entId": model.hqBpId,
              "name": model.hqBpName
            });
            this.selectedEnterpriseModelsCount++;
          }
        } else {
          this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].enterprises.push({
            "entId": model.hqBpId,
            "name": model.hqBpName
          });
          this.selectedEnterpriseModelsCount++;
        }

      }

    } else {
      if (this.userRoleList && this.userRoleList.length > 0) {
        if (this.selectedURLType && this.selectedURLType == 'grouppreveledge') {
          if (this.userRoleList[this.groupIndex]
            && this.userRoleList[this.groupIndex].privileges
            && this.userRoleList[this.groupIndex].privileges.length > 0) {
            const index = this.userRoleList[this.groupIndex].privileges[this.privilegeIndex].enterprises.findIndex(data => data.entId === model.hqBpId);
            this.userRoleList[this.groupIndex].privileges[this.privilegeIndex].enterprises.splice(index, 1);
            this.selectedEnterpriseModelsCount--;
          }
        } else if (this.selectedURLType && this.selectedURLType == 'insidemodulepreveledge') {
          if (this.userRoleList[this.groupIndex]
            && this.userRoleList[this.groupIndex].modules
            && this.userRoleList[this.groupIndex].modules.length > 0
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules.length > 0
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges.length > 0) {
            const index = this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].enterprises.findIndex(data => data.entId === model.hqBpId);
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].enterprises.splice(index, 1);
            this.selectedEnterpriseModelsCount--;
          } else {
            const index = this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].enterprises.findIndex(data => data.entId === model.hqBpId);
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules[this.insideModuleIndex].privileges[this.privilegeIndex].enterprises.splice(index, 1);
            this.selectedEnterpriseModelsCount--;
          }
        }
        else if (this.selectedURLType && this.selectedURLType == 'preveledge') {
          if (this.userRoleList[this.groupIndex]
            && this.userRoleList[this.groupIndex].modules
            && this.userRoleList[this.groupIndex].modules.length > 0
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].modules.length > 0
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges
            && this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges.length > 0) {
            const index = this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].enterprises.findIndex(data => data.entId === model.hqBpId);
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].enterprises.splice(index, 1);
            this.selectedEnterpriseModelsCount--;
          } else {
            const index = this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].enterprises.findIndex(data => data.entId === model.hqBpId);
            this.userRoleList[this.groupIndex].modules[this.moduleIndex].privileges[this.privilegeIndex].enterprises.splice(index, 1);
            this.selectedEnterpriseModelsCount--;
          }
        }
      }
    }
  }

  moduleItemCheck(event, groupName, groupIndex, moduleIndex, privilegeIndex, type, insideModuleIndex) {
    if (event) {
      if (this.userRoleList && this.userRoleList.length > 0) {
        if (type == 'group') {
          //Add group name
          this.userRoleList[groupIndex].isChecked = true;
          if (this.userRoleList[groupIndex] && this.userRoleList[groupIndex].privileges
            && this.userRoleList[groupIndex].privileges.length > 0) {
            this.userRoleList[groupIndex].privileges.map(value => {
              value.isChecked = true;
            })
          }
          this.userRoleList[groupIndex].modules.map(data => {
            data.isChecked = true;
            if (data.privileges && data.privileges.length > 0) {
              data.privileges.map(priviledge => {
                priviledge.isChecked = true;
              })
            }
            if (data.modules && data.modules.length > 0) {
              data.modules.map(insideModule => {
                insideModule.isChecked = true;
                if (insideModule.privileges && insideModule.privileges.length > 0) {
                  insideModule.privileges.map(priviledge => {
                    priviledge.isChecked = true;
                  })
                }
              })
            }
          })
        } else if (type == 'module') {
          //add module name
          this.userRoleList[groupIndex].isChecked = true;
          if (this.userRoleList[groupIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex]) {
            this.userRoleList[groupIndex].modules[moduleIndex].isChecked = true
          }
          if (this.userRoleList[groupIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex] &&
            this.userRoleList[groupIndex].modules[moduleIndex].privileges) {
            this.userRoleList[groupIndex].modules[moduleIndex].privileges.map(data => {
              data.isChecked = true;
            })
          }
          if (this.userRoleList[groupIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex] &&
            this.userRoleList[groupIndex].modules[moduleIndex].modules) {
            this.userRoleList[groupIndex].modules[moduleIndex].modules.map(data => {
              data.isChecked = true;
              if (data.privileges && data.privileges.length > 0) {
                data.privileges.map(value => {
                  value.isChecked = true;
                })
              }
            })
          }
        }
        else if (type == 'insidemodule') {
          this.userRoleList[groupIndex].isChecked = true;
          if (this.userRoleList[groupIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex]) {
            this.userRoleList[groupIndex].modules[moduleIndex].isChecked = true
          }
          if (this.userRoleList[groupIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex] &&
            this.userRoleList[groupIndex].modules[moduleIndex].modules) {
            this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].isChecked = true;
            if (this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].privileges &&
              this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].privileges.length > 0) {
              this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].privileges.map(value => {
                value.isChecked = true;
              })
            }
          }
        } else if (type == 'preveledge') {
          //add previdlge name
          this.userRoleList[groupIndex].isChecked = true;
          this.userRoleList[groupIndex].modules[moduleIndex].isChecked = true
          if (this.userRoleList[groupIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex] &&
            this.userRoleList[groupIndex].modules[moduleIndex].privileges &&
            this.userRoleList[groupIndex].modules[moduleIndex].privileges.length > 0) {
            this.userRoleList[groupIndex].modules[moduleIndex].privileges[privilegeIndex].isChecked = true;
          }
          if (this.userRoleList[groupIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex] &&
            this.userRoleList[groupIndex].modules[moduleIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex] &&
            this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].privileges &&
            this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].privileges.length > 0) {
            this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].privileges[privilegeIndex].isChecked = true;
          }
        }
        else if (type == 'grouppreveledge') {
          //add previdlge name
          this.userRoleList[groupIndex].privileges[privilegeIndex].isChecked = true
        }
      }
    } else {
      if (this.userRoleList && this.userRoleList.length > 0) {
        if (type == 'group') {
          //remove group name
          this.userRoleList[groupIndex].isChecked = false;
          if (this.userRoleList[groupIndex] && this.userRoleList[groupIndex].privileges
            && this.userRoleList[groupIndex].privileges.length > 0) {
            this.userRoleList[groupIndex].privileges.map(value => {
              value.isChecked = false;
            })
          }
          this.userRoleList[groupIndex].modules.map(data => {
            data.isChecked = false;
            if (data.privileges && data.privileges.length > 0) {
              data.privileges.map(priviledge => {
                priviledge.isChecked = false;
              })
            }
            if (data.modules && data.modules.length > 0) {
              data.modules.map(insideModule => {
                insideModule.isChecked = false;
                if (insideModule.privileges && insideModule.privileges.length > 0) {
                  insideModule.privileges.map(priviledge => {
                    priviledge.isChecked = false;
                  })
                }
              })
            }
          })
        } else if (type == 'module') {
          //remove module name
          this.userRoleList[groupIndex].modules[moduleIndex].isChecked = false
          if (this.userRoleList[groupIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex]) {
            this.userRoleList[groupIndex].modules[moduleIndex].isChecked = false
          }
          if (this.userRoleList[groupIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex] &&
            this.userRoleList[groupIndex].modules[moduleIndex].privileges) {
            this.userRoleList[groupIndex].modules[moduleIndex].privileges.map(data => {
              data.isChecked = false;
            })
          }
          if (this.userRoleList[groupIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex] &&
            this.userRoleList[groupIndex].modules[moduleIndex].modules) {
            this.userRoleList[groupIndex].modules[moduleIndex].modules.map(data => {
              data.isChecked = false;
              if (data.privileges && data.privileges.length > 0) {
                data.privileges.map(value => {
                  value.isChecked = false;
                })
              }
            })
          }
        } else if (type == 'insidemodule') {
          if (this.userRoleList[groupIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex] &&
            this.userRoleList[groupIndex].modules[moduleIndex].modules) {
            this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].isChecked = false;
            if (this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].privileges &&
              this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].privileges.length > 0) {
              this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].privileges.map(value => {
                value.isChecked = false;
              })
            }
            // this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].map(data => {
            //   if (data.privileges && data.privileges.length > 0) {
            //     data.privileges.map(value => {
            //       value.isChecked = false;
            //     })
            //   }
            // })
          }
        } else if (type == 'preveledge') {
          //remove previdlge name
          if (this.userRoleList[groupIndex].modules[moduleIndex] &&
            this.userRoleList[groupIndex].modules[moduleIndex].privileges &&
            this.userRoleList[groupIndex].modules[moduleIndex].privileges.length > 0) {
            this.userRoleList[groupIndex].modules[moduleIndex].privileges[privilegeIndex].isChecked = false;
          }
          if (this.userRoleList[groupIndex].modules[moduleIndex] &&
            this.userRoleList[groupIndex].modules[moduleIndex].modules &&
            this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex] &&
            this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].privileges &&
            this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].privileges.length > 0) {
            this.userRoleList[groupIndex].modules[moduleIndex].modules[insideModuleIndex].privileges[privilegeIndex].isChecked = false;
          }
        }
        else if (type == 'grouppreveledge') {
          //remove previdlge name
          this.userRoleList[groupIndex].privileges[privilegeIndex].isChecked = false
        }
      }
    }
  }

}
