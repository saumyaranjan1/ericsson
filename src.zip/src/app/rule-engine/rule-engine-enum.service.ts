import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RuleEngineEnumService {
  public static DATA = {
    data: [],
    columns: [
      {
        displayName: 'Rule Name',
        key: 'name',
        filter: ''
      },
      {
        displayName: 'Rule',
        key: 'condition',
        filter: ''
      },
      {
        displayName: 'Action',
        key: 'actionData',
        filter: ''
      },
      {
        displayName: 'activation Status',
        key: 'activationStatus',
        filter: 'uppercase'
      },

    ],
    actions: [
    ],
    actionsLabel: 'Actions',
    tableHeader: 'Rule Engine',
    deleteFlag: true,
    showGridCheckBox: true,
    tableActions: {
      add: true,
      search: true,
      dropdown: true
    },
    ruleNameValueDropdown: [
      { id: 1, value: "Android Phone", check: false },
      { id: 2, value: "Setup Box", check: false },
      { id: 3, value: "Tracker", check: false }],
    MatchSpecialCharacter: /^[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]*$/,
    ruleCheckRegex: /[(]*[0-9a-zA-Z]+[)]*(\s+(&&|\|\|)\s+[(]*[0-9a-zA-Z]+[)]*)*$/
  };

  public static ENTERPRISE_KEY = "enterprise";
  public static SERVICE_KEY = "servicecategory";
  // public static ENTERPRISE_KEY = "os_1";
  // public static SERVICE_KEY = "os_2";

}



