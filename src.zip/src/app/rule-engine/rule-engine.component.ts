import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  ChangeDetectionStrategy
} from '@angular/core';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { RuleEngineService } from './rule-engine.service';
import { RuleEngineEnumService } from './rule-engine-enum.service';
import { DataService } from '../shared/services/data.service';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { forkJoin } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { SpinnerService } from '../shared/services/spinner.service';
import { HeaderService } from './../main/header/header.service';

import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';

@Component({
  selector: 'app-rule-engine',
  templateUrl: './rule-engine.component.html',
  styleUrls: ['./rule-engine.component.less']
})
export class RuleEngineComponent implements OnInit {
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('changeActivationModelContent', { static: true }) changeActivationModelContent: ElementRef;
  @ViewChild('serverPaginationComponent', { static: true }) serverPaginationComponent: ElementRef;
  @ViewChild('addRuleEngineContent', { static: true }) addRuleEngineContent: ElementRef;
  constructor(
    private cms: CommonMethodsService,
    private ngbModal: NgbModal,
    public router: Router,
    private route: ActivatedRoute,
    private fb: FormBuilder,
    private ruleEngineService: RuleEngineService,
    private userService: UserService,
    private SpinnerService: SpinnerService,
    private dataService: DataService,
    private HeaderService: HeaderService
  ) { }
  ruleEngineInfo: any = {};
  selectedValue;
  domainInfo = [];
  filterSearch = "";
  ruleType = [{ id: 1, value: "App" }, { id: 2, value: "Profile" }, { id: 3, value: "Firmware" }]; // Rule Type Array
  profileNameData = ''; // Profile Name Modal Value
  profileNameSearchFilter; //Profile Name modal search value
  applicationNameSearchFilter; //Application Name modal search value
  firmareNameSearchFilter;
  event;
  lessThenString = '<'; //Less Than string
  submitFormFlag = true; // without true form should not be submited
  viewProfileIds = []; //View Profiles
  viewApplicationIds = []; //View Application
  viewFirmwareIds = [];
  noSelectionRules = '';
  pageSize = 1;
  ruleEngineType = '';
  hqbpid = '';
  filterKeySearch;
  filterValueSearch;
  searchFilter;
  actionProfiles = [];
  profileNames = [];
  keyRuleDropdownData = [];
  valueRuleDropdownData = [];
  noSelectAnyruleDropdown;
  firmWareVersions = [];
  expressionValues = [];
  applicationNames = [];
  firmareNames = [];
  createRuleEngineFormGroup: FormGroup;
  tableHeaderActions;
  configModalOptionMode = null;
  tableHeader = RuleEngineEnumService.DATA.tableHeader;
  deleteFlag = RuleEngineEnumService.DATA.deleteFlag;
  showGridCheckBox = RuleEngineEnumService.DATA.showGridCheckBox;
  headerDropdownList;
  columns = RuleEngineEnumService.DATA.columns;
  actionsArr: any;
  //data Get All Rule Data
  data = {
    page: 1,
    total: 0,
    data: []

  };
  ruleGroupType = "app";
  modalConfig = {
    create: { headerText: 'Create Rule', primeBtnText: 'Save' },
    edit: { headerText: 'Edit Rule', primeBtnText: 'Update' },
    view: { headerText: 'View Rule', primeBtnText: 'View' }
  };
  actionsObj = {
    actionsLabel: RuleEngineEnumService.DATA.actionsLabel,
    actions: RuleEngineEnumService.DATA.actions
  };
  domainParams;

  /**
   * Get Initial Data
   **/
  ngOnInit() {
    this.domainParams = this.HeaderService.getSelectedDomain();
    this.getDomainInfo();
    const checkRuleGroupParams = this.getQueryParams();
    if (checkRuleGroupParams) {
      this.ruleGroupType = checkRuleGroupParams.type ? checkRuleGroupParams.type : 'app';
      if (this.ruleGroupType === 'profile') {
        this.ruleType = [{ id: 2, value: "Profile" }]; // Rule Type Array
        this.ruleEngineType = 'Profile';
      } else if (this.ruleGroupType === 'app') {
        this.ruleType = [{ id: 1, value: "App" }]; // Rule Type Array
        this.ruleEngineType = 'App';
      } else if (this.ruleGroupType === 'firmware') {
        this.ruleType = [{ id: 3, value: "Firmware" }]; // Rule Type Array
        this.ruleEngineType = 'Firmware';
      }

    }
    this.searchFilter = [{ key: 'value', }];
    this.profileNameSearchFilter = [{ key: 'name' }];
    this.applicationNameSearchFilter = [{ key: 'applicationName' }];
    this.firmareNameSearchFilter = [{ key: 'firmwareName' }];
    this.actionProfiles = [{ actionProfileId: 1, actionProfileName: "Provisoning Action" }];
  }

  changeDomain(event) {
    let domainValue;
    const domainData = this.domainInfo.filter(data => {
      return data.id === event.value;
    });
    if (domainData && domainData.length > 0) {
      domainValue = { id: domainData[0].id, name: domainData[0].name };
      this.domainParams = { id: domainData[0].id, name: domainData[0].name };
    }
    this.HeaderService.setDomain(domainValue);
    this.getInitialData(this.ruleGroupType);
  }


  getDomainInfo() {
    this.HeaderService.getDomainInfo().subscribe(result => {
      let domainData = [];
      if (result) {
        domainData = result;
        if (domainData && domainData.length > 0) {
          const selectedDomain = this.HeaderService.getSelectedDomain();
          if (selectedDomain && selectedDomain.id) {
            this.selectedValue = selectedDomain.id;
            this.domainParams = { name: selectedDomain.name, id: selectedDomain.id }
          } else {
            const deviceData = { id: domainData[0].domainId, name: domainData[0].domainName };
            this.HeaderService.setToStorage('domain', deviceData);
            this.selectedValue = domainData[0].domainId;
            this.domainParams = { name: domainData[0].domainName, id: domainData[0].domainId }
          }
          domainData.forEach(value => {
            this.domainInfo.push({ id: value.domainId, name: value.domainName });
          });
          this.getActions(this.ruleGroupType);
          this.getInitialData(this.ruleGroupType);

        }
      }
    }, error => {
    });
  }

  /**
   * Get Query Params
   */
  getQueryParams() {
    const ruleGroupId = this.route.snapshot.queryParams &&
      this.route.snapshot.queryParams.ruleEngineId ? this.route.snapshot.queryParams.ruleEngineId : '';
    const ruleGroupType = this.route.snapshot.queryParams &&
      this.route.snapshot.queryParams.ruleEngineType ? this.route.snapshot.queryParams.ruleEngineType : '';
    return { ruleGroupId: ruleGroupId, type: ruleGroupType };
  }

  /**
   * Get Rule Engine Action Data
   */
  getRuleEngineData(event) {
    event.appendUserId = true;
    const queryData = this.getQueryParams();
    if (this.ruleGroupType === 'app') {
      this.ruleEngineService.getRuleEngineData(queryData.ruleGroupId).subscribe((results) => {
        this.SpinnerService.toggleSpinner(0);
        if (results && results.data) {
          results.data.map((value) => {
            value.actionData = JSON.stringify(value.action);
            value.activationStatus = value.status ? value.status.toUpperCase() : '';
            value.moduleType = 'ruleengine';
            return value;
          });
          this.data = {
            page: 1,
            total: results.data.length,
            data: results.data
          };
        }
      }, error => {
        this.SpinnerService.toggleSpinner(0);
        this.data.data = [];
        this.data.total = 0;
        this.data.page = 1;
      });
    } else if (this.ruleGroupType === 'firmware') {
      this.ruleEngineService.getRuleEngineFirmwareData(queryData.ruleGroupId).subscribe((results) => {
        this.SpinnerService.toggleSpinner(0);
        if (results && results.data) {
          results.data.map((value) => {
            value.actionData = JSON.stringify(value.action);
            value.activationStatus = value.status ? value.status.toUpperCase() : '';
            value.moduleType = 'ruleengine';
            return value;
          });
          this.data = {
            page: 1,
            total: results.data.length,
            data: results.data
          };
        }
      }, error => {
        this.SpinnerService.toggleSpinner(0);
        this.data.data = [];
        this.data.total = 0;
        this.data.page = 1;
      });
    } else if (this.ruleGroupType === 'profile') {
      this.ruleEngineService.getRuleEngineProfileData(queryData.ruleGroupId).subscribe((results) => {
        this.SpinnerService.toggleSpinner(0);
        if (results && results.data) {
          results.data.map((value) => {
            value.actionData = JSON.stringify(value.action);
            value.activationStatus = value.status ? value.status.toUpperCase() : '';
            value.moduleType = 'ruleengine';
            return value;
          });
          this.data = {
            page: 1,
            total: results.data.length,
            data: results.data
          };
        }
      }, error => {
        this.SpinnerService.toggleSpinner(0);
        this.data.data = [];
        this.data.total = 0;
        this.data.page = 1;
      });
    }

  }

  /**
   * Get Action Config
   */
  getActions(type) {
    let _module;
    if (type == 'app') {
      _module = EnumsService.AUTOPS_APP;
    } else if (type == 'profile') {
      _module = EnumsService.AUTOPS_CONFIG;
    } else {
      _module = EnumsService.AUTOPS_FIRMWARE;
    }

    const main_module = EnumsService.AUTOPS;
    // Form object to get the previliiages from server
    const obj = {
      moduleCode: main_module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe(prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

      this.actionsObj.actions = this.actionsArr.actionsArray.filter(function (item) {
        return item.type == 'edit' || item.type == 'delete';
      });
      this.actionsObj.actions.push({
        type: 'activationstatus',
        title: 'Change Activation Status'
      });

      this.actionsArr.actionsArray.push({
        type: 'activationstatus',
        title: 'Change Activation Status'
      });

      this.tableHeaderActions = this.actionsArr.headerRights;
      this.tableHeaderActions['deleteAction'] = false;
      this.actionsObj.actionsLabel = "Actions";
      // this.actionsObj.actions = [{ type: "edit", title: "edit" }, { type: "delete", title: "delete" }];

    });




  }

  /**
 * Set Type
 */
  setRuleType(event, typeName) {
    if (event.isUserInput) {
      this.ruleEngineType = typeName.value;
    }
  }

  /**
   * Get EnterPrise Ids
   */
  getEnterPriseId(index, data, page?) {
    // const obj = { limit: 500, offset: 0, page: 1, pageNum: 1, rpp: 500 };
    let obj;
    if (page) {
      let pageOffset = this.pageSize * 200;
      this.pageSize = this.pageSize + 1;
      obj = { limit: 200, offset: pageOffset, page: this.pageSize, pageNum: this.pageSize, rpp: 200 };
    } else {
      obj = { limit: 200, offset: 0, page: 1, pageNum: 1, rpp: 200 };
    }
    const totalEnterPriseCount = this.ruleEngineService.getTotalCountEnterprises();
    const totalEnterpriseResult = this.ruleEngineService.getVendorList(obj);
    this.SpinnerService.toggleSpinner(0);
    forkJoin([totalEnterPriseCount, totalEnterpriseResult]).subscribe(results => {
      this.SpinnerService.toggleSpinner(0);
      let valueArr = [];
      if (results[1]) {
        if (
          this.configModalOptionMode !== 'edit' &&
          this.configModalOptionMode !== 'view'
        ) {
          this.valueRuleDropdownData = this.valueRuleDropdownData.concat(results[1].data);
        } else {
          this.valueRuleDropdownData = results[1].data
        }
        this.valueRuleDropdownData.forEach((element, index) => {
          valueArr.push(
            {
              id: index,
              check: false,
              value: element.hqBpName,
              hqbpid: element.hqBpId,
              hqBpName: element.hqBpName,
              hqBpId: element.hqBpId
            });
        });
        this.valueRuleDropdownData = valueArr;
        if (this.expressionValues.length > 0) {
          for (let i = index; i < this.expressionValues.length; i++) {
            if (this.expressionValues[i].expressionValue === 'value') {
              if (this.expressionValues[i].backEndValue) {
                this.valueRuleDropdownData.map((value) => {
                  const values = value.value.replace(/\s+/g, '');
                  const keyValues = values.replace(/,/g, "").toLowerCase(); //remove single quote
                  const selectedValue = this.expressionValues[i].backEndValue.replace(/\s+/g, '').toLowerCase();
                  if (keyValues === selectedValue) {
                    value.check = true;
                    return value;
                  }
                });
              }
              this.expressionValues[i].dropdownValues = this.valueRuleDropdownData;
              this.expressionValues[i].selectedValue = false;
              this.expressionValues[i].dropdownValues.forEach(element => {
                if ((element.serviceType && element.serviceType == 'enterprise') ||
                  (element.hqbpid && element.hqbpid != '')) {
                  this.expressionValues[i].keyType = "enterprise";
                } else {
                  this.expressionValues[i].keyType = "notenterprise";
                }
              });
              break;
            }
          }
        }
      }
    }, error => {
      this.valueRuleDropdownData = [];
      this.SpinnerService.toggleSpinner(0);
      if (this.expressionValues.length > 0) {
        for (let i = index; i < this.expressionValues.length; i++) {
          if (this.expressionValues[i].expressionValue === 'value') {
            this.expressionValues[i].dropdownValues = [];
            this.expressionValues[i].selectedValue = false;
            break;
          }
        }
      }
      this.failureCase(error);
    });
  }
  searchWithEnterpriseName(evt, index) {
    if (evt.target.value) {
      this.filterSearch = evt.target.value;
      const obj = { hqBpName: evt.target.value };
      this.valueRuleDropdownData = [];
      const totalEnterpriseResult = this.ruleEngineService.getEnterpriseSearchName(obj);
      this.SpinnerService.toggleSpinner(1);
      forkJoin([totalEnterpriseResult]).subscribe(results => {
        this.SpinnerService.toggleSpinner(0);
        let valueArr = [];
        if (results[0] && results[0].data && results[0].data.length > 0) {
          this.valueRuleDropdownData = results[0].data;
          this.valueRuleDropdownData.forEach((element, index) => {
            valueArr.push(
              {
                id: index,
                check: false,
                value: element.hqBpName,
                hqbpid: element.hqBpId,
                hqBpName: element.hqBpName,
                hqBpId: element.hqBpId
              });
          });
          this.valueRuleDropdownData = valueArr;
          if (this.expressionValues.length > 0) {
            for (let i = index; i < this.expressionValues.length; i++) {
              if (this.expressionValues[i].expressionValue === 'value') {
                if (this.expressionValues[i].backEndValue) {
                  this.valueRuleDropdownData.map((value) => {
                    const values = value.value.replace(/\s+/g, '');
                    const keyValues = values.replace(/,/g, "").toLowerCase(); //remove single quote
                    const selectedValue = this.expressionValues[i].backEndValue.replace(/\s+/g, '').toLowerCase();
                    if (keyValues === selectedValue) {
                      value.check = true;
                      return value;
                    }
                  });
                }
                this.expressionValues[i].dropdownValues = this.valueRuleDropdownData;
                this.expressionValues[i].selectedValue = false;
                break;
              }
            }
          }
          this.SpinnerService.toggleSpinner(0);
        } else {
          this.valueRuleDropdownData = [];
          this.SpinnerService.toggleSpinner(0);
        }
      }, error => {
        this.valueRuleDropdownData = [];
        this.SpinnerService.toggleSpinner(0);
        if (this.expressionValues.length > 0) {
          for (let i = index; i < this.expressionValues.length; i++) {
            if (this.expressionValues[i].expressionValue === 'value') {
              this.expressionValues[i].dropdownValues = [];
              this.expressionValues[i].selectedValue = false;
              break;
            }
          }
        }
        this.failureCase(error);
      });
    } else {
      this.valueRuleDropdownData = [];
      this.filterSearch = '';
      this.pageSize = 1;
      this.getEnterPriseId(index, '', '');
    }
  }
  getServiceCategory(index, data) {
    this.ruleEngineService.getPartnerByHqbpId(this.hqbpid).subscribe((results) => {
      this.SpinnerService.toggleSpinner(0);
      let valueArr = [];
      if (results && results.data) {
        this.valueRuleDropdownData = results.data;
        this.valueRuleDropdownData.forEach((element, index) => {
          valueArr.push(
            {
              id: index,
              check: false,
              value: element.partnerName
            });
        });
        this.valueRuleDropdownData = valueArr;
        if (this.expressionValues.length > 0) {
          for (let i = index; i < this.expressionValues.length; i++) {
            if (this.expressionValues[i].expressionValue === 'value') {
              if (this.expressionValues[i].backEndValue) {
                this.valueRuleDropdownData.map((value) => {
                  const values = value.value.replace(/\s+/g, '');
                  const keyValues = values.replace(/,/g, "").toLowerCase(); //remove single quote
                  const selectedValue = this.expressionValues[i].backEndValue.replace(/\s+/g, '').toLowerCase();
                  if (keyValues === selectedValue) {
                    value.check = true;
                    return value;
                  }
                });
              }
              this.expressionValues[i].dropdownValues = this.valueRuleDropdownData;
              this.expressionValues[i].selectedValue = false;
              break;
            }
          }
        }
      }
    }, error => {
      this.valueRuleDropdownData = [];
      this.SpinnerService.toggleSpinner(0);
      if (this.expressionValues.length > 0) {
        for (let i = index; i < this.expressionValues.length; i++) {
          if (this.expressionValues[i].expressionValue === 'value') {
            this.expressionValues[i].dropdownValues = [];
            this.expressionValues[i].selectedValue = false;
            break;
          }
        }
      }
      this.failureCase(error);
    });
  }


  /**
   * Get Value Lable Rule Data
   */
  getValueLableDropdownData(data, index, selectedValue) {
    const params = { entityName: data };
    if (data.toLowerCase() === RuleEngineEnumService.ENTERPRISE_KEY) {
      //callenterprice\
      this.valueRuleDropdownData = [];
      this.pageSize = 1;
      this.getEnterPriseId(index, data);
    } else if (data.toLowerCase() === RuleEngineEnumService.SERVICE_KEY) {
      //service category
      this.valueRuleDropdownData = [];
      this.getServiceCategory(index, data);
    } else {
      this.valueRuleDropdownData = [];
      this.ruleEngineService.getValueRuleDropdownData(params).subscribe((results) => {
        this.SpinnerService.toggleSpinner(0);
        let valueArr = [];
        if (results && results.data) {
          this.valueRuleDropdownData = results.data;
          this.valueRuleDropdownData.forEach((element, index) => {
            valueArr.push(
              {
                id: index,
                check: false,
                value: element
              });
          });
          this.valueRuleDropdownData = valueArr;
          if (this.expressionValues.length > 0) {
            for (let i = index; i < this.expressionValues.length; i++) {
              if (this.expressionValues[i].expressionValue === 'value') {
                if (this.expressionValues[i].backEndValue) {
                  this.valueRuleDropdownData.map((value) => {
                    const values = value.value.replace(/\s+/g, '');
                    const keyValues = values.replace(/,/g, "").toLowerCase(); //remove single quote
                    const selectedValue = this.expressionValues[i].backEndValue.replace(/\s+/g, '').toLowerCase();
                    if (keyValues === selectedValue) {
                      value.check = true;
                      return value;
                    }
                  });
                }
                this.expressionValues[i].dropdownValues = this.valueRuleDropdownData;
                this.expressionValues[i].selectedValue = false;
                this.expressionValues[i].keyType = '';
                break;
              }
            }
          }
        }
      }, error => {
        this.valueRuleDropdownData = [];
        this.SpinnerService.toggleSpinner(0);
        if (this.expressionValues.length > 0) {
          for (let i = index; i < this.expressionValues.length; i++) {
            if (this.expressionValues[i].expressionValue === 'value') {
              this.expressionValues[i].dropdownValues = [];
              this.expressionValues[i].selectedValue = false;
              break;
            }
          }
        }
        this.failureCase(error);
      });
    }
    if (this.expressionValues.length > 0) {
      for (let i = index; i < this.expressionValues.length; i++) {
        if (this.expressionValues[i].expressionValue === 'value') {
          if (data.toLowerCase() === RuleEngineEnumService.ENTERPRISE_KEY) {
            //callenterprice
            this.expressionValues[i].dropdownValues.forEach(element => {
              if ((element.serviceType && element.serviceType == 'enterprise') ||
                (element.hqbpid && element.hqbpid != '')) {
                this.expressionValues[i].keyType = "enterprise";
              } else {
                this.expressionValues[i].keyType = "notenterprise";
              }
            });
          }
        }
      }
    }

  }


  getFirmwareName() {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = { limit: 500, offset: 0, domains: this.domainParams.name };
    } else {
      params = { limit: 500, offset: 0 };
    }
    this.ruleEngineService.getFirmwareName(params).subscribe(results => {
      if (results) {
        this.SpinnerService.toggleSpinner(0);
        this.firmareNames = results.data && results.data.items ? results.data.items : [];
        let versionValue = [];
        this.firmareNames.map((value) => {
          if (value.versions && value.versions.length > 0) {
            value.versions.forEach(element => {
              if (element.shortDescription) {
                versionValue.push(
                  {
                    id: value.id,
                    firmwareNameId: element.id,
                    value: value.name ? value.name : '',
                    firmwareName: value.name ? value.name + ',' + element.name : element.name,
                    firmwareSubmitValue: { name: 'firmware', versionid: element.id, version: null },
                    versionid: element.id
                  });
              }
            });
          }
          return value;
        });
        this.firmareNames = versionValue;
      }
    }, error => {
      this.firmareNames = [];
      this.SpinnerService.toggleSpinner(0);
    }
    );
  }

  getApplicationName() {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = { limit: 500, offset: 0, domainName: this.domainParams.name };
    } else {
      params = { limit: 500, offset: 0 };
    }
    this.ruleEngineService.getApplicationName(params).subscribe(results => {
      this.SpinnerService.toggleSpinner(0);
      if (results) {
        this.applicationNames = results.data && results.data.items ? results.data.items : [];
        let versionValue = [];
        this.applicationNames.map((value) => {
          if (value.versions && value.versions.length > 0) {
            value.versions.forEach(element => {
              if (value.name && element.id) {
                versionValue.push(
                  {
                    id: value.id,
                    applicationNameId: element.id,
                    value: value.name,
                    applicationName: value.name + ',' + element.name,
                    applicationSubmitValue: { name: 'app', versionid: element.id, version: null },
                    versionid: element.id
                  });
              }
            });
          }
          return value;
        });
        this.applicationNames = versionValue;
      }
    }, error => {
      this.SpinnerService.toggleSpinner(0);
      this.applicationNames = [];
    }
    );
  }

  getkeyRuleData() {
    const keyLabelObj = { pageNum: 1, rpp: 50 };
    this.ruleEngineService.getKeyRuleDropdownData(keyLabelObj).subscribe(results => {
      this.SpinnerService.toggleSpinner(0);
      if (results && results.data) {
        this.keyRuleDropdownData = results.data;
        let valueArr = [];
        this.keyRuleDropdownData.forEach((element, index) => {
          valueArr.push(
            {
              id: index,
              check: false,
              value: element
            });
        });
        this.keyRuleDropdownData = valueArr;
      }
    }, error => {
      this.SpinnerService.toggleSpinner(0);
      this.keyRuleDropdownData = [];
    }
    );
  }

  /**
   * Get Initial load All data
   */
  getInitialData(type) {

    this.getkeyRuleData();
    if (type === 'app') {
      this.getApplicationName();
    } else if (type === 'firmware') {
      this.getFirmwareName();
    }
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = { limit: 500, offset: 0, domainName: this.domainParams.name };
    } else {
      params = { limit: 500, offset: 0 };
    }
    if (type === 'profile') {
      const getProfileName = this.ruleEngineService.getProfileName(params);

      forkJoin([getProfileName]).subscribe(results => {
        this.SpinnerService.toggleSpinner(0);
        if (results && results[0]) {
          let profileNames = results[0] && results[0].data && results[0].data.items ? results[0].data.items : [];
          this.profileNames = profileNames.filter(function (e) {
            return e.name.trim() !== '';
          });
          this.profileNames.map((value) => {
            if (value.name) {
              value.profileSubmitValue = { name: 'profile', id: value.id, version: null };
              return value;
            }
          });
        }
      }, error => {
        this.SpinnerService.toggleSpinner(0);
        this.profileNames = [];
      }
      );
    }

  }
  /***
     * Submit Add / Edit Form
     */
  submitForm(form, close, formName) {
    const formData = form.value;
    if (this.expressionValues.length === 0) {
      this.noSelectionRules = 'Please create rule';
      return false;
    }
    // if (this.ruleEngineType == 'Profile') {
    //   this.createRuleEngineFormGroup.get('applicationNameId').clearValidators();
    //   this.createRuleEngineFormGroup.get('applicationNameId').updateValueAndValidity();
    //   this.createRuleEngineFormGroup.get('firmwareNameId').clearValidators();
    //   this.createRuleEngineFormGroup.get('firmwareNameId').updateValueAndValidity();
    // } else if (this.ruleEngineType == 'App') {
    //   this.createRuleEngineFormGroup.get('profileId').clearValidators();
    //   this.createRuleEngineFormGroup.get('profileId').updateValueAndValidity();
    //   this.createRuleEngineFormGroup.get('firmwareNameId').clearValidators();
    //   this.createRuleEngineFormGroup.get('firmwareNameId').updateValueAndValidity();
    // } else if (this.ruleEngineType == 'Firmware') {
    //   this.createRuleEngineFormGroup.get('applicationNameId').clearValidators();
    //   this.createRuleEngineFormGroup.get('applicationNameId').updateValueAndValidity();
    //   this.createRuleEngineFormGroup.get('profileId').clearValidators();
    //   this.createRuleEngineFormGroup.get('profileId').updateValueAndValidity();
    // }
    if (this.createRuleEngineFormGroup.valid) {
      this.filterSearch = "";
      if (formData.id) {
        this.updateRuleEngineSubmitData(formData, close);
      } else {
        this.addRuleEngineSubmitData(formData, close);
      }

    } else {
      this.cms.validateAllFormFields(form);
    }

  }

  /**
   * Click on check button check rule
   */
  checkRule() {
    if (this.expressionValues.length > 0) {
      const conditionValue = this.ruleEngineService.getArrayToStringCondition(this.expressionValues);
      const response = this.ruleEngineService.ruleCheckFormat(conditionValue, this.expressionValues);
      if (response) {
        this.submitFormFlag = true;
      } else {
        this.submitFormFlag = false;
      }
    }

  }

  /**
   * Update submited data
   */
  updateRuleEngineSubmitData(formData, close) {
    const conditionValue = this.ruleEngineService.getArrayToStringCondition(this.expressionValues);
    const response = this.ruleEngineService.ruleCheckFormat(conditionValue, this.expressionValues);
    if (response) {
      this.submitFormFlag = true;
    } else {
      this.submitFormFlag = false;
      return false;
    }
    const data = this.getQueryParams();
    let actionValue = []
    if (this.ruleEngineType == 'Profile') {
      if (formData.profileId && formData.profileId.length > 0) {
        formData.profileId.forEach(selectedProfile => {
          actionValue.push({ name: 'profile', id: selectedProfile, version: null });
        });
      }
    } else if (this.ruleEngineType == 'App') {
      //application
      if (formData.applicationNameId && formData.applicationNameId.length > 0) {
        formData.applicationNameId.forEach(selectedApplication => {
          actionValue.push({ name: 'app', id: selectedApplication, version: null });
        });
      }
    } else if (this.ruleEngineType == 'Firmware') {
      //application
      if (formData.firmwareNameId && formData.firmwareNameId.length > 0) {
        formData.firmwareNameId.forEach(selectedFirmware => {
          actionValue.push({ name: 'firmware', id: selectedFirmware, version: null });
        });
      }
    }
    const postParams =
    {
      "name": formData.ruleName.trim(),
      "description": formData.description.trim(),
      "flags": [
        "lock-on-active"
      ],
      "salience": 4,
      "dialect": "java",
      "condition": conditionValue,
      "action": actionValue,
      ruleGroupId: data.ruleGroupId,
      ruleId: formData.id
    }
    this.SpinnerService.toggleSpinner(1);
    this.ruleEngineService.updateRuleEngine('put', postParams, this.ruleGroupType).subscribe(
      res => {
        this.SpinnerService.toggleSpinner(0);
        if (res) {
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Rule Update Successfully'
          });
          const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10, userId: data.ruleGroupId }
          this.getRuleEngineData(event)
          this.closeModel(close);
        }
      },
      error => {
        this.failureCase(error);
      }
    );
  }

  /*** 
   * Create Rule Engine
   **/
  addRuleEngineSubmitData(formData, close) {
    const conditionValue = this.ruleEngineService.getArrayToStringCondition(this.expressionValues);
    const response = this.ruleEngineService.ruleCheckFormat(conditionValue, this.expressionValues);
    if (response) {
      this.submitFormFlag = true;
    } else {
      this.submitFormFlag = false;
      return false;
    }
    const data = this.getQueryParams();
    const ruleGroupId = data.ruleGroupId;
    let actionValue = []
    if (this.ruleEngineType == 'Profile') {
      if (formData.profileId && formData.profileId.length > 0) {
        formData.profileId.forEach(selectedProfile => {
          actionValue.push({ name: 'profile', id: selectedProfile, version: null });
        });
      }
    } else if (this.ruleEngineType == 'App') {
      //application
      if (formData.applicationNameId && formData.applicationNameId.length > 0) {
        formData.applicationNameId.forEach(selectedApplication => {
          actionValue.push({ name: 'app', id: selectedApplication, version: null });
        });
      }
    } else if (this.ruleEngineType == 'Firmware') {
      //application
      if (formData.firmwareNameId && formData.firmwareNameId.length > 0) {
        formData.firmwareNameId.forEach(selectedFirmware => {
          actionValue.push({ name: 'firmware', id: selectedFirmware, version: null });
        });
      }
    }
    const postParams =
    {
      "name": formData.ruleName.trim(),
      "description": formData.description.trim(),
      "flags": [
        "lock-on-active"
      ],
      "salience": 4,
      "dialect": "java",
      "condition": conditionValue,
      "action": actionValue,
      ruleId: ruleGroupId
    }
    this.SpinnerService.toggleSpinner(1);
    if (this.ruleGroupType === 'app') {
      this.ruleEngineService.createRuleEngine('post', postParams).subscribe(
        res => {
          this.SpinnerService.toggleSpinner(0);
          if (res) {
            this.dataService.broadcast('alert', {
              type: 'success',
              message: 'Rule Add Successfully'
            });
            const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10, userId: ruleGroupId }
            this.getRuleEngineData(event)
            this.closeModel(close);
          }
        },
        error => { this.failureCase(error); }
      );
    } else if (this.ruleGroupType === 'profile') {
      this.ruleEngineService.createProfileRuleEngine('post', postParams).subscribe(
        res => {
          this.SpinnerService.toggleSpinner(0);
          if (res) {
            this.dataService.broadcast('alert', {
              type: 'success',
              message: 'Rule Add Successfully'
            });
            const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10, userId: ruleGroupId }
            this.getRuleEngineData(event)
            this.closeModel(close);
          }
        },
        error => { this.failureCase(error); }
      );
    } else if (this.ruleGroupType === 'firmware') {
      this.ruleEngineService.createFirmwareeRuleEngine('post', postParams).subscribe(
        res => {
          this.SpinnerService.toggleSpinner(0);
          if (res) {
            this.dataService.broadcast('alert', {
              type: 'success',
              message: 'Rule Add Successfully'
            });
            const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10, userId: ruleGroupId }
            this.getRuleEngineData(event)
            this.closeModel(close);
          }
        },
        error => { this.failureCase(error); }
      );
    }

  }

  /**
   * Error Response
   */
  failureCase(error) {
    this.SpinnerService.toggleSpinner(0);
    this.dataService.broadcast('alert', {
      type: 'danger',
      message: error.error ? error.error : error.error && error.error.errorDetails ? error.error.errorDetails : 'Network error please try again'
    });
  }


  /**
   * CLick on delete button open modal
   */
  deleteItem(event) {
    this.openModel(this.deleteConfirmModalContent, event);
  }

  changeActivationStatus(event) {
    this.event = event;
    this.openModel(this.changeActivationModelContent, event);
  }

  /**
   *  Open Model 
   */
  openModel(content, event) {
    this.ruleEngineInfo = event;
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: 'sm',
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }

  /**
   * Redirect Rule Engine List
   */
  ruleEngineList(value) {
    this.router.navigate(['../main/rule-engine'],
      { queryParams: { ruleEngineId: value.ruleGroupId, type: value.purpose } });
  }

  /**
   * Delete Rule Engine
   */
  deleteRuleEngine(close) {
    const data = this.getQueryParams();
    const _req = { userName: data.ruleGroupId, ruleId: this.ruleEngineInfo.id };
    this.ruleEngineService.deleteRuleEngine(_req, this.ruleGroupType).subscribe((res: any) => {
      this.SpinnerService.toggleSpinner(0);
      this.dataService.broadcast('alert', {
        type: 'success',
        message: 'Delete Rule Successfully'
      });
      const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10, userId: data.ruleGroupId }
      this.getRuleEngineData(event);
      this.closeModel(close);
    });
  }

  checkActivationStatus(close) {
    const data = this.getQueryParams();
    const postParams =
    {
      status: this.event && this.event.status && this.event.status == 'inactive' ? 'active' : 'inactive',
      ruleGroupId: data.ruleGroupId,
      ruleId: this.event.id
    }
    this.SpinnerService.toggleSpinner(1);
    this.ruleEngineService.updateRuleEngine('put', postParams, this.ruleGroupType).subscribe(
      res => {
        this.SpinnerService.toggleSpinner(0);
        if (res) {
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Activation Status Changed successfully'
          });
          const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10, userId: data.ruleGroupId }
          this.getRuleEngineData(event)
          this.closeModel(close);
        }
      },
      error => {
        this.failureCase(error);
      }
    );
  }

  /**
   * Close popup model 
   */
  closeModel(close) {
    close('Cross click');
  }

  updateRuleEngine(event) {
    event.mode = 'edit';
    this.event = event;
    this.openAddRuleEngineModal(this.addRuleEngineContent, { mode: 'edit' });
    this.createRuleEngineForm(event);
  }

  viewRuleEngine(event) {
    event.mode = 'view';
    this.event = event;
    let conditionArr = [];
    const expressionArray = this.ruleEngineService.getConditionRuleExpression(event.condition);
    if (expressionArray && expressionArray.length > 0) {
      const viewrulecondition = this.ruleEngineService.getConditionRuleExpressionArray(expressionArray, this.getKeyRuleDropdownReset(), this.getValueRuleDropdownReset());
      if (viewrulecondition && viewrulecondition.length > 0) {
        viewrulecondition.forEach(value => {
          if (value.expressionType == 'button') {
            conditionArr.push({ type: value.expressionType, value: value.expressionValue });
          } else if (value.expressionType == 'dropdown' && value.expressionValue == 'key') {
            const selectedDropdownValue = value.dropdownValues.filter(value => value.check == true);
            if (selectedDropdownValue && selectedDropdownValue.length > 0) {
              conditionArr.push({ type: value.expressionType, value: selectedDropdownValue[0].value });
            } else {
              conditionArr.push({ type: value.expressionType, value: value.expressionValue });
            }
          }
          else if (value.expressionType == 'dropdown' && value.expressionValue == 'value') {
            conditionArr.push({ type: value.expressionType, value: value.backEndValue });
          }
        })
      }
      this.event['ruleCondition'] = conditionArr;
    }
    this.openAddRuleEngineModal(this.addRuleEngineContent, { mode: 'view' });
    this.createRuleEngineForm(event);
  }


  openAddRuleEngineModal(content, option) {
    this.resetModelValue();
    this.valueRuleDropdownData = [];
    this.configModalOptionMode = option.mode;
    if (
      this.configModalOptionMode !== 'edit' &&
      this.configModalOptionMode !== 'view'
    ) {
      this.initalForms();
    }
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: 'lg',
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }

  initalForms() {
    this.expressionValues = [];
    this.createRuleEngineForm();
  }

  checkFilterData(eventId, btnIndex, event, param, type) {
    if (event.isUserInput) {
      if (type === 'key') {
        this.getValueLableDropdownData(param.value, btnIndex, '');
      }
      if (type == 'value') {
        const hqbpid = this.valueRuleDropdownData.filter(value => value.value === param.value);
        if (hqbpid && hqbpid.length > 0) {
          this.hqbpid = hqbpid[0].hqbpid;
        }
      }
      this.expressionValues.forEach((value, i) => {
        if (i === btnIndex) {
          this.expressionValues[btnIndex].dropdownValues.forEach((checkboxValue, checkboxIndex) => {
            if (checkboxValue.id === eventId) {
              this.expressionValues[btnIndex].dropdownValues[checkboxIndex].check = true;
            } else {
              this.expressionValues[btnIndex].dropdownValues[checkboxIndex].check = false;
            }
            this.expressionValues[btnIndex].disable = true;
            this.expressionValues[btnIndex].selectedValue = true;

          });
        }
        // else {
        //   this.expressionValues[i].keyType = "notenterprise";
        // }
      });
      if (this.expressionValues.length > 0) {
        for (let i = 0; i < this.expressionValues.length; i++) {
          if (this.expressionValues[i].expressionValue === 'value') {
            if (param.value.toLowerCase() === RuleEngineEnumService.ENTERPRISE_KEY) {
              //callenterprice
              this.expressionValues[i].dropdownValues.forEach(element => {
                if ((element.serviceType && element.serviceType == 'enterprise') ||
                  (element.hqbpid && element.hqbpid != '')) {
                  this.expressionValues[i].keyType = "enterprise";
                } else {
                  this.expressionValues[i].keyType = "notenterprise";
                }
              });
            }
          }
        }
      }
      if (this.expressionValues.length > 0) {
        this.noSelectAnyruleDropdown = this.expressionValues.filter(value => value.selectedValue === false);
        if (this.noSelectAnyruleDropdown && this.noSelectAnyruleDropdown.length > 0) {
          this.noSelectionRules = 'Please select key or value';
          return false;
        }
      }
    }

  }


  /**
   * Click On multiple button create rule
   */
  createExpression(value, type) {
    if (this.expressionValues.length > 0) {
      if (type === 'delete') {
        this.expressionValues.splice(-1, 1);
      }
      this.noSelectAnyruleDropdown = this.expressionValues.filter(value => value.selectedValue === false);
      if (this.noSelectAnyruleDropdown && this.noSelectAnyruleDropdown.length > 0) {
        this.noSelectionRules = 'Please select key or value';
        return false;
      }
    }
    let dropdownData;
    let selectedValue;
    let enterpriseType = "notenterprise";
    if (type === 'dropdown') {
      this.filterKeySearch = '';
      this.filterValueSearch = '';
    }
    if (type !== 'delete') {
      if (value === 'key') {
        dropdownData = this.getKeyRuleDropdownReset();
        selectedValue = false;
      } else if (value === 'value') {
        dropdownData = this.getValueRuleDropdownReset();;
        selectedValue = false;
      }
      if (value == 'value' && type == 'dropdown') {
        const checkEnterprise = dropdownData.filter(value => value.serviceType == "enterprise");
        if (checkEnterprise && checkEnterprise.length > 0) {
          enterpriseType = "enterprise";
        }
      }
      this.expressionValues.push({
        expressionType: type, expressionValue: value, expressionStatus: true,
        dropdownValues: dropdownData, disable: false, selectedValue: selectedValue, keyType: enterpriseType
      });
    }

  }

  /**
   * Selected Key rule dropdown
   */
  compareKeyObjects(key: any): boolean {
    if (key.check === true) {
      return true;
    } else {
      return false;
    }
  }

  /**
 * Selected Value rule dropdown
 */
  compareValueObjects(value: any): boolean {
    if (value.check === true) {
      return true;
    } else {
      return false;
    }
  }


  /**
   * get Key Rule Drop Down Reset Value
   */
  getKeyRuleDropdownReset() {
    let response = [];
    if (this.keyRuleDropdownData && this.keyRuleDropdownData.length > 0) {
      this.keyRuleDropdownData.forEach(value => {
        response.push({ id: value.id, check: false, value: value.value });
      });
    }
    return response;

  }

  /**
   * get Key Rule Drop Down Reset Value
   */
  getValueRuleDropdownReset() {
    let response = [];
    if (this.valueRuleDropdownData && this.valueRuleDropdownData.length > 0) {
      this.valueRuleDropdownData.forEach(value => {
        if (value && value.hqbpid) {
          response.push({ id: value.id, check: false, value: value.value, serviceType: "enterprise" });
        } else {
          response.push({ id: value.id, check: false, value: value.value, serviceType: "" });
        }
      });
    }
    return response;

  }

  /**
    * Profile Dropdown Change Validation
  */
  profileDropdownChangeValidation(formGroup: FormGroup) {
    if (!formGroup.parent) {
      return null;
    }
    if (formGroup.parent.get('selectionType').value !== '' && formGroup.parent.get('selectionType').value === 2) {
      return Validators.required(formGroup);
    } else {
      return formGroup;
    }
  }
  /**
   * Application Dropdown Change Validation
   */
  applicationDropdownChangeValidation(formGroup: FormGroup) {
    if (!formGroup.parent) {
      return null;
    }
    if (formGroup.parent.get('selectionType').value !== '' && formGroup.parent.get('selectionType').value === 1) {
      return Validators.required(formGroup);
    } else {
      return formGroup;
    }
  }

  firmwareDropdownChangeValidation(formGroup: FormGroup) {
    if (!formGroup.parent) {
      return null;
    }
    if (formGroup.parent.get('selectionType').value !== '' && formGroup.parent.get('selectionType').value === 3) {
      return Validators.required(formGroup);
    } else {
      return formGroup;
    }
  }

  /**
   * Create Add / Edit Form  
   */
  createRuleEngineForm(event?) {
    let actionData = [];
    if (event && event.condition) {
      const expressionArray = this.ruleEngineService.getConditionRuleExpression(event.condition);
      if (expressionArray && expressionArray.length > 0) {
        this.expressionValues = this.ruleEngineService.getConditionRuleExpressionArray(expressionArray, this.getKeyRuleDropdownReset(), this.getValueRuleDropdownReset());
      }
    }
    if (event && event.action && event.action.length > 0) {
      const profileArr = event.action.filter(value => value.name === 'profile');
      const applicationArr = event.action.filter(value => value.name === 'app');
      const firmwareArr = event.action.filter(value => value.name === 'firmware');
      if (profileArr && profileArr.length > 0) {
        this.ruleEngineType = 'Profile';
      } else if (applicationArr && applicationArr.length > 0) {
        this.ruleEngineType = 'App';
      } else if (firmwareArr && firmwareArr.length > 0) {
        this.ruleEngineType = 'Firmware';
      }
      event.action.forEach(value => {
        if (value.name == 'profile') {
          actionData.push(value.id);
        } if (value.name == 'app') {
          actionData.push(value.id);
        } if (value.name == 'firmware') {
          actionData.push(value.id);
        }
      });
    }
    if (event && event.mode === 'view') {
      let profileIdsArr = [];
      let applicationIdsArr = [];
      let firmwareIdsArr = [];
      if (this.ruleEngineType === 'Profile') {
        if (this.profileNames.length > 0) {
          this.profileNames.forEach(value => {
            event.action.forEach(profileId => {
              if (value.id === profileId.id) {
                profileIdsArr.push(value.name);
              }
            });
          })
        }
        this.viewProfileIds = profileIdsArr;
      }
      if (this.ruleEngineType === 'App') {
        if (this.applicationNames.length > 0) {
          this.applicationNames.forEach(value => {
            event.action.forEach(applicationId => {
              if (value.versionid === applicationId.id) {
                applicationIdsArr.push(value.applicationName);
              }
            });
          })
        }
        this.viewApplicationIds = applicationIdsArr;
      }
      if (this.ruleEngineType === 'Firmware') {
        if (this.firmareNames.length > 0) {
          this.firmareNames.forEach(value => {
            event.action.forEach(firmwareId => {
              if (value.versionid === firmwareId.id) {
                firmwareIdsArr.push(value.firmwareName);
              }
            });
          })
        }

        this.viewFirmwareIds = firmwareIdsArr;
      }
    }

    let ruleTypeData = "";
    if (this.ruleEngineType == 'Profile') {
      ruleTypeData = "2";
    } else if (this.ruleEngineType == 'App') {
      ruleTypeData = "1";
    } else if (this.ruleEngineType == 'Firmware') {
      ruleTypeData = "3";
    }
    if (this.ruleEngineType == 'Profile') {
      this.createRuleEngineFormGroup = this.fb.group({
        id: [{ value: event && event.id ? event.id : '', disabled: event && event.mode === 'view' ? true : false }],
        actionProfileId: [{ value: event ? this.actionProfiles[0].actionProfileId : '', disabled: event && event.mode === 'view' ? true : false }, Validators.required],
        profileId: [
          { value: event && event.action ? actionData : '', disabled: event && event.mode === 'view' ? true : false },
          Validators.required],
        description: [{ value: event && event.description ? event.description : '', disabled: event && event.mode === 'view' ? true : false },
        [Validators.required, this.noWhitespaceValidator]],
        ruleName: [{ value: event && event.name ? event.name : '', disabled: event && event.mode === 'view' ? true : false },
        [Validators.required, this.noWhitespaceValidator]],
      })
    } else if (this.ruleEngineType == 'App') {
      this.createRuleEngineFormGroup = this.fb.group({
        id: [{ value: event && event.id ? event.id : '', disabled: event && event.mode === 'view' ? true : false }],
        actionProfileId: [{ value: event ? this.actionProfiles[0].actionProfileId : '', disabled: event && event.mode === 'view' ? true : false }, Validators.required],
        applicationNameId: [
          { value: event && event.action ? actionData : '', disabled: event && event.mode === 'view' ? true : false },
          Validators.required],
        description: [{ value: event && event.description ? event.description : '', disabled: event && event.mode === 'view' ? true : false },
        [Validators.required, this.noWhitespaceValidator]],
        ruleName: [{ value: event && event.name ? event.name : '', disabled: event && event.mode === 'view' ? true : false },
        [Validators.required, this.noWhitespaceValidator]],
      })
    } else if (this.ruleEngineType == 'Firmware') {
      this.createRuleEngineFormGroup = this.fb.group({
        id: [{ value: event && event.id ? event.id : '', disabled: event && event.mode === 'view' ? true : false }],
        actionProfileId: [{ value: event ? this.actionProfiles[0].actionProfileId : '', disabled: event && event.mode === 'view' ? true : false }, Validators.required],
        description: [{ value: event && event.description ? event.description : '', disabled: event && event.mode === 'view' ? true : false }, Validators.required],
        firmwareNameId: [
          { value: event && event.action ? actionData : '', disabled: event && event.mode === 'view' ? true : false },
          Validators.required],
        ruleName: [{ value: event && event.name ? event.name : '', disabled: event && event.mode === 'view' ? true : false }, Validators.required],
      })
    } else {
      this.createRuleEngineFormGroup = this.fb.group({
        selectionType: [{ value: ruleTypeData, disabled: event && event.mode === 'view' ? true : false }, Validators.required],
        id: [{ value: event && event.id ? event.id : '', disabled: event && event.mode === 'view' ? true : false }],
        actionProfileId: [{ value: event ? this.actionProfiles[0].actionProfileId : '', disabled: event && event.mode === 'view' ? true : false }, Validators.required],
        profileId: [
          { value: event && event.action ? actionData : '', disabled: event && event.mode === 'view' ? true : false },
          this.profileDropdownChangeValidation],
        description: [{ value: event && event.description ? event.description : '', disabled: event && event.mode === 'view' ? true : false },
        [Validators.required, this.noWhitespaceValidator]],
        applicationNameId: [
          { value: event && event.action ? actionData : '', disabled: event && event.mode === 'view' ? true : false },
          this.applicationDropdownChangeValidation],
        firmwareNameId: [
          { value: event && event.action ? actionData : '', disabled: event && event.mode === 'view' ? true : false },
          this.firmwareDropdownChangeValidation],
        ruleName: [{ value: event && event.name ? event.name : '', disabled: event && event.mode === 'view' ? true : false },
        [Validators.required, this.noWhitespaceValidator]],
      })
    }


  }
  /**
   * White space validation
   */
  public noWhitespaceValidator(control: FormControl) {
    if (control.value) {
      const isWhitespace = (control.value || '').trim().length === 0;
      const isValid = !isWhitespace;
      return isValid ? null : { 'whitespace': true };
    }
    return { 'whitespace': false };
  }

  /**
  * Reset Selected Modal Value
  */
  resetModelValue() {
    this.profileNameData = '';
    this.filterSearch = '';
    this.pageSize = 1;
  }

  fetchMore(index, event) {
    if (event > 0 && this.filterSearch == '') {
      if (this.valueRuleDropdownData.length == this.pageSize * 200) {
        this.getEnterPriseId(index, '', event);
      }
    }
  }
}
