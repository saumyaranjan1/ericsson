import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { SharedModule } from '../shared/shared.module';
import { RuleEngineRoutingModule } from './rule-engine-routing.module';
import { RuleEngineComponent } from './rule-engine.component';
import { RuleEngineService } from './rule-engine.service';

@NgModule({
  imports: [
    CommonModule,
    RuleEngineRoutingModule,
    AngularMultiSelectModule,
    SharedModule
  ],
  providers: [RuleEngineService],
  declarations: [RuleEngineComponent]
})
export class RuleEngineModule { }
