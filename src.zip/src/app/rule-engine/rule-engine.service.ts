import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';
import { RuleEngineEnumService } from './rule-engine-enum.service';
import { Action } from 'rxjs/internal/scheduler/Action';

@Injectable()
export class RuleEngineService {

  constructor(private interceptor: InterceptorService) { }
  /**
   * Get Rule Engine Data
   */
  getRuleEngineData(request) {
    let params = {};
    params['extraParams'] = "?rule-group-id=" + request;
    return this.interceptor.httpCall('get', 'getRuleEngineList', params);
  }

  getTotalCountEnterprises() {
    return this.interceptor.httpCall('get', 'getRuleEnginegTotalCountEnterprises');
  }

  getVendorList(request) {
    return this.interceptor.httpCall('get', 'getRuleEngineEnterpriseList', request);
  }

  getPartnerByHqbpId(request) {
    let params = {};
    params['extraParams'] = "?hqbpid=" + request;
    return this.interceptor.httpCall('get', 'getPartnerByHqbpId', params);
  }

  getRuleEngineFirmwareData(request) {
    let params = {};
    params['extraParams'] = "?rule-group-id=" + request;
    return this.interceptor.httpCall('get', 'getFirmwareRuleEngineList', params);
  }
  getRuleEngineProfileData(request) {
    let params = {};
    params['extraParams'] = "?rule-group-id=" + request;
    return this.interceptor.httpCall('get', 'getProfileRuleEngineList', params);
  }
  /**
 * Get Profile Name
 */
  getProfileName(request) {
    request.responseType = 'json';
    return this.interceptor.httpCall('get', 'getProfileName', request);
  }
  /**
 * Get Application Name
 */
  getApplicationName(request) {
    request.responseType = 'json';
    return this.interceptor.httpCall('get', 'getApplicationName', request);
  }
  /**
 * Get Firmware Name
 */
  getFirmwareName(request) {
    request.responseType = 'json';
    return this.interceptor.httpCall('get', 'getFirmwareName', request);
  }
  /**
* Get Key Rule Dropdown Data
*/
  getKeyRuleDropdownData(request) {
    request.responseType = 'json';
    return this.interceptor.httpCall('get', 'getKeyRuleDropdown', request);
  }
  /**
  * Get Value Rule Dropdown Data
  */
  getValueRuleDropdownData(request) {
    request.responseType = 'json';
    return this.interceptor.httpCall('post', 'getValueRuleDropdown', request);
  }
  /**
   * Submit Rule Engine
   */
  createRuleEngine(method, action) {
    action.responseType = 'text';
    action.extraParams = "?rule-group-id=" + action.ruleId;
    return this.interceptor.httpCallReturn(method, 'createRuleEngine', action);
  }
  createProfileRuleEngine(method, action) {
    action.responseType = 'text';
    action.extraParams = "?rule-group-id=" + action.ruleId;
    return this.interceptor.httpCallReturn(method, 'createProfileRuleEngine', action);
  }
  createFirmwareeRuleEngine(method, action) {
    action.responseType = 'text';
    action.extraParams = "?rule-group-id=" + action.ruleId;
    return this.interceptor.httpCallReturn(method, 'createFirmwareRuleEngine', action);
  }
  /**
   * Update Rule Engine
   */
  updateRuleEngine(method: string, request: any, ruleGroupType) {
    request.responseType = 'text';
    request['extraParams'] = "?rule-group-id=" + request.ruleGroupId + '&rule-id=' + request.ruleId;
    if (ruleGroupType === 'app') {
      return this.interceptor.httpCall(method, 'updateRuleEngine', request);
    } else if (ruleGroupType === 'profile') {
      return this.interceptor.httpCall(method, 'updateProfileRuleEngine', request);
    } else if (ruleGroupType === 'firmware') {
      return this.interceptor.httpCall(method, 'updateFirmwareRuleEngine', request);
    }

  }
  /**
   * Condition field converted in to array
   */
  getConditionRuleExpression(ruleStr) {
    const removespacerules = ruleStr.replace(/\s+/g, ''); // remove space
    const rules = removespacerules.replace(/['"]+/g, ''); // remove double quotes
    const rulesStr = rules.replace(/,/g, ""); //remove single quote
    const reulesModifiedString = rulesStr.split('(').join('( ')
      .split('==').join(' == ')
      .split(')').join(' )')
      .split('&&').join(' && ')
      .split('||').join(' || ')
      .split('<').join(' < ')
      .split('>').join(' > ');
    const reulesArr = reulesModifiedString.split(" ");
    if (reulesArr && reulesArr.length > 0) {
      return reulesArr;
    } else {
      return [];
    }

  }


  /**
   * Delete Rule Group
   */
  deleteRuleEngine(request, ruleGroupType) {
    request.responseType = 'text';
    request.extraParams = "?rule-group-id=" + request.userName + '&rule-id=' + request.ruleId;
    if (ruleGroupType === 'app') {
      return this.interceptor.httpCall('delete', 'deleteRuleEngine', request.extraParams);
    } else if (ruleGroupType === 'profile') {
      return this.interceptor.httpCall('delete', 'deleteProfileRuleEngine', request.extraParams);
    } else if (ruleGroupType === 'firmware') {
      return this.interceptor.httpCall('delete', 'deleteFirmwareRuleEngine', request.extraParams);
    }

  }

  changeActivationRuleEngine(request, ruleGroupType) {
    request.responseType = 'text';
    request.extraParams = "?rule-group-id=" + request.userName + '&rule-id=' + request.ruleId;
    if (ruleGroupType === 'app') {
      return this.interceptor.httpCall('delete', 'statusChangeRuleEngine', request.extraParams);
    } else if (ruleGroupType === 'profile') {
      return this.interceptor.httpCall('delete', 'statusChangeProfileRuleEngine', request.extraParams);
    } else if (ruleGroupType === 'firmware') {
      return this.interceptor.httpCall('delete', 'statusChangeFirmwareRuleEngine', request.extraParams);
    }

  }


  /**
   * Rule Check Format
   */
  ruleCheckFormat(ruleStr, expressionValues) {
    // let format = RuleEngineEnumService.DATA.ruleCheckRegex;
    // if (ruleStr.match(format)) {
    //   return true;
    // }
    // return false;
    //return this.checkRule(ruleStr);
    return this.checkRuleArray(expressionValues);
  }
  /*
  ** Return Expression Array
  **/
  getConditionRuleExpressionArray(expressionArray, keyRule, ValueRule) {
    if (keyRule && keyRule.length > 0) {
      let format = RuleEngineEnumService.DATA.MatchSpecialCharacter;
      let epressionValue = [];
      let expressionType = '';
      let keyValue = '';
      let labelKeyIndex = "";
      expressionArray.forEach((expressionValue, index) => {
        if (expressionValue.match(format)) {
          epressionValue.push({
            "disable": false,
            "dropdownValues": "",
            "expressionStatus": true,
            "expressionType": "button",
            "expressionValue": expressionValue,
            "selectedValue": ""
          });
        } else {
          let dropDownValue = [];
          const noSelectKeyAnyruleDropdown = keyRule.filter(value => value.value.replace(/\s+/g, '').toLowerCase() === expressionValue.toLowerCase());
          if (noSelectKeyAnyruleDropdown && noSelectKeyAnyruleDropdown.length > 0) {
            expressionType = 'key';
            labelKeyIndex = index;
            let keyid = noSelectKeyAnyruleDropdown[0] && noSelectKeyAnyruleDropdown[0].id ? noSelectKeyAnyruleDropdown[0].id : 0;
            keyValue = noSelectKeyAnyruleDropdown[0] && noSelectKeyAnyruleDropdown[0].value ? noSelectKeyAnyruleDropdown[0].value : '';
            let ruleArray = [];
            keyRule.forEach(item => {
              ruleArray.push({ id: item.id, value: item.value, check: item.id === keyid ? true : false })
            });
            dropDownValue = ruleArray;
            epressionValue.push(
              {
                "disable": false,
                "dropdownValues": dropDownValue,
                "expressionStatus": true,
                "expressionType": "dropdown",
                "expressionValue": expressionType,
                "selectedValue": true,
                "data": '',
                "keyIndex": '',
                "backEndValue": ''
              });
          } else {
            if (keyValue) {
              expressionType = 'value';
              epressionValue.push(
                {
                  "disable": false,
                  "dropdownValues": [],
                  "expressionStatus": true,
                  "expressionType": "dropdown",
                  "expressionValue": expressionType,
                  "selectedValue": true,
                  "data": keyValue,
                  "keyIndex": labelKeyIndex,
                  "backEndValue": expressionValue
                });
            }
          }

        }

      });
      return epressionValue;
    }
    return [];
  }

  /**
   * Return Array to string
   */
  getArrayToStringCondition(arrayData) {
    const conditionArray = [];
    arrayData.forEach(dataValue => {
      if (dataValue.expressionType === 'button') {
        conditionArray.push(dataValue.expressionValue);
      }
      if (dataValue.expressionType === 'dropdown') {
        if (dataValue.dropdownValues && dataValue.dropdownValues.length > 0) {
          const selectionDropdownValue = dataValue.dropdownValues.filter(value => value.check === true);
          if (selectionDropdownValue && selectionDropdownValue.length > 0) {
            if (dataValue.expressionValue === "value") {
              conditionArray.push("'" + selectionDropdownValue[0].value + "'");
            } else {
              conditionArray.push(selectionDropdownValue[0].value);
            }

          }
        }
      }
    });
    const conditionStr = conditionArray.toString();
    const conditionActualStr = conditionStr.replace(/,/g, ""); //remove single quote
    return conditionActualStr;
  }

  checkRule(expr) {
    let holder = [];
    let openBrackets = ['('];
    let closedBrackets = [')']
    let openOperator = ['==', '&&', '||', '=', '&', '|'];
    let closeOperator = ['==', '&&', '||', '=', '&', '|'];
    let format = /^([a-zA-Z0-9 _.'-]+)$/;
    for (let i = 0; i < expr.length; i++) {
      if (expr[i] === '(') {
        holder.push(expr[i]);
      } else if (expr[i].match(format)) {
        const matchStr = expr[i].match(format);
        let openPair = expr[matchStr.index];
        if (holder[holder.length - 1] !== openPair) {
          holder.push(expr[i])
        }
      } else if (closeOperator.includes(expr[i])) {
        let openPair = openOperator[closeOperator.indexOf(expr[i])]
        if (holder[holder.length - 1] === openPair) {
          holder.push(expr[i])
        }
      } else if (closedBrackets.includes(expr[i])) {
        let openPair = openBrackets[closedBrackets.indexOf(expr[i])]
        if (holder[holder.length - 1] === openPair) {
          holder.splice(-1, 1)

        } else {
          holder.push(expr[i])
        }
      } else {
        holder.push(expr[i])
      }
    }

    return (holder.length === 0) // return true if length is 0, otherwise false
  }



  checkRuleArray(expressionValues) {
    let result = 0;
    if (expressionValues.length > 0) {
      for (let index = 0; index < expressionValues.length; index++) {
        if (expressionValues.length > index + 1) {
          if (expressionValues[0].expressionValue == '(' && index == 0) {
            result = 1;
          } else if (index % 2 === 0 && expressionValues[index].expressionType == 'button' &&
            expressionValues[index - 1].expressionValue == 'key' &&
            expressionValues[index + 1].expressionValue == 'value' &&
            expressionValues[index].expressionValue == '==') {
            //even elements are here, you can access it by box
            result = 1;
          } else if (index % 2 === 0 && expressionValues[index].expressionType == 'button' &&
            expressionValues[index - 1].expressionValue == 'value' &&
            expressionValues[index + 1].expressionValue == 'key' &&
            expressionValues[index].expressionValue !== '==') {
            //even elements are here, you can access it by box
            result = 1;
          } else if (index % 2 !== 0 &&
            (expressionValues[index].expressionValue == 'key' || expressionValues[index].expressionValue == 'value')
            && expressionValues[index].expressionType == 'dropdown') {
            //odd elements are here, you can access it by box
            result = 1;
          } else if (expressionValues.length == index + 1 &&
            expressionValues[expressionValues.length - 1].expressionValue == ')') {
            result = 1;
          } else {
            result = 0;
            break;
          }
        } else if (expressionValues[expressionValues.length - 1].expressionValue == ')') {
          result = 1;
        } else {
          result = 0;
          break;
        }

      };
    }
    if (result == 1) {
      return true;
    } else {
      return false;
    }
  }

  getEnterpriseSearchName(request) {
    return this.interceptor.httpCall('get', 'getRuleCreateEnterpriseSearchName', request);
  }

}


