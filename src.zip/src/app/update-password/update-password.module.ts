import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UpdatePasswordComponent } from './update-password.component';
import { SharedModule } from '../shared/shared.module';
import { UpdatePasswordRoutingModule } from './update-password-routing.module';
import { MatFormFieldModule, MatInputModule, MatRadioModule, MatCheckboxModule, MatListModule, MatSelectModule, MatNativeDateModule, MatTooltipModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { UpdatePasswordService } from './update-password.service';



@NgModule({
  declarations: [UpdatePasswordComponent],
  imports: [
    CommonModule,
    SharedModule,
    MatFormFieldModule,
    UpdatePasswordRoutingModule,
    MatInputModule,
    MatFormFieldModule,
    MatRadioModule,
    MatCheckboxModule,
    MatListModule,
    MatSelectModule,
    MatNativeDateModule,
    FormsModule,
    ReactiveFormsModule,
    MatTooltipModule
  ],
  providers: [UpdatePasswordService]
})
export class UpdatePasswordModule { }
