import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { AppConfigService } from '../app-config.service';
import { DataService } from '../shared/services/data.service';

@Injectable({
  providedIn: 'root'
})
export class UpdatePasswordService {

  constructor(private interceptor: InterceptorService,
    private acs: AppConfigService,
    private cms: CommonMethodsService,
    private dataService: DataService) { }
  changePassword(request, type) {
    request.jioUtils = true;
    return this.interceptor.httpCall('put',type=='portal'? 'changePortalPassword':'changePlatformPassword', request);
  }

  getFinalObject(obj) {
    const finalObj = {
      loginId: this.dataService.getParseAndAtob('loginMember'),
      oldPwd: this.getEmcrypedPassword(obj.currentPassword),
      newPwd: this.getEmcrypedPassword(obj.password),
      category: this.dataService.getAtobLocalStorage('category') ? this.dataService.getAtobLocalStorage('category') : '',
      passwordType: this.dataService.getParseFromSession('passwordType') ? this.dataService.getParseFromSession('passwordType') : 'portal',
      hqbpId: this.dataService.getParseFromSession('loginHqBpId') ? this.dataService.getParseFromSession('loginHqBpId') : '',
      partnerId: obj.partnerId
    };
    return finalObj;
  }

  getEmcrypedPassword(pwd) {
    return this.cms.encryptData(pwd, this.acs.configData['encryptKeyForSha256']);
  }

  forgotPassword(request, privateVar) {
    return this.interceptor.httpCall('get', privateVar ? 'forgotPlatformPasswordprivate' : 'forgotPlatformPasswordpublic', request);
  }
}
