import {
  Component, OnInit, ViewChild,
  ElementRef,
} from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl,
  FormGroupDirective,
  NgForm
} from '@angular/forms';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { ErrorStateMatcher } from '@angular/material/core';
import { UpdatePasswordService } from './update-password.service';
import { DataService } from '../shared/services/data.service';
import { SpinnerService } from '../shared/services/spinner.service';
import { InterceptorService } from '../shared/services/interceptor.service';
import { AppConfigService } from '../app-config.service';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';

class CrossFieldErrorMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted && form.invalid;
    return (control.dirty && form.invalid) || isSubmitted;
  }
}

@Component({
  selector: 'app-update-password',
  templateUrl: './update-password.component.html',
  styleUrls: ['./update-password.component.less']
})
export class UpdatePasswordComponent implements OnInit {
  @ViewChild('partnerListModel', { static: false }) partnerListModel: ElementRef;

  updateForm: FormGroup;
  errorMatcher = new CrossFieldErrorMatcher();
  alert: any;
  alertSubs: any;
  passwordIsValid = false;
  tabelTooltip = 'Change Password';
  privateVar;
  loginMemberInfo = {
    loginId: ''
  };
  partnerValueModule;
  passwordType;
  partnerList;
  category;
  partnerIds = [];
  showPartnerSelection;
  constructor(
    private ngbModal: NgbModal,
    private fb: FormBuilder,
    private cms: CommonMethodsService,
    private router: Router,
    private acs: AppConfigService,
    private updatePwdService: UpdatePasswordService,
    private dataService: DataService,
    private spinnerService: SpinnerService,
    private interceptor: InterceptorService
  ) { }

  ngOnInit() {
    this.privateVar = this.acs.configData['private'];
    this.loginMemberInfo.loginId = this.dataService.getParseAndAtob(
      'loginMember'
    ).split('@')[0].replace('.', ' ');
    this.passwordType = this.dataService.getParseFromSession('passwordType') ? this.dataService.getParseFromSession('passwordType') : 'portal';
    this.category = this.dataService.getAtobLocalStorage('category');
    this.updateFormBlock();
  }

  openConnectionModel(content, size) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        keyboard: false,
      })
      .result.then(result => { }, reason => { });
  }
  updateFormBlock() {
    const partnerId = this.dataService.getParseFromSession('loginPartnerId');
    let isEnterprise = false;
    if (this.category == 'ENTERPRISE') {
      isEnterprise = true;
    }

    // If it's public portal append logged in menber partner ID to partnerID or choose from dropdown for PARTNER_ADMIN category

    this.updateForm = this.fb.group({
      partnerId: [isEnterprise ? partnerId : null],
      currentPassword: [null, Validators.required],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    },
      {
        // check whether our password and confirm password match
        validator: this.cms.passwordValidatorMatrialInput
      });
  }
  submitForm(formData) {
    if (this.updateForm.valid) {
      this.updatePassword(formData.value);
    } else {
      this.cms.validateAllFormFields(this.updateForm);
    }
  }
  updatePassword(data) {
    const updatePwdReq = this.updatePwdService.getFinalObject(data);
    this.updatePwdService.changePassword(updatePwdReq, this.passwordType).subscribe(res => {
      if (res.data && res.message) {
        this.dataService.broadcast('alert', {
          type: 'danger',
          message: res.message
        });
        this.showPartnerSelection = true;
        const partner = this.updateForm.controls['partnerId'];
        partner.setValidators([Validators.required]);
        partner.updateValueAndValidity();
        this.partnerIds = [];
        this.partnerIds = res.data;
      } else {
        if (updatePwdReq.passwordType == 'platform') {
          this.dataService.broadcast('alert', {
            type: 'success',
            message: res.message
          });
          this.clearData();
        } else {
          sessionStorage.clear();
          this.router.navigate(['/login']);
        }
      }
    });
  }
  passwordValid(event) {
    this.passwordIsValid = event;
  }
  displayAlert = res => {
    this.alert = res;
    setTimeout(() => {
      this.alert = null;
      this.spinnerService.toggleSpinner(0);
    }, 4000);
  }
  clear(event) {
    this.updateForm.setValue({ password: '', confirmPassword: '' });
  }

  closeModel(close) {
    close('Cross click');
  }

  clearData() {
    this.updateFormBlock();
    this.showPartnerSelection = false;
  }

  changepartherValue(partner){
    this.partnerValueModule=partner;
  }
  
  forgotPassword(close?,partner?) {
    var request = {
      'loginId': this.dataService.getParseAndAtob('loginMember'),
      'passwordType': 'platform'
    }
    if (this.privateVar) {
      request['category'] = this.category
    }
    if(partner){
      request['partnerId'] = partner
      this.closeModel(close);
    }
    this.updatePwdService.forgotPassword(request, this.privateVar).subscribe(res => {
      if (res.data) {
        this.partnerList=res.data;
        this.openConnectionModel(this.partnerListModel, 'sm');
      }
     
      this.partnerValueModule='';
      this.dataService.broadcast('alert', {
        type: 'success',
        message: res.message
      });
    });
  }
}
