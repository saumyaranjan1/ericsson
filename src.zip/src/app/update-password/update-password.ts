export interface UpdatePassword {
    password: string;
    newPassword: string;
    confirmPassword: string;
   }
   