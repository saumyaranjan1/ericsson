import { Injectable } from '@angular/core';
import { InterceptorService } from './../shared/services/interceptor.service';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';

@Injectable({
  providedIn: 'root'
})
export class ModelDmDomainService {

  constructor(private interceptor: InterceptorService) { }


  /**
   * Get Model DM Domain Details
   */
  modelDmDomainDetail() {
    return this.interceptor.httpCall('get', 'getModelDmDomainDetail');
  }

  /**
   * Get View Data
   */
  getViewData(action) {
    const params = { extraParams: '/' + action };
    return this.interceptor.httpCall('get', 'getModelDmDomainViewData', params);
  }

  /**
   * Error List
   */
  getErrorData() {
    return this.interceptor.httpCall('get', 'getModelDmDomainErrorData');
  }

  getDownloadFile(action) {
    action['responseType'] =  'blob';
    return this.interceptor.httpCall('get', 'getModelDmDomainDownloadFile', action);
  }

  /**
   * Upload File
   */
  uploadFileData(action) {
    return this.interceptor.httpCall('post', 'uploadModelDmDomainFile', action);
  }

  getHistoryData() {
    return this.interceptor.httpCall('get', 'getModelDmDomainHistoryData');
  }
}
