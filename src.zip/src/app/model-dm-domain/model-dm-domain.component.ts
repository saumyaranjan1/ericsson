import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { ModelDmDomainEnumService } from './model-dm-domain-enum.service';
import { ModelDmDomainService } from './model-dm-domain.service';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../shared/services/data.service';

import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { SpinnerService } from '../shared/services/spinner.service';
import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';

@Component({
  selector: 'app-model-dm-domain',
  templateUrl: './model-dm-domain.component.html',
  styleUrls: ['./model-dm-domain.component.less']
})
export class ModelDmDomainComponent implements OnInit {
  @ViewChild('addModelDmDomainModalContent', { static: true }) addModelDmDomainModalContent: ElementRef;
  @ViewChild('confirmationModel', { static: true }) confirmationModel: ElementRef;
  uploadedFile;
  uploadedFileName;
  uplodBtn = true;
  fileExtension;
  fileSubmitReq;
  closeUploadFile;
  tacCodeList = ModelDmDomainEnumService.DATA;
  historyData = ModelDmDomainEnumService.HISTORY_DATA;
  errorData = ModelDmDomainEnumService.ERROR_DATA;
  errorListStatus = false;
  tableHeaderActions = {
    add: true,
    search: true,
    exportToCsv: true,
    dropDown: false
  };
  isView = false;
  isError = false;
  isHistory = false;
  createTacFormGroup: FormGroup;
  event;
  columns = ModelDmDomainEnumService.DATA.columns;
  tableHeader = ModelDmDomainEnumService.DATA.tableHeader;
  actionsObj = {
    actionsLabel: ModelDmDomainEnumService.DATA.actionsLabel,
    actions: ModelDmDomainEnumService.DATA.actions
  };
  hideListTable = false;
  actionsArr: any;
  constructor(
    private mdds: ModelDmDomainService,
    private spinnerService: SpinnerService,
    private DataService: DataService,
    private fb: FormBuilder,
    private userService: UserService,
    private ngbModal: NgbModal,
    private dataService: DataService
  ) { }

  ngOnInit() {
    this.getModelDmDomainLIst();
    this.getErrorCodeList();
  }

  /**
   * Spinner Start
   */
  spinnerStart() {
    this.spinnerService.toggleSpinner(1);
  }

  /**
  * Spinner End
  */
  spinnerEnd() {
    this.spinnerService.toggleSpinner(0);
  }

  /**
   * Export to csv file
   */
  async exportDataToCsv(data) {
    this.spinnerService.toggleSpinner(1);
    let csv = ModelDmDomainEnumService.tacCodeCsvHeader;
    if (data && data.data && data.data.length > 0) {
      let csvArray = [];
      csvArray = data.data;
      csvArray.forEach((row) => {
       // csv += row['partnerId'] ? row['partnerId'] + "|" : '' + "|";
        // csv += row['id'] ? row['id'] + "," : '' + ",";
        csv += row['domain'] ? row['domain'] + "|" : '' + "|";
        csv += row['tac'] ? row['tac'] + "|" : '' + "|";
        csv += row['manufacturer'] ? row['manufacturer'] + "|" : '' + "|";
        csv += row['modelName'] ? row['modelName'] + "|" : '' + "|";
        //csv += row['hqbpid'] ? row['hqbpid'] + "|" : '' + "|";
        //csv += row['label'] ? row['label'] + "|" : '' + "|";
        // csv += row['createdAt'] ? row['createdAt']  : '|';
        csv += row['os'] ? row['os'] + "|" : '' + "|";
        csv += row['deviceType'] ? row['deviceType'] : '';
        csv += '\n';
      });
    }
    const hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    hiddenElement.target = '_blank';
    hiddenElement.download = 'tac_code_of_list.csv';
    hiddenElement.click();
    this.spinnerService.toggleSpinner(0);
  }


  sampleFileDownload() {
    let link = document.createElement('a');
    link.setAttribute('type', 'hidden');
    link.href = 'assets/files/model-dm-domain-sample.csv';
    link.download = '';
    document.body.appendChild(link);
    link.click();
    link.remove();
  }

  /**
   * 
   * Get Actions previliges forDM Domain
   */
  getActions() {
    const _module = EnumsService.DEVCON;

    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe( prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

     
    this.tacCodeList.tableActions = this.actionsArr;
    this.tacCodeList.tableActions.search=this.actionsArr.headerRights.search;
    this.tacCodeList.tableActions.upload = this.actionsArr.headerRights.upload;
    this.tacCodeList.actions =  this.actionsArr.actionsArray;
    this.tacCodeList.tableActions['exportToCsv']=true;
    this.tacCodeList.tableActions['refreshData']=true;
      
    });
    }

  /**
   * Get Tac Code Data
   */
  getModelDmDomainLIst() {
    this.getActions();
    this.spinnerStart();
    let tacCodeData = [];
    const userData = this.DataService.getParseAndAtob(
      'loginMember'
    ).split('@')[0].replace('.', ' ');
    this.tacCodeList.refreshValue = userData ? 'Last Uploaded By : ' + userData : 'Last Uploaded By :';

    this.mdds.modelDmDomainDetail().subscribe(
      res => {
        this.spinnerEnd();
        if (res) {
          let today;
          if (res[0].createdAt) {
            today = new Date(res[0].createdAt);
          } else {
            today = new Date();
          }
          const date = today.getDate() + '/' + (today.getMonth() + 1) + '/' + today.getFullYear();
          var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
          this.tacCodeList.uploadValue = 'Last uploaded date : ' + date + ' ' + time + '<br />';
          tacCodeData = res.map(data => {
            data.tacId = data.id;
            data.status = data.status;
            return data;
          });
        };
        this.tacCodeList.data = tacCodeData;
      },
      error => {
        this.tacCodeList.data = [];
        this.failureCase(error);
      }
    );
  }

  /**
   * Get Error code list
   */
  getErrorCodeList() {
    this.spinnerStart();

    this.mdds.getErrorData().subscribe(
      res => {
        this.spinnerEnd();
        let today;
        if (res && res.length > 0) {
          if (res[0].createdAt) {
            today = new Date(res[0].createdAt);
          } else {
            today = new Date();
          }
          const date = today.getDate() + '/' + (today.getMonth() + 1) + '/' + today.getFullYear();
          var time = today.getHours() + ":" + today.getMinutes() + ":" + today.getSeconds();
          this.errorListStatus = true;
          this.tacCodeList.uploadValue = 'Last uploaded date : ' + date + ' ' + time + '<br />';
          this.tacCodeList.validationError = true;
        } else {
          this.errorListStatus = false;
          //this.tacCodeList.uploadValue = 'Last uploaded date : None' + '<br />';
          this.tacCodeList.validationError = false;
        }
      },
      error => {
        // this.tacCodeList.uploadValue = 'Last uploaded date : None' + '<br />';
        this.errorListStatus = false;
        this.tacCodeList.validationError = false;
        this.failureCase(error);
      }
    );
  }

  getErrorData() {
    let errorData = [];
    this.hideTable();
    this.spinnerStart();
    this.isView = false;
    this.isError = true;
    this.isHistory = false;
    const userData = this.DataService.getParseAndAtob(
      'loginMember'
    ).split('@')[0].replace('.', ' ');
    this.mdds.getErrorData().subscribe(res => {
      this.spinnerEnd();
      if (res) {
        errorData = res.map(data => {
          data.tacId = data.id;
          data.downloadkey = data.fileName;
          data.createdBy = userData ? userData : '-';
          data.operatinsystem = data.os ? data.os : '';
          return data;
        });
      };
      this.errorData.data = errorData;
    },
      error => {
        this.errorData.data = [];
        this.failureCase(error);
      }
    );
  }

  hideTable() {
    this.hideListTable = !this.hideListTable;
    if (!this.hideListTable) {
      this.isView = false;
      this.isError = false;
      this.isHistory = false;
    }
  }

  getHistoryData() {
    let historyDaya = [];
    this.hideTable();
    this.spinnerStart();
    this.isView = false;
    this.isError = false;
    this.isHistory = true;
    const userData = this.DataService.getParseAndAtob(
      'loginMember'
    ).split('@')[0].replace('.', ' ');
    this.mdds.getHistoryData().subscribe(res => {
      this.spinnerEnd();
      if (res) {
        historyDaya = res.map(data => {
          data.tacId = data.tacId;
          data.downloadkey = data.fileName;
          data.createdBy = userData ? userData : '-';
          return data;
        });
      };
      this.historyData.data = historyDaya;
    },
      error => {
        this.historyData.data = [];
        this.failureCase(error);
      }
    );
  }

  /**
   * View Data
   **/
  viewData(event) {
    this.hideTable();
    this.isView = !this.isView;
    this.isError = false;
    this.isHistory = false;
    this.event = event;
    // this.mdds.getViewData(event.tacId).subscribe(result => {
    //   this.event = result;
    // },
    //   error => {
    //     this.event = '';
    //     this.failureCase(error);
    //   });
  }

  fileEvent($event) {
    this.uploadedFile = $event.target.files[0];
    this.uploadedFileName = this.uploadedFile.name;
    const dotPos = this.uploadedFile.name.lastIndexOf('.');
    if (this.uploadedFile.name.lastIndexOf('.') > 0) {
      this.fileExtension = this.uploadedFile.name.substring(
        dotPos + 1,
        this.uploadedFile.name.length
      );
    }
    if (this.fileExtension.toLowerCase() === 'csv') {
      this.createTacFormGroup.controls.uploadFile.setValue(
        this.uploadedFileName
      );
      this.fileSubmitReq = new FormData();
      this.fileSubmitReq.append('file', this.uploadedFile);
    }
  }


  closeModel(close) {
    close('Cross click');
  }

  submitForm(form, close) {
    this.closeUploadFile = close;
    if (form.valid) {
      this.openModel(this.confirmationModel, event, 'sm');
    }
  }

  uploadFile(close, closeUpload) {
    this.uplodBtn = false;
    this.closeModel(close);
    this.closeModel(closeUpload);
    this.spinnerStart();
    this.mdds.uploadFileData(this.fileSubmitReq).subscribe(
      result => {
        this.uplodBtn = true;
        this.spinnerEnd();
        this.DataService.broadcast('alert', {
          type: 'success',
          message: 'Upload successfully'
        });
        this.getModelDmDomainLIst();
        this.getErrorCodeList();
      },
      error => {
        this.uplodBtn = true;
        this.getModelDmDomainLIst();
        this.getErrorCodeList();
        this.fileSubmitReq = new FormData();
        this.fileSubmitReq.append('file', this.uploadedFile);
        this.failureErrorCase(error);
      }
    );
  }

  openAddConfigModal() {
    this.createTacCodeForm();
    this.openModel(this.addModelDmDomainModalContent, event, 'sm');
  }
  downloadTacFile(event) {
    this.spinnerStart();
    if (event && event.gridId && event.gridId && event.fileName) {
      this.mdds.getDownloadFile({ id: event.gridId }).subscribe(result => {
        this.spinnerEnd();
        var newBlob = new Blob([result], { type: "application/csv" });
        if (window.navigator && window.navigator.msSaveOrOpenBlob) {
          window.navigator.msSaveOrOpenBlob(newBlob);
          return;
        }
        const data = window.URL.createObjectURL(newBlob);
        var link = document.createElement('a');
        link.href = data;
        link.download = event.fileName;
        link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
        setTimeout(function () {
          window.URL.revokeObjectURL(data);
          link.remove();
        }, 100);
      },
        error => {
          this.failureCase(error);
        });
    }
  }




  createTacCodeForm(event?) {
    this.createTacFormGroup = this.fb.group({
      uploadFile: [event ? event.uploadFile : '', Validators.required],
    })
  }

  openModel(content, event, size) {
    this.ngbModal
      .open(content, {
        windowClass: "jio-modal config-push-popup",
        size: size,
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }


  /** 
  * Failure Case
  **/
  failureCase(error) {
    this.spinnerService.toggleSpinner(0);
    this.DataService.broadcast('alert', {
      type: 'danger',
      message: error && error.error ? error.error.errorDetails : 'Network error please try again'
    });
  }

  failureErrorCase(error) {
    this.spinnerService.toggleSpinner(0);
    this.DataService.broadcast('alert', {
      type: 'danger',
      message: error ? error : 'Network error please try again'
    });
  }

}
