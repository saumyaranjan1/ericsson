import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ModelDmDomainComponent } from './model-dm-domain.component';
import { SharedModule } from '../shared/shared.module';
import { ModelDmDomainRoutingModule } from './model-dm-domain-routing.module';


@NgModule({
  declarations: [ModelDmDomainComponent],
  imports: [
    CommonModule,
    SharedModule,
    ModelDmDomainRoutingModule
  ],
  providers: []
})
export class ModelDmDomainModule { }
