import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { ModelDmDomainComponent } from './model-dm-domain.component';


const routes: Routes = [{ path: '', component: ModelDmDomainComponent }];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  exports: [RouterModule]
})
export class ModelDmDomainRoutingModule { }
