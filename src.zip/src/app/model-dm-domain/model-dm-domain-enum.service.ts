import { Injectable } from '@angular/core';
import { animationFrameScheduler } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ModelDmDomainEnumService {
  public static DATA = {
    data: [],
    columns: [
      {
        displayName: 'DM Domain',
        key: 'domain',
        filter: ''
      },
      {
        displayName: 'tac',
        key: 'tacId',
        filter: ''
      },
      {
        displayName: 'model',
        key: 'modelName',
        filter: ''
      },
      {
        displayName: 'Manufacturer',
        key: 'manufacturer',
        filter: ''
      }, {
        displayName: 'os',
        key: 'os',
        filter: ''
      },
      {
        displayName: 'device Type',
        key: 'deviceType',
        filter: ''
      }
    ],
    actions: [
      {
        type: 'view',
        title: 'view'
      }
    ],
    actionsLabel: '',
    tableHeader: 'Model To DM Domain',
    refreshHeader: 'Model To DM Domain View History',
    refreshValue: "Last Uploaded By : ",
    uploadValue: 'New Upload : None',
    validationError: false,
    tableActions: {
      add: false,
      search: true,
      dropdown: false,
      exportToCsv: true,
      showCheck: false,
      refreshData: true,
      upload: false
    },
    tabelTooltip: 'This is the index page which shows list of Model To DM Domain',
    tabelTooltipShow:true,
  };


  public static HISTORY_DATA = {
    data: [],
    columns: [
      {
        displayName: 'Uploaded BY',
        key: 'createdBy',
        filter: ''
      },
      {
        displayName: 'Uploaded On',
        key: 'createdOn',
        filter: 'dateWithTime'
      },
      {
        displayName: 'Number Of Tac Codes',
        key: 'tacCnt',
        filter: ''
      },
      {
        displayName: 'Uploaded File',
        key: 'downloadkey',
        filter: ''
      }, {
        displayName: 'Status',
        key: 'status',
        filter: ''
      }
    ],
    actions: [
      {
        type: 'view',
        title: 'view'
      }
    ],
    actionsLabel: '',
    tableHeader: 'Model To DM Domain : History',
    refreshHeader: 'Model To DM Domain View History',
    refreshValue: "Last Uploaded By : ",
    tableActions: {
      add: false,
      search: true,
      dropdown: false,
      exportToCsv: false,
      showCheck: false,
      refreshData: false,
      upload: false
    },
    tabelTooltip: 'This is the index page which shows list of History'
  };

  public static ERROR_DATA = {
    data: [],
    columns: [
      {
        displayName: 'Error MSG',
        key: 'errorMsg',
        filter: ''
      },
      {
        displayName: 'DM Domain',
        key: 'domain',
        filter: ''
      },
      {
        displayName: 'TAC',
        key: 'tac',
        filter: ''
      },
      {
        displayName: 'model',
        key: 'modelName',
        filter: ''
      },
      {
        displayName: 'Manufacturer',
        key: 'manufacturer',
        filter: ''
      },{
        displayName: 'OS',
        key: 'os',
        filter: ''
      },
      {
        displayName: 'device Type',
        key: 'deviceType',
        filter: ''
      }
    ],
    actions: [

    ],
    actionsLabel: '',
    tableHeader: 'Error observed in following Model To DM Domain',
    tableActions: {
      add: false,
      search: true,
      dropdown: false,
      exportToCsv: false,
      showCheck: false,
      refreshData: false,
      upload: false
    },
    tabelTooltip: 'This is the index page which shows list of Error List'
  };


  public static tacCodeCsvHeader =
    'DM Domain|TAC|Manufacturer|Model Name|Operating System|Device Type\n';
     
}
