import { NgModule } from '@angular/core';
import { SharedModule } from '../shared/shared.module';
import { AccessDeniedRoutingModule } from './access-denied-routing.module';
import { AccessDeniedComponent } from './access-denied.component';



@NgModule({
  declarations: [AccessDeniedComponent],
  imports: [
    AccessDeniedRoutingModule,
    SharedModule
  ]
})
export class AccessDeniedModule { }
