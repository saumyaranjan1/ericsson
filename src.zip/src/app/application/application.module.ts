import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './../shared/shared.module';
import { ApplicationRoutingModule } from './application-routing.module';
import { ApplicationComponent } from './application.component';
import { ApplicationService } from './application.service';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    ApplicationRoutingModule
  ],
  declarations: [ApplicationComponent],
  providers: [ApplicationService]
})
export class ApplicationModule { }
