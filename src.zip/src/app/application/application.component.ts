import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { Router } from '@angular/router';

import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { ApplicationService } from './application.service';
import { IAppFormData } from './application';
import { DataService } from '../shared/services/data.service';
import { InlinePagenationTableComponent } from '../shared/components/inline-pagenation-table/inline-pagenation-table.component';
import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';
import { HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.less']
})
export class ApplicationComponent implements OnInit {
  @ViewChild('addAppContent', { static: true }) addAppContent: ElementRef;
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild(InlinePagenationTableComponent, { static: false }) child: InlinePagenationTableComponent;

  appForm: FormGroup;
  configModalOptionMode = null;
  newRowData: any;
  deleatParam: any;
  modalConfig = {
    create: { headerText: 'Create App', primeBtnText: 'Create' },
    edit: { headerText: 'Edit App', primeBtnText: 'Update' },
    view: { headerText: 'View App' },
    sige: { sm: 'sm', lg: 'lg' }
  };
  appInfo;
  data = {
    data: [],
    columns: [
      {
        displayName: 'appid',
        key: 'appId',
        filter: '',
        input: true,
        dropdown: false,
        textArea: false,
        save: true,
        editvalue: false,
        rajex: '^[A][0-9]{9}',
        errorMassage: 'App Id format is A followed by nine digits',
        isNotRequired: true
      },
      {
        displayName: 'appname',
        key: 'appName',
        filter: '',
        input: true,
        dropdown: false,
        textArea: false,
        save: true,
        editvalue: false
      },
      {
        displayName: 'appKey',
        key: 'appKey',
        filter: '',
        input: true,
        dropdown: false,
        textArea: false,
        save: true,
        editvalue: false
      },
      {
        displayName: 'app Type',
        key: 'appTypeData',
        filter: '',
        input: false,
        dropdown: false,
        textArea: false,
        save: true,
        singleSelect: true,
        editvalue: false
      },
      {
        displayName: 'appDescription',
        key: 'appDescription',
        filter: '',
        input: false,
        dropdown: false,
        textArea: true,
        save: true,
        editvalue: true
      }
    ],
    actions: [
    ],
    actionsLabel: 'Actions',
    tableHeader: 'IOT App On-boarding',
    tableActions: {
      search: true,
      add: true,
      view: true,
      delete: true,
      edit: true
    }
  };
  actionsArr;
  constructor(
    private formBuilder: FormBuilder,
    private ngbModal: NgbModal,
    private cms: CommonMethodsService,
    private appService: ApplicationService,
    private userService: UserService,
    public router: Router,
    private dataService: DataService
  ) { }

  ngOnInit() {
    this.appFormBlock();
    setTimeout(() => {
      this.getApplicationDetails();
    });
  }

  editChanges(emit){
    if(emit.appType=='FIXED'){
      this.data.columns[3].editvalue=true;
      this.data.data[emit.id].appTypeData.values=[{ value: 'FIXED', name: 'FIXED' },{ value: 'SYSTEM_DEFAULT', name: 'SYSTEM DEFAULT' }];
    }else{
      this.data.columns[3].editvalue=false;
      this.data.data[emit.id].appTypeData.values=[{ value: 'ASSIGNED', name: 'ASSIGNED' }];
    }
  }
  sendAppId(event) {
    if (event) {
      this.data.data[0].appTypeData.values=[{ value: 'FIXED', name: 'FIXED' }];
    }else{
      this.data.data[0].appTypeData.values=[{ value: 'ASSIGNED', name: 'ASSIGNED' }];
    }
  }

  appFormBlock(event?) {
    this.appForm = this.formBuilder.group({
      appId: [event ? event.appId : null],
      appName: [event ? event.appName : null, Validators.required],
      appKey: [event ? event.appKey : null, Validators.required],
      appDescription: [
        event ? event.appDescription : null,
        [Validators.required, Validators.maxLength(1024)]
      ]
    });
  }
  addApp(option) {
    this.configModalOptionMode = option.mode;
    this.appFormBlock();
    this.openModal(this.addAppContent, this.modalConfig.sige.lg);
  }
  editApp(event, option) {
    this.configModalOptionMode = option.mode;
    this.appFormBlock(event);
    if (option.mode === 'view') {
      this.appForm.disable();
    }
    this.openModal(this.addAppContent, this.modalConfig.sige.lg, event);
  }
  openModal(content, size, event?) {
    this.appInfo = event;
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        backdrop: 'static',
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }
  closeModel(close) {
    close('Cross click');
  }

  submitForm(event) {
    this.createApp(event.data, event.action);
  }


  createApp(data, action) {
    const obj = {};
    if (action) {
      obj['url'] = 'createApplication';
      obj['method'] = 'post';
    } else {
      obj['url'] = 'updateApplication';
      obj['method'] = 'put';
    }
    var param = {
      'appDescription': data.appDescription,
      'appId': data.appId,
      'appKey': data.appKey,
      'appName': data.appName,
      'appType': data.appTypeData.showItem
    }
    this.appService.createApplication(obj, param).subscribe(res => {
      if (!action) {
        this.dataService.broadcast('alert', {
          type: 'success',
          message: `Update successfully!`
        });
      } else {
        this.dataService.broadcast('alert', {
          type: 'success',
          message: `Save successfully!`
        });
      }
      //this.getApplicationDetails();
      this.router
      .navigateByUrl('../main/dboard', { skipLocationChange: true })
      .then(() => this.router.navigate(['../main/app_ui_api']));
      this.child.cancelEdit(data);
      this.child.submit = false;
    });
  }

  setId() {
    this.data.data.forEach(function (item, key) {
      item["id"] = key;
    });
  }

  getApplicationDetails() {
    this.getActions();
    this.appService.getApplicationDetails().subscribe(res => {
      if (res) {
        this.data.data = res;
        this.data.data.forEach(element => {
          element['appTypeData'] = {};
          element['appTypeData']['showItem'] = element.appType;
          element['appTypeData']['model'] = element.appType =='SYSTEM_DEFAULT' ? 'SYSTEM DEFAULT' : element.appType ;
          element['appTypeData']['values'] = [{ value: 'ASSIGNED', name: 'ASSIGNED' }, { value: 'FIXED', name: 'FIXED' }];

        });
        this.setId();
        this.child.updateEditCache('notEdit');
      }
    });
  }
  getActions() {
    const _module = EnumsService.APP_UI_API;

    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe(prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );
      this.data.tableActions = this.actionsArr;
      this.data.tableActions.search = this.actionsArr.headerRights.search;
      this.data.tableActions.add = this.actionsArr.headerRights.add;
      this.data.tableActions.delete = this.actionsArr.headerRights.delete;
      this.data.actions = this.actionsArr.actionsArray;
    });


  }

  openDeleteModal(event) {
    this.deleatParam = event.appName
    this.openModal(
      this.deleteConfirmModalContent,
      this.modalConfig.sige.sm,
      event
    );
  }

  deleteApp(close) {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      body: {
        "appName": this.appInfo.appName
      }
    }
    this.appService.deleteApplication(options).subscribe((res: any) => {
      this.getApplicationDetails();
      this.closeModel(close);
    });
  }

  getnewRowData(event) {
    this.newRowData = {
      'appid': '',
      'appName': '',
      'appKey': '',
      'appTypeData': {},
      'appDescription': '',
      'newRow': true
    };

    this.newRowData.appTypeData.showItem = [];
    this.newRowData.appTypeData.model = [];
    this.newRowData.appTypeData.values = [{ value: 'ASSIGNED', name: 'ASSIGNED' }, { value: 'FIXED', name: 'FIXED' }]
    this.data.data.splice(0, 0, this.newRowData);
    this.child.updateEditCache('edit');
  }
}
