import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class ApplicationService {

  constructor(private interceptorService: InterceptorService) { }

  getApplicationDetails() {
    return this.interceptorService.httpCall('get', 'getApplications');
  }

  createApplication(obj, request) {
    return this.interceptorService.httpCall(obj.method, obj.url, request);
  }

  deleteApplication(request) {
    const param = {
      'data': request,
      'isdelete': true
    }
    return this.interceptorService.httpCall('delete', 'deleteApplication', param);
  }
}
