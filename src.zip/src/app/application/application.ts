export interface IAppFormData {
    appId: number;
    appName: string;
    appkey: string;
    appDescription: string;
}
