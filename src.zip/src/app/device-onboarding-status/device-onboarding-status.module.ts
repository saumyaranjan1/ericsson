import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DeviceOnBoardingComponent } from './device-onboarding-status.component';
import { SharedModule } from '../shared/shared.module';
import { DeviceOnBoardingRoutingModule } from './device-onboarding-status-routing.module';


@NgModule({
  declarations: [DeviceOnBoardingComponent],
  imports: [
    CommonModule,
    SharedModule,
    DeviceOnBoardingRoutingModule
  ],
  providers: []
})
export class DeviceOnBoardingModule { }
