import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DeviceOnBoardingService } from './device-onboarding-status.service';
import { DeviceOnBoardingEnumService } from './device-onboarding-status-enum.service';
import * as jsonURL from "./../../assets/dropdown-json/dropdown.json";
import { SpinnerService } from '../shared/services/spinner.service';

@Component({
  selector: 'app-device-onboarding-status',
  templateUrl: './device-onboarding-status.component.html',
  styleUrls: ['./device-onboarding-status.component.less']
})
export class DeviceOnBoardingComponent implements OnInit {
  jsonData: any = (jsonURL as any).default;
  columns = DeviceOnBoardingEnumService.DATA.columns;
  eventcolumns = DeviceOnBoardingEnumService.DATA.eventcolumns;
  headerDropdownList;
  eventDropdownList;
  hideListTable = true;
  actionsObj = {
    actionsLabel: DeviceOnBoardingEnumService.DATA.actionsLabel,
    actions: DeviceOnBoardingEnumService.DATA.actions
  };
  tableHeader = DeviceOnBoardingEnumService.DATA.tableHeader;
  tableEventHeader = DeviceOnBoardingEnumService.DATA.tableEventHeader;
  showGridCheckBox=DeviceOnBoardingEnumService.DATA.showGridCheckBox;
  deleteFlag=DeviceOnBoardingEnumService.DATA.deleteFlag;
  tableHeaderActions = {
    add: false,
    provisionsearch: true,
    exportToCsv: false,
    provisiondropDown: true,
    deviceEventRequest:true
  }
  tableEventHeaderActions = {
    add: false,
    provisionsearch: true,
    exportToCsv: false,
    provisiondropDown: true
  }
  data = {
    page: 1,
    total: 1,
    data: []
  };
  eventdata = {
    page: 1,
    total: 1,
    data: []
  };
  constructor(
    private dos: DeviceOnBoardingService,
    private spinnerService: SpinnerService
  ) { }

  ngOnInit() {
    this.headerDropdownList = this.jsonData.deviceonboardingdropdown;
    this.eventDropdownList = this.jsonData.deviceeventonboardingdropdown;
  }

  eventOnboardingData(event){
    this.hideListTable = false;
  }

  hideTable(){
    this.hideListTable = true;
  }

  /**
   * Spinner Start
   */
  spinnerStart() {
    this.spinnerService.toggleSpinner(1);
  }

  /**
  * Spinner End
  */
  spinnerEnd() {
    this.spinnerService.toggleSpinner(0);
  }

  getActions() {
    this.actionsObj.actions = [];
  }

  /**
   * Get Device Data
   */
  getData(obj) {
    const params = { "limit": obj.limit, "offset": obj.offset };
    this.spinnerStart();
    let devicdeData = [];
    this.dos.getDeviceData(params).subscribe(
      res => {
        if (res && res.data && res.data.length > 0) {
          devicdeData = res.data.map(data => {
            return data;
          });
        }
        this.data = {
          page: obj.page,
          total: res.totalCount,
          data: devicdeData
        };
        this.spinnerEnd();
      },
      error => {
        this.data = {
          page: 1,
          total: 1,
          data: devicdeData
        };
        this.spinnerEnd();
      }
    );
    this.getActions();
  }

  /**
   * Get Device Data
   */
  getEventData(obj) {
    const params = { "limit": obj.limit, "offset": obj.offset };
    this.spinnerStart();
    let devicdeData = [];
    this.dos.getEventDeviceData(params).subscribe(
      res => {
        if (res && res.data && res.data.length > 0) {
          devicdeData = res.data.map(data => {
            data.status = data.result
            return data;
          });
        }
        this.eventdata = {
          page: obj.page,
          total: res.totalCount,
          data: devicdeData
        };
        this.spinnerEnd();
      },
      error => {
        this.eventdata = {
          page: 1,
          total: 1,
          data: devicdeData
        };
        this.spinnerEnd();
      }
    );
    this.getActions();
  }
  /**
   * Get Search Device Data
   */
  getDataBySearch(data) {
    this.spinnerStart();
    let obj;
    let devicdeData = [];
    obj = this.dos.getObject(data);
    obj.limit = 10;
    obj.offset = 0;
    this.dos.getDeviceData(obj).subscribe(
      res => {
        if (res && res.data && res.data.length > 0) {
          devicdeData = res.data.map(data => {
            return data;
          });
        }
        this.data = {
          page: obj.page,
          total: res.totalCount,
          data: devicdeData
        };
        this.spinnerEnd();
      },
      error => {
        this.data = {
          page: 1,
          total: 1,
          data: devicdeData
        };
        this.spinnerEnd();
      }
    );
  }

  getEventDataBySearch(data) {
    this.spinnerStart();
    let obj;
    let devicdeData = [];
    obj = this.dos.getObject(data);
    obj.limit = 10;
    obj.offset = 0;
    this.dos.getEventDeviceData(obj).subscribe(
      res => {
        if (res && res.data && res.data.length > 0) {
          devicdeData = res.data.map(data => {
            data.status = data.result
            return data;
          });
        }
        this.eventdata = {
          page: obj.page,
          total: res.totalCount,
          data: devicdeData
        };
        this.spinnerEnd();
      },
      error => {
        this.eventdata = {
          page: 1,
          total: 1,
          data: devicdeData
        };
        this.spinnerEnd();
      }
    );
  }
}
