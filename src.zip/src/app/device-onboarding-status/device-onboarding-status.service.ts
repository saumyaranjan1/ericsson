import { Injectable } from '@angular/core';
import { InterceptorService } from './../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class DeviceOnBoardingService {

  constructor(private interceptor: InterceptorService) { }

  /**
   * Get Device Details
   */
  getDeviceData(params) {
    return this.interceptor.httpCall('get', 'getDeviceOnboardingstatus', params);
  }
  getEventDeviceData(params) {
    return this.interceptor.httpCall('get', 'getDeviceEventOnboardingstatus', params);
  }

  getObject(request) {
    const key = request['dropDownValue'].trim();
    const value = request['searchKey'].trim();
    const dataObj = {};
    if (request.dropDownValue.trim() === 'deviceid') {
      let deviceSpace = request.searchKey.split(",");
      let deviceIds = [];
      if (deviceSpace && deviceSpace.length > 0) {
        deviceSpace.forEach(element => {
          deviceIds.push(element);
        });
      } else {
        deviceIds.push(deviceSpace);
      }
      dataObj['deviceIds'] = value;
    } else {
      dataObj['domain'] = value;
    }
    return dataObj;
  }
}