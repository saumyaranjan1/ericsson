import { Injectable } from '@angular/core';
import { animationFrameScheduler } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DeviceOnBoardingEnumService {
  public static DATA = {
    data: [],
    columns: [
      {
        displayName: 'Device Id',
        key: 'deviceId',
        filter: ''
      },
      {
        displayName: 'RedBendId',
        key: 'redBendId',
        filter: ''
      },
      {
        displayName: 'Domain',
        key: 'domain',
        filter: ''
      }, 
      {
        displayName: 'Registered Status',
        key: 'registered',
        filter: ''
      }
      
    ],
    eventcolumns: [
      {
        displayName: 'Device Id',
        key: 'deviceId',
        filter: ''
      },
      {
        displayName: 'Failure Reason',
        key: 'failureReason',
        filter: ''
      },
      {
        displayName: 'Domain',
        key: 'domain',
        filter: ''
      }, 
      {
        displayName: 'Status',
        key: 'status',
        filter: ''
      },
      {
        displayName: 'Action',
        key: 'action',
        filter: ''
      },
      {
        displayName: 'Event Date & Time',
        key: 'timeInMs',
        filter: 'dateWithTime'
      }
      
    ],
    actions: [],
    tableHeader: 'DM Registration Status',
    tableEventHeader: 'DM Registration Event',
    deleteFlag:true,
    showGridCheckBox:true,
    actionsLabel: '',
    tableActions: {
      search: true,
      dropdown: true,
      exportToCsv: true,
      showCheck: false,
    }
  };


}