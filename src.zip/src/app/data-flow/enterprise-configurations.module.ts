import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EnterpriseConfigurationsComponent } from './enterprise-configurations.component';
import { EnterpriseConfigurationsRoutingModule } from './enterprise-configurations-routing.module';
import { SharedModule } from '../shared/shared.module';
import { EnterpriseConfigurationsService } from './enterprise-configurations.service';
//import { UserOnboardService } from '../../user-onboard/user-onboard.service';


@NgModule({
  declarations: [EnterpriseConfigurationsComponent],
  imports: [
    CommonModule,
    SharedModule,
    EnterpriseConfigurationsRoutingModule
  ],
  providers: [EnterpriseConfigurationsService],
})
export class EnterpriseConfigurationsModule { }
