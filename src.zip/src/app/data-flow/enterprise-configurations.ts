export interface EnterpriseConfigurations {
}
