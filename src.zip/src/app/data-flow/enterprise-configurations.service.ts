import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';
import { DataService } from '../shared/services/data.service';

@Injectable({
  providedIn: 'root'
})
export class EnterpriseConfigurationsService {

  constructor(private interceptor: InterceptorService,
    private dataService: DataService) { }


  getPartnerDetails() {
    const request = {
      partnerId: this.dataService.getParseFromSession('partnerId'),
      hqBpId: this.dataService.getParseFromSession('hqBpId'),
      // appendHqBpIdAndPartnerId: true,
      jioUtils: true
    };
    return this.interceptor.httpCall('get', 'getpartnerInfo', request);
  }


  //  getPartnerDetails() {
  //   const request = {
  //     email: this.dataService.getParseAndAtob('loginMember'),
  //     jioUtils : true,
  //     donotShowError:true
  //  };
  //   return this.interceptor.httpCall('get', 'getDirectPartnerInfo', request);
  // }

  createDirectEnterpriseInfo(request, method) {
    request['jioUtils'] = true;
    request['hqbpid'] = request.hqbpid;
    request['queryParam'] = true;
    request['opEng'] = {};
    request['opEng']['email'] = this.dataService.getParseFromSession('admin').email;
    request['opEng']['phone'] = this.dataService.getParseFromSession('admin').phone;
    request['opEng']['name'] = this.dataService.getParseFromSession('admin').firstName + ' ' + this.dataService.getParseFromSession('admin').lastName;
    // this.dataService.getParseFromSession('admin')
    request["partnerType"] = "DIRECT";
    request["serviceNames"] = "Direct Service";
    let url = 'createDirectEnterpriseInfo';
    if (method == 'put') {
      url = 'updateDirectPartner';
      request.queryParamData = { partnerId: request.partnerId };
    }
    return this.interceptor.httpCall(method, url, request);
  }

  getConfigDeatils(request) {
    //request['jioUtils'] = true;

    return this.interceptor.httpCall('get', 'createDirectEnterpriseInfo', request);
  }

  getEditData(request) {

    const partnerId = this.dataService.getParseFromSession('partnerId');
    const hqBpId = this.dataService.getParseFromSession('hqBpId');

    // if(partnerId && hqBpId) {
    //   request['partnerId'] = partnerId;
    //   request['hqBpId'] = hqBpId;
    //   request['pathParams'] = true;
    // }

    return this.interceptor.httpCall('get', 'getConsumerDatabypages', request);
  }

  getPartnerIds() {
    return this.interceptor.httpCall('get', 'getPartnerIds');
  }

  getSvcData(request) {
    return this.interceptor.httpCall('post', 'getSvcWithPartnerId', request);
  }

  getSvcWithPartnerId(request) {
    return this.interceptor.httpCall('post', 'svcWithPartnerIdco', request)
  }

  uploadDeviceList(request) {
    return this.interceptor.httpCall('post', 'uploadCoDevice', request)
  }

  getUploadDeviceList(request) {
    return this.interceptor.httpCall('get', 'getCoDevice', request)
  }

  editUploadDeviceList(request) {
    request.extraParams = '?transactionId=' + request.transactionId;
    delete request.transactionId;

    return this.interceptor.httpCall('put', 'updateCoDevice', request)
  }

  getConsumerAutomationData() {
    const request = {
      jioUtils: true,
      userId: this.dataService.getParseAndAtob('partnerBasedConsumerLoginId'),
      appendUserId: true
    };

    const fromLoginScreen = this.dataService.getParseFromSession('fromLoginScreen');
    return this.interceptor.httpPromise('get', fromLoginScreen ? 'getConsumerDataFormLogin' : 'getConsumerData', request);
  }


  submitConsumerData(request, existedData) {
    request['hqBpId'] = existedData.hqbpId;
    request['partnerId'] = existedData.partner ? existedData.partner.partnerId : existedData.partnerId;
    request['pathParams'] = true;
    return this.interceptor.httpCall('put', 'submitConsumerData', request);
  }


  getTransationId(request) {
    return this.interceptor.httpCall('get', 'getTransationId', request)
  }

  getDeviceListForReConcile(request) {
    return this.interceptor.httpCall('get', 'getDeviceListForReConcile', request)
  }

  getDeviceCountForReConcile(request) {
    return this.interceptor.httpCall('get', 'getDeviceCountForReConcile', request)
  }

  getDeviceProgressCount(request){

    request['noSpiner']=true;

    return this.interceptor.httpCall('get', 'getDeviceProgressCount',request)
  }

  callSaveService(request){
    return this.interceptor.httpCall('put', 'updateSingleCoDevice',request)
  }

  

}
