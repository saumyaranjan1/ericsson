import { TestBed } from '@angular/core/testing';

import { EnterpriseConfigurationsService } from './enterprise-configurations.service';

describe('EnterpriseConfigurationsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: EnterpriseConfigurationsService = TestBed.get(EnterpriseConfigurationsService);
    expect(service).toBeTruthy();
  });
});
