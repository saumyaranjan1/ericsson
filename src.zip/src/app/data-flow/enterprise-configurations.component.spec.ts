import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EnterpriseConfigurationsComponent } from './enterprise-configurations.component';

describe('EnterpriseConfigurationsComponent', () => {
  let component: EnterpriseConfigurationsComponent;
  let fixture: ComponentFixture<EnterpriseConfigurationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EnterpriseConfigurationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EnterpriseConfigurationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
