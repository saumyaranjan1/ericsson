import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { EnterpriseConfigurationsService } from './enterprise-configurations.service';
import { DataService } from '../shared/services/data.service';
import { UserOnboardService } from '../old-user-onboard/user-onboard.service';
import { LoginService } from '../login/login.service';
import { EnumsService } from '../shared/services/enums.service';
import { AppConfigService } from '../app-config.service';
import { SpinnerService } from '../shared/services/spinner.service';
import { ngxCsv } from 'ngx-csv/ngx-csv';
import * as Excel from 'exceljs';
import * as FileSaver from 'file-saver';


@Component({
  selector: 'app-enterprise-configurations',
  templateUrl: './enterprise-configurations.component.html',
  styleUrls: ['./enterprise-configurations.component.less']
})
export class EnterpriseConfigurationsComponent implements OnInit {
  directPartnerInfo;
  showDirectPartnerInfoSection = false;
  enterpriseName;
  hqBpId;
  p: number = 1;
  enterpriseTotalCount;
  enterpriseList;
  svcValueModule;
  enterpriseData;
  sourceOfRequest;
  partnerInfo;
  partnerValue;
  availableEvents;
  edit = false;
  svcValue;
  openPopUp=false;
  showSvcList = true;
  uploadReconciliation = false;
  errorSvcRequared;
  uploadedFile;
  uploadedFileName;
  fileExtension;
  fileSubmitReq;
  fileId;
  ipsList = [];
  nextButtonShow = false;
  mainToolTipInfo = 'Publish device details and Stream information details page.';
  titleToolTipInfo = 'In this page customer provides the end point detail to receive the detail of the devices purchased';
  loginTokenTollTipInfo = 'Jio Platform uses the following end point URL and access credentials to get the login token to connect to your platform';
  receiveDeviceDetails = 'Jio Platform uses the end point URL to send the details of your purchased devices';
  @ViewChild('directPartnerInfoTemplate', { static: false }) directPartnerInfoTemplate: ElementRef;
  @ViewChild('reconciliationModalContent', { static: false }) reconciliationModalContent: ElementRef;
  @ViewChild('imeiAndMsisdnModalContent', { static: false }) imeiAndMsisdnModalContent: ElementRef;
  @ViewChild('publishTemplate', { static: false }) publishTemplate: ElementRef;
  @ViewChild('errorTemplate', { static: false }) errorTemplate: ElementRef;
  @ViewChild('confirmTemplate', { static: false }) confirmTemplate: ElementRef;
  @ViewChild('singleUploadModalContent', { static: false }) singleUploadModalContent: ElementRef;

  //pagenation 

  pagiantionDataflowObj = {
    pageNum: 1,
    rpp: 10,
    offset: 0,
    pageSize: 10,
    pageNumber: 1
  };

  pagiantionObj = {
    page: 1,
    limit: 10,
    offset: 0,
    pageNum: 1,
    rpp: 0,
    pageNumber: 1,
    pageSize: 0,
    svcCode: '',
    connectivityType: ''
  };
  roleIdList = [];
  searchValue;
  category;
  searchAttributes = [];
  serverSearchValue: String = '';
  selectedValue;
  errorMessage;
  searchErrorMsg;
  rowIndex;
  shouldNotallowNewStrems;
  searched;
  publishIpForm: FormGroup;
  pushStreamGroupForm: FormGroup;
  publishAndPushObj = {
    ip: [],
    streams: []
  };
  svcList = [];
  showEnterpriseList = true
  enterpriseRowValue;
  reconciliationList;
  partnerIds: any;
  userName;
  nonReConciledDeviceCount;
  constructor(private router: Router,
    private fb: FormBuilder,
    private cms: CommonMethodsService,
    private ngbModal: NgbModal,
    private ecs: EnterpriseConfigurationsService,
    private dataService: DataService,
    private apc: AppConfigService,
    private userOnboardService: UserOnboardService,
    private spinnerService: SpinnerService,
    private loginService: LoginService) { }

  ngOnInit() {
    this.directPartnerFormBlock();
    this.enterpriseName = this.dataService.getParseFromSession('partnerName');
    this.hqBpId = this.dataService.getParseFromSession('hqBpId');
    this.sourceOfRequest = this.dataService.getParseFromSession('sourceOfRequest');
    this.category = this.dataService.getAtobLocalStorage('category');
    if (this.sourceOfRequest == 'NPBE') {
      this.getPartnerDetails();
    }
    this.getPage(1);

    this.userName = this.dataService.getParseAndAtob(
      'loginMember'
    ).split('@')[0].replace('.', ' ');
  }

  openModal(content, size) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal user-onboard',
        size,
        keyboard: false
      })
      .result.then(
        result => { },
        reason => { }
      );
  }

  openReconcileModel(content, size) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        keyboard: false,
        backdrop: 'static',
      })
      .result.then(result => { }, reason => { });
  }

  openConnectionModel(content, size) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        keyboard: false,
      })
      .result.then(result => { }, reason => { });
  }
  getPartnereIds() {
    this.loginService.getPartnerIds().subscribe(res => {
      if (res) {
        this.partnerIds = res;
        this.validateIsDirectEnterpriseOrNot();
      }
    });
  }
  getPartnerDetails() {

    setTimeout(() => {
      this.ecs.getPartnerDetails().subscribe(result => {
        if (result && result.length > 0) {
          this.partnerInfo = result[0];
        } else {
          this.openDirectEnterpriseInfoSection();
        }
      }, error => {
        this.openDirectEnterpriseInfoSection();
      }
      );
    }, 0);

  }
  getPartnerDetailsForList() {
    this.ecs.getPartnerDetails().subscribe(result => {
      this.showEnterpriseList = false;
      if (result && result.length > 0) {
        this.partnerInfo = result[0];
      }
    }, error => {
    }
    );
  }
  getOnboardServiceData(req) {
    // const req = {
    //     pageSize: this.pagiantionObj.rpp,
    //     pageNumber: this.pagiantionObj.pageNum
    // };
    // if(searchObj) {
    //   const key = Object.keys( searchObj );
    //   req['searchBy'] = key[0];
    //   req['searchValue'] = searchObj[key[0]];
    // }
    this.ecs
      .getEditData(req)
      .subscribe(res => {
        if (res) {
          this.enterpriseList = res.data;
          this.enterpriseTotalCount = res.totalCount;
          this.enterpriseList.forEach(item => {
            item['check'] = false;
          });
        }
        this.searchAttributes = res.searchAttributes;
      });
  }

  goToCustConfigCreation(enterprise) {
    // enterprise.emailId
    this.dataService.setLocalStorageAsStringify(
      'partnerBasedConsumerLoginId',
      btoa(enterprise.id)
    );

    if (enterprise.partner && enterprise.partner.partnerId && enterprise.partner.partnerType == 'FIXED') {
      this.dataService.setLocalStorage('partnerId', JSON.stringify(enterprise.partner.partnerId));
      this.dataService.setLocalStorage('sourceOfRequest', JSON.stringify('NPBE'));
    }
    this.dataService.setLocalStorage('fromLoginScreen', JSON.stringify(false));
    this.router.navigate(['/main/user-onboard']);
  }

  goBack() {
    this.openDirectEnterpriseInfoSection();
  }
  goToCreatePartnerData(data) {

    if (this.partnerInfo) {
      this.edit = true;
    } else {
      this.edit = false;
    }

    if (this.dataService.getAtobLocalStorage('category')!=='ADMIN') {
      this.dataService.setLocalStorageAsStringify1(
        'loginMember',
        btoa(data.emailId)
      );
     }else{
      this.dataService.setLocalStorageAsStringify1(
        'loginEmail',
        btoa(data.emailId)
      );
     }
   
    // this.validateIsDirectEnterpriseOrNot();
    this.getPartnereIds();

  }

  validateIsDirectEnterpriseOrNot() {
    this.loginService.validateIsDirectEnterpriseOrNot(false).subscribe(result => {
      if (result) {

        this.dataService.setLocalStorage('admin', JSON.stringify(result.admin));
        this.enterpriseName = result.hqBpName;
        this.hqBpId = result.hqBpId;
        this.dataService.setLocalStorage('sourceOfRequest', JSON.stringify(result.sourceOfRequest));

        // this.dataService.setLocalStorage('svcCode', JSON.stringify(result.userId));

        if (result.sourceOfRequest == 'NPBE') {
          if (result.partnerId) {
            this.dataService.setLocalStorage('partnerId', JSON.stringify(result.partnerId));
          }

          if (result.partnerIds) {
            this.partnerIds.forEach(element => {
              result.partnerIds.forEach(innerElement => {
                if (element.partnerType == "FIXED" && element.partnerId == innerElement) {
                  this.dataService.setLocalStorage('partnerId', JSON.stringify(innerElement))
                }
              });
            });
          }
        }
        this.getSvcData(result.hqBpId)

        this.directPartnerFormBlock(this.partnerInfo);
        this.openDirectEnterpriseInfoSection();

      }
    }, error => {

    })
  }
  getSvcData(hqBpId) {
    var svcParam = {
      'hqBpId': hqBpId,
      'partnerIds': [this.dataService.getParseFromSession('partnerId')]
    };

    this.ecs.getSvcData(svcParam).subscribe(result => {
      this.dataService.setLocalStorage('svcCode', JSON.stringify(result[0].svcCode));
    });
  }

  openDirectEnterpriseInfoSection() {
    //  this.openModal(this.directPartnerInfoTemplate, 'lg')
    this.showDirectPartnerInfoSection = !this.showDirectPartnerInfoSection;
    this.modifyDataflow = false;
  }
  directPartnerFormBlock(data?) {
    // const reg = '^(https?|chrome):\/\/[^\s$.?#].[^\s]*$';
    // const reg = '(https?://.*):(\d*)\/?(.*)';
    const reg = '^(http|https):\/\/(([a-z0-9]|[a-z0-9][a-z0-9\-]*[a-z0-9])\.)*([a-z0-9]|[a-z0-9][a-z0-9\-]*[a-z0-9])(:[0-9]+)?$';


    this.directPartnerInfo = this.fb.group({
      urlToGetToken: [
        data ? data.loginURL : '',
        [
          Validators.required, Validators.pattern(reg)
        ]
      ],
      tokenLoginUsername: [
        data ? data.userName : '',
        [
          Validators.required
        ]
      ],
      tokenLoginPassword: [
        data ? data.password : '',
        [
          Validators.required
        ]
      ],
      urlToSendEnterpriseDeviceAssociation: [
        data ? data.portalUrl : '',
        [
          Validators.required, Validators.pattern(reg)
        ]
      ]
    });
  }
  submitForm(form) {
    if (form.valid) {
      this.submitDirectEnterpriseInfo();
    } else {
      this.cms.validateAllFormFields(form);
    }
  }

  deleteSourceOfRequest() {
    sessionStorage.removeItem('sourceOfRequest');
  }
  submitDirectEnterpriseInfo() {
    this.deleteSourceOfRequest();
    let request =
    {
      hqbpid: this.hqBpId,
      partnerId: this.dataService.getParseFromSession('partnerId'),
      loginURL: this.directPartnerInfo.controls.urlToGetToken.value,
      partnerName: this.dataService.getParseFromSession('svcCode'),
      userName: this.directPartnerInfo.controls.tokenLoginUsername.value,
      password: this.directPartnerInfo.controls.tokenLoginPassword.value,
      addLoginPayload: null,
      partnerUrl: this.directPartnerInfo.controls.urlToSendEnterpriseDeviceAssociation.value,
      portalUrl: this.directPartnerInfo.controls.urlToSendEnterpriseDeviceAssociation.value,
      isRetryRequired: false,
      retryThreshold: 3
    };

    if (this.edit) {
      request['partnerUUID'] = this.partnerInfo.partnerUUID;
    }

    let method = this.edit ? 'put' : 'post';
    this.ecs.createDirectEnterpriseInfo(request, method).subscribe(result => {
      this.openDirectEnterpriseInfoSection();
      this.getPartnerDetails();
      this.goBackList();
      //  this.getOnboardServiceData();

    },  error => {
    if(error=='Please complete device reconciliation to ensure IMEI data can be mapped'){
     this.openPopUp=true;
    }
    })
  }


  getPage(page: number, searchObj?) {
    this.pagiantionDataflowObj.pageNum = page;
    this.pagiantionDataflowObj.offset = (page - 1) * this.pagiantionDataflowObj.rpp;

    this.pagiantionDataflowObj.pageSize = this.pagiantionDataflowObj.rpp;
    this.pagiantionDataflowObj.pageNumber = this.pagiantionDataflowObj.pageNum;
    if (searchObj) {
      const key = Object.keys(searchObj);
      this.pagiantionDataflowObj['searchBy'] = key[0];
      this.pagiantionDataflowObj['searchValue'] = searchObj[key[0]];
    } else {

      if (this.pagiantionDataflowObj['searchBy']) {
        delete this.pagiantionDataflowObj['searchBy'];
      }
      if (delete this.pagiantionDataflowObj['searchValue']) {
        delete this.pagiantionDataflowObj['searchValue'];
      }

    }


    this.getOnboardServiceData(this.pagiantionDataflowObj);
    this.p = page;
  }
  existedJobs;
  addMoreStreamsAllow;
  showBackButton;
  showExpand(data, index) {
    data.check = true;
    this.showBackButton=true;
    this.partnerInfo = null;
    this.dataService.setLocalStorage('hqBpId', JSON.stringify(data.hqbpId));
    if (data.partner && data.partner.partnerId) {
      this.dataService.setLocalStorage('partnerId', JSON.stringify(data.partner.partnerId));
      this.enterpriseRowValue = data;
      this.existedJobs = data.jobs;
      // this.enterpriseRowValue.streams = [];
      data.streams.forEach((stream, index) => {
        delete stream.topics;
        const stremsArray = this.userOnboardService.getStreamArray(stream);
        this.enterpriseRowValue.streams[index] = {}
        this.enterpriseRowValue.streams[index] = stremsArray
        // this.enterpriseRowValue.streams.push(stremsArray);
      });
      this.checkJobStatus();
      this.getPartnerDetailsForList();
    }
    this.dataService.setLocalStorageAsStringify(
      'partnerBasedConsumerLoginId',
      btoa(data.id)
    );
    this.getRoleList();
  }

  getRoleList() {
    this.userOnboardService
      .getEditData()
      .then(result => {
        if (result.data) {
          // this.availableEvents = result.data.availableEvents;
          // this.existedData = result.data;
          // this.existedStreams = [];
          // this.existedStreams = result.data.streams;
          // this.existedJobs = result.data.jobs;
          this.roleIdList = result.data.roleList;
          this.enterpriseRowValue.ip = result.data.ip;

          this.selectedRoleValue=result.data.roleId;
          // this.selectedRoleValue = result.data.roleId;
          // this.roleSelectedId = result.data.roleId;
          // this.hqbpName = result.data.hqbpName;
          // this.publishAndPushObj.ip = [];
          // this.publishAndPushObj.streams = [];
          // if (result.data.ip) {
          //   result.data.ip.forEach(ip => {
          //     this.publishAndPushObj.ip.push({ ip });
          //   });
          // }
          // if (result.data.streams) {
          //   result.data.streams.forEach(stream => {
          //     delete stream.topics;
          //     const stremsArray = this.userOnboardService.getStreamArray(stream);
          //     this.publishAndPushObj.streams.push(stremsArray);
          //   });
          // }
          // this.checkJobStatus();
        }
      });


  }

  selectedRoleValue
  roleValueSelected(event) {
    this.selectedRoleValue = event.value
  }

  checkJobStatus() {
    if (this.existedJobs) {
      const completedJobs = this.existedJobs.filter((job) => {
        return job.status.toLowerCase() === 'done' || job.status.toLowerCase() === 'failed' || job.status.toLowerCase() === 'incomplete';
      });
      if (completedJobs.length === this.existedJobs.length) {
        this.addMoreStreamsAllow = true;
      } else {
        this.addMoreStreamsAllow = false;
      }
    }
  }



  showCollaps(data, index) {
    data.check = false;
  }

  goBackList() {
    this.deleteSourceOfRequest();
    this.router
      .navigateByUrl('../main', { skipLocationChange: true })
      .then(() => this.router.navigate(['../main/cuscfg']));
  }

  valueSelected(data, event?) {
    if (data === 'dropDown') {
      this.serverSearchValue = null;
      this.selectedValue = event.value;
    }
    if (this.selectedValue || this.serverSearchValue) {
      this.searchErrorMsg = '';
      this.searched = false;
    }
  }
  onKeyUp(event) {
    // Checking for Backspace or Delete if Search field is empty
    if ((event.keyCode == 8 || event.keyCode == 46) && !this.searchValue) {
      this.getPage(1);
    }
  }

  valueRoleSelected(value) {
    this.selectedValue = value;
  }

  serachValue() {
    this.searched = true;
    if (!this.selectedValue) {
      this.searchErrorMsg = 'Please select dropdown value!';
    } else if (!this.serverSearchValue) {
      this.searchErrorMsg = 'Please search the value according to selecttion!';
    } else {
      this.clearSearcErrors();
    }
  }

  clearSearcErrors() {
    this.searchErrorMsg = '';
    this.searched = false;
    const searchObj = {
      [this.selectedValue]: this.serverSearchValue
    };
    this.getPage(1, searchObj);
  }

  showmodify;
  modifyDataflow
  // showButton(){
  //   this.showmodify=!this.showmodify;
  // }

  dataflowConfigurationData;
  // modify(event){
  //   this.modifyDataflow=true;
  //   this.showDirectPartnerInfoSection=true;
  //   this.dataflowConfigurationData=event;
  // }

  authorizationValue
  authorizationCheck(event) {
    this.authorizationValue = event;
  }

  /** connection only part */


  /** Ger Svc List*/
  // connectionUiModel(){
  //   this.openModel(this.reconciliationModalContent);
  // }

  connectionUiModel() {
    const _req = {
      'partnerIds': [this.dataService.getParseFromSession('partnerId')],
      'hqBpId': this.hqBpId
    }
    this.ecs.getSvcWithPartnerId(_req).subscribe(res => {
      this.svcList = res;
      this.showSvcList = true;
      this.uploadReconciliation = false;
      this.uploadedFileName = '';
      this.openPopUp=false;
      this.openConnectionModel(this.reconciliationModalContent, 'sm');
    });
  }

  svcValueSelected(event) {
    this.svcValue = event.value.svcCode;
    this.partnerValue = event.value.partnerId;
  }

  reconciliationCount;
  errorForCsvSubmit;

  getReConcilePage(page: number) {
    this.p = page;
    this.pagiantionObj.page = page;
    this.pagiantionObj.pageNum = page;
    this.pagiantionObj.offset = (page - 1) * this.pagiantionObj.limit;
    this.pagiantionObj.rpp = this.pagiantionObj.limit;
    this.pagiantionObj.pageNumber = page;
    this.pagiantionObj.pageSize = this.pagiantionObj.rpp;
    this.pagiantionObj['transactionId'] = this.fileId
    delete this.pagiantionObj.rpp;
    delete this.pagiantionObj.pageNumber;
    delete this.pagiantionObj.connectivityType;
    this.getDeviceList(this.pagiantionObj);
  }

  getPageCon(page: number) {
    this.p = page;
    this.pagiantionObj.page = page;
    this.pagiantionObj.pageNum = page;
    this.pagiantionObj.offset = (page - 1) * this.pagiantionObj.limit;
    this.pagiantionObj.rpp = this.pagiantionObj.limit;
    this.pagiantionObj.pageNumber = page;
    this.pagiantionObj.pageSize = this.pagiantionObj.rpp;
    this.pagiantionObj.svcCode = this.svcValue;
    this.pagiantionObj.connectivityType = 'co'
    this.getDeviceListForReConcile(this.pagiantionObj)
  }

  getConOnlyPage(page: number) {
    this.p = page;
    this.pagiantionObj.page = page;
    this.pagiantionObj.pageNum = page;
    this.pagiantionObj.offset = (page - 1) * this.pagiantionObj.limit;
    this.pagiantionObj.rpp = this.pagiantionObj.limit;
    this.pagiantionObj.pageNumber = page;
    this.pagiantionObj.pageSize = this.pagiantionObj.rpp;
    this.pagiantionObj.svcCode = this.svcValue;
    this.pagiantionObj.connectivityType = 'co'
    this.getDeviceListForReConcile(this.pagiantionObj)
  }

   reConcileDeviceCount
   reConcileDeviceList

  getDeviceListForReConcile(param) {
    param.userId = '111'
    this.ecs.getDeviceListForReConcile(param).subscribe(res => {
      this.reConcileDeviceList = res.data;
      this.reConcileDeviceList.forEach((value, key) => {
        if (value.imei.slice(0, 1) == 'm') {
          value.imei = '';
          value['isEmptyImei'] = false;
          value['isImeiWithm'] = true;
        } else {
          value['isImeiWithm'] = false;
        }
      });
      this.getDeviceCountForReConcile(this.reConcileDeviceList[0].userID);
    });
  }

  getDeviceCountForReConcile(userid) {
    var param = {
      'userId': userid,
      'svcCode': this.svcValue,
      'connectivityType': 'CO'
    }
    this.ecs.getDeviceCountForReConcile(param).subscribe(res => {
      this.reConcileDeviceCount = res.data;
    });
    let paramForNonReconciled = {
      'userId': userid,
      'svcCode': this.svcValue,
      'connectivityType': 'CO',
      'isNonReconciled': true
    }
    this.ecs.getDeviceCountForReConcile(paramForNonReconciled).subscribe(res => {
      this.nonReConciledDeviceCount = res.data;
    });
  }


  next(close) {
    this.ecs.getTransationId({'svcCode':this.svcValue}).subscribe(res => {
      if(res.data.status=='COMPLETED' || res.data.status=='NOTSTARTED'){
        if (this.svcValue) {
          this.showSvcList = false;
          //this.uploadReconciliation = true;
          this.closeModel(close);
          this.getConOnlyPage(1);
          this.openConnectionModel(this.singleUploadModalContent, 'lg');
          this.errorSvcRequared = false;
        } else {
          this.errorSvcRequared = true;
        }
      }else{
        this.spinnerService.toggleSpinner(1);
        setTimeout(() => {
          this.fileId = res.data.transactionId;
          this.reconciliationCount = 0;
          this.openReconcileModel(this.imeiAndMsisdnModalContent, 'lg');
          this.getReConcilePage(1);
          this.closeModel(close);
          this.errorForCsvSubmit = false;
        }, 2000);
      }
     });
    // if (this.svcValue) {
    //   this.showSvcList = false;
    //   this.uploadReconciliation = true;
    //   this.errorSvcRequared = false;
    // } else {
    //   this.errorSvcRequared = true;
    // }
  }

  /***
     * Upload File
     */

  fileEvent($event) {
    this.uploadedFile = $event.target.files[0];
    this.uploadedFileName = this.uploadedFile.name;
    const dotPos = this.uploadedFile.name.lastIndexOf('.');
    if (this.uploadedFile.name.lastIndexOf('.') > 0) {
      this.fileExtension = this.uploadedFile.name.substring(
        dotPos + 1,
        this.uploadedFile.name.length
      );
    }
    this.fileSubmitReq = new FormData();
    this.fileSubmitReq.append('file', this.uploadedFile);
    this.fileSubmitReq.append('partnerId', this.partnerValue);
    this.fileSubmitReq.append('svc', this.svcValue);
    this.fileSubmitReq.append('hqBpId', this.hqBpId);
    this.fileSubmitReq.append('attachDc', 'yes');
  }
 // errorForCsvSubmit = false;
  finish(close) {
    if (this.fileSubmitReq) {
      this.ecs.uploadDeviceList(this.fileSubmitReq).subscribe(res => {
        this.spinnerService.toggleSpinner(1);
        setTimeout(() => {
          this.fileId = res.data.transactionId;
          this.reconciliationCount = 0;
          this.dataService.broadcast('alert', { type: 'success', message: res.responseCode });
          this.openReconcileModel(this.imeiAndMsisdnModalContent, 'lg');
          this.getReConcilePage(1);
          this.closeModel(close);
          this.errorForCsvSubmit = false;
          
        }, 2000);
      });
    } else {
      this.errorForCsvSubmit = true;
    }
    // this.ecs.uploadDeviceList(this.fileSubmitReq).subscribe(res => {
    //   this.fileId = res.data.transactionId;
    //   this.dataService.broadcast('alert', { type: 'success', message: res.data.message });
    //   this.getDeviceList(res.data.transactionId);
    //   this.closeModel(close);
    // });
  }

  closeModel(close) {
    close('Cross click');
  }

  getPercentage
  totalRecord;
  interval: any;

  getDeviceProgressCount() {
    let param = {
      'transactionId': this.fileId,
      'isCount': true
    }
    this.ecs.getDeviceProgressCount(param).subscribe(res => {
      this.totalRecord=res.data.totalCoRecordCnt;
      this.getPercentage = (res.data.processedCoRecordCnt / res.data.totalCoRecordCnt) * 100;
      this.reconciliationCount = res.data.processedCoRecordCnt;
      if (this.getPercentage == 100) {
        clearInterval(this.interval);
      }
    });
  }

  getDeviceList(param) {
    // this.ecs.getUploadDeviceList({ "transactionId": param }).subscribe(res => {
    //   this.openConnectionModel(this.imeiAndMsisdnModalContent, 'lg');
    //   this.reconciliationList = res.data;
    // });
    delete param.userId;
    this.ecs.getUploadDeviceList(param).subscribe(res => {
      this.reconciliationList = res.data;
      this.spinnerService.toggleSpinner(0);
      if (this.reconciliationList.length == 0 && param.pageNum == 1) {
        this.spinnerService.toggleSpinner(1);
        setTimeout(() => {
          this.getReConcilePage(1);
        }, 2000);
      }

      this.interval = setInterval(() => {
        this.getDeviceProgressCount();
      }, 2000);

    });
  }

  updateCoDevice(row, close) {
    this.closeModel(close);
    var param = {
      "msisdn": row.msisdn,
      "imei": row.imei,
      "imsi": row.imsi,
      "transactionId": this.fileId,
      "partnerId": this.partnerValue,
      "hqBpId": this.hqBpId,
      "svc": this.svcValue
    }
    this.ecs.editUploadDeviceList(param).subscribe(res => {
      this.dataService.broadcast('alert', { type: 'success', message: 'Update successfully' });
      this.getDeviceList(this.fileId);
      
    });
    // var param = {
    //   "msisdn": row.msisdn,
    //   "imei": row.imei,
    //   "imsi": row.imsi,
    //   "transactionId": this.fileId,
    //   "hqBpId": this.hqBpId,
    //   "partnerId": this.dataService.getParseFromSession('partnerId'),
    //   "svc": this.svcValue
    // }
    // this.ecs.editUploadDeviceList(param).subscribe(res => {
    //   this.closeModel(close);
    //   this.dataService.broadcast('alert', { type: 'success', message: 'Update successfully' });
    //   //this.reconciliationList = res;
    //   this.getDeviceList(this.fileId);
    // });
  }

  changeImei;
  onImeiChange(event, index) {
    if (event.length == 15 || event.length == 16) {
      this.changeImei = true;
      this.reConcileDeviceList[index].isEmptyImei = false;
      this.reConcileDeviceList[index].isEmptyLength = false;
    } else {
      this.reConcileDeviceList[index].isEmptyImei = true;
      this.reConcileDeviceList[index].isEmptyLength = true;
    }
  }

  closeInterval(close) {
    clearInterval(this.interval);
    close('Cross click');
  }

  callSaveService(data, index) {
    if (data.imei && this.changeImei) {
      this.changeImei = false;
      this.reConcileDeviceList[index].isEmptyImei = false;
      let param = {
        "msisdn": data.msisdn,
        "imei": data.imei,
        "partnerId": data.partnerId,
        "svc": data.svc,
        "eid": data.eid
      }
      this.ecs.callSaveService(param).subscribe(res => {
        this.reConcileDeviceList[index].isImeiWithm = false;
       });
    } else if (data.imei == '') {
      this.reConcileDeviceList[index].isEmptyImei = true;
    }
  }

  downLoadCsvForReconcil() {
    let workBook = new Excel.Workbook();
    let workSheet = workBook.addWorksheet("New");
    workSheet.columns = [
      { header: 'MSISDN', key: 'msisdn', width: 18 },
      { header: 'IMSI', key: 'imsi', width: 18 },
      { header: 'IMEI', key: 'imei', style: { numFmt: '@'}, width: 18 }
    ];
    this.pagiantionObj['userId'] = '111';
    this.pagiantionObj.pageNum = 1;
    this.pagiantionObj.rpp = 0;
    this.pagiantionObj['isNonReconciled'] = true;
    this.ecs.getDeviceListForReConcile(this.pagiantionObj).subscribe(res => {
      if (res.data.length!==0) {
        this.reConcileDeviceList = res.data;
        delete this.pagiantionObj['isNonReconciled'];
        var data = [];
        this.reConcileDeviceList.forEach((value, key) => {
          workSheet.addRow({msisdn: value.msisdn, imsi: value.imsi, imei: '' });
          workSheet.getCell('C' + (key + 2)).protection = { locked: false };
        });
        
        workSheet.protect("", {});
        
        workBook.xlsx.writeBuffer().then(function (data) {
          var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
          FileSaver.saveAs(blob, "deviceReconciliation.xlsx");
        });

        if (this.nonReConciledDeviceCount >= 100000 ) {
          this.dataService.broadcast('alert',
          { type: 'danger', message: `You can download upto 1 Lakh non-reconciled device info. Incase you have more 
          than 1 Lakh non-reconciled devices, download and reconcile 1st 1 Lakh device then repeat the same` });
        }
      }else{
        this.dataService.broadcast('alert',
        { type: 'danger', message: 'All devices are already reconciled' });
      }
    });

  }

  backToUpload(close) {
    this.closeModel(close);
    this.uploadReconciliation = true;
    this.openConnectionModel(this.reconciliationModalContent, 'sm');
  }

  showButton(index) {
    this.reconciliationList.forEach((element, key) => {
      if (key == index) {
        element.showButton = !element.showButton;
        if (!element.showButton) {
          element.modify = false;
        }
      }
    });
  }

  showEnterprisenterButton(index) {
    this.enterpriseList.forEach((element, key) => {
      if (key == index) {
        element.showButton = !element.showButton;
        if (!element.showButton) {
          element.modify = false;
        }
      }
    });
  }

  showStreams(index) {
    this.enterpriseRowValue.streams.forEach((element, key) => {
      if (key == index) {
        element.showButton = !element.showButton;
        if (!element.showButton) {
          element.modify = false;
        }
      }
    });
  }

  checkHowManyNewStremsAreThere() {
    const newStreams = this.enterpriseRowValue.streams.filter((stream) => {
      return stream.action === 'ADD';
    });
    this.shouldNotallowNewStrems = newStreams.length >= parseInt(this.apc['maxStremGroupCount']) ? true : false;
  }

  showStreamsExpand(data, index) {

    this.checkHowManyNewStremsAreThere();
    if (this.shouldNotallowNewStrems) {
      this.errorMessage = EnumsService.IOT_USER_ONBOARD.MAX_STREMS;
      this.openModal(this.errorTemplate, 'sm');
    } else {

      if (this.addMoreStreamsAllow) {
        //this.dataflowConfigurationData=strem;
        this.availableEvents = data.availableEvents;
        this.rowIndex = index;
        this.pushStreamGroupForm = this.fb.group({
          name: [data.streams[index].name],
          locations: [data && data.streams[index].push.events ? data.streams[index].push.events.includes('locinfo') : 'Yes'],
          events: [data && data.streams[index].push.events ? data.streams[index].push.events.includes('events') : 'Yes'],
          alerts: [data && data.streams[index].push.events ? data.streams[index].push.events.includes('alerts') : 'Yes'],
          pushApiUrl: [data && data.streams[index].push ? data.streams[index].push.pushApiUrl : '', [Validators.required, this.cms.patternValidator(
            /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
            { isValidUrl: true }
          )]],
          ackApiUrl: [data && data.streams[index].push ? data.streams[index].push.ackApiUrl : '', [this.cms.patternValidator(
            /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
            { isValidUrl: true }
          )]],
          authReq: [data && data.streams[index].push ? data.streams[index].push.authReq : false],
          pushLoginUrl: [data && data.streams[index].push ? data.streams[index].push.pushLoginUrl : ''],
          loginReq: [data && data.streams[index].push ? data.streams[index].push.loginReq : ''],
          accessToken: [data && data.streams[index].push ? data.streams[index].push.accessToken : '', Validators.required],
          id: [data && data.streams[index].push ? data.streams[index].id : '']
        });

        if (data.streams[index].push.authReq) {
          this.authorizationValue = true;
        }

        this.modifyDataflow = true;
      } else {
        this.errorMessage = EnumsService.IOT_USER_ONBOARD.STREAM_GROUP_ERROR;
        this.openModal(this.errorTemplate, 'sm');
      }
    }
  }

  modify(index) {
    this.reconciliationList.forEach((element, key) => {
      if (key == index) {
        element.modify = !element.modify;
      }
    });
  }

  modifyEnterprise(index, enterprise) {
    this.showEnterpriseList = false;
    this.enterpriseRowValue = enterprise;
  }

  backButton(){
    this.showEnterpriseList = true;
  }

  backButtonConOnly(){
    this.showDirectPartnerInfoSection=false;
   }

  
  openPublishTempalte(ips) {
    if (ips) {
      this.ipsList = ips;
    } else {
      this.ipsList = [];
    }
    this.nextButtonShow = false;
    this.getIpFormBlock()
    this.openModal(this.publishTemplate, 'sm');
  }

  getIpFormBlock(ip?) {
    this.publishIpForm = this.fb.group({
      ip: [
        '',
        [
          Validators.required,
          this.cms.patternValidator(
            /\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\.|$)){4}\b/,
            { isValidUrl: true }
          )
        ]
      ]
    });
  }

  addIps() {
    this.getIpFormBlock();
    this.nextButtonShow = !this.nextButtonShow;
  }

  pushToIpList() {
    if (this.publishIpForm.controls['ip'].value) {
      this.ipsList.push(this.publishIpForm.controls['ip'].value)
      this.nextButtonShow = false;
    }
  }

  removeIps(id) {
    this.ipsList.splice(id, 1);
  }


  closeModal(close) {
    close('Cross click');
  }


  finalSubmit(close) {
    const obj = {
      ip: [],
      streams: this.userOnboardService.getFinalStream(this.publishAndPushObj.streams)
    };
    this.publishAndPushObj.ip.forEach(element => {
      obj.ip.push(element.ip);
    });
    // this.disableSubmitButton = true;
    // this.isChecked = true;  
    // get hqBpid and PartnerId from this.existedData;
    this.userOnboardService
      .submitConsumerData(obj, {})
      .subscribe(res => {
        this.closeModal(close);
        //this.isChecked = false;
        this.router.navigate(['/main/success']);
      });
  }

  submitFinalData() {
    this.openModal(this.confirmTemplate, 'sm');
  }

  submitIps(close) {
    //  this.publishAndPushObj.ip=this.ipsList;
    //  this.enterpriseRowValue.ip=this.ipsList;
    //  this.nextButtonShow = false;
    //  this.closeModal(close);
    const obj = {
      ip: this.ipsList,
      streams: [],
      roleId:this.selectedRoleValue
    };
    // this.publishAndPushObj.ip.forEach(element => {
    //   obj.ip.push(element.ip);
    // });
    this.userOnboardService
      .submitConsumerData(obj, this.enterpriseRowValue)
      .subscribe(res => {
        this.closeModal(close);
        this.router.navigate(['/main/success']);
      });
  }

  submitStreamForm(pushStreamGroupForm) {
    //if (pushStreamGroupForm.valid) {
    this.enterpriseRowValue.streams[this.rowIndex].push.pushApiUrl = pushStreamGroupForm.controls['pushApiUrl'].value;
    this.enterpriseRowValue.streams[this.rowIndex].push.ackApiUrl = pushStreamGroupForm.controls['ackApiUrl'].value;
    this.enterpriseRowValue.streams[this.rowIndex].push.accessToken = pushStreamGroupForm.controls['accessToken'].value;
    this.enterpriseRowValue.streams[this.rowIndex].push.pushLoginUrl = pushStreamGroupForm.controls['pushLoginUrl'].value;
    this.enterpriseRowValue.streams[this.rowIndex].push.loginReq = pushStreamGroupForm.controls['loginReq'].value;
    this.enterpriseRowValue.streams[this.rowIndex].push.authReq=pushStreamGroupForm.controls['authReq'].value;
     
    const obj = {
      ip: this.enterpriseRowValue.ip,
      streams: this.enterpriseRowValue.streams,
      roleId:this.selectedRoleValue
    };
    this.userOnboardService
      .submitConsumerData(obj, this.enterpriseRowValue)
      .subscribe(res => {
        this.closeModal(close);
        this.router.navigate(['/main/success']);
      });
    // } else {
    //   this.cms.validateAllFormFields(pushStreamGroupForm);
    // }
  }




}
