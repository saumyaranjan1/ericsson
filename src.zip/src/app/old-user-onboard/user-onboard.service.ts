import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';
import { DataService } from '../shared/services/data.service';

@Injectable({
  providedIn: 'root'
})
export class UserOnboardService {

  constructor(private interceptor: InterceptorService,
              private dataService: DataService) { }

  getEventsArry(data) {
    // START:: Topics related
    const events = [];
    if (data.alerts) {
      events.push('alerts');
    }
    if (data.events) {
      events.push('events');
    }
    if (data.locations) {
      events.push('locinfo');
    }
    return events;
    // END:: Topics related
  }

  isExistInStream(data, streams) {
    let existingStream;
    streams.forEach(stream => {
      if (stream.id === data.id) {
        if (!this.isEquivalent(data.push, stream.push) || data.name !== stream.name) {
          data.action = 'UPDATE';
          existingStream  = data;
        }
      }
    });
    return existingStream;
  }
  getStreamArray(data) {
    const streamsArray = {
      name: data.name,
      push : {
        authReq: false,
        pushApiUrl: data.push ? data.push.pushApiUrl : data.pushApiUrl,
        ackApiUrl: data.push ? data.push.ackApiUrl : data.ackApiUrl,
        pushLoginUrl: '',
        loginReq: '',
        accessToken: '',
        events : data.push ? data.push.events : this.getEventsArry(data)
      },
      pullReq: false,
      svc: data.push ? data.svc : '',
      userServicesId: data.push ? data.userServicesId : '',
      id: data.push || data.id ? data.id : '',
      action: data.push ? 'UPDATE' : 'ADD'
    };

    if (data.push) {
      if (data.push.authReq)  {
        streamsArray.push.authReq = data.push.authReq;
        streamsArray.push.pushLoginUrl = data.push.pushLoginUrl;
        streamsArray.push.loginReq = data.push.loginReq;
        delete streamsArray.push.accessToken;
      } else {
        streamsArray.push.accessToken = data.push.accessToken;
        delete streamsArray.push.pushLoginUrl;
        delete streamsArray.push.loginReq;
      }
    } else {
      if (data.authReq) {
        streamsArray.push.authReq = data.authReq;
        streamsArray.push.pushLoginUrl = data.pushLoginUrl;
        streamsArray.push.loginReq = data.loginReq;
        delete streamsArray.push.accessToken;
      } else {
        streamsArray.push.accessToken = data.accessToken;
        delete streamsArray.push.pushLoginUrl;
        delete streamsArray.push.loginReq;
      }
    }
    return streamsArray;
  }
  isEquivalent(a, b) {
    // Create arrays of property names
    const aProps = Object.getOwnPropertyNames(a);
    const bProps = Object.getOwnPropertyNames(b);

    // If number of properties is different,
    // objects are not equivalent
    if (aProps.length !== bProps.length) {
        return false;
    }

    for (let i = 0; i < aProps.length; i++) {
        const propName = aProps[i];

        // If values of same property are not equal,
        // objects are not equivalent
        if (Array.isArray(a[propName])) {
          if ( JSON.stringify(a[propName]) !== JSON.stringify( b[propName])) {
            return false;
          }
        } else {
          if (a[propName] !== b[propName]) {
            return false;
          }
        }
    }

    // If we made it this far, objects
    // are considered equivalent
    return true;
  }
  getEditData() {
    const request = {
      // jioUtils: true,
      // userServiceId: this.dataService.getParseAndAtob('partnerBasedConsumerLoginId'),
      // extraParams: true
   };

   request['extraParams']="?userServiceId="+this.dataService.getParseAndAtob('partnerBasedConsumerLoginId')
   
   const fromLoginScreen = this.dataService.getParseFromSession('fromLoginScreen');
  
    return this.interceptor.httpPromise('get', fromLoginScreen ? 'getConsumerDataFormLogin' : 'getConsumerData', request);
 }
 submitConsumerData(request, existedData) {
  // request.jioUtils = true;
  // request.isPathVariable = true;
  // request['hqBpId'] = existedData.hqbpId;
  // request['partnerId'] = existedData.partner ? existedData.partner.partnerId : existedData.partnerId;
  // request['pathParams'] = true;
  //  request.loginId = this.dataService.getParseAndAtob('partnerBasedConsumerLoginId');
  // request.pathVariables = {
  //   loginId: request.loginId
  // };

  var partnerId=existedData.partner ? existedData.partner.partnerId : existedData.partnerId
  
  request['extraParams'] =  "?hqbpId="+existedData.hqbpId+"&partnerId="+partnerId;

  
  return this.interceptor.httpCall('put', 'submitConsumerData', request);
 }
 getFinalStream(streams) {
  const finalStreams = [];
  streams.forEach((item, index) => {
    if (item.action === 'ADD' || item.action === 'DELETE' || item.action === 'UPDATE') {
      finalStreams.push(item);
    }
  });
  return finalStreams;
 }
}
