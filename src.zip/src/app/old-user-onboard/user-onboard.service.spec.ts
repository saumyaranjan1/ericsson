import { TestBed } from '@angular/core/testing';

import { UserOnboardService } from './user-onboard.service';

describe('UserOnboardService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: UserOnboardService = TestBed.get(UserOnboardService);
    expect(service).toBeTruthy();
  });
});
