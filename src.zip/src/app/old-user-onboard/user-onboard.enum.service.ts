import { Injectable } from '@angular/core';

@Injectable()
export class UserOnboardEnumsService {
  public static PAGE_INFO =
    `This is the page where you can enter your device details
     so that you can publish to device to from website and also
     provide visualization details so that you can view your device data.`;
  public static PUBLISH_IPS_INFO = `Add IP's of your device to publish data from your website.`;
  public static PUSH_INFO = `Add details of your visualization platform to get device data.`;
  public static EDIT_STREAMS = `Edit provided data stream details.`;
  constructor() {}
}
