import {AbstractControl, ValidationErrors, ValidatorFn} from '@angular/forms';

export function jsonValidator(): ValidatorFn {
  return (control: AbstractControl): ValidationErrors | null => {
    const error: ValidationErrors = { jsonInvalid: true };
    const emptyJsonError: ValidationErrors = { jsonEmpty: true };

    try {
      const isParsedData = JSON.parse(control.value);

      if (Object.keys(isParsedData).length === 0) {
        control.setErrors(emptyJsonError);
        return emptyJsonError;
      }

    } catch (e) {
      control.setErrors(error);
      return error;
    }

    control.setErrors(null);
    return null;
  };
}
