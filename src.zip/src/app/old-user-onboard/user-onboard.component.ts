import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UserOnboardEnumsService } from './user-onboard.enum.service';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { jsonValidator } from './json.validator';
import { UserOnboardService } from './user-onboard.service';
import { EnumsService } from '../shared/services/enums.service';
import { AppConfigService } from '../app-config.service';
import { DataService } from '../shared/services/data.service';
@Component({
  selector: 'app-user-onboard',
  templateUrl: './user-onboard.component.html',
  styleUrls: ['./user-onboard.component.less']
})
export class UserOnboardComponent implements OnInit {
  @ViewChild('publishTemplate', { static: false }) publishTemplate: ElementRef;
  @ViewChild('streamGroupTemplate', { static: false }) streamGroupTemplate: ElementRef;
  @ViewChild('confirmTemplate', { static: false }) confirmTemplate: ElementRef;
  @ViewChild('errorTemplate', { static: false }) errorTemplate: ElementRef;
  pageInfo = UserOnboardEnumsService.PAGE_INFO;
  publishInfo = UserOnboardEnumsService.PUBLISH_IPS_INFO;
  pushInfo = UserOnboardEnumsService.PUSH_INFO;
  editInfo = UserOnboardEnumsService.EDIT_STREAMS;
  deviceEventsError = false;
  publishIpForm: FormGroup;
  pushStreamGroupForm: FormGroup;
  publishAndPushObj = {
    ip: [],
    streams: []
  };
  disableSubmitButton = true;
  existedData = [];
  existedStreams = [];
  hqbpName;
  availableEvents;
  roleIdList = [];
  isEdit = false;
  readOnlyInputField;
  index;
  namesArray = [];
  errorMessage;
  addMoreStreamsAllow = true;
  existedJobs = [];
  shouldNotallowNewStrems;
  groupNameExists;
  selectedRoleValue;
  roleSelectedId;
  sourceOfRequest;
  isChecked = false;
  category;
  constructor(
    private ngbModal: NgbModal,
    private fb: FormBuilder,
    private cms: CommonMethodsService,
    private userOnboardService: UserOnboardService,
    private router: Router,
    private apc: AppConfigService,
    private dataService: DataService
  ) { }

  ngOnInit() {
    this.getExistingData();
    this.sourceOfRequest = this.dataService.getParseFromSession('sourceOfRequest');
    this.category = this.dataService.getAtobLocalStorage('category');
  }
  refreshData() {
    this.getExistingData();
  }

  getIpFormBlock(ip?) {
    this.publishIpForm = this.fb.group({
      ip: [
        '',
        [
          Validators.required,
          this.cms.patternValidator(
            /\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\.|$)){4}\b/,
            { isValidUrl: true }
          )
        ]
      ]
    });
  }
  removeIp(i: number) {
    this.publishAndPushObj.ip.splice(i, 1);
  }
  openPublishTempalte() {
    this.getIpFormBlock();
    this.openModal(this.publishTemplate, 'sm');
  }
  openStreamGroupTempalte(stream?, index?) {
    this.checkHowManyNewStremsAreThere();
    if (!stream && this.shouldNotallowNewStrems) {
      this.errorMessage = EnumsService.IOT_USER_ONBOARD.MAX_STREMS;
      this.openModal(this.errorTemplate, 'sm');
    } else {
      if (this.addMoreStreamsAllow) {
        this.isEdit = stream ? true : false;
        this.index = index;
        this.getStreamGroupFormBlock(stream);
        this.openModal(this.streamGroupTemplate, 'lg');
      } else {
        this.errorMessage = EnumsService.IOT_USER_ONBOARD.STREAM_GROUP_ERROR;
        this.openModal(this.errorTemplate, 'sm');
      }
    }
  }
  checkJobStatus() {
    if (this.existedJobs) {
      const completedJobs = this.existedJobs.filter((job) => {
        return job.status.toLowerCase() === 'done' || job.status.toLowerCase() === 'failed' || job.status.toLowerCase() === 'incomplete';
      });

      if (completedJobs.length === this.existedJobs.length) {
        this.addMoreStreamsAllow = true;
      } else {
        this.addMoreStreamsAllow = false;
      }
    }
  }
  getStreamGroupFormBlock(data?) {
    this.readOnlyInputField = false;
    let name = '';
    if (data && data.name) {
      name = data.name;
      this.readOnlyInputField = true;
    } else if (this.publishAndPushObj.streams.length === 0) {
      name = 'Default';
      this.readOnlyInputField = true;
    }
    this.publishAndPushObj.streams.forEach((stream) => {
      if (stream.name) {
        this.namesArray.push(stream.name.toLowerCase());
      }
    });
    this.namesArray = this.namesArray.filter(e => e !== name);
    this.pushStreamGroupForm = this.fb.group({
      name: [name, [Validators.required]],
      locations: [data && data.push.events ? data.push.events.includes('locinfo') : 'Yes'],
      events: [data && data.push.events ? data.push.events.includes('events') : 'Yes'],
      alerts: [data && data.push.events ? data.push.events.includes('alerts') : 'Yes'],
      
      // locations: ['Yes'],
      // events: ['Yes'],
      // alerts: ['Yes'],
      pushApiUrl: [data && data.push ? data.push.pushApiUrl : '', [Validators.required, this.cms.patternValidator(
        /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
        { isValidUrl: true }
      )]],
      ackApiUrl: [data && data.push ? data.push.ackApiUrl : '', [this.cms.patternValidator(
        /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
        { isValidUrl: true }
      )]],
      authReq: [data && data.push ? data.push.authReq : false],
      pushLoginUrl: [data && data.push ? data.push.pushLoginUrl : ''],
      loginReq: [data && data.push ? data.push.loginReq : ''],
      accessToken: [data && data.push ? data.push.accessToken : '', Validators.required],
      id: [data && data.push ? data.id : '']
    });
  }
  verifyGroupName(data) {
    if (data) {
      this.groupNameExists = this.namesArray.includes(data.toLowerCase());
    } else {
      this.groupNameExists = false;
    }
  }
  openModal(content, size) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal user-onboard',
        size,
        backdrop: 'static',
        keyboard: false
      })
      .result.then(
        result => { },
        reason => { }
      );
  }
  closeModal(close) {
    this.isEdit = false;
    this.index = '';
    this.groupNameExists = false;
    this.isChecked = false;
    close('Cross click');
  }
  deleteStream(data, close) {
    if (data.id) {
      this.publishAndPushObj.streams.forEach(stream => {
        if (stream.id === data.id) {
          // stream.action = 'DELETE';
          this.closeModal(close);
          this.errorMessage = EnumsService.IOT_USER_ONBOARD.DELETE_SUBMITED_STREAM;
          this.openModal(this.errorTemplate, 'sm');
        }
      });
    } else {
      this.publishAndPushObj.streams.splice(this.index, 1);
      this.closeModal(close);
    }
  }
  submitForm(form, close, formName) {
    if (form.valid) {
      this.disableSubmitButton = false;
      if (formName === 'publish') {
        this.publishAndPushObj.ip.push(form.value);
        this.closeModal(close);
      } else {
        if (!this.deviceEventsError && !this.groupNameExists) {
          this.readOnlyInputField = false;
          const stremsArray = this.userOnboardService.getStreamArray(form.value);
          if (stremsArray.id) {
            const isModified = this.userOnboardService.isExistInStream(stremsArray, this.publishAndPushObj.streams);
            if (isModified) {
              const indexOfModifiedSteeam = this.publishAndPushObj.streams.findIndex(stream => stream.id === isModified.id);
              this.publishAndPushObj.streams.splice(indexOfModifiedSteeam, 1, isModified);
            } else {
              this.disableSubmitButton = true;
              // this.publishAndPushObj.streams.push(stremsArray);
            }
          } else {
            if (this.publishAndPushObj.streams.length > 0) {

              const index = this.publishAndPushObj.streams.findIndex(stream => stream.name === stremsArray.name);
              if (index >= 0) {
                this.publishAndPushObj.streams.splice(index, 1, stremsArray);
              } else {
                this.publishAndPushObj.streams.push(stremsArray);
              }
            } else {
              this.publishAndPushObj.streams.push(stremsArray);
            }
          }
          this.closeModal(close);
        } else {
          this.cms.validateAllFormFields(form);
        }
      }
    } else {
      this.cms.validateAllFormFields(form);
    }
  }
  checkValues() {
    if (
      this.pushStreamGroupForm.value.events ||
      this.pushStreamGroupForm.value.alerts ||
      this.pushStreamGroupForm.value.locations
    ) {
      this.deviceEventsError = false;
    } else {
      this.deviceEventsError = true;
    }
  }
  enableSubmitButton() {
    this.disableSubmitButton = false;
  }

  setAuthRequirizationValidations() {
    const pushStreamGroupForm = this.pushStreamGroupForm;
    if (pushStreamGroupForm.value.authReq) {
      pushStreamGroupForm
        .get('pushLoginUrl')
        .setValidators([Validators.required, this.cms.patternValidator(
          /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
          { isValidUrl: true })]);
      pushStreamGroupForm
        .get('loginReq')
        .setValidators([Validators.required, jsonValidator()]);
      pushStreamGroupForm
        .get('accessToken')
        .setValidators([]);
    } else {
      pushStreamGroupForm
        .get('pushLoginUrl')
        .setValidators([]);
      pushStreamGroupForm
        .get('loginReq')
        .setValidators([]);
      pushStreamGroupForm
        .get('accessToken')
        .setValidators([Validators.required]);
    }
    this.updateValidation();
  }
  updateValidation() {
    const pushStreamGroupForm = this.pushStreamGroupForm;
    pushStreamGroupForm.get('pushLoginUrl').updateValueAndValidity();
    pushStreamGroupForm.get('loginReq').updateValueAndValidity();
    pushStreamGroupForm.get('accessToken').updateValueAndValidity();
  }
  getExistingData() {
    this.userOnboardService
      .getEditData()
      .then(result => {
        if (result.data) {
          this.availableEvents = result.data.availableEvents;
          this.existedData = result.data;
          this.existedStreams = [];
          this.existedStreams = result.data.streams;
          this.existedJobs = result.data.jobs;
          this.roleIdList = result.data.roleList;
          this.selectedRoleValue = result.data.roleId;
          this.roleSelectedId = result.data.roleId;
          this.hqbpName = result.data.hqbpName;
          this.publishAndPushObj.ip = [];
          this.publishAndPushObj.streams = [];
          if (result.data.ip) {
            result.data.ip.forEach(ip => {
              this.publishAndPushObj.ip.push({ ip });
            });
          }
          if (result.data.streams) {
            result.data.streams.forEach(stream => {
              delete stream.topics;
              const stremsArray = this.userOnboardService.getStreamArray(stream);
              this.publishAndPushObj.streams.push(stremsArray);
            });
          }
          this.checkJobStatus();
        }
      });
  }
  checkHowManyNewStremsAreThere() {
    const newStreams = this.publishAndPushObj.streams.filter((stream) => {
      return stream.action === 'ADD';
    });
    this.shouldNotallowNewStrems = newStreams.length >= parseInt(this.apc['maxStremGroupCount']) ? true : false;
  }
  submitFinalData() {
    if (this.existedStreams.length > 0) {
      this.errorMessage = EnumsService.IOT_USER_ONBOARD.STREAM_GROUP_SUBMIT_ERROR;
      this.openModal(this.confirmTemplate, 'sm');
    } else {
      const streams = this.userOnboardService.getFinalStream(this.publishAndPushObj.streams);
      if (streams.length > 0) {
        this.errorMessage = EnumsService.IOT_USER_ONBOARD.STREAM_GROUP_SUBMIT_ERROR;
        this.openModal(this.confirmTemplate, 'sm');
      } else {
        this.errorMessage = EnumsService.IOT_USER_ONBOARD.ATLEAST_ONE_STREAM;
        this.openModal(this.errorTemplate, 'sm');
      }
    }
  }
  finalSubmit(close) {
    const obj = {
      ip: [],
      streams: this.userOnboardService.getFinalStream(this.publishAndPushObj.streams)
    };
    obj['roleId'] = this.selectedRoleValue
    this.publishAndPushObj.ip.forEach(element => {
      obj.ip.push(element.ip);
    });
    this.disableSubmitButton = true;
    this.isChecked = true;
    // get hqBpid and PartnerId from this.existedData
    this.userOnboardService
      .submitConsumerData(obj, this.existedData)
      .subscribe(res => {
        this.closeModal(close);
        this.isChecked = false;
        this.roleSelectedId = this.selectedRoleValue;
        this.router.navigate(['/main/success']);
      });
  }

  valueSelected(event) {
    if (this.roleSelectedId !== event.value) {
      this.disableSubmitButton = false;
      this.selectedRoleValue = event.value
    } else {
      this.disableSubmitButton = true;
    }
  }

  resetPage() {
    this.router.navigate(['/main/cuscfg']);
  }
}
