import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserOnboardComponent } from './user-onboard.component';
import { SharedModule } from '../shared/shared.module';
import { UserOnboardRoutingModule } from './user-onboard-routing.module';



@NgModule({
  declarations: [UserOnboardComponent],
  imports: [
    CommonModule,
    UserOnboardRoutingModule,
    SharedModule
  ]
})
export class UserOnboardModule { }
