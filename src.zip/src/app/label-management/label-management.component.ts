import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { LabelManagementService } from './label-management.service';
import { InlinePagenationTableComponent } from '../shared/components/inline-pagenation-table/inline-pagenation-table.component';

import { HttpHeaders } from '@angular/common/http';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { DataService } from '../shared/services/data.service';

import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';

@Component({
  selector: 'app-label-management',
  templateUrl: './label-management.component.html',
  styleUrls: ['./label-management.component.less']
})

export class LabelManagementComponent implements OnInit {
  @ViewChild(InlinePagenationTableComponent, { static: false }) child: InlinePagenationTableComponent;
  @ViewChild('addLabelContent', { static: false }) addLabelContent: ElementRef;
  @ViewChild('deleteConfirmModalContent', { static: false }) deleteConfirmModalContent: ElementRef;
  //getData: any;
  updatedetails;
  deleteDetails;
  getEntityValue: [];
  closeResult: string;
  distinctentityName: [];
  entityParamName: any;
  entityParamValue: any;
  entityParamVersion: any;
  addValue: any;
  deleteData;
  details;
  saveDetails;
  distinctValue: any;
  addLabelinput: any;
  trmpCount: any;
  addLabelObj = {
    entityName: []
  }
  newRowData: any;
  data = {
    data: [],
    columns: [
      {
        displayName: 'labelName',
        key: 'entityNameSelect',
        filterRowEvent: true,
        input: false,
        singleSelect: true,
        edit: true,
        editvalue: false
      },
      {
        displayName: 'labelValue',
        key: 'entityValue',
        filterRowEvent: true,
        input: true,
        singleSelect: false,
        editvalue: false
      },
      {
        displayName: 'labelVersion',
        key: 'entityVersion',
        filterRowEvent: true,
        input: true,
        singleSelect: false,
        editvalue: true
      },
      {
        displayName: 'labelDescription',
        key: 'entityDescription',
        filterRowEvent: false,
        input: true,
        singleSelect: false,
        editvalue: true
      }
    ],
    actions: [

    ],

    actionsLabel: 'Actions',
    total: 0,
    tableHeader: 'Label Management',
    tableActions: {
    },
    moduleName: EnumsService.TITLE_UI_API,
    headerDropdownList: [
      { key: "entityName", value: "Label Name" },
      { key: "entityValue", value: "Label Value" },
      { key: "entityVersion", value: "Label Version" },
      // {key: "entityDescription", value: "Label Description"}
    ]
  };

  actionsArr;
  constructor(private labelService: LabelManagementService, private userService: UserService, private ngbModal: NgbModal, private cms: CommonMethodsService, private dataService: DataService, ) {
  }

  ngOnInit() {
    this.getDetailsTotal();
    this.trmpCount = 0;
  }
  getDetails(params) {
    this.getActions();
    this.labelService.getTitleDetails(params).subscribe((res: any) => {
      this.data.data = [];
      this.data.data = res.data;
      if (res.count) {
        this.data.total = res.count;
      } else {
        this.getDetailsTotal();
      }
      this.data.data.map(item => {
        item['entityNameSelect'] = {};
        item['entityNameSelect']['model'] = item.entityName;
      });

      this.setId();
      this.child.updateEditCache('notEdit');
    },
      (error) => {
        console.log(error);
      });
  }

  sortData(event) {
    var param = {
      'pageNum': 1,
      'rpp': 10,
      'sortingkey': event.columnName,
      'orderByKey': event.orderBy
    }

    if (param.sortingkey == 'entityNameSelect') {
      param.sortingkey = 'entityName';
    }
    this.getDetails(param)
  }

  getDetailsTotal() {
    this.labelService.getTitleDetailsTotal().subscribe((res: any) => {
      this.data.total = res.data;
    },
      (error) => {
        console.log(error);
      });
  }
  getActions() {
    const _module = EnumsService.TITLE_UI_API;

    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe(prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

      this.data.tableActions = this.actionsArr;
      this.data.tableActions['search'] = this.actionsArr.headerRights.search;
      this.data.tableActions['add'] = this.actionsArr.headerRights.add;
      this.data.tableActions['delete'] = this.actionsArr.headerRights.delete;
      this.data.tableActions['dropDown'] = true;
      this.data.actions = this.actionsArr.actionsArray;

    });



  }


  ngOnChanges() {
    this.data = this.data;
    this.setId();
  }

  addLabel(event) {
    this.addValue =
      {
        "entityName": event.entityName,
        "entityValue": event.entityValue,
        "entityVersion": event.entityVersion,
        "entityDescription": event.entityDescription
      }
    this.labelService.addLabelDetails(this.addValue).subscribe((res: any) => {
      this.addValue = event;
    });
  }

  editValue: any;
  editabelField = false;
  entityVersionList: any;

  editDetails(event) {
    this.editValue =
      {
        "entityName": event.entityName,
        "entityValue": event.entityValue,
        "entityVersion": event.entityVersion,
        "entityDescription": event.entityDescription
      }
  }

  saveData(event) {
    if (event.action) {
      const params = {
        "entityName": event.data.entityNameSelect.showItem,
        "entityValue": event.data.entityValue,
        "entityVersion": event.data.entityVersion,
        "entityDescription": event.data.entityDescription
      }
      this.labelService.addLabelDetails(params).subscribe((res: any) => {
        this.dataService.broadcast('alert', {
          type: 'success',
          message: `Save successfully!`
        });
        this.child.getPage(1);
        this.child.cancelEdit(event.data);
        this.child.submit = false;
      });
    } else {
      this.updatedetails =
        {
          existingTitleDetail:
            this.editValue,
          updateTitleDetail:
          {
            "entityVersion": event.data.entityVersion,
            "entityDescription": event.data.entityDescription
          }
        }
      this.labelService.saveDetails(this.updatedetails).subscribe((res: any) => {
        this.dataService.broadcast('alert', {
          type: 'success',
          message: `Update successfully!`
        });
        this.child.getPage(1);
        this.child.cancelEdit(event.data);
        this.child.submit = false;
      });
    }
  }

  setId() {
    this.data.data.forEach(function (item, key) {
      item["id"] = key; // will add to each item the image
    });
  }


  getlabel(){
    this.labelService.getDistinctEntityName({}).subscribe((res: any) => {
      this.distinctentityName = res.data;
    });
  }

  removeLabel(entityName){
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      body: {
        "entityName": entityName,
       }
    }
    this.labelService.deleteEntityName(options).subscribe((res: any) => {
      this.getlabel();
    });
   }

  open(content: any, size) {
    if (this.data.data.length === 0) {
      this.ngbModal
        .open(content, {
          windowClass: 'jio-modal',
          size,
          backdrop: 'static',
          keyboard: false
        })
        .result.then(
          result => { },
          reason => { }
        );
      this.labelService.getDistinctEntityName({}).subscribe((res: any) => {
        this.distinctentityName = res.data;
      });
    } else {
      this.labelService.getDistinctEntityName({}).subscribe((res: any) => {
        this.distinctentityName = res.data;
        this.ngbModal
          .open(content, {
            windowClass: 'jio-modal',
            size,
            backdrop: 'static',
            keyboard: false
          })
          .result.then(
            result => { },
            reason => { }
          );
      });
    }

  }

  showIsDeleat(item){
    if(item=='DEVICE_OS' || item=='PLAN_CODE'|| item=='DEVICE_TYPE'){
     return false;
    }else{
      return true;
    }
  }

  closeModal(close) {
    close('Cross click');
  }

  entityName;
  onboardEntityNames(event) {
    this.open(this.addLabelContent, event);
    this.entityName = {
      "entityName": event.entityName
    }
  }


  deleteTitleDetails(event) {
    this.deleteData = event;
    this.open(this.deleteConfirmModalContent, 'sm');
  }

  closeModel(close) {
    close('Cross click');
  }

  deleteTitleData(close) {
    const options = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json'
      }),
      body: {
        "entityName": this.deleteData.entityName,
        "entityValue": this.deleteData.entityValue,
        "entityVersion": this.deleteData.entityVersion
      }
    }
    this.labelService.deleteTitle(options).subscribe((res: any) => {
      this.deleteDetails = event;
      this.closeModel(close);
      this.child.getPage(1);
    });
  }

  // deleteTitleDetails(event) {
  //   const options = {
  //     headers: new HttpHeaders({
  //       'Content-Type': 'application/json'
  //     }),
  //     body: {
  //       "entityName": event.entityName,
  //       "entityValue": event.entityValue,
  //       "entityVersion": event.entityVersion
  //     }
  //   }
  //   this.labelService.deleteTitle(options).subscribe((res: any) => {
  //     this.deleteDetails = event;
  //     this.child.getPage(1);
  //   });
  // }



  submitForm(params) {
    this.entityName = {
      "entityName": params
    }
    this.labelService.onboardEntityNames(this.entityName).subscribe((res: any) => {
      this.entityName = res;
      this.getDistinctEntityName();
    });
  }

  removeILabel(i: number) {
    this.addLabelObj.entityName.splice(i, 1);
  }

  getDistinctEntityName() {
    this.labelService.getDistinctEntityName({}).subscribe((res: any) => {
      this.distinctentityName = res.data;
      this.addLabelinput = '';
    });
  }


  getnewRowData(event) {
    this.newRowData = {
      'entityNameSelect': {},
      'entityValue': '',
      'entityVersion': '',
      'entityDescription': '',
      'newRow': true
    };
    this.labelService.getDistinctEntityName({}).subscribe((res: any) => {
      this.entityVersionList = [];
      res.data.forEach(item => {
        this.entityVersionList.push({ value: item, name: item.charAt(0).toUpperCase() + item.slice(1).toLowerCase() });
      });
      this.newRowData.entityNameSelect.model = [];
      this.newRowData.entityNameSelect.showItem = [];
      this.newRowData.entityNameSelect.values = this.entityVersionList;
      this.data.data.splice(0, 0, this.newRowData);
      this.child.updateEditCache('edit');
    });

  }




  // getnewRowData(event){
  // if(event.value=='entityName'){
  //  const param = {
  //     "entityName": event.param
  //   }
  //   this.entityParamName=event.param;
  //   this.labelService.getDistinctTitleValue(param).subscribe((res:any)=>{
  //     this.data.data.forEach(item => {
  //        if(item.tempCount ==  event.data){
  //         item.entityValue = res.data;
  //        }
  //     });
  // });
  // }else if(event.value=='entityValue' ){
  // const param = {
  //     "entityName": this.entityParamName,
  //     "entityValue": event.param
  //   }
  //   this.entityParamValue=event.param;
  //   this.labelService.getDistinctTitleValue(param).subscribe((res:any)=>{

  //     this.data.data.forEach(item => {
  //       if(item.tempCount ==  event.data){
  //        item.entityVersion = res.data;
  //       }
  //    });
  // });
  // }else if(event.value=='entityVersion' ){
  //  const param = {
  //      "entityName": this.entityParamName,
  //      "entityValue": this.entityParamValue,
  //      "entityVersion":event.param
  //    }
  //  this.labelService.getDetails(param).subscribe((res:any)=>{
  //      this.data.data.forEach(item => {
  //       if(item.tempCount ==  event.data){
  //        item.entityDescription = res.data.entityDescription;
  //       }
  //      });
  //      this.editValue = res.data;
  //   });
  //  }
  // else
  // {
  // this.labelService.getDistinctTitleValue({}).subscribe((res:any)=>{
  //      this.trmpCount=this.trmpCount + 1;
  //      this.editabelField=false;
  //      this.getEntityValue=res.data;
  //      this.newRowData = {
  //       'entityName': res.data,
  //       'entityValue': '',
  //       'entityVersion': '',
  //       'entityDescription': '',
  //       'tempCount': this.trmpCount,
  //       'newRow':true
  //     };
  //      this.data.data.splice(0,0,this.newRowData);
  //      this.child.updateEditCache('edit');
  // });
  // }
  // }


}
