import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { LabelManagementComponent } from './label-management.component';
import { LabelManagementService } from './label-management.service';


  const routes: Routes = [{ path: '', component: LabelManagementComponent }];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  declarations: [],
  exports: [RouterModule]
})  
export class LabelRoutingModule { }
