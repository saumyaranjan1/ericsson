import { LabelManagementModule } from './label-management.module';

describe('LabelManagementModule', () => {
  let labelManagementModule: LabelManagementModule;

  beforeEach(() => {
    labelManagementModule = new LabelManagementModule();
  });

  it('should create an instance', () => {
    expect(labelManagementModule).toBeTruthy();
  });
});
