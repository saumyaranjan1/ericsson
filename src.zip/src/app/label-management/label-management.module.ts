import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LabelManagementComponent } from './label-management.component';
import { SharedModule } from '../shared/shared.module';
import { LabelRoutingModule } from './label-routing.module';
import { LabelManagementService } from './label-management.service';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    LabelRoutingModule
  ],
  declarations: [LabelManagementComponent],
  providers: [LabelManagementService]
})
export class LabelManagementModule { }
