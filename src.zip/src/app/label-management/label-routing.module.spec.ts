import { LabelRoutingModule } from './label-routing.module';

describe('LabelRoutingModule', () => {
  let labelRoutingModule: LabelRoutingModule;

  beforeEach(() => {
    labelRoutingModule = new LabelRoutingModule();
  });

  it('should create an instance', () => {
    expect(labelRoutingModule).toBeTruthy();
  });
});
