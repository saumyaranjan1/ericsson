import { TestBed } from '@angular/core/testing';

import { LabelManagementService } from './label-management.service';

describe('LabelManagementService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: LabelManagementService = TestBed.get(LabelManagementService);
    expect(service).toBeTruthy();
  });
});
