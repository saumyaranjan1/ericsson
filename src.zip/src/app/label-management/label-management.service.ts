import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DeleteIntercepterService } from '../shared/services/delete-ajax-method.service';

@Injectable({
  providedIn: 'root'
})
export class LabelManagementService {

  constructor(private interceptor: InterceptorService, private http: HttpClient) { }


  addLabelDetails(request) {
    return this.interceptor.httpCall('post', 'addLabelDetails', request);
  }

  saveDetails(request) {
    return this.interceptor.httpCall('post', 'saveDetails', request);
  }

  getTitleDetails(request) {
    const param = {
      pageNum: request.pageNum,
      rpp: request.rpp,
      textToSearch: request.searchValue,
      textSearchInColumn: request.searchBy,
    };
    if (request.orderByKey && request.sortingkey) {
      param['sortingkey']=request.sortingkey;
      param['orderByKey']=request.orderByKey;
    }
     if (request.searchValue && request.searchBy) {
      delete param.pageNum;
      delete param.rpp;
      return this.interceptor.httpCall('get', 'searchByFieldValue', param);
    } else {
      return this.interceptor.httpCall('get', 'getLabelManagementTitleDetails', param);
    }
  }


  getTitleDetailsTotal() {
    return this.interceptor.httpCall('get', 'getTitleDetailsTotal');
  }

  getCountOfTitleDetails(request) {
    return this.interceptor.httpCall('get', 'getLabelManagementCountOfTitleDetails', request);
  }

  getDistinctTitleValue(request) {
    return this.interceptor.httpCall('post', 'getDistinctTitleValue', request);
  }

  getDetails(request) {
    return this.interceptor.httpCall('post', 'getDetails', request);
  }

  deleteTitle(request) {
    const param = {
      'data': request,
      'isdelete': true
    }
    return this.interceptor.httpCall('delete', 'deleteTitle', param);
  }

  deleteEntityName(request) {
    const param = {
      'data': request,
      'isdelete': true
    }
    return this.interceptor.httpCall('delete', 'deleteEntityName', param);
  }

  getDistinctEntityName(request) {
    return this.interceptor.httpCall('get', 'getLabelManagementDistinctEntityName');
  }

  onboardEntityNames(request) {
    return this.interceptor.httpCall('post', 'onboardEntityNames', request);
  }
}
