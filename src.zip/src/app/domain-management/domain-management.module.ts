import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DomainManagementComponent } from './domain-management.component';
import { SharedModule } from '../shared/shared.module';
import { DomainManagementRoutingModule } from './domain-management-routing.module';


@NgModule({
  declarations: [DomainManagementComponent],
  imports: [
    CommonModule,
    SharedModule,
    DomainManagementRoutingModule
  ],
  providers: []
})
export class DomainManagementModule { }
