import { Injectable } from '@angular/core';
import { animationFrameScheduler } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DomainManagementEnumService {
  public static DATA = {
    data: [],
    columns: [
      {
        displayName: 'Domain Name',
        key: 'domainName',
        filter: ''
      },
      {
        displayName: 'User Name',
        key: 'userName',
        filter: ''
      },
    ],
    actions: [
      // {
      //   type: 'view',
      //   title: 'view',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'edit',
      //   title: 'edit',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'delete',
      //   title: 'delete',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // }
    ],
    tableHeader: 'Domain Management',
    actionsLabel: 'Actions',
    tableActions: {
      add: false,
      search: false,
      dropdown: false,
      exportToCsv: false,
      showCheck: false,
    },
    tabelTooltip: 'This is the index page which shows list of Domain Management'
  };


}