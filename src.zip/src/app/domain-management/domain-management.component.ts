import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { DomainManagementService } from './domain-management.service';
import { DomainManagementEnumService } from './domain-management-enum.service';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../shared/services/data.service';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { SpinnerService } from '../shared/services/spinner.service';

import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';

@Component({
  selector: 'app-tac-code',
  templateUrl: './domain-management.component.html',
  styleUrls: ['./domain-management.component.less']
})
export class DomainManagementComponent implements OnInit {
  @ViewChild('addDomainModalContent', { static: true }) addDomainModalContent: ElementRef;
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  uploadedFile;
  uploadedFileName;
  isView = false;
  isEdit = false;
  uplodBtn = true;
  fileExtension;
  fileSubmitReq;
  domainList = DomainManagementEnumService.DATA;
  tableHeaderActions = {
    add: true,
    search: true,
    exportToCsv: true,
    dropDown: false
  };
  isValidate = true //validate button enable
  isSave = false; //save button false
  createDomainFormGroup: FormGroup;
  event;
  columns = DomainManagementEnumService.DATA.columns;
  tableHeader = DomainManagementEnumService.DATA.tableHeader;
  actionsObj = {
    actionsLabel: DomainManagementEnumService.DATA.actionsLabel,
    actions: DomainManagementEnumService.DATA.actions
  };
  hideListTable = false;
  actionsArr: any;
  constructor(
    private dms: DomainManagementService,
    private spinnerService: SpinnerService,
    private DataService: DataService,
    private userService: UserService,
    private fb: FormBuilder,
    private ngbModal: NgbModal,
    private dataService: DataService
  ) { }

  ngOnInit() {
    this.getDomainList();
  }

  /**
   * Spinner Start
   */
  spinnerStart() {
    this.spinnerService.toggleSpinner(1);
  }

  /**
  * Spinner End
  */
  spinnerEnd() {
    this.spinnerService.toggleSpinner(0);
  }

  validateDomain(form, close) {
    if (form.valid) {
      this.spinnerStart();
      const request = {
        domainName: form.controls.domainName.value,
        userName: this.createDomainFormGroup.value.userName.replace(/\s+/g, ""),
        password: this.createDomainFormGroup.value.password.replace(/\s+/g, ""),
       // domain: this.createDomainFormGroup.value.domainId
      }
      this.dms.validateDomain(request).subscribe(
        result => {
          if(result === 'FAILED'){
            this.isValidate = true;
            this.isSave = false;
            this.DataService.broadcast('alert', {
              type: 'danger',
              message: 'Invalid domain or credentials'
            });
          }
          else if(result === 'SUCCESS')
          {
            this.isSave = true;
            this.isValidate = false;
            this.DataService.broadcast('alert', {
              type: 'success',
              message: 'Validate Successfully'
            });
          }
          this.spinnerEnd();     
         
        },
        error => {
          this.isSave = false;
          this.isValidate = true;
          this.DataService.broadcast('alert', {
            type: 'danger',
            message: 'Invalid domain or credentials'
          });
          this.spinnerEnd();     
        })
    }
  }

  fieldTextType: boolean;
  toggleFieldTextType() {
    this.fieldTextType = !this.fieldTextType;
  }

  changeData(value){
    if(value){
      this.isSave = false;
      this.isValidate = true;
    }
  }

  /**
   * Get Domain Data
   */
  getDomainList() {
    this.getActions();
    this.spinnerStart();
    let domainData = [];
    this.isView = false;
    this.isEdit = false;
    this.dms.getDomainDetail().subscribe(
      res => {
        this.spinnerEnd();
        if (res) {
          domainData = res.map(data => {
            return data;
          });
        };
        this.domainList.data = domainData;
      },
      error => {
        this.domainList.data = [];
        this.failureCase(error);
      }
    );
  }

  /**
   * 
   * Get Actions previliges for Domains
   */
  getActions() {
    const _module = EnumsService.RBCONN;
  // Form object to get the previliiages from server
  const obj = {
    moduleCode: _module,
    roleId: this.dataService.getAtobLocalStorage('roleId'),
    previliages: true
  };

  // API to get Previliages
  this.userService.getPreViliages(obj).subscribe( prev => {

    this.actionsArr = this.userService.getModulePermission(
      EnumsService.ACTIONS[_module],
      prev.data.privilege // Passing privilege to the methos to get thr actions array
    );

    this.domainList.tableActions = this.actionsArr;
    this.domainList.tableActions.search=this.actionsArr.headerRights.search;
    this.domainList.tableActions.add=this.actionsArr.headerRights.add;
    this.domainList.actions =  this.actionsArr.actionsArray;
    
  });
    }

  /**
   * View Data
   **/
  viewData(event) {
    this.isView = true;
    this.isEdit = false;
    this.event = event;
    this.openModel(this.addDomainModalContent, event, 'sm');
  }

  /**
   * Delete Domain
   */
  deleteDomain(event) {
    this.isView = false;
    this.isEdit = false;
    this.event = event;
    this.openModel(this.deleteConfirmModalContent, event, 'sm');
  }

  /**
   * Delete Record
   */
  deleteDomainRecord(close) {
    const _req = "?domainName=" + this.event.domainName+"&userName="+this.event.userName;
    this.dms.deleteDomain(_req).subscribe((res: any) => {
      this.DataService.broadcast('alert', {
        type: 'success',
        message: 'Delete successfully'
      });
      this.getDomainList();
      this.closeModel(close);
    },
      error => {
      });
  }

  /**
   * Edit Data
   */
  editData(event) {
    this.event = event;
    this.isView = false;
    this.isEdit = true;
    this.isSave = false;
    this.isValidate = true;
    this.createDomainFormData(event);
    this.openModel(this.addDomainModalContent, event, 'sm');
  }

  closeModel(close) {
    close('Cross click');
  }

  /**
   * Add Form
   */
  addForm(request, close) {
    const reqParams = {
      domainName: this.createDomainFormGroup.value.domainName,
      userName: this.createDomainFormGroup.value.userName.replace(/\s+/g, ""),
      password: this.createDomainFormGroup.value.password.replace(/\s+/g, "")
    }
    this.dms.createForm(reqParams).subscribe(
      result => {
        this.spinnerEnd();
        this.DataService.broadcast('alert', {
          type: 'success',
          message: 'Create Domain Successfully'
        });
        this.getDomainList();
        this.closeModel(close);
      },
      error => {
       
      }
    );
  }

  /**
   * Update Form
   */
  updateForm(request, close) {
    this.dms.updateForm(request).subscribe(
      result => {
        this.spinnerEnd();
        this.DataService.broadcast('alert', {
          type: 'success',
          message: 'Update Domain Successfully'
        });
        this.getDomainList();
        this.closeModel(close);
      },
      error => {
        
      }
    );
  }
  submitForm(form, close) {
    if (form.valid) {
      this.spinnerStart();
      const request = {
        domainName: form.controls.domainName.value,
        userName: this.createDomainFormGroup.value.userName.replace(/\s+/g, ""),
        password: this.createDomainFormGroup.value.password.replace(/\s+/g, ""),
        domain: this.createDomainFormGroup.value.domainId
      }
      if (request.domain) {
        this.updateForm(request, close);
      } else {
        this.addForm(request, close);
      }
    }
  }
  openAddConfigModal(event) {
    this.isView = false;
    this.isEdit = false;
    this.isSave = false;
    this.isValidate = true;
    this.createDomainFormData(event);
    this.openModel(this.addDomainModalContent, event, 'sm');
  }


  createDomainFormData(event?) {
    this.createDomainFormGroup = this.fb.group({
      domainName: [{ value: event && event.domainName ? event.domainName : '', disabled: this.isEdit ? true : false }, Validators.required],
      domainId: event && event.domainId ? event.domainId : '',
      userName: [event && event.userName ? event.userName : '', Validators.required],
      password: [event && event.password ? event.password : '', Validators.required],
    })
  }

  openModel(content, event, size) {
    this.ngbModal
      .open(content, {
        windowClass: "jio-modal domain-management-popup",
        size: size,
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }


  /** 
  * Failure Case
  **/
  failureCase(error) {
    this.spinnerService.toggleSpinner(0);
    this.DataService.broadcast('alert', {
      type: 'danger',
      message: error && error.error ? error.error.errorDetails : 'Network error please try again'
    });
  }

}
