import { Injectable } from '@angular/core';
import { InterceptorService } from './../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class DomainManagementService {

  constructor(private interceptor: InterceptorService) { }

  /**
   * Get Domain Details
   */
  getDomainDetail() {
    return this.interceptor.httpCall('get', 'getDomainDetail');
  }
  /**
   * Create Form
   */
  createForm(action) {
    return this.interceptor.httpCall('post', 'createDomainForm', action);
  }
  /**
   * update Form
   */
  updateForm(request) {
    request.extraParams = "?domain="+request.domainName;
    return this.interceptor.httpCall('put', 'updateDomainForm', request, false, true);
  }

  /**
   * Delete Domain
   */
  deleteDomain(action) {
    return this.interceptor.httpCall('delete', 'deleteDomainManagement', action);
  }

  validateDomain(request){
    request['responseType'] = 'text';
    return this.interceptor.httpCall('post', 'validateDomain', request);  
  }
}