import { Component, OnInit } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators
} from '@angular/forms';
import { Router } from '@angular/router';
import { DiagnosisService } from './diagnosis.service';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { DataService } from '../shared/services/data.service';

@Component({
  selector: 'app-diagnosis',
  templateUrl: './diagnosis.component.html',
  styleUrls: ['./diagnosis.component.less']
})
export class DiagnosisComponent implements OnInit {
  diagnosisForm: FormGroup;
  viewT2RDetails : any;
  eventData;
  outerHeader=[]
  outerValue=[]
  normalLoops=[];
  extHeader=[];
  extdata=[];
  outerKey;
  extKey;
  keys;
  extValue=[];
  loader = false;
  T2RToken;
  onBoard = {
    suc: '',
    msg: '',
    code: '',
    timestamp:new Date()
  }
  vendor = {
    suc: '',
    msg: '',
    code: '',
    timestamp: new Date()
  }
  activate = {
    suc: '',
    msg: '',
    code: '',
    timestamp: new Date(),
  }
  configure = {
    suc: '',
    msg: '',
    code: '',
    timestamp: new Date(),
  }
  application = {
    suc: '',
    msg: '',
    code: '',
    timestamp: new Date(),
    apps:[]
  }
  auth = {
    suc: '',
    msg: '',
    code: '',
    timestamp: new Date(),
    apps:[]
  }
  dataFlow = {
    suc: '',
    msg: '',
    code: '',
    timestamp: new Date()
  }

  constructor(private router: Router,
    private ds: DiagnosisService,
    private fb: FormBuilder,
    private dataService: DataService,
    private cms: CommonMethodsService, ) { }
  validatationIsDone = false;
  ngOnInit() {
    this.formBlock();
  }
  resetToInitial(){
    this.onBoard = {
      suc: '',
      msg: '',
      code: '',
      timestamp:new Date()
    }
    this.vendor = {
      suc: '',
      msg: '',
      code: '',
      timestamp: new Date()
    }
    this.activate = {
      suc: '',
      msg: '',
      code: '',
      timestamp: new Date(),
    }
    this.configure = {
      suc: '',
      msg: '',
      code: '',
      timestamp: new Date(),
    }
    this.application = {
      suc: '',
      msg: '',
      code: '',
      timestamp: new Date(),
      apps:[]
    }
    this.auth = {
      suc: '',
      msg: '',
      code: '',
      timestamp: new Date(),
      apps:[]
    }
    this.dataFlow = {
      suc: '',
      msg: '',
      code: '',
      timestamp: new Date()
    }
  }
 
  refresh(){
    this.viewT2RDetails = '';
    this.outerHeader = [];
    this.outerValue = [];
    this.outerKey = [];
  }
  formBlock() {
    this.diagnosisForm = this.fb.group(
      {
        did: ['', [Validators.required, Validators.minLength(15),
        Validators.maxLength(16),
        Validators.pattern('^[0-9]*$')]],
      });
  }
   OnBoarding(did) {
     const statusOne = {
       did,
      status: 'ONBOARDING'
    };
    this.ds.getDeviceStatus(statusOne).subscribe((suc: any)=> {
    this.onBoard.suc = 'true';
      this.onBoard.msg = suc.body.msg;
      if (suc.body.timestamp) {
        this.onBoard.timestamp = suc.body.timestamp;
      }
      else {}  
      this.Vendorintimation(did);
    }, err=> {
        if(err.status === 403){
          this.dataService.broadcast('alert', {
            type: 'danger',
            message: err.error.msg || err.error.code
          });
        }
        else {
        this.onBoard.suc = 'false';
        this.onBoard.msg = err.error.msg || err.error.code;
        if (err.error.timestamp) {
          this.vendor.timestamp = err.error.timestamp;
        }
      }
    });
  }
  Vendorintimation(did) {
    const statusTwo = {
            did,
            status: 'VENDORINTIMATION'
          };
    this.ds.getDeviceStatus(statusTwo).subscribe((suc: any)=> {
        this.vendor.suc = 'true';
        this.vendor.msg = suc.body.msg;
        if (suc.body.timestamp) {
          this.vendor.timestamp = suc.body.timestamp;
        }
        else { }
        this.Activation(did);
    }, err=> {
        this.vendor.suc = 'false';
        this.vendor.msg = err.error.msg || err.error.code;
        if (err.error.timestamp) {
          this.vendor.timestamp = err.error.timestamp;
        }
        else { }
    });
  }
  Activation(did) {
      const statusThree = {
          did,
          status: 'ACTIVATION'
        };
     this.ds.getDeviceStatus(statusThree).subscribe((suc: any)=> {
        this.activate.suc = 'true';
        this.activate.msg = suc.body.msg;
        if (suc.body.timestamp) {
          this.activate.timestamp = suc.body.timestamp;
        }
        else { }
      this.Configuration(did);
    }, err=> {
        this.activate.suc = 'false';
        this.activate.msg = err.error.msg || err.error.code;
        if (err.error.timestamp) {
          this.activate.timestamp = err.error.timestamp;
        }
        else { }
    });
  }
  Configuration(did) {
    const statusFour = {
            did,
            status: 'CONFIGURATION'
          };
    this.ds.getDeviceStatus(statusFour).subscribe((suc: any)=> {
        this.configure.suc = 'true';
        this.configure.msg = suc.body.msg;
        if (suc.body.timestamp) {
          this.configure.timestamp = suc.body.timestamp;
        }
        else { }
      this.Application(did);
    }, err=> {
        this.configure.suc = 'false';
        this.configure.msg = err.error.msg || err.error.code;
        if (err.error.timestamp) {
          this.configure.timestamp = err.error.timestamp;
        }
        else { }
    });
  }
  Application(did) {
    const statusFive = {
            did,
            status: 'APPLICATION'
          };
   this.ds.getDeviceStatus(statusFive).subscribe((suc: any)=> {
        this.application.suc = 'true';
        this.application.msg = suc.body.msg;
        this.application.apps = suc.body.apps;
        if (suc.body.timestamp) {
          this.application.timestamp = suc.body.timestamp;
        }
        else { }
     this.Authentication(did);
    }, err => {
        this.application.suc = 'false';
        this.application.msg = err.error.msg || err.error.code;
        if (err.error.timestamp) {
          this.application.timestamp = err.error.timestamp;
        }
        else { }
    });
  }
  Authentication(did) {
    const statusSix = {
            did,
            status: 'AUTHENTICATION'
          };
    this.ds.getDeviceStatus(statusSix).subscribe((suc: any)=> {
         this.auth.suc = 'true';
         this.auth.msg = suc.body.msg;
         this.auth.apps = suc.body.apps;
         if (suc.body.timestamp) {
           this.auth.timestamp = suc.body.timestamp;
         }
         else { }
       this.DataFlow(did);
     }, err=> {
         this.auth.suc = 'false';
         this.auth.msg = err.error.msg || err.error.code;
         if (err.error.timestamp) {
           this.auth.timestamp = err.error.timestamp;
         }
         else { }
     });
   }
  DataFlow(did){
    const statusSeven = {
        did,
        status: 'DATAFLOW'
      };
    this.ds.getDeviceStatus(statusSeven).subscribe((suc: any)=> {
        this.dataFlow.suc = 'true';
        this.dataFlow.msg = suc.body.msg;
        if (suc.body.timestamp) {
          this.dataFlow.timestamp = suc.body.timestamp;
        }
        else { }
    }, err=> {
        this.dataFlow.suc = 'false';
        this.dataFlow.msg = err.error.msg || err.error.code;
        if (err.error.timestamp) {
          this.dataFlow.timestamp = err.error.timestamp;
        }
        else { }
    });
  }

  

  search(did) {
    this.resetToInitial();
    this.refresh();
    this.OnBoarding(did);
    this.T2ROnboarding(did);
   }

  T2ROnboarding(did){
    const T2RDetails = {
     did
   };
   
      this.ds.getT2RDetails(T2RDetails).subscribe(
        (res : any)=> {
        if(res.data.data){
             this.viewT2RDetails = res.data.data;
             this.extdata.push( this.viewT2RDetails[0].ext)
             delete  this.viewT2RDetails[0].ext;
             this.normalLoops.push( this.viewT2RDetails[0]);
             this.normalLoops.forEach(item => {
               this.outerHeader = Object.keys(item);
               this.outerValue =  Object["values"](item);
             });
            this.keys = Object.keys(this.viewT2RDetails);
             this.eventData= this.viewT2RDetails;
             this.viewT2RDetails = '';
        }
       else{
        this.viewT2RDetails = res.evd;
        this.viewT2RDetails = '';
        this.outerHeader = [];
        this.outerValue = [];
        this.outerKey = [];
        console.log(this.viewT2RDetails);
       }
      },
       error =>{
       }
      );
    }

  
  submitForm(form) {
    const formData = form.value;
    if (form.valid) {
      this.search(formData.did);
    } else {
      this.cms.validateAllFormFields(form);
    }
  }
 

}
