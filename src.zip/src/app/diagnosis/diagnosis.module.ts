import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DiagnosisComponent } from './diagnosis.component';
import { DiagnosisRoutingModule } from './diagnosis-routing.module';
import { DiagnosisService } from './diagnosis.service';
import { SharedModule } from './../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    DiagnosisRoutingModule
  ],
  declarations: [DiagnosisComponent],
  providers: [DiagnosisService]
})
export class DiagnosisModule { }
