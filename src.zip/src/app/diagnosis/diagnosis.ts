export interface Diagnosis {
}
