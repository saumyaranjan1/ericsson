import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { DiagnosisComponent } from './diagnosis.component';

const routes: Routes = [{ path: '', component: DiagnosisComponent }];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  declarations: [],
  exports: [RouterModule]
})
export class DiagnosisRoutingModule { }
