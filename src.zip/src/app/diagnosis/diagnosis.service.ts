import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders} from '@angular/common/http';
import { UrlMappingsService } from '../shared/services/url-mappings.service';
import { AppConfigService } from '../app-config.service';
import { UtilService } from '../shared/services/util.service';
import { InterceptorService } from '../shared/services/interceptor.service';


@Injectable({
  providedIn: 'root'
})
export class DiagnosisService {
  options;
  t2rOptions;
  t2rOptionsToken;
  constructor(private http: HttpClient,
    private UrlMap: UrlMappingsService,
    private appConfig: AppConfigService,
    private utilService: UtilService,
    private interceptor: InterceptorService) { }

  getDeviceStatus(request){
    let serverUrl = this.appConfig.configData['getBaseUrl'];
   
    let url = serverUrl + this.UrlMap.getEndUrl('getDeviceStatus');
    url = this.utilService.encodeURL(url, request);
    this.setHttpHeader();
    return this.http.get(url, this.options);
   }
 
  setHttpHeader() {

    const  header = new HttpHeaders(
      {
       'Authorization': this.interceptor.getAccessToken(false),
       'Content-Type': 'application/json'
     });;
    

    const customOptions = {
      headers: header,
      observe: 'response' as 'body', // to display the full response & as 'body' for type cast
      responseType: 'json'
    };
    this.options = customOptions;
  }

  getT2RDetails(request) {
    let params = {};
    params = { extraParams: '/' + request.did};
    return this.interceptor.httpCall('get', 'getT2RDetails', params);
   }
 }