import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe, DecimalPipe, LowerCasePipe, CurrencyPipe } from '@angular/common';

@Pipe({
  name: 'format'
})
export class FormatPipe implements PipeTransform {

  datePipe = new DatePipe('en-US');
  lowerCasePipe = new LowerCasePipe();
  currencyPipe = new CurrencyPipe('en-US');


  transform(value: any, args?: any): any {

    if (!value || !args) { return value; }

    let result = value;

    switch (args) {
      case 'date': result = this.datePipe.transform(value); break;
      case 'dateWithTime': result = this.datePipe.transform(value, 'medium'); break;
      case 'dateWithUTC':result = value; break;
      case 'lowercase': result = this.lowerCasePipe.transform(value); break;
      case 'currency': result = this.currencyPipe.transform(value); break;
      case 'list': result = value; break;
    }
    return result;
  }

}
