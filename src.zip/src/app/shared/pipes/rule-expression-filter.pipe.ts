import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'ruleexpressionfilter'
})
export class ruleExpressionFilterPipe implements PipeTransform {

  transform(arr: any, data: any, ruleData: any,fullData:any,btnIndex:number): any {
  
    if (data) {
      let keys = ruleData.map(item => {
         return item.key;
      });
      if(fullData){
        fullData.map((ruleItem,i) => {
          if(i === btnIndex){
            btnIndex = i;
          }
        });
      }
     
      return fullData[btnIndex].dropdownValues.filter((item: any) => {
        return keys.filter((key) => {
          return (String(item[key]).toLocaleLowerCase()).includes(data.toLocaleLowerCase());
        }).length;
      });
     
    } else {
      return arr;
    }
  }
}
