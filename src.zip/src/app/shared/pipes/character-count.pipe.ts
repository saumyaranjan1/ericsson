import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'characterCount'
})
export class CharacterCountPipe implements PipeTransform {

  transform(text: string, args: number): any {
    let maxLength = args || 250
    let length = text ? text.length : 0;
    return (maxLength - length);
  }

}
