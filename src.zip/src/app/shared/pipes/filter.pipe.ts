import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(arr: any, term: any, columns: any): any {
    if (term) {
      let keys = columns.map(item => {
         return item.key;
      });
      // let keys = Object.keys(arr[0]);
      return arr.filter((item: any) => {
        return keys.filter((key) => {
          return (String(item[key]).toLocaleLowerCase()).includes(term.toLocaleLowerCase());
        }).length;
      });
    } else {
      return arr;
    }
  }

}
