import { Pipe, PipeTransform } from '@angular/core';
import { TitleCasePipe } from '@angular/common';

@Pipe({
  name: 'formatData'
})
export class SplitWord implements PipeTransform {
  titleCasePipe = new TitleCasePipe();

  transform(data: any): any {
    if (!data) {
      return data;
    } else {
     const result = data.replace(/([A-Z])/, ' $1');
     return this.titleCasePipe.transform(result);
    }
  }
}
