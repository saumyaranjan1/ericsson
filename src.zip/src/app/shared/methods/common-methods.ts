import { Injectable } from '@angular/core';
import {
  AbstractControl,
  ValidationErrors,
  ValidatorFn,
  FormGroup,
  FormControl,
  FormArray
} from '@angular/forms';
import { AppConfigService } from '../../app-config.service';
import CryptoJS from 'crypto-js';
import { AesUtilService } from './AesUtils';
@Injectable()
export class CommonMethodsService {
  constructor(private appConfigService: AppConfigService) { }

  changeArrayElementsPosition(arr, oldIndex, newIndex) {
    if (newIndex >= arr.length) {
      let k = newIndex - arr.length + 1;
      while (k--) {
        arr.push(undefined);
      }
    }
    arr.splice(newIndex, 0, arr.splice(oldIndex, 1)[0]);
    return arr;
  }

  arraysEqual(a1, a2) {
    /* WARNING: arrays must not contain {objects} or behavior may be undefined */
    return JSON.stringify(a1) == JSON.stringify(a2);
  }

  encryptData(data, secretKey) {
    const iv = CryptoJS.lib.WordArray.random(128 / 8).toString(
      CryptoJS.enc.Hex
    );
    const salt = CryptoJS.lib.WordArray.random(128 / 8).toString(
      CryptoJS.enc.Hex
    );

    const aesUtil = new AesUtilService(256, 1000);

    const ciphertext = aesUtil.encrypt(salt, iv, secretKey, data);
    const aesPassword = iv + '::' + salt + '::' + ciphertext;
    const password = btoa(aesPassword);

    return password;
  }

  decryptData(encryptData, secretKey) {
    const btoaEncryptedData = atob(encryptData);
    const aesPassword = btoaEncryptedData.split('::');
    const aesUtil = new AesUtilService(256, 1000);
    const ciphertext = aesUtil.decrypt(aesPassword[1], aesPassword[0], secretKey, aesPassword[2]);
    return ciphertext;
  }

  encryptDataAsAes(data, secretKey) {
    return CryptoJS.AES.encrypt(JSON.stringify(data), secretKey).toString();
  }
  encryptDataAsSha256(data) {
    return CryptoJS.SHA256(data).toString();
  }

  decryptAesData(encryptData, secretKey) {
    const bytes = CryptoJS.AES.decrypt(encryptData, secretKey);
    if (bytes.toString(CryptoJS.enc.Utf8)) {
      return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
    } else {
      return encryptData;
    }
  }
  getSecretKey(userNameStr, passwordStr) {
    const userNameIndex = (userNameStr.length / 2) - 2;
    const userName = userNameStr.substring(userNameIndex, userNameIndex + 4);
    const passwordIndex = (passwordStr.length / 2) - 2;
    const password = passwordStr.substring(passwordIndex, passwordIndex + 4);
    return userName + this.appConfigService.configData['encryptKeyForSha256'] + password + passwordStr;
  }

  getEpochFromDateAndTime(date, time) {
    let dateM = new Date(date);

    let dd = dateM.getDate();
    let mm = dateM.getMonth() + 1;
    let yyyy = dateM.getFullYear();

    let timeIn24Format = this.convertTime12to24(time);
    let datestring = mm + '/' + dd + '/' + yyyy + ' ' + timeIn24Format;
    // let parts = datestring.match(/(\d{2})\/(\d{2})\/(\d{4}) (\d{2}):(\d{2})/);
    const newDate = new Date(datestring);
    return Math.floor(newDate.getTime());
  }
  getEpochTimeForInstallStartDay(str) {
    const date = new Date(str);
    const mnth = ("0" + (date.getMonth() + 1)).slice(-2);
    const day = ("0" + date.getDate()).slice(-2);

    const myDate = new Date(date.getFullYear(), parseInt(mnth) - 1, parseInt(day), 0, 0, 0);
    return Math.floor(myDate.getTime());
  }

  getEpochTimeForInstallStartDayAndTime(str, time) {
    const date = new Date(str);
    const mnth = ("0" + (date.getMonth() + 1)).slice(-2);
    const day = ("0" + date.getDate()).slice(-2);
    const hr = time.substring(0, 2);
    const mm = time.substring(3, 5);
    const myDate = new Date(date.getFullYear(), parseInt(mnth) - 1, parseInt(day), hr, mm, 0);
    return Math.floor(myDate.getTime());
  }



  getEpochTimeForInstallEndDay(str) {
    const date = new Date(str);
    const mnth = ("0" + (date.getMonth() + 1)).slice(-2);
    const day = ("0" + date.getDate()).slice(-2);

    const myDate = new Date(date.getFullYear(), parseInt(mnth) - 1, parseInt(day), 23, 59, 59);
    return Math.floor(myDate.getTime());
  }
  getDateObj(str) {
    const date = new Date(str);
    const mnth = ("0" + (date.getMonth() + 1)).slice(-2);
    const day = ("0" + date.getDate()).slice(-2);
    return [mnth, day, date.getFullYear()].join("/");
  }

  dateDiffIndays(fromdate, todate) {
    const dt1 = new Date(this.getDateObj(fromdate));
    const dt2 = new Date(this.getDateObj(todate));
    return Math.floor((Date.UTC(dt2.getFullYear(), dt2.getMonth(), dt2.getDate()) - Date.UTC(dt1.getFullYear(), dt1.getMonth(), dt1.getDate())) / (1000 * 60 * 60 * 24));
  }

  convertTime12to24(time12h) {
    const [time, modifier] = time12h.split(' ');

    let [hours, minutes] = time.split(':');
    if (hours < 10) {
      hours = '0' + hours;
    }

    if (hours === '12' && modifier === 'AM') {
      hours = '00';
    }

    if (modifier === 'PM') {
      hours = parseInt(hours, 10) + 12;
    }

    return `${hours}:${minutes}`;
  }


  getEpcohTIme(date) {
    if (date) {
      const myDate = new Date(date.year, date.month - 1, date.day);
      return myDate.getTime() / 1000.0;
    } else {
      return '';
    }
  }
  getTimeFromEpcoh(epcoh) {
    const myDate = new Date(epcoh * 1000).toLocaleString().split(',');
    const d = myDate[0].split('/');
    const dateObj = {
      day: parseInt(d[1], 10),
      month: parseInt(d[0], 10),
      year: parseInt(d[2], 10)
    };
    return dateObj;
  }
  getTimeFromEpcohToCsv(epcoh) {
    const myDate = new Date(epcoh * 1000).toLocaleString().split(',');
    const d = myDate[0].split('/');
    return parseInt(d[1], 10) + '/' + parseInt(d[0], 10) + '/' + parseInt(d[2], 10);
  }
  numberOnly(event: any): boolean {
    const charCode = event.which ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  }

  isNumber(str) {
    const pattern = /^\d+$/;
    return pattern.test(str); // returns a boolean
  }
  alphaNumeric(inputtxt: any): boolean {
    const regex = /^[0-9a-zA-Z]+$/;
    if (regex.test(inputtxt)) {
      return true;
    } else {
      return false;
    }
  }

  findLength(data) {
    return Math.ceil(Math.log10(data));
  }

  patternValidator(regex: RegExp, error: ValidationErrors): ValidatorFn {
    return (control: AbstractControl): { [key: string]: any } => {
      if (!control.value) {
        // if control is empty return no error
        return null;
      }
      // test the value of the control against the regexp supplied
      const valid = regex.test(control.value);

      // if true, return no error (no error), else return error passed in the second parameter
      return valid ? null : error;
    };
  }

  checkValidPartner(error: ValidationErrors) {
    return (control: AbstractControl): { [key: string]: any } => {
      let valid = false;
      let partnerValue = control.value;
      if (partnerValue) {
        let validId = this.appConfigService.configData['partnerIds'];
        validId.forEach(element => {
          if (element == partnerValue) {
            return valid = true;
          } else if (partnerValue && partnerValue.length == '7') {
            return valid = true;
          }
        });
        return valid ? null : error;
      }
    };
  }

  // checkValidPartnerLength(error: ValidationErrors) {
  //   return (control: AbstractControl): { [key: string]: any } => {
  //     let valid = false;
  //     let partnerValue = control.value;
  //     if (partnerValue) {
  //       let validId = this.appConfigService.configData['partnerIds'];
  //       validId.forEach(element => {
  //         if (element == partnerValue || partnerValue.length == '7') {
  //           return valid = true;
  //         }
  //       });
  //       return valid ? null : error;
  //     }
  //   };
  // }

  validUrl(value: any) {

    // test the value of the control against the regexp supplied
    const regex = /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/;
    const valid = regex.test(value);

    // if true, return no error (no error), else return error passed in the second parameter
    return valid ? true : false;
  }

  passwordMatchValidator(control: AbstractControl) {
    const password: string = control.get('password').value; // get password from our password form control
    const confirmPassword: string = control.get('confirmPassword').value; // get password from our confirmPassword form control
    // compare is the password math
    if (password !== confirmPassword) {
      // if they don't match, set an error in our confirmPassword form control
      control.get('confirmPassword').setErrors({ NoPassswordMatch: true });
    }
  }
  startDateAndEndDateValidation(control: AbstractControl) {
    const startDate =
      control['controls']['plan']['controls']['startDate'].value;
    const endDate = control['controls']['plan']['controls']['endDate'].value;
    if (startDate && endDate) {
      const sDate = new Date(
        startDate.year,
        startDate.month - 1,
        startDate.day
      );
      const eDate = new Date(endDate.year, endDate.month - 1, endDate.day);
      const startEpcohTime = Math.floor(sDate.getTime() / 1000.0);
      const eDateEpcohTime = Math.floor(eDate.getTime() / 1000.0);
      if (eDateEpcohTime <= startEpcohTime) {
        control['controls']['plan']['controls']['endDate'].setErrors({
          endDateShouldNotLessThanStartDate: true
        });
        // control['controls']['plan']['controls']['startDate'].setErrors({ endDateShouldNotLessThanStartDate: true });
      }
    }
  }
  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        if (control.status !== 'DISABLED') {
          control.markAsTouched({ onlySelf: true });
        }
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else if (control instanceof FormArray) {
        
        for (const control1 of control.controls) {
          if (control1 instanceof FormControl) {
            control1.markAsTouched({
              onlySelf: true
            });
          }
          if (control1 instanceof FormGroup) {
            this.validateAllFormFields(control1);
          }
        }
      }
    });
  }

  validateInnerFormFields(formGroup: FormGroup) {
    var control
    Object.keys(formGroup.controls).forEach(field => {
      control = formGroup.get(field);
      if (control instanceof FormControl) {
        if (control.status !== 'DISABLED') {
          control.markAsTouched({ onlySelf: true });
        }
      } else {
        this.validateAllFormFields(control);
      }
    });
  }

  getEpcohTImeFromExcelDataForStartOfDay(date) {
    if (date) {
      const dateArray = date.split('/');
      const myDate = new Date(dateArray[2], dateArray[1] - 1, dateArray[0], 0, 0, 0);
      return myDate.getTime() / 1000.0;
    } else {
      return new Date().getTime() / 1000.0; // default returning current epcoh time
    }
  }
  getEpcohTImeFromExcelDataForEndOfDay(date) {
    if (date) {
      const dateArray = date.split('/');
      const myDate = new Date(dateArray[2], dateArray[1] - 1, dateArray[0], 23, 59, 59);
      return myDate.getTime() / 1000.0;
    } else {
      return new Date().getTime() / 1000.0; // default returning current epcoh time
    }
  }
  deepCopyOfObject(data) {
    return JSON.parse(JSON.stringify(data));
  }

  passwordValidatorMatrialInput(control: AbstractControl) {
    const condition = control.get('password').value !== control.get('confirmPassword').value;
    return condition ? { NoPassswordMatch: true } : null;
  }

}
