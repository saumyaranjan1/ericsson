
import {
    ComponentFactoryResolver, ComponentRef, Directive, Input, OnInit,
    ViewContainerRef
} from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FieldConfig } from "../components/dynamic-form/field.interface";
import { InputComponent } from "../components/dynamic-form/input/input.component";
import { ButtonComponent } from "../components/dynamic-form/button/button.component";
import { SelectComponent } from "../components/dynamic-form/select/select.component";

@Directive({
    selector: '[dynamicField]'
})
export class DynamicFieldDirective {
    @Input() field: FieldConfig;
    @Input() group: FormGroup;
    @Input() configModalOptionMode : any;
    componentRef: any;
    componentMapper = {
        input: InputComponent,
        button: ButtonComponent,
        select: SelectComponent
    };
    constructor(
        private resolver: ComponentFactoryResolver,
        private container: ViewContainerRef) { }

    ngOnInit() {
        const factory = this.resolver.resolveComponentFactory(
            this.componentMapper[this.field.type]
        );
        this.componentRef = this.container.createComponent(factory);
        this.componentRef.instance.field = this.field;
        this.componentRef.instance.group = this.group;
        this.componentRef.instance.configModalOptionMode = this.configModalOptionMode;
    }
}