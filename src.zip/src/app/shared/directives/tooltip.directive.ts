import { AfterViewInit, Directive, ElementRef, EventEmitter, Output,ChangeDetectorRef } from '@angular/core';

@Directive({
  selector: '[appTooltip]'
})
export class TooltipDirective implements AfterViewInit {

  constructor(private elementRef: ElementRef,private cdr: ChangeDetectorRef) {}

  ngAfterViewInit(): void {
    setTimeout(() => {
      this.cdr.detectChanges();
      const element = this.elementRef.nativeElement;
      if(element.offsetWidth < element.scrollWidth){
        element.removeAttr('title');
       }
    }, 500);
  }

}
