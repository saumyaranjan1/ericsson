import { TestBed, ComponentFixture } from '@angular/core/testing';
import { AppPasswordDirective } from './app-password.directive';
import { By } from '@angular/platform-browser';
import { Directive, ElementRef } from '@angular/core';
import { Component, DebugElement } from '@angular/core';

@Component({
  template: `<input type="text" appAppPassword>`
})
class TestPasswordComponent {
}

describe('AppPasswordDirective', () => {

  let component: TestPasswordComponent;
  let fixture: ComponentFixture<TestPasswordComponent>;
  let inputEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
        declarations: [TestPasswordComponent, AppPasswordDirective]
    });
    fixture = TestBed.createComponent(TestPasswordComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input'));
  });

  it('should create an instance', () => {
    const directive = new AppPasswordDirective(inputEl);
    expect(directive).toBeTruthy();
  });

});
