import { TestBed, ComponentFixture } from '@angular/core/testing';
import { ClickOutsideDirective } from './click-outside.directive';
import { By } from '@angular/platform-browser';
import { Directive, ElementRef } from '@angular/core';
import { Component, DebugElement } from '@angular/core';

@Component({
  template: `<input type="text" appClickOutside>`
})
class TestPasswordComponent {
}
describe('ClickOutsideDirective', () => {

  let component: TestPasswordComponent;
  let fixture: ComponentFixture<TestPasswordComponent>;
  let inputEl: DebugElement;

  beforeEach(() => {
    TestBed.configureTestingModule({
        declarations: [TestPasswordComponent, ClickOutsideDirective]
    });
    fixture = TestBed.createComponent(TestPasswordComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input'));
  });

  it('should create an instance', () => {
    const directive = new ClickOutsideDirective(inputEl);
    expect(directive).toBeTruthy();
  });
});
