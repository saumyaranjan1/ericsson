import { Directive, ElementRef, Output, EventEmitter, HostListener } from '@angular/core';


@Directive({
  selector: '[appHidepopover]'
})
export class HidepopoverDirective {
  constructor(private elementRef: ElementRef) {
  }
  @HostListener('click', ['$event'])
  onClick() {
    this.elementRef.nativeElement.closest('.popover').remove();
  }
}
