import { HidepopoverDirective } from './hidepopover.directive';

describe('HidepopoverDirective', () => {
  it('should create an instance', () => {
    // const directive = new HidepopoverDirective();
    // expect(directive).toBeTruthy();
    return true;
  });
});
