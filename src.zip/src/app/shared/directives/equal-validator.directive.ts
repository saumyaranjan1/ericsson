import { Directive, forwardRef, Attribute } from '@angular/core';
import { Validator, AbstractControl, NG_VALIDATORS } from '@angular/forms';
@Directive({
    selector: '[appValidateEqual][formControlName],[appValidateEqual][formControl],[appValidateEqual][ngModel]',
    providers: [
        { provide: NG_VALIDATORS, useExisting: forwardRef(() => EqualValidatorDirective), multi: true }
    ]
})
export class EqualValidatorDirective implements Validator {
    constructor( @Attribute('appValidateEqual') public validateEqual: string, @Attribute('reverse') public reverse: string) {}

    private get isReverse() {
      if (!this.reverse) {
        return false;
      }
      return this.reverse === 'true' ? true : false;
    }

    validate(c: AbstractControl): { [key: string]: any } {
        // self value (e.g. retype password)
        const currentTargetValue = (c.value) ? c.value.toString() : '';

        // control value (e.g. password)
        const coompareTargetInput = c.root.get(this.validateEqual);

        const coompareTargetValue = (coompareTargetInput) ? coompareTargetInput.value.toString() : '';

        // value not equal
        if (coompareTargetInput && currentTargetValue !== coompareTargetValue && !this.isReverse) {
           return {
            validateEqual: false
          };
        }

        // value equal and reverse
        if (coompareTargetInput && currentTargetValue === coompareTargetValue && this.isReverse) {
          delete coompareTargetInput.errors['validateEqual'];
          if (!Object.keys(coompareTargetInput.errors).length) {
            coompareTargetInput.setErrors(null);
          }
        }

        // value not equal and reverse
        if (coompareTargetInput && currentTargetValue !== coompareTargetValue && this.isReverse) {
          coompareTargetInput.setErrors({ validateEqual: false });
        }

        return null;
    }
}
