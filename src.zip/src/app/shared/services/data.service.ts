
import {from as observableFrom,  Observable ,  Subject } from 'rxjs';
import { Injectable, EventEmitter } from '@angular/core';

@Injectable()
export class DataService {
  data = {};
  userData:any;
  events;
  listeners = {};
  constructor() {


    this.events = observableFrom(this.subject);
    this.events.subscribe(
      ({ name, args }) => {
        if (this.listeners[name]) {
          for (const listener of this.listeners[name]) {
            listener(...args);
          }
        }
      });
      //this.userData=this.userService.getUserData() || {};//creates circular dependency
      //this.userData=this.getUserData() || {};
  }

  private subject = new Subject<any>();


  on(name, listener) {
    if (!this.listeners[name]) {
      this.listeners[name] = [];
    }
    this.listeners[name].push(listener);
  }

  broadcast(name, ...args) {
    this.subject.next({
      name,
      args
    });
  }

  removeListener(arr) {
    for (const item of arr) {
      delete this.listeners[item];
    }
  }

  getData(key) {
    return this.data[key];
  };

  setData(key, value) {
    this.data[key] = value;
  };

  clearData() {
    this.data = {};
  }

  // setUserData(res){
  //   this.userData = res;
  //   this.setToStorage("userData",res);
  // }
  // getUserData(){
  //   return this.userData || this.getFromStorage("userData");
  // }
  // getLoggedUserName(){
  //   return this.userData.firstname + " " + this.userData.lastname;
  // }
  setToStorage(key,val){
    sessionStorage.setItem(key, JSON.stringify(val));
  }
  getFromStorage(key){
    let _res = sessionStorage.getItem(key);
    return JSON.parse(_res);
  }
  removeStorage(key) {
    sessionStorage.removeItem(key);
  }
  setLocalStorage(key, val) {
    sessionStorage.setItem(key, val);
  }
  setLocalStorageAsStringify(key, val) {
    sessionStorage.setItem(key, JSON.stringify(val));
  }
  setLocalStorageAsStringify1(key, val) {
    sessionStorage.setItem(key, JSON.stringify(val));
  }
  getLocalStorage(key) {
   return JSON.parse(sessionStorage.getItem(key));
  }
  setBtoaLocalStorage(key, val) {
    sessionStorage.setItem(key, btoa(JSON.stringify(val)));
  }
  getAtobLocalStorage(key) {
    let value;
    if(sessionStorage.getItem(key)) {
      value = JSON.parse(atob(sessionStorage.getItem(key)));
    } else {
      value  = null;
    }
    return value;
  }
  setBtoaLocalStorage1(key, val) {
    localStorage.setItem(key, btoa(JSON.stringify(val)));
  }
  getAtobLocalStorage1(key) {
    return JSON.parse(atob(localStorage.getItem(key)));
  }
  removeLocalStorage(key) {
    sessionStorage.removeItem(key);
  }
  getParseAndAtob(key) {
    return atob(JSON.parse(sessionStorage.getItem(key)));
  }
  getParse(key) {
    return JSON.parse(localStorage.getItem(key));
  }
  getParseFromSession(key) {

    let value;
    if(sessionStorage.getItem(key)) {
      value = JSON.parse(sessionStorage.getItem(key));
    } else {
      value  = null;
    }
    return value;

   // return JSON.parse(sessionStorage.getItem(key));
  }
  clearSession() {
    sessionStorage.clear();
  }
}
