import { Injectable } from '@angular/core';

@Injectable()
export class UtilService {

  constructor() { }

  encodeURL(url, data) {
    let encodedUrl = url;
    const keys = Object.keys(data);
    if (data && keys.length > 0) {
      encodedUrl = encodedUrl + '?' + keys.map(function (k) {
         /*if(Array.isArray(data[k])){
            data[k] = JSON.stringify(data[k]);
         }*/
        return encodeURIComponent(k) + '=' + data[k];
      }).join('&');
    }
    return encodedUrl;
  }
  
  appendDataToUrl(url, data) {
    let encodedUrl = url;
    const keys = Object.keys(data);
    if (data && keys.length > 0 && data['id'] && data['jobId']) {
      encodedUrl = encodedUrl + '?userServiceId=' + data['id'] + '&jobId=' + data['jobId']
    }
    return encodedUrl;
  }

  appendHqbpidAndPartnerId(url, data) {
    let encodedUrl = url;
    const keys = Object.keys(data);
    if (data && keys.length > 0 && data['hqBpId'] && data['partnerId']) {
      encodedUrl = encodedUrl + '/' + data['hqBpId'] + '/' + data['partnerId']
    }
    return encodedUrl;
  }
  appendRoleIdAndModuleCode(url, data) {
    let encodedUrl = url;
    const keys = Object.keys(data);
    if (data && keys.length > 0 && data['roleId'] && data['moduleCode']) {
      encodedUrl = encodedUrl + '/' + data['roleId'] + '/' + data['moduleCode']
    }
    return encodedUrl;
  }

  deepCopy(source) {
    return source.map(a => JSON.parse(JSON.stringify(a)));
  }

  deepCopyObject(source) {
    return JSON.parse(JSON.stringify(source));
  }

  getIndexInObjectArray(arr, key, val) {
    return arr.findIndex(item => item[key] == val);
  }
  encodeURLT2R(url, data) {
    let encodedUrl = url;
    if (data) {
      encodedUrl = encodedUrl + "/" + Object.keys(data).map(function (k) {
         /*if(Array.isArray(data[k])){
            data[k] = JSON.stringify(data[k]);
         }*/
        return data[k];
      }).join('/');
    }
    return encodedUrl;
  }
}
