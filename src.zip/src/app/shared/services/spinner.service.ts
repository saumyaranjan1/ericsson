import { filter } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import { DataService } from './data.service';
import {
  Router,
  NavigationEnd,
  NavigationStart,
  NavigationCancel,
  NavigationError
} from '@angular/router';

@Injectable()
export class SpinnerService {
  serviceCount = 0;
  constructor(private dataService: DataService, private router: Router) {
    this.router.events
      .pipe(filter(event => event instanceof NavigationStart))
      .subscribe((event: NavigationStart) => {
        if (event.url) {
          // this.toggleSpinner(1);
          this.toggleSpinner(0);
        }
      });

    this.router.events
      .pipe(filter(event => event instanceof NavigationEnd))
      .subscribe((event: NavigationEnd) => {
        if (event.url) {
          this.toggleSpinner(0);
        }
      });
    this.router.events
      .pipe(filter(event => event instanceof NavigationCancel))
      .subscribe((event: NavigationCancel) => {
        if (event.url) {
          this.toggleSpinner(0);
        }
      });
    this.router.events
      .pipe(filter(event => event instanceof NavigationError))
      .subscribe((event: NavigationError) => {
        if (event.url) {
          this.toggleSpinner(0);
        }
      });
  }

  toggleSpinner(spinnerFlag) {
    switch (spinnerFlag) {
      case 0:
        this.serviceCount -= 1;
        if (this.serviceCount <= 0) {
          this.serviceCount = 0;
          this.dataService.broadcast('spinner', false);
        }
        break;
      case 1:
        this.serviceCount += 1;
        this.dataService.broadcast('spinner', true);
        break;
      case 2:
        this.serviceCount = 1;
        this.dataService.broadcast('spinner', false);
        break;
    }
  }
}
