import { Injectable } from '@angular/core';

@Injectable()
export class EnumsService {
  public static MAXCHARS = 250;
  public static MAXIMEICHARS = 100;
  public static MAX_IDLE_SESSION_TIME = 1800; // 30 minutes in seconds
  public static MAX_SESSION_TIMEOUT_IN_MIN = 30; // 30 minutes
  public static IMEICHARS = 16;
  public static CUST_CONFIG = 'CFGJOB';
  public static ACTIVE = 'Active';
  public static USERMGMT = 'USRMGM';
  public static ROLEMGMT = 'ROLMGM';
  public static PROFILE = 'USRPFL';
  public static B2B_UI_API = 'B2B_UI_API';
  public static B2B_DEVICES = 'Devices';
  public static B2C_UI_API = 'B2C_UI_API';
  public static B2C_DEVICES = 'B2C_DEVICES';
  public static APP_UI_API = 'APP_UI_API';
  public static CLUSTER_UI_API = 'CLUSTER_UI_API';
  public static DOMAIN_DETAILS_UI_API = 'DOMAIN_DETAILS_UI_API';
  public static DOMAIN = 'Domain';
  public static PARTNER_UI_API = 'PARTNER_UI_API';
  public static TITLE_UI_API = "TITLE_UI_API";
  public static PLAN_APP_UI_API = "PLAN_APP_UI_API";
  public static PLAN_PROFILE_UI_API = "PLAN_PROFILE_UI_API";
  public static AUTOPS = 'AUTOPS';
  public static AUTOPS_APP = 'AUTOPS_APP';
  public static AUTOPS_CONFIG = 'AUTOPS_CONFIG';
  public static AUTOPS_FIRMWARE = 'AUTOPS_FIRMWARE';
  public static PSFIRM = 'PSFIRM';
  public static RBCONN = 'RBCONN';
  public static PSCONF = 'PSCONF';
  public static PSAPPS = 'PSAPPS';
  public static DEVCON = 'DEVCON';

  public static CAMPPS = 'CAMPPS';
  public static CAMPPS_APP = 'CAMPPS_APP';
  public static CAMPPS_CONFIG = 'CAMPPS_CONFIG';
  public static CAMPPS_FIRMWARE = 'CAMPPS_FIRMWARE';
  public static CAMPPS_AUTO_APP = 'CAMPPS_AUTO_APP';
  public static CAMPPS_AUTO_CONFIG = 'CAMPPS_AUTO_CONFIG';
  public static CAMPPS_AUTO_FIRMWARE = 'CAMPPS_AUTO_FIRMWARE';

  public static STRCFG = "STRCFG";
  public static ERROR_MESSAGE = 'Backend servers not responding. Please try again after some time.';

  // START :: Header actions for table 
  public static ADD = 'add';
  public static UPLOAD = 'upload';
  public static EDIT = 'edit';
  public static DELETE = 'delete';
  public static SEARCH = 'search';
  public static DROPDOWN = 'Dropdown';
  public static REFRESH_ENTERPRISE = 'RefreshEnterprises';
  public static REFRESH_DOMAIN = 'RefreshDomain';
  public static REFRESH_DEVICES = 'RefreshDevices';
  public static EXPORT_DEVICES = 'ExportDevices';
  public static JIO_IOT_APPLICATIONS = 'Jio IOT Applications';
  public static PLAN_APP_MAPPING = 'Plan App Mapping';

  // END :: Header actions for table

  public static ROLE_REJECT = {
    type: 'reject',
    title: 'Reject',
    showIconProp: 'showApproveIcon',
    disableIconProp: null,
    negate: true
  };
  public static CREATEROLECODE = 'CR';
  public static TYPE_APPROVE = 'approve';
  public static TYPE_REJECT = 'reject';
  public static CREATEUSERCODE = 'CU';
  public static ACTIONS = {
    ROLMGM: {
      JHRMCI: { type: 'add' },
      JHRMUI: { type: 'edit' },
      JHRMRI: { type: 'view' },
      JHRMCA: { type: 'approve' },
      JHRMAI1: { type: 'reject' },
      JHRMDI: { type: 'delete' },
      SR : {type: 'search'}
    },
    USRMGM: {
      JHUMCI: { type: 'add' },
      JHUMUI: { type: 'edit' },
      JHUMRI: { type: 'view' },
      JHUMAI: { type: 'approve' },
      JHUMAI1: { type: 'reject' },
      JHUMDI: { type: 'delete' },
      SU : {type: 'search'}
    },
    B2B_UI_API: {
      jnops_iot_admin_iso_enterprise_site_C: { type: 'add' },
      jnops_iot_admin_iso_enterprise_site_U: { type: 'edit' },
      jnops_iot_admin_iso_enterprise_site_R: { type: 'view' },
      jnops_iot_admin_iso_enterprise_site_D: { type: 'delete' },
      jnops_iot_admin_iso_enterprise_site_connection_C: { type: 'createDevice' },
      jnops_iot_admin_iso_enterprise_site_connections_C: { type: 'bulkupload' },
      jnops_iot_admin_getListofDevicesPagination_R: { type: 'getDeviceList' }
    },
    Devices: {
      jnops_iot_admin_iso_enterprise_site_connection_D: { type: 'delete' },
      jnops_iot_admin_iso_enterprise_site_connection_U: { type: 'edit' },
      jnops_iot_admin_getListofDevicesPagination_R: { type: 'view' },
      jnops_iot_admin_iso_enterprise_registerDeviceRequest_C: { type: 'activateOrDeActivate' }
    },
    B2C_UI_API: {
      jnops_iot_admin_iso_domain_customer_registration_C: { type: 'add' },
      jnops_iot_admin_iso_domain_customer_registration_U: { type: 'edit' },
      jnops_iot_admin_getTop10UserDetails_R: { type: 'view' },
      jnops_iot_admin_iso_domain_customer_registration_D: { type: 'delete' },
      jnops_iot_admin_iso_domain_customer_deviceregistration_C: { type: 'createDevice' },
      jnops_iot_admin_getListofDevicesPagination_R: { type: 'getDeviceList' }
    },
    B2C_DEVICES: {
      jnops_iot_admin_iso_domain_customer_deviceregistration_C: { type: 'edit' },
      jnops_iot_admin_getListofDevicesPagination_R: { type: 'view' },
      jnops_iot_admin_iso_enterprise_registerDeviceRequest_C:  { type: 'activateOrDeActivate' }
    },
    APP_UI_API: {
      jnops_iot_admin_appRegistration_C: { type: 'add' },
      jnops_iot_admin_updateApplication_U: { type: 'edit' },
      jnops_iot_admin_getApplications_R: { type: 'view' },
      jnops_iot_admin_deleteApplication_D: { type: 'delete' },
    },
    CLUSTER_UI_API: {
      jnops_iot_admin_setClusterDetails_C: { type: 'add' },
      jnops_iot_admin_updateClusterDetails_U: { type: 'edit' },
      jnops_iot_admin_getApplications_R: { type: 'view' },
      jnops_iot_admin_updateClusterDetails_D: { type: 'delete' },  
    },
    DOMAIN_DETAILS_UI_API: {
      jnops_iot_admin_config_createDomain_C: { type: 'add' },
      jnops_iot_admin_updateClusterDetails_U: { type: 'edit' },
      jnops_iot_admin_config_getDomainsList_R: { type: 'view' },
      jnops_iot_admin_config_deleteDomain_D: { type: 'delete' },  
    },
    PARTNER_UI_API: {
      jnops_iot_admin_addpartner_C: { type: 'add' },
      jnops_iot_admin_updatePartner_U: { type: 'edit' },
      jnops_iot_admin_getAllPartners_R: { type: 'view' },
      //jnops_iot_admin_deletePartner_D: { type: 'delete' },  
    },
    TITLE_UI_API : {
      jnops_iot_admin_onboardEntityNames_C: { type: 'add' },
      jnops_iot_admin_deleteTitleDetails_U: { type: 'edit' },
      jnops_iot_admin_getTitleDetails_R: { type: 'view' },
      jnops_iot_admin_deleteTitleDetails_D: { type: 'delete' }, 
    },
    PLAN_APP_UI_API : {
      jnops_iot_admin_planRegistration_C: { type: 'add' },
      jnops_iot_admin_updatePlan_U: { type: 'edit' },
      jnops_iot_admin_getApplications_R: { type: 'view' },
      jnops_iot_admin_deletePlan_D: { type: 'delete' }, 
    },
    PLAN_PROFILE_UI_API: {
      jnops_iot_admin_config_createPlanProfileInfo_C: { type: 'add' },
      jnops_iot_admin_config_updateProfiles_U: { type: 'edit' },
      jnops_iot_admin_config_getPlanProfileList_R: { type: 'view' },
      jnops_iot_admin_config_deletePlanProfileInfo_D: { type: 'delete' },
    },

    // public static CAMPPS = 'CAMPPS';
    // public static CAMPPS_APP = 'CAMPPS_APP';
    // public static CAMPPS_CONFIG = 'CAMPPS_CONFIG';
    // public static CAMPPS_FIRMWARE = 'CAMPPS_FIRMWARE';
//     APP CAMpaign

// 5: {code: "PSAPCI", description: "Create app provisioning service"}
// 6: {code: "PSAPUI", description: "Update app provisioning service"}
// 7: {code: "PSAPDI", description: "Delete app provisioning service"}
// 8: {code: "PSAPRI", description: "Read app provisioning service"}
// 9: {code: "PSAPPI", description: "partial update app provisioning service"}

// Config Camapaign
// 0: {code: "PSCOCI", description: "Create config provisioning service"}
// 1: {code: "PSCOUI", description: "Update config provisioning service"}
// 2: {code: "PSCODI", description: "Delete config provisioning service"}
// 3: {code: "PSCORI", description: "Read config provisioning service"}
// 4: {code: "PSCOPI", description: "partial update config provisioning service"}

// Firmware Campaign

// 10: {code: "FIRMCI", description: "Create firmware provisioning"}
// 11: {code: "FIRMUI", description: "Update firmware provisioning"}
// 12: {code: "FIRMDI", description: "Delete firmware provisioning"}
// 13: {code: "FIRMRI", description: "Read firmware provisioning"}
// 14: {code: "FIRMPI", description: "partial update firmware provisioning"}
    CAMPPS : {
      PSAPRI: { type: 'apRead'},
      PSCORI: { type: 'cpRead'},
      FIRMRI: { type: 'fpRead'}
    },
    CAMPPS_CONFIG : {
      PSCOCI: { type: 'adddevice' },
      PSCOUI: { type: 'stop' },
      PSCODI: { type: 'delete' },
    },
    CAMPPS_APP : {
      PSAPCI: { type: 'adddevice' },
      PSAPUI: { type: 'stop' },
      PSAPDI: { type: 'delete' },
    },
    CAMPPS_FIRMWARE : {
      FIRMCI: { type: 'adddevice' },
      FIRMUI: { type: 'stop' },
      FIRMDI: { type: 'delete' },
    },
    
    CAMPPS_AUTO_APP : {
      AUAPCI: { type: 'adddevice' },
      AUAPUI: { type: 'stop' },
      AUAPDI: { type: 'delete' },
    },CAMPPS_AUTO_CONFIG : {
      AUCOCI: { type: 'adddevice' },
      AUCOUI: { type: 'stop' },
      AUCODI: { type: 'delete' },
    },CAMPPS_AUTO_FIRMWARE : {
      FIRMCI: { type: 'adddevice' },
      FIRMUI: { type: 'stop' },
      FIRMDI: { type: 'delete' },
    },
    AUTOPS : {
      AUCORI: { type: 'apRead'},
      AUAPRI: { type: 'cpRead'},
      AUFMRI: { type: 'fpRead'}
    },
    AUTOPS_CONFIG : {
      AUCOCI: { type: 'add' },
      AUCOUI: { type: 'edit' },
      AUCORI: { type: 'redirecturl' },
      AUCODI: { type: 'delete' },
    },
//     {code: "AUCOCI", description: "Create config auto provisioning service"}
// 1: {code: "AUCOUI", description: "Update config auto provisioning service"}
// 2: {code: "AUCODI", description: "Delete config auto provisioning service"}
// 3: {code: "AUCORI", description: "Read config auto provisioning service"}
// 4: {code: "AUCOPI", description: "partial update config auto provisioning service"}

AUTOPS_APP : {
  AUAPCI: { type: 'add' },
  AUAPUI: { type: 'edit' },
  AUAPRI: { type: 'redirecturl' },
  AUAPDI: { type: 'delete' },
},
// 5: {code: "AUAPCI", description: "Create app auto provisioning service"}
// 6: {code: "AUAPUI", description: "Update app auto provisioning service"}
// 7: {code: "AUAPDI", description: "Delete app auto provisioning service"}
// 8: {code: "AUAPRI", description: "Read app auto provisioning service"}
// 9: {code: "AUAPPI", description: "partial update app auto provisioning service"}

AUTOPS_FIRMWARE : {
  AUFMCI: { type: 'add' },
  AUFMUI: { type: 'edit' },
  AUFMRI: { type: 'redirecturl' },
  AUFMDI: { type: 'delete' },
},

// 10: {code: "AUFMCI", description: "Create firmware auto provisioning"}
// 11: {code: "AUFMUI", description: "Update firmware auto provisioning"}
// 12: {code: "AUFMDI", description: "Delete firmware auto provisioning"}
// 13: {code: "AUFMRI", description: "Read firmware auto provisioning"}
// 14: {code: "AUFMPI", description: "partial update firmware auto provisioning"}
PSFIRM : {
  FIRMCI: { type: 'add' },
  FIRMUI: { type: 'edit' },
  FIRMRI: { type: 'view' },
  FIRMDI: { type: 'delete' },
  FIRMPI: { type: 'install'}
},
// 0: {code: "FIRMCI", description: "Create firmware provisioning"}
// 1: {code: "FIRMUI", description: "Update firmware provisioning"}
// 2: {code: "FIRMDI", description: "Delete firmware provisioning"}
// 3: {code: "FIRMRI", description: "Read firmware provisioning"}
// 4: {code: "FIRMPI", description: "partial update firmware provisioning"}
RBCONN : {
  RBCOCI: { type: 'add' },
  RBCOUI: { type: 'edit' },
  RBCORI: { type: 'view' },
  RBCODI: { type: 'delete' }
},
// 0: {code: "RBCOCI", description: "Create RB Connector"}
// 1: {code: "RBCOUI", description: "Update RB Connector"}
// 2: {code: "RBCODI", description: "Delete RB Connector"}
// 3: {code: "RBCORI", description: "Read RB Connector"}
// 4: {code: "RBCOPI", description: "partial update RB Connector"}
PSCONF: {
  PSCOCI: { type: 'add' },
  PSCOUI: { type: 'edit' },
  PSCORI: { type: 'view' },
  PSCOPI: { type: 'install' },
  PSCODI: { type: 'delete' }
},
// 0: {code: "PSCOCI", description: "Create config provisioning service"}
// 1: {code: "PSCOUI", description: "Update config provisioning service"}
// 2: {code: "PSCODI", description: "Delete config provisioning service"}
// 3: {code: "PSCORI", description: "Read config provisioning service"}
// 4: {code: "PSCOPI", description: "partial update config provisioning service"}
PSAPPS: {
  PSAPCI: { type: 'add' },
  PSAPUI: { type: 'edit' },
  PSAPRI: { type: 'view' },
  PSAPPI: { type: 'install' },
  PSAPDI: { type: 'delete' }
},
// 0: {code: "PSAPCI", description: "Create app provisioning service"}
// 1: {code: "PSAPUI", description: "Update app provisioning service"}
// 2: {code: "PSAPDI", description: "Delete app provisioning service"}
// 3: {code: "PSAPRI", description: "Read app provisioning service"}
// 4: {code: "PSAPPI", description: "partial update app provisioning service"}
DEVCON : {
  DEVCCI: { type: 'upload'} 
},
// 0: {code: "DEVCCI", description: "Create Device Config"}
// 1: {code: "DEVCUI", description: "Update Device Config"}
// 2: {code: "DEVCDI", description: "Delete Device Config"}
// 3: {code: "DEVCRI", description: "Read Device Config"}
// 4: {code: "DEVCPI", description: "partial update Device Config"}
    STRCFG: {
      JDSFUI: { type: 'edit' },
    },
    Domain: {
      CD: { type: 'add' },
      ED: { type: 'edit' },
      VD: { type: 'view' },
      DELD: { type: 'delete' },
      CED: { type: 'createDevice' },
      GDL: { type: 'getDeviceList' },
      SD: { type: 'search' },
      DRD: { type: 'Dropdown' },
      RFD: { type: 'RefreshDomain' }
    },
    'B2C-Devices' : {
      DELD: { type: 'delete' },
      ED: { type: 'edit' },
      CSD: { type: 'activateOrDeActivate' },
      SD: { type: 'search' },
      DRD: { type: 'Dropdown' },
      RFD: { type: 'RefreshDevices' },
      EXPD : { type : 'ExportDevices'}
    },
    Partner: {
      CP: { type: 'add' },
      EP: { type: 'edit' },
      DELP: { type: 'delete' },
      SP : {type: 'search'}
    },
    CFGJOB: {
      JDCJRI: { type: 'view' },
      JDCJUI: { type: 'edit' },
    },
    'Jio IOT Applications' : {
      CA: { type: 'add' },
      EA: { type: 'edit' },
      DELA: { type: 'delete' },
      SA : {type: 'search'},
      VA : {type: 'view'}
    },
    'Plan App Mapping' : {
      CPA: { type: 'add' },
      EPA: { type: 'edit' },
      DELPA: { type: 'delete' },
      SPA : {type: 'search'},
      VPA : {type: 'view'}
    }
  };
  public static PASSWORD_REG_EXP = new RegExp(
    `^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})`
  );
  public static PASSWORD_ERROR = `A password must be eight characters including one uppercase letter,
                                  one special character and alphanumeric characters`;
  public static PASSWORD_NOT_MATCHED =
    'Confirm password not matched with new password';
  public static EMPTY_CSV_FILE =
    'File is empty, please upload proper csv file!';
  public static NOT_CSV_FILE = 'Please try with only CSV file!';
  public static paginationObj = {
    recordsPerPage: 10,
    defaultPage: 1
  };
  public static ERROR = {
    IMEI : 'IMEI minimum required numbers is 15 and max number is 16.',
    NUMBER: 'Please enter only numbers!',
    DEFAULT_VALUES : 'Please fill the input field accroding to the selection!',
    IMEI_PLMID : 'Please select either IMEI or PLMID',
    PLMID : 'PLMID should be only alpha numaric !',
    PLMID_LENGTH: 'PLMID should not be more than 17 characters !'
  };
  public static DEVICE_STRINGS = {
    HEADER : 'Get device information  based on IMEI or PLMID',
    DROPDOWN_DEFAULT : 'Please Choose Either IMEI / PLMID'
  };
  public static moduleWithUri = [
    { name: 'Enterprise (B2B)', uri: 'enterprise-b2b', project: 'jnops' },
    { name: 'Domain (B2C)', uri: 'b2c_ui_api', project: 'jnops' },
    { name: 'Partner', uri: 'partner', project: 'jnops' },
    { name: 'Jio IOT Applications', uri: 'application', project: 'jnops' },
    { name: 'Plan', uri: 'plan', project: '' },
    { name: 'Plan App Mapping', uri: 'plan-app-mapping', project: 'jnops' },
    { name: 'Job Details', uri: 'job-details', project: 'jnops' },
    {
      name: 'Plan Profile Mapping',
      uri: 'plan-profile-mapping',
      project: 'jnops'
    },
    { name: 'Device Details', uri: 'device-details', project: 'jnops' },
    { name: 'User Management', uri: 'user-management', project: 'jnops' },
    { name: 'Diagnosis', uri: 'diagnosis', project: 'jnops' },
    { name: 'Role Management', uri: 'role-management', project: 'jnops' },
    { name: 'Domain Details', uri: 'domain-details', project: 'jnops' },
  ];
  public static MULTI_SELECT_DROPDOWN_OPTIONS = {
    singleSelection: false,
    text: '',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableSearchFilter: true,
    classes: '',
    maxHeight: 150,
    disabled: false,
    escapeToClose: true
    // lazyLoading: true
  };
  public static SINGLE_SELECT_DROPDOWN_OPTIONS = {
    singleSelection: true,
    text: 'Please Select',
    enableSearchFilter: true,
    classes: 'no-check-box',
    maxHeight: 150,
    disabled: false,
    escapeToClose: true
    // lazyLoading: true
  };
  public static privilege = [
    {"moduleCode":"Enterprise",
    "moduleName":"B2B",
    "isWebRole":"Y",
    "status":"Y",
    "privilege":[
      {"code":"jnops_iot_admin_iso_enterprise_site_C",
      "description":"Add Enterprise",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"jnops_iot_admin_iso_enterprise_site_D",
      "description":"Delete Enterprise",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"jnops_iot_admin_iso_enterprise_site_U",
      "description":"Edit Enterprise",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"jnops_iot_admin_iso_enterprise_site_R",
      "description":"View Enterprise",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"jnops_iot_admin_iso_enterprise_site_connection_C",
      "description":"Create Device",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"jnops_iot_admin_iso_enterprise_site_connections_C",
      "description":"Bulk Upload Devices",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"DED",
      "description":"Get Device List",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"SE",
      "description":"Search",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"DRE",
      "description":"DropDown",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"RFE",
      "description":"Refresh Enterprise",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"}
    ]},
    {"moduleCode":"Devices",
    "moduleName":"Devices",
    "isWebRole":"Y",
    "status":"Y",
    "privilege":[
      {"code":"DELD",
      "description":"Delete Device",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"ED",
      "description":"Edit Device",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"VD",
      "description":"View Device",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"CSD",
      "description":"Change Device Status",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"RFD",
      "description":"Refresh Devices",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"},
      {"code":"EXPD",
      "description":"Export Devices",
      "category":["SUPER_ADMIN","ADMIN","CONTRIBUTOR","VISITOR"],
      "uri":"/role",
      "method":"GET",
      "status":"Y"}
    ]}
  ];
  public static previlages = [
    {
      title: 'Enterprise',
      uri: 'enterprise-b2b',
      dataEvents: [
        {
          id: 9331,
          code: 'CE',
          description: 'Add Enterprise',
          check: true
        },
        {
          id: 9333,
          code: 'DELE',
          description: 'Delete Enterprise',
          check: true
        },
        {
          id: 9334,
          code: 'EE',
          description: 'Edit Enterprise',
          check: true
        },
        {
          id: 9335,
          code: 'VE',
          description: 'View Enterprise',
          check: true
        },
        {
          id: 9340,
          code: 'CED',
          description: 'Create Device',
          check: true
        },
        {
          id: 9341,
          code: 'BUED',
          description: 'Bulk Upload Devices',
          check: true
        },
        {
          id: 9343,
          code: 'DED',
          description: 'Get Device List',
          check: true
        },
        {
          id: 9354,
          code: 'SE',
          description: 'Search',
          check: true
        },
        {
          id: 9354,
          code: 'DRE',
          description: 'DropDown',
          check: true
        },
        {
          id: 9356,
          code: 'RFE',
          description: 'Refresh Enterprise',
          check: true
        }
      ]
    },
    {
      title: 'Domain',
      uri: 'b2c_ui_api',
      dataEvents: [
        {
          id: 9331,
          code: 'CD',
          description: 'Add Domain',
          check: true
        },
        {
          id: 9333,
          code: 'DELD',
          description: 'Delete Domain',
          check: true
        },
        {
          id: 9334,
          code: 'ED',
          description: 'Edit Domain',
          check: true
        },
        {
          id: 9335,
          code: 'VD',
          description: 'View Domain',
          check: true
        },
        {
          id: 9340,
          code: 'CED',
          description: 'Create Device',
          check: true
        },
        {
          id: 9343,
          code: 'GDL',
          description: 'Get Device List',
          check: true
        },
        {
          id: 9354,
          code: 'SD',
          description: 'Search',
          check: true
        },
        {
          id: 9354,
          code: 'DRD',
          description: 'DropDown',
          check: true
        },
        {
          id: 9356,
          code: 'RFD',
          description: 'Refresh Domain',
          check: true
        }
      ]
    },
    {
      module: 'DomainDetails',
      uri: 'domain-details'
    },
    {
      title: 'Device-Details',
      uri: 'device-details',
      roles: ['ADMIN', 'Vendor', 'RedBend', 'JioAdmin']
    },
    {
      title: 'Devices',
      uri: 'devices',
      dataEvents: [
        {
          id: 9333,
          code: 'DELD',
          description: 'Delete Device',
          check: true
        },
        {
          id: 9334,
          code: 'ED',
          description: 'Edit Device',
          check: true
        },
        {
          id: 9334,
          code: 'VD',
          description: 'View Device',
          check: true
        },
        {
          id: 9341,
          code: 'CSD',
          description: 'Change Device Status',
          check: true
        },
        {
          id: 9354,
          code: 'SD',
          description: 'Search',
          check: false
        },
        {
          id: 9354,
          code: 'DRD',
          description: 'DropDown',
          check: false
        },
        {
          id: 9356,
          code: 'RFD',
          description: 'Refresh Devices',
          check: true
        },
        {
          id: 123,
          code : 'EXPD',
          description : 'Export Devices',
          check: true
        }
      ]
    },
    {
      title: 'B2C-Devices',
      uri: 'b2c-devices',
      dataEvents: [
        {
          id: 9333,
          code: 'DELD',
          description: 'Delete Device',
          check: false
        },
        {
          id: 9334,
          code: 'ED',
          description: 'Edit Device',
          check: true
        },
        {
          id: 9341,
          code: 'CSD',
          description: 'Change Device Status',
          check: true
        },
        {
          id: 9354,
          code: 'SD',
          description: 'Search',
          check: false
        },
        {
          id: 9354,
          code: 'DRD',
          description: 'DropDown',
          check: false
        },
        {
          id: 9356,
          code: 'RFD',
          description: 'Refresh Devices',
          check: true
        },
        {
          id: 123,
          code : 'EXPD',
          description : 'Export Devices',
          check: false
        }
      ]
    },
    {
      title: 'Partner',
      uri: 'partner',
      dataEvents: [
        {
          code: 'CP',
          description: 'Add Partner',
          check: true
        },
        {
          code: 'EP',
          description: 'Edit Partner',
          check: true
        },
        {
          code: 'DELP',
          description: 'Delete Partner',
          check: true
        },
        {
          code: 'SP',
          description: 'Search Partner',
          check: true
        }
      ]
    },
    {
      title: 'Jio IOT Applications',
      uri: 'application',
      dataEvents: [
        {
          code: 'CA',
          description: 'Create Application',
          check: true
        },
        {
          code: 'EA',
          description: 'Edit Application',
          check: true
        },
        {
          code: 'DELA',
          description: 'Delete Application',
          check: true
        },
        {
          code: 'SA',
          description: 'Search Application',
          check: true
        },
        {
          code: 'VA',
          description: 'View Application',
          check: true
        }
      ]
    },
    {
      title: 'Plan',
      uri: 'plan',
      roles: ['ADMIN', 'Vendor', 'RedBend', 'JioAdmin']
    },
    {
      title: 'Plan App Mapping',
      uri: 'plan-app-mapping',
      dataEvents: [
        {
          code: 'CPA',
          description: 'Create Application',
          check: true
        },
        {
          code: 'EPA',
          description: 'Edit Application',
          check: true
        },
        {
          code: 'DELPA',
          description: 'Delete Application',
          check: true
        },
        {
          code: 'SPA',
          description: 'Search Application',
          check: true
        },
        {
          code: 'VPA',
          description: 'View Application',
          check: true
        }
      ]
    },
    {
      title: 'Job Details',
      uri: 'job-details',
      roles: ['ADMIN', 'Vendor', 'RedBend', 'JioAdmin']
    },
    {
      title: 'Plan Profile Mapping',
      uri: 'plan-profile-mapping',
      roles: ['ADMIN', 'Vendor', 'RedBend', 'JioAdmin']
    },
    {
      module: 'Diagnosis',
      uri: 'diagnosis',
      roles: ['ADMIN', 'Vendor', 'RedBend', 'JioAdmin']
    },
  ];
  public static deviceCsvHeaders =
    'PARTNER ID, IMEI, DEVICE STATUS, BPID, RSN, CATEGORY, ACTIVE STATUS,REQUEST ORIGIN,SVC,EID,VERSION, BAND, MSISDN,IMSI,DEVICE ID,ENTERPRISE ID,PLAN CODE, PLAN DESCRIPTION,PLAN NAME,PLAN STARTDATE,PLAN ENDDATE\n';
  public static deviceCsvHeadersvone =
    'PARTNER ID, IMEI, DEVICE STATUS, BPID, RSN,ACTIVE STATUS,REQUEST ORIGIN,EID,BAND, MSISDN,IMSI,DEVICE ID,ENTERPRISE ID,PLAN CODE, PLAN DESCRIPTION,PLAN NAME,PLAN STARTDATE,PLAN ENDDATE,VEHICLE MAKE,VEHICLE MODEL,YEAR OF MANUFACTURING ,VEHICLE REGISTRATION NUMBER,VEHICLE FUELTYPE\n';
  public static deviceCsvHeadersForMachineInfo =
    'PARTNER ID, IMEI, DEVICE STATUS, BPID, RSN, CATEGORY, ACTIVE STATUS,REQUEST ORIGIN,SVC,EID,VERSION, BAND, MSISDN,IMSI,DEVICE ID,ENTERPRISE ID,PLAN CODE, PLAN DESCRIPTION,PLAN NAME,PLAN STARTDATE,PLAN ENDDATE,VEHICLE FUELTYPE,VEHICLE MAKE ,VEHICLE MODEL,VEHICLE REGISTRATION NUMBER,YEAR OF MANUFACTURING\n';

  
    public static IOT_USER_ONBOARD = {
      STREAM_GROUP_ERROR: 'The requested services are in progress. You can only be add/delete/modify after the requested services are activated.',
      STREAM_GROUP_ERROR_NOTACTIVE: 'The requested services are in progress. You can only be add/delete/modify after the requested services are activated.',
      STREAM_GROUP_SUBMIT_ERROR: 'The streams can only be add/delete/modify after activation of the already requested services.',
      MAX_STREMS : 'You are allowed to add only 3 new streams in single request.',
      FORM_ERROR: 'There are some errors in the form. Please correct it :)',
      VALID_JSON: 'Push Login Request should be a valid JSON format !!. Please correct it :)',
      EMPTY_JSON: 'Push Login Request should not be empty json. Please correct it :)',
      ATLEAST_ONE_STREAM: 'Atleast One stream group should be present to intiate the request',
      DELETE_SUBMITED_STREAM: 'Saved stream can’t be deleted'
  };
  constructor() {}
}
