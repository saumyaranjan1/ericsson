import { Injectable } from '@angular/core';

@Injectable()
export class UrlMappingsService {
  endUrls;
  constructor() {

    this.endUrls = {
      //login: '/oauth/token', 
      publicLogin: '/auth-engine/web/v2.0/login/public',
      privateLogin: '/auth-engine-ead/web/v2.0/login/ead',
      logout: '/oauth/token/logout',
      changePortalPassword: '/auth-engine/web/change-portal-password',
      changePlatformPassword: '/auth-engine/web/change-platform-password',
      changePassword: '/auth-engine/web/changePassword',
      forgotPasswordPublic: '/auth-engine/web/forgotPassword',
      forgotPasswordPrivate: '/auth-engine-ead/web/forgotPassword',
      submitConsumerData: '/data-consumer-automation/web/consumer-account',
      getConsumerData: '/data-consumer-automation/web/consumer-account',
      getConsumerDatabypages: '/data-consumer-automation/web/consumer-account/all',
      getConsumerDataFormLogin: '/data-consumer-automation/web/consumer-account/auth',
      getInstallerDetails: '/jioutils/iot/config/installerTypes',
      forgotPlatformPasswordprivate: '/auth-engine-ead/web/forgotPassword',
      forgotPlatformPasswordpublic: '/auth-engine/web/forgotPassword',
      //Software management or Applications

      createApp: '/psweb/app-provisioning/v1.0/app-associations',
      getPlatforms: '/psweb/app-provisioning/v1.0/platforms',
      updateSoftwareByVersion: '/psweb/app-provisioning/v1.0/app-versions',
      uploadFileDetails: '/psweb/app-provisioning/v1.0/apps',
      deleteSoftware: '/psweb/app-provisioning/v1.0/apps',
      deleteSoftwareVersion: '/psweb/app-provisioning/v1.0/app-versions',
      getDevices: '/iot/t2r-provisioning/v2/devices',
      getAppDetails: '/psweb/app-provisioning/v1.0/app-details',
      getAllPackagesList: '/psweb/app-provisioning/v1.0/apps',
      installPackage: '/psweb/app-provisioning/v1.0/campaigns',
      defaultTimeZones: '/psweb/app-provisioning/v1.0/campaign-defaultParams',
      getAllPackages: '/psweb/app-provisioning/v1.0/app-details',
      setAppplicationStatus: '/psweb/app-provisioning/v1.0/app-version-status',

      //getAllPackagesList: '/psweb/v1/provision/packages/filter',
      //getAllPackagesList: '/psweb/app-provisioning/v1.0/apps',
      ///app-provisioning/v1.0/campaigns
      //getDevices: '/psweb/v1/provision/devices',
      //createApp: '/psweb/v1/provision/packages',
      //updateSoftwareByVersion: '/psweb/v1/provision/packages/versions',
      //deleteSoftware: '/psweb/v1/provision/packages',
      //uploadFileDetails: '/psweb/v1/provision/packages',
      //getPlatforms: '/psweb/v1/provision/platforms?softwareType=SCOTA',
      //getAllPackages: '/psweb/v1/provision/packages',   
      //installPackage: '/psweb/v1/provision/installPackage',
      //defaultTimeZones: '/psweb/v1/provision/campaigns/defaultParams',

      populateOtherDetails: '/psweb/v1/provision/packages',

      getModalsData: '/psweb/app-provisioning/v1.0/models',
      getPackageDetails: '/psweb/v1/provision/packages',

      getViewData: '/psweb/v1/provision/packages',
      getTasks: '/jioutils/iot/config/tasks',
      getUserPrivileges: '/role-manager/web/role/user',
      getUserMenus: '/role-manager/web/role/user-menus',
      getUserMainMenus: '/role-manager/web/role/user-main-menus',
      getPreviliages: '/role-manager/web/role/module-privilege',
      getSoftwareTotalCountEnterprises: '/iot/admin/getTotalCountEnterprises',
      getSoftwateEnterpriseList: '/iot/admin/getListofEnterprisesPagination',
      getEnterpriseSearchName: '/iot/admin/getEnterpriseByField',

      //Campaign Details
      getCampaignDetails: '/psweb/app-provisioning/v1.0/campaigns',
      getCampaignConfigDetails: '/psweb/config-provisioning/v1.0/campaigns',
      getCampaignAppAutoProvisioningDetails: '/psweb/app-auto-provisioning/v1.0/install-campaigns',
      getConfigAutoProvisioning: '/psweb/config-auto-provisioning/v1.0/install-campaigns',
      getFirmwarAutoCampaign: '/psweb/firmware-auto-provisioning/v1.0/install-campaigns',
      getFirmwarenConfigDetails: '/psweb/firmware-provisioning/v1.0/campaigns',
      getCampaignInfo: '/psweb/app-provisioning/v1.0/campaigns-details-operations',
      getAppAutoCampaignInfo: '/psweb/app-provisioning/v1.0/campaigns-details-operations',
      getConfigCampaignInfo: '/psweb/config-provisioning/v1.0/campaigns-details-operations',
      getFirmwareCampaignInfo: '/psweb/firmware-provisioning/v1.0/campaigns-details-operations',
      deleteCampign: '/psweb/app-provisioning/v1.0/campaigns',
      deleteConfigCampign: '/psweb/config-provisioning/v1.0/campaigns',
      executeConfigCampign: '/psweb/config-provisioning/v1.0/activate-campaigns',
      deleteFirmwareCampign: '/psweb/firmware-provisioning/v1.0/campaigns',
      executeFirmwareCampign: '/psweb/firmware-provisioning/v1.0/activate-campaigns',
      deleteAutoAppPushCampign: '/psweb/app-provisioning/v1.0/campaigns',
      executeAutoAppPushCampign: '/psweb/app-provisioning/v1.0/activate-campaigns',
      deleteAutoConfigPushCampign: '/psweb/config-provisioning/v1.0/campaigns',
      executeAutoConfigPushCampign: '/psweb/config-provisioning/v1.0/activate-campaigns',
      deleteAutoFirmwarePushCampign: '/psweb/firmware-provisioning/v1.0/campaigns',
      executeAutoFirmwarePushCampign: '/psweb/firmware-provisioning/v1.0/activate-campaigns',
      executeCampign: '/psweb/app-provisioning/v1.0/activate-campaigns',
      stopCampign: '/psweb/app-provisioning/v1.0/stop-campaigns',
      stopConfigCampign: '/psweb/config-provisioning/v1.0/stop-campaigns',
      stopFirmwareCampign: '/psweb/firmware-provisioning/v1.0/stop-campaigns',
      stopAutoAppCampaignData: '/psweb/app-provisioning/v1.0/stop-campaigns',
      stopAutoConfigCampaignData: '/psweb/config-provisioning/v1.0/stop-campaigns',
      stopAutoFirmwareCampaignData: '/psweb/firmware-provisioning/v1.0/stop-campaigns',
      restartCampign: '/psweb/app-provisioning/v1.0/rerun-campaigns',
      restartFirmwareCampign: '/psweb/firmware-provisioning/v1.0/rerun-campaigns',
      restartAppAutoCampign: '/psweb/app-provisioning/v1.0/rerun-campaigns',
      restartConfigAutoCampaignData: '/psweb/config-provisioning/v1.0/rerun-campaigns',
      restartFirmwareAutoCampaignData: '/psweb/firmware-provisioning/v1.0/rerun-campaigns',
      restartConfigCampign: '/psweb/config-provisioning/v1.0/rerun-campaigns',
      getCampaignProvisioningDetails: '/psweb/app-auto-provisioning/v1.0/campaigns',
      uploadDeviceFileDetails: '/psweb/app-provisioning/v1.0/update-campaign',
      uploadFirmwareDeviceFileDetails: '/psweb/firmware-provisioning/v1.0/campaigns',
      uploadConfigDeviceFileDetails: '/psweb/config-provisioning/v1.0/update-campaign',
      uploadAppAutoDeviceFileDetails: '/psweb/app-provisioning/v1.0/campaigns',
      uploadIsFormwareAutoDeviceFileDetails: '/psweb/firmware-provisioning/v1.0/campaigns',
      uploadConfigAutoDeviceFileDetails: '/psweb/Config-provisioning/v1.0/campaigns',
      //configDetails
      getConfigDetails: '/psweb/config-provisioning/v1.0/config-profiles',
      getDeviceSettings: '/psweb/config-provisioning/v1.0/device-settings',
      getDeviceSetting: '/psweb/config-provisioning/v1.0/device-settings-details',
      getSpecificProfile: '/psweb/config-provisioning/v1.0/config-profiles-details',
      createConfigProfile: '/psweb/config-provisioning/v1.0/config-profiles',
      deleteProfile: '/psweb/config-provisioning/v1.0/config-profiles',
      updateConfigProfile: '/psweb/config-provisioning/v1.0/config-profiles',
      getConfigDevices: '/iot/t2r-provisioning/v2/devices',
      getConfigTotalCountEnterprises: '/iot/admin/getTotalCountEnterprises',
      getConfigEnterpriseList: '/iot/admin/getListofEnterprisesPagination',
      defaultConfigTimeZones: '/psweb/config-provisioning/v1.0/campaign-defaultParams',
      createProfiles: '/psweb/v1/provision/profiles',
      getConfigEnterpriseSearchName: '/iot/admin/getEnterpriseByField',

      //old api
      //getDeviceSettings: '/psweb/config-provisioning/v1.0/config-profiles',  
      //getDeviceSetting: '/psweb/config-provisioning/v1.0/config-profiles',  
      // getSpecificProfile: '/psweb/v1/provision/profiles',

      // Partner Details
      getPartnerIds: '/iot/admin/getAllPartners',
      getPartnerDetails: '/iot/admin/getAllPartnersDetails',
      addPartner: '/iot/admin/addpartner',
      updatePartner: '/iot/admin/updatePartner',
      deletePartner: '/iot/admin/deletePartner/',
      getPartnerIdsVersionTwo: '/iot/admin/iso/v2/enterprise/onboarded/partners/info',
      getPartnerByName:'/iot/admin/partnerByName',
      // Application
      getApplications: '/iot/admin/getApplications',
      createApplication: '/iot/admin/appRegistration',
      updateApplication: '/iot/admin/updateApplication',
      deleteApplication: '/iot/admin/deleteApplication',

      // jobDetails
      jobList: '/iot/admin/iso/enterprise/site/connections/joblist',
      v2JobList: '/iot/admin/iso/v2/enterprise/site/connections/joblist',
      jobState: '/iot/admin/iso/enterprise/site/connections/jobstate/',
      v2JobState: '/iot/admin/iso/v2/enterprise/site/connections/jobstate/',
      jobdetails: '/iot/admin/iso/enterprise/site/connections/jobdetails',
      v2Jobdetails: '/iot/admin/iso/v2/enterprise/site/connections/jobdetails',
      deleteJob: '/iot/admin/iso/enterprise/site/connections/job/',
      v2DeleteJob: '/iot/admin/iso/v2/enterprise/site/connections/job/',

      // Plan Mapping with Profile
      getPlanProfileList: '/iot/admin/config/getPlanProfileList',
      createPlanProfileInfo: '/iot/admin/config/createPlanProfileInfo',
      updateProfile: '/iot/admin/config/updateProfiles',
      getProfileList: '/iot/admin/config/getProfileList',
      profilesByDomain: '/iot/admin/config/profilesByDomain',
      deletePlanAndprofileMap: '/iot/admin/config/deletePlanProfileInfo/',
      getDomainsList: '/iot/admin/config/getDomainsList',
      loadDomains: '/iot/admin/config/loadDomains',
      loadProfileListByDomain: '/iot/admin/config/loadProfileList',
      installProfilePackage: '/psweb/config-provisioning/v1.0/campaigns',

      // Domain details
      createDomain: '/iot/admin/config/createDomain',
      deleteDomain: '/iot/admin/config/deleteDomain/',
      serviceLoginStatus: '/iot/admin/config/isServiceIdLogin',

      // Role mapping related
      getRoleListUpdated:
        '/role-manager/web/role/createdByUser',
      addRole: '/role-manager/web/role',
      updateRole: '/role-manager/web/role',
      updateRoleDraft: '/role-manager/web/role/draft',
      getRole: '/role-manager/web/role',
      getRoles: '/role-manager/web/role/by-category',
      approveOrReject: '/role-manager/web/role',
      updateStatus: '/role-manager/web/role/status',
      getRoleList: '/rolemanager/all',
      verifyIsExistInMakerTable: '/role-manager/web/role/draft',
      //  getRoleMasterData: jioUtils.RoleMgmtPort + '/masterdata/configByCode',
      getRoleMasterData:
        '/role-manager/web/role/master/privilege',
      getUpdateData: '/role-manager/web/role/privilege',
      getMakerValues: '/role-manager/web/role/draft/privilege',
      getApprovedRoles: `/role-manager/web/role/by-status?status=AP, DA`,
      getPendingRoles: `/role-manager/web/role/draft/by-status?status=CI, UI, DI`,
      getDraftsRoles: `/role-manager/web/role/draft/by-status?status=CD, UD, UR, CR, DR`,

      // User Management
      category: '/user-management/web/category',
      //  getUserList: jioUtils.UserMgmtPort + '/user-management/web/account/transaction/TS',
      getUserList: '/user-management/web/account/active',
      getPendingUserList:
        '/user-management/web/account/transaction/TI',
      addUser: '/user-management/web/account',
      editUser: '/user-management/web/updateuser',
      domain: '/user-management/web/account/domain',
      managers: '/user-management/web/account/domain/all',
      getUserDataByUserName: '/user-management/web/account/domain',

      // TASK details (automation)
      getTaskDetails: '/data-consumer-automation/web/consumer-account-job/all',
      changeTaskStatus: '/data-consumer-automation/web/consumer-account-job/status',
      // notify: jioUtils.UserMgmtPort + '/user-management/web/account/notify'
      getInternalJobDetails: '/data-consumer-automation/web/consumerAccount?portalType=INTERNAL',

      // Enterprise b2bx
      b2bCreateEnterprise: '/iot/admin/iso/enterprise/site',
      b2bSearchiseVtwo: '/iot/admin/iso/v2/enterprise/site',
      mapSvcWithHqbpidPartnerId: '/iot/admin/mapSvcWithHqbpidPartnerId',
      getSvcWithPartnerId: '/iot/admin/getSvcWithPartnerId',
      svcExistOrNot: '/iot/admin/validateSvc',
      getDeviceListForReConcile:  '/iot/admin/getListofDevicesPagination',
      getDeviceCountForReConcile: '/iot/admin/getTotalCountDevices',
      updateSingleCoDevice :'/iot/admin/codevices',
      //need change              
      b2bCreateEnterpriseVtwo: '/iot/admin/iso/v2/enterprise/site',

      b2bCreateDeviceVtwo: '/iot/admin/iso/v2/enterprise/site/connection',

      deleteEnterpise: '/iot/admin/iso/enterprise/site',
      getEnterpriseList: '/iot/admin/getListofEnterprisesPagination',
      getTotalCountEnterprises: '/iot/admin/getTotalCountEnterprises',
      deleteEnterpiseVtwo: '/iot/admin/iso/v2/enterprise/site',
      addOrDeleteprovision: '/iot/admin/iso/v2/enterprise/provision',

      // Devices
      getDeviceList: '/iot/admin/getListofDevicesPagination',
      getTotalCountDevices: '/iot/admin/getTotalCountDevices',
      createUpdateDeleteDevice: '/iot/admin/iso/enterprise/site/connection',
      changeDeviceStatus: '/iot/admin/iso/enterprise/registerDeviceRequest',
      createUpdateDeleteDeviceVtwo: '/iot/admin/iso/v2/enterprise/site/connection',
      getDeviceListById: '/iot/admin/iso/v2/enterprise/site/connection/ui',
      getTransationId:'/iot/admin/reconcilation-status',

      // Device info
      deviceInfo: '/iot/admin/getDevice',
      getDeviceProgressCount:'/iot/admin/codevices',

      // Bulk Upload devices
      uploadDevices: '/iot/admin/iso/enterprise/site/connections',
      v2UploadDevices: '/iot/admin/iso/v2/enterprise/site/connections',
      v2UploadDeleteDevices: '/iot/admin/iso/v2/enterprise/site/connections',

      // Plan mapping with App
      planMapRegistration: '/iot/admin/planRegistration',
      getPlanMappingDetails: '/iot/admin/getPlans',
      deletePlanMap: '/iot/admin/deletePlan',
      updatePlanMap: '/iot/admin/updatePlan',

      // Plan
      createPlan: '/jioUtils/iot/admin/uploadPlanConfigs',
      updatePlan: '/jioUtils/iot/admin/updatePlanConfig',
      deletePlan: '/jioUtils/iot/admin/deletePlanConfig',
      getPlanDetails: '/jioUtils/iot/admin/getPlanConfigs',

      //diagnosis
      getDeviceStatus: '/iot/device/admin/devicestatus',
      getT2RDetails: '/data-consumer-automation/web/t2r',

      // b2c
      domainB2c: '/iot/admin/iso/domain/customer/registration',
      domainB2cList: '/iot/admin/getUserDetails',
      deviceB2c: '/iot/admin/iso/domain/customer/deviceregistration',
      deviceB2cUpdate: '/iot/admin/iso/domain/customer/registration',
      getTopTenUserDetails: '/iot/admin/getTop10UserDetails',

      // b2c device
      domainB2cDeviceList: '/iot/admin/getListofDevicesPagination',
      addLabelDetails: '/iot/admin/onboardTitles',
      saveDetails: '/iot/admin/updateTitleDetails',
      getLabelManagementTitleDetails: '/iot/admin/getTitlesDetail',
      getTitleDetailsTotal: '/iot/admin/getTitlesDetail/count',
      getLabelManagementCountOfTitleDetails: '/iot/admin/getTitlesDetail/count',
      getDistinctTitleValue: '/iot/admin/getDistinctTitlevalues',
      getDetails: '/iot/admin/getTitleDetails',
      deleteTitle: '/iot/admin/deleteTitleDetails',
      deleteEntityName: '/iot/admin/deleteEntityName',
      getLabelManagementDistinctEntityName: '/iot/admin/getDistinctEntityNames',
      onboardEntityNames: '/iot/admin/onboardEntityNames',

      //label management

      searchByFieldValue: '/iot/admin/searchByFieldValue',


      //cluster
      getClusterDetailsTotal: '/iot/admin/getClustersDetail/count',
      getClustersDetail: '/iot/admin/getClustersDetail',
      saveData: '/iot/admin/setClusterDetails',
      updateData: '/iot/admin/updateClusterDetails',
      deleteData: '/iot/admin/deleteClusterDetails',
      searchUrl:'/iot/admin/searchClusterDetailsByFieldValue',
      //  // JIO Iot Data Explorer

      //  getRefDidData:'/refportal/v1/pull/eventsByDid',
      //  getRefSVCData:'/refportal/v1/pull/eventsBySvc',
      //  getEventsdetail:'/refportal/v1/pull/eventDetails',

      //Rule Group
      getRuleGroup: '/psweb/app-auto-provisioning/v1.0/rule-groups',
      getConfigPushRuleGroup: '/psweb/config-auto-provisioning/v1.0/rule-groups',
      getFirmWareRuleGroup: '/psweb/firmware-auto-provisioning/v1.0/rule-groups',

      getPurposeData: '/psweb/app-auto-provisioning/v1.0/rule-groups/purpose',
      getConfigPurposeData: '/psweb/config-auto-provisioning/v1.0/rule-groups/purpose',
      getFirmwarePurposeData: '/psweb/firmware-auto-provisioning/v1.0/rule-groups/purpose',
      getEnterPriseIds: '/psweb/v1/provision/jicds/enterpriseIds',

      createRuleGroup: '/psweb/app-auto-provisioning/v1.0/rule-groups',
      deleteRuleGroup: '/psweb/app-auto-provisioning/v1.0/rule-groups',
      updateRuleGroup: '/psweb/app-auto-provisioning/v1.0/rule-groups',

      createConfigRuleGroup: '/psweb/config-auto-provisioning/v1.0/rule-groups',
      deleteConfigRuleGroup: '/psweb/config-auto-provisioning/v1.0/rule-groups',
      updateConfigRuleGroup: '/psweb/config-auto-provisioning/v1.0/rule-groups',

      createFirmwareRuleGroup: '/psweb/firmware-auto-provisioning/v1.0/rule-groups',
      deleteFirmwareRuleGroup: '/psweb/firmware-auto-provisioning/v1.0/rule-groups',
      updateFirmwareRuleGroup: '/psweb/firmware-auto-provisioning/v1.0/rule-groups',

      getRuleGroupTotalCountEnterprises: '/iot/admin/getTotalCountEnterprises',
      getRuleGroupEnterpriseList: '/iot/admin/getListofEnterprisesPagination',
      getRuleEngineEnterpriseSearchName: '/iot/admin/getEnterpriseByField',

      //Rule Engine : 
      getRuleEngineList: '/psweb/app-auto-provisioning/v1.0/rules-in-group',
      getFirmwareRuleEngineList: '/psweb/firmware-auto-provisioning/v1.0/rules-in-group',
      getProfileRuleEngineList: '/psweb/config-auto-provisioning/v1.0/rules-in-group',
      getProfileName: '/psweb/config-provisioning/v1.0/config-profiles',
      getApplicationName: '/psweb/app-provisioning/v1.0/apps',
      getKeyRuleDropdown: '/iot/admin/getDistinctEntityNames',
      getValueRuleDropdown: '/iot/admin/getDistinctTitlevalues',
      createRuleEngine: '/psweb/app-auto-provisioning/v1.0/rules-in-group',
      createProfileRuleEngine: '/psweb/config-auto-provisioning/v1.0/rules-in-group',
      createFirmwareRuleEngine: '/psweb/firmware-auto-provisioning/v1.0/rules-in-group',
      getRuleEnginegTotalCountEnterprises: '/iot/admin/getTotalCountEnterprises',
      getRuleEngineEnterpriseList: '/iot/admin/getListofEnterprisesPagination',
      getPartnerByHqbpId: '/iot/admin/getPartnersByHqbpid',
      getRuleCreateEnterpriseSearchName: '/iot/admin/getEnterpriseByField',
      updateRuleEngine: '/psweb/app-auto-provisioning/v1.0/rules-in-group',
      updateProfileRuleEngine: '/psweb/config-auto-provisioning/v1.0/rules-in-group',
      updateFirmwareRuleEngine: '/psweb/firmware-auto-provisioning/v1.0/rules-in-group',

      deleteRuleEngine: '/psweb/app-auto-provisioning/v1.0/rules-in-group',
      deleteProfileRuleEngine: '/psweb/config-auto-provisioning/v1.0/rules-in-group',
      deleteFirmwareRuleEngine: '/psweb/firmware-auto-provisioning/v1.0/rules-in-group',
      statusChangeRuleEngine: '/psweb/app-auto-provisioning/v1.0/rules-in-group',
      statusChangeProfileRuleEngine: '/psweb/config-auto-provisioning/v1.0/rules-in-group',
      statusChangeFirmwareRuleEngine: '/psweb/firmware-auto-provisioning/v1.0/rules-in-group',

      getFirmwareName: '/psweb/firmware-provisioning/v1.0/firmware-details',

      //phase 0
      getDirectPartnerInfo: '/iot/admin/iso/enterprise/site',
      getpartnerInfo: '/device-end-point/web/consumerAccount/getAllPartnersDetailsByPartnerId',
      createDirectEnterpriseInfo: '/device-end-point/web/consumerAccount/attachDCEndPoint',
      updateDirectPartner: '/device-end-point/web/consumerAccount/updatePartner',
      // JIO Iot Data Explorer

      getRefDidData: '/refportal/v1/pull/pagination/events',
      getRefSVCData: '/refportal/v1/pull/pagination/events',
      getEventsdetail: '/refportal/v1/pull/eventDetails',

      //Failure management API 
      // getrecordbyFilters : '/jioutils/iot/admin/getFailedRecordByFilters',
      // retryBycorelationId : '/jioutils/iot/admin/retrySelectedRecords',
      // retryByFilter:   '/jioutils/iot/admin/retryRecordByFilters',
      // getDistinctValuesOfField: '/jioutils/iot/admin/getDistinctValuesOfField',
      // getTotalCount: '/jioutils/iot/admin/getTotalCountOfFatalRecords'

      getrecordbyFilters: '/iot/admin/fms/getFailedRecordByFilters',
      retryBycorelationId: '/iot/admin/fms/retrySelectedRecords',
      retryByFilter: '/iot/admin/fms/retryRecordByFilters',
      getDistinctValuesOfField: '/iot/admin/fms/getDistinctValuesOfField',
      getTotalCount: '/iot/admin/fms/getTotalCountOfFatalRecords',

      //Firmware : 
      getfirmwareTotalCountEnterprises: '/iot/admin/getTotalCountEnterprises',
      getFirmwareEnterpriseList: '/iot/admin/getListofEnterprisesPagination',
      getAllFirmwareList: '/psweb/firmware-provisioning/v1.0/firmware-details',
      getFirmwarePlatforms: '/psweb/firmware-provisioning/v1.0/platforms?softwareType=FOTA',
      getFirmwareDeviceVendor: '/web/v1/provision/devicevendor',
      getFirmwareDeviceModal: '/psweb/firmware-provisioning/v1.0/models',
      updateFileFirmwareVersion: '/psweb/firmware-provisioning/v1.0/firmware-versions',
      populateFirmwareVersion: '/web/v1/provision/firmware',
      createFirmware: '/psweb/firmware-provisioning/v1.0/firmwares',
      defaultFirmwareTimeZones: '/psweb/firmware-provisioning/v1.0/campaign-defaultParams',
      installFirmwarePackage: '/psweb/firmware-provisioning/v1.0/install-campaigns?action=install',
      getFirmwareDevices: '/iot/t2r-provisioning/v2/devices',
      deleteFirmware: '/psweb/firmware-provisioning/v1.0/firmwares',
      deleteFirmwareVersion: '/psweb/firmware-provisioning/v1.0/firmware-versions',
      updateNewVersionData: '/psweb/v1/provision/updatefirmware',
      getFirmwareByID: '/psweb/firmware-provisioning/v1.0/firmware-versions',
      getFirmwareByIDVersion: '/psweb/firmware-provisioning/v1.0/firmware-details',
      getFirmwareByVersion: '/psweb/firmware-provisioning/v1.0/firmware-versions',
      updateVersionFirmware: '/psweb/firmware-provisioning/v1.0/firmware-versions',
      getFirmwareEnterpriseSearchName: '/iot/admin/getEnterpriseByField',

      //Header
      getDomainInfo: '/psweb/rb-connector/v1.0/login-profiles',

      //Tac Code 
      getTacCodeDetail: '/deviceconfig/v1/policies/tac',
      getTacCodeViewData: '/tac/data',
      uploadTacFile: '/deviceconfig/v1/policies/tac',
      getHistoryData: '/tac/log',
      getTacDownloadFile: '/tac/download',
      getTacCodeErrorData: '/tac/error',

      //Model DM Domain
      getModelDmDomainDetail: '/psweb/device-data/v1.0/rb/onboarding-profiles',
      getModelDmDomainViewData: '/psweb/device-data/v1.0/rb/onboarding-profiles',
      uploadModelDmDomainFile: '/psweb/device-data/v1.0/rb/onboarding-profiles',
      getModelDmDomainHistoryData: '/psweb/device-data/v1.0/rb/onboarding-profiles-history',
      getModelDmDomainDownloadFile: '/psweb/device-data/v1.0/rb/download-onboarding-profiles',
      getModelDmDomainErrorData: '/psweb/device-data/v1.0/rb/onboarding-profiles-error',

      //Domain
      getDomainDetail: '/psweb/rb-connector/v1.0/login-profiles',
      createDomainForm: '/psweb/rb-connector/v1.0/login-profiles',
      updateDomainForm: '/psweb/rb-connector/v1.0/login-profiles',
      deleteDomainManagement: '/psweb/rb-connector/v1.0/login-profiles',
      validateDomain: '/psweb/rb-connector/v1.0/validate-login-profiles',

      //Device Onboarding Status
      getDeviceOnboardingstatus: '/psweb/rb-onboarding/v1.0/status',
      getDeviceEventOnboardingstatus: '/psweb/rb-onboarding/v1.0/events',

      // Strem Configuration Information (Partner admin and Admin)
      getStreamInfo: '/data-consumer-automation/web/stream-consumers',

      //Action Profile:
      getActionProfile: '/psweb/v1.0/actions-profiles',
      getUrlList: '/psweb/v1.0/getUrlList',
      addActionProfile: '/psweb/v1.0/actions-profiles',
      deleteActionProfile: '/psweb/v1.0/actions-profiles',
      updateActionProfile: '/psweb/v1.0/actions-profiles',

      //user management abac
      getProfileUserList: '/jioutils/v1.0/user-profiles',
      saveProfileUserList: '/psweb/urlmgmt/v1.0/userProfiles',
      deleteProfileUserList: '/psweb/urlmgmt/v1.0/userProfiles',
      enterpriseList: '/iot/admin/getListofEnterprisesPagination',
      getUserActionProfile: '/jioutils/v1.0/actions-profiles',
      getManagerList: '/user-management/web/account/domain/all',
      createProfileUserList: '/psweb/urlmgmt/v1.0/userProfiles',

      //connection only
      svcWithPartnerIdco: '/iot/admin/getSvcWithPartnerId',
      uploadCoDevice: '/iot/admin/codevices',
      getCoDevice: '/iot/admin/codevices',
      updateCoDevice: '/iot/admin/codevices',

      //Role Category
      createRoleCategory: '/psweb/urlmgmt/v1.0/roleCategory',
      updateRoleCategory: '/psweb/urlmgmt/v1.0/roleCategory',
      deleteRoleCategory: '/psweb/urlmgmt/v1.0/roleCategory',
      getRoleCategoryData: '/psweb/urlmgmt/v1.0/roleCategories',

      //User Profile Management
      ///getUserProfileData: '/psweb/urlmgmt/v1.0/users/levels',
      getUserProfileData: '/psweb/urlmgmt/v1.0/userProfiles/filter',
      getSearchUserProfileData: '/psweb/urlmgmt/v1.0/userProfiles/filter',
      getUserManagementEnterpriseSearchName: '/iot/admin/getEnterpriseByField',
      getUserManagementTotalCountEnterprises: '/iot/admin/getTotalCountEnterprises',
      getUserManagementEnterpriseList: '/iot/admin/getListofEnterprisesPagination',
      getUserManagementDeviceList: '/iot/admin/getListofDevicesPagination',
      getRoleCategory: '/psweb/urlmgmt/v1.0/roleCategories',
      getUserCategory: '/psweb/urlmgmt/v1.0/groups/categories',
      getUserProfileByID : '/psweb/urlmgmt/v1.0/userProfiles',

      //role management ABAC
      addHeaderRole: '/psweb/urlmgmt/v1.0/groups',
      updateHeaderRole: '/psweb/urlmgmt/v1.0/groups',
      getHeaderGroups: '/psweb/urlmgmt/v1.0/groups',
      addGroupChildHeader: '/psweb/urlmgmt/v1.0/group/modules',
      getChildModule: '/psweb/urlmgmt/v1.0/group/modules',
      getRoleCategories: '/psweb/urlmgmt/v1.0/roleCategories',
      addUrlChild: '/psweb/urlmgmt/v1.0/privileges',
      updateUrlChild :'/psweb/urlmgmt/v1.0/privileges',
      getChildGridList: '/psweb/urlmgmt/v1.0/module',
      deleteModuleList:'/psweb/urlmgmt/v1.0/modules',
      deleteGroupList:'/psweb/urlmgmt/v1.0/groups',
      deletePriviledgeList:'/psweb/urlmgmt/v1.0/privileges',
      setDefaultPriviledgeList : '/psweb/urlmgmt/v1.0/privileges',
      getGroupPrivileg:'/psweb/urlmgmt/v1.0/group',
      updateModuleHeaderRole:'/psweb/urlmgmt/v1.0/group/modules',
      addGroupSubChildHeader : '/psweb/urlmgmt/v1.0/module/subModule',
    };
  }
  getEndUrl(endurl) {
    return this.endUrls[endurl];
  }
}
