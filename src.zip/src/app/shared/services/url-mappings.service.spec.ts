import { TestBed, inject } from '@angular/core/testing';

import { UrlMappingsService } from './url-mappings.service';

describe('UrlMappingsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UrlMappingsService]
    });
  });

  it('should be created', inject([UrlMappingsService], (service: UrlMappingsService) => {
    expect(service).toBeTruthy();
  }));
});
