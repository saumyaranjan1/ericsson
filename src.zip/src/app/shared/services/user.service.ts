import { Injectable } from '@angular/core';
import { DataService } from './data.service';
import { EnumsService } from './enums.service';
import { InterceptorService } from './interceptor.service';
@Injectable()
export class UserService {
  userData: any;
  accessData: any;
  privilege: any;
  userPrivilege: any;
  constructor(private dataService: DataService, private interceptor: InterceptorService) {}

  setUserData(res) {
    this.userData = res;
    this.dataService.setToStorage('userData', res);
  }
  username() {
    return atob(JSON.parse(sessionStorage.getItem('loginMember')));
  }
  getUserData() {
    return this.userData || this.dataService.getFromStorage('userData');
  }
  getLoggedUserName() {
    return this.getUserData() ? this.getUserData().access_token : '';
  }
  setAccessData(res) {
    this.accessData = res;
    this.dataService.setToStorage('accessData', res);
    this.dataService.setLocalStorageAsStringify('accessData', res);
  }
  getAccessData() {
    return this.accessData || this.dataService.getFromStorage('accessData');
  }
  getUserPrivilege() {
    return this.getAccessData() ? this.getAccessData().previlageAccess : '';
  }
  getAccessDataFromLocalStorage() {
    //  return this.accessData || this.dataService.getLocalStorage('accessData');
    return this.dataService.getAtobLocalStorage('previlages');
  }
  getUserPrivilegeFromLocalStorage() {
    return this.getAccessDataFromLocalStorage()
      ? this.getAccessDataFromLocalStorage()
      : '';
  }
  getModulePermission(action, privileges) {
    this.userPrivilege = this.getUserPrivilegeFromLocalStorage();
    if (this.userPrivilege) {
      this.privilege = privileges;
      if (this.privilege.length) {
        let actionsArray = this.privilege.map(o => {
          if (typeof action[o.code] !== 'undefined') {
            return {
              type: action[o.code].type,
              title: o.description,
              showIconProp: null,
              disableIconProp: true,
              negate: null
            };
          }
        });
        actionsArray = actionsArray.filter((element) => {
          return element !== undefined;
        });
        const editArray = actionsArray.filter((obj) => {
          return obj.type === EnumsService.EDIT;
        });
        const deleteArray = actionsArray.filter((obj) => {
          return obj.type === EnumsService.DELETE;
        });
        const addArray = actionsArray.filter((obj) => {
          return obj.type === EnumsService.ADD;
        });
        const uploadArray = actionsArray.filter((obj) => {
          return obj.type === EnumsService.UPLOAD;
        });
        const searchArray = actionsArray.filter((obj) => {
          return obj.type === EnumsService.SEARCH;
        });
        const dropDownArray = actionsArray.filter((obj) => {
          return obj.type === EnumsService.DROPDOWN;
        });
        const refreshArray = actionsArray.filter((obj) => {
          return obj.type === EnumsService.REFRESH_DOMAIN ||
                obj.type === EnumsService.REFRESH_ENTERPRISE ||
                obj.type === EnumsService.REFRESH_DEVICES;
        });
        const exportDevicesArray = actionsArray.filter((obj) => {
          return obj.type === EnumsService.EXPORT_DEVICES;
        });

        if(addArray.length > 0 || editArray.length > 0){
          actionsArray.push( {
            type: 'save',
            title: 'Save',
            showIconProp: null,
            disableIconProp: true,
            negate: null
          },
          {
            type: 'times',
            title: 'Cancel',
            showIconProp: null,
            disableIconProp: true,
            negate: null}
          )
        }
      


        const json = {
          actionsArray,
          headerRights: {
            add: addArray.length > 0 ? addArray[0].disableIconProp : false,
            search: true,
            // search: searchArray.length > 0 ? searchArray[0].disableIconProp : false,
            dropDown: dropDownArray.length > 0 ? dropDownArray[0].disableIconProp : false,
            searchActiom: dropDownArray.length > 0 ? dropDownArray[0].disableIconProp : false,
            refreshData: refreshArray.length > 0 ? refreshArray[0].disableIconProp : false,
            edit: editArray.length > 0 ? editArray[0].disableIconProp : false,
            delete: deleteArray.length > 0 ? deleteArray[0].disableIconProp : false,
            deleteAction: deleteArray.length > 0 ? deleteArray[0].disableIconProp : false,
            exportToCsv: exportDevicesArray.length > 0 ? exportDevicesArray[0].disableIconProp : false,
            upload: uploadArray.length > 0 ? uploadArray[0].disableIconProp : false
          }
        };
        return json;
      }
    }
    const _json = {
      actionsArray: '',
      addRights: false,
      search: false,
      dropDown: false,
      searchActiom: false,
      refreshData: false,
      edit: false,
      exportToCsv: false,
      deleteAction: false,
      delete: false,
      add:false,
      upload: false
    };
    return _json;
  }
  getPreViliages(request) {
    request['extraParams'] =  "?roleId="+request.roleId+"&moduleCode="+request.moduleCode;
    delete request.roleId;
    delete request.moduleCode;
    delete request.previliages;
    return this.interceptor.httpCall('get', 'getPreviliages', request);
   }
}
