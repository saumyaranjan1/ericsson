import { throwError as observableThrowError, Observable } from 'rxjs';

import { map, catchError } from 'rxjs/operators';
import { Injectable } from '@angular/core';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';

import { AppConfigService } from './../../app-config.service';
import { DataService } from './data.service';
import { UtilService } from './util.service';
import { SpinnerService } from './spinner.service';
import { UrlMappingsService } from './url-mappings.service';
import { AuthorizationService } from '../authGuard/authorization.service';
import { EnumsService } from './enums.service';

@Injectable()
export class InterceptorService {
  options;
  login;
  counter = 0;
  donotShowError = false;
  checkFlag;
  staticErrorMessage = EnumsService.ERROR_MESSAGE;
  constructor(
    private http: HttpClient,
    private appConfig: AppConfigService,
    private dataService: DataService,
    private utilService: UtilService,
    private spinnerService: SpinnerService,
    private UrlMap: UrlMappingsService,
    private authorizationService: AuthorizationService
  ) { }

  httpPromise(type, endUrl, data?, isLogin = false, formData = false) {
    let serverUrl = this.appConfig.configData['getBaseUrl'];
    let setHttpHeader = '';


    if (data && data.responseType) {
      setHttpHeader = data.responseType;
      delete data.responseType;
    }
    this.spinnerService.toggleSpinner(1);
    let url = serverUrl + this.UrlMap.getEndUrl(endUrl);
    const int = setInterval(() => {
      this.counter += 1;
      if (this.counter >= 1) {
        if (this.checkFlag !== true) {
          //this.spinnerService.toggleSpinner(1);
          this.counter = 0;
        } else {
          clearInterval(int);
          this.spinnerService.toggleSpinner(0);
        }
      }

    }, 1000);


    this.setHttpHeader({ isLogin, formData, url: endUrl, responseType: setHttpHeader });
    this.login = isLogin;
    switch (type) {
      case 'post':
        this.donotShowError = true;
        return this.http
          .post(url, data, this.options)
          .toPromise()
          .then(this.dataHandler)
          .catch(this.errorHandler);
      case 'get':
        if (data) {
          if (data.donotShowError) {
            this.donotShowError = data.donotShowError;
          } else {
            this.donotShowError = false;
          }
          if (data.appendUserId) {
            url = url + '/' + data.userId;
            // delete data.appendUserId;
            // delete data.jioUtils;
          }

          if (data.extraParams) {
            url = url + data.extraParams;
            delete data.extraParams;
          }

          url = this.utilService.encodeURL(url, data);
        }
        return this.http
          .get(url, this.options)
          .toPromise()
          .then(this.dataHandler)
          .catch(this.errorHandler);
      case 'put':
        this.donotShowError = true;
        if (data.user) {
          if (data.user.queryParam && data.user.bodyParams) {
            delete data.user.queryParam;
            delete data.user.bodyParams;
            url = this.utilService.appendDataToUrl(url, data.user.queryParamData);
            data = data.user.bodyParamsData;
          } else if (data.user.queryParam && !data.user.bodyParams) {
            delete data.user.queryParam;
            const req = { roleId: data.user.roleId };
            url = this.utilService.encodeURL(url, req);
            data = data.user;
          } else {
            url = url + '/' + data.user.userName;
            data = data.user;
          }
        }
        return this.http
          .put(url, data, this.options)
          .toPromise()
          .then(this.dataHandler)
          .catch(this.errorHandler);
      case 'patch':
        this.donotShowError = true;
        if (data.id) {
          url = url + '?roleId=' + data.id;
        }
        return this.http
          .patch(url, data, this.options)
          .toPromise()
          .then(this.dataHandler)
          .catch(this.errorHandler);
    }
  }
  httpCall(
    type,
    endUrl,
    data?,
    isLogin = false,
    formData = false
  ): Observable<any> {
    this.donotShowError = false;
    let serverUrl = this.appConfig.configData['getBaseUrl'];
    let setHttpHeader = '';

    // if (data && data.type === 'config') {
    //   serverUrl = this.appConfig.getConfigBaseUrl();
    //   delete data.type;
    // }

    if (data && data.responseType) {
      setHttpHeader = data.responseType;
      delete data.responseType;
    }
    let url = serverUrl + this.UrlMap.getEndUrl(endUrl);

    //remove when deploy
    // if (endUrl == 'addHeaderRole' || endUrl == 'addGroupSubChildHeader' || endUrl == 'updateModuleHeaderRole' || endUrl == 'getGroupPrivileg' || endUrl == 'updateUrlChild' || endUrl == 'setDefaultPriviledgeList' || endUrl == 'updateHeaderRole' || endUrl == 'getHeaderGroups' || endUrl == 'deleteProfileUserList' || endUrl == 'addGroupChildHeader' || endUrl == 'getChildModule' || endUrl == 'getRoleCategories' || endUrl == 'addUrlChild' || endUrl == 'getChildGridList') {
    //   serverUrl = 'http://10.162.4.78:49302/jioutils/urlmgmt';
    //   url = serverUrl + this.UrlMap.getEndUrl(endUrl);
    // }
    // if (endUrl == 'getUserProfileData' || endUrl =='getUserProfileByID' || endUrl == 'createProfileUserList' || endUrl == 'saveProfileUserList') {
    //   serverUrl = 'http://10.162.4.78:49316';
    //   url = serverUrl + this.UrlMap.getEndUrl(endUrl);
    // }
    // if(endUrl == 'createRoleCategory'  || endUrl == 'updateRoleCategory' || endUrl == 'deleteRoleCategory' || endUrl == 'getRoleCategoryData'){
    //   serverUrl = 'http://10.162.4.78:49316';
    //   url = serverUrl + this.UrlMap.getEndUrl(endUrl);
    // }


    if(data && data.noSpiner){
      this.spinnerService.toggleSpinner(0);
    }else{
      this.spinnerService.toggleSpinner(1);

    }

    // const int = setInterval(() => {
    //   this.counter += 1;
    //   if (this.counter >= 1) {
    //     if (this.checkFlag !== true) {
    //       //this.spinnerService.toggleSpinner(1);
    //       this.counter = 0;
    //     } else {
    //       this.spinnerService.toggleSpinner(0);
    //       clearInterval(int);
    //     }
    //   }
    // }, 1000);

    this.setHttpHeader({ isLogin, formData, url: endUrl, responseType: setHttpHeader });
    this.login = isLogin;
    switch (type) {
      case 'post':
        if (data && data.extraParams) {
          url = url + '/' + data.extraParams;
          delete data.extraParams;
        }

        if (data && data.extraQueryParams) {
          url = url + data.extraQueryParams;
          delete data.extraQueryParams;
        }

        if (data.bodyParams) {
          if (data.queryParam && data.bodyParams) {
            url = this.utilService.encodeURL(url, data.queryParam);
            data = data.bodyParams ? data.bodyParams : {};
          }
        } else {
          if (data && data.queryParam) {
            url = this.utilService.encodeURL(url, data);
          }
        }
        return this.http.post(url, data, this.options).pipe(
          map(this.dataHandler),
          catchError(this.errorHandler)
        );
      case 'put':

        if (data.user) {
          if (data.user.queryParam && data.user.bodyParams) {
            delete data.user.queryParam;
            delete data.user.bodyParams;
            url = this.utilService.appendDataToUrl(url, data.user.queryParamData);
            data = data.user.bodyParamsData;
          } else if (data.user.queryParam && !data.user.bodyParams) {
            delete data.user.queryParam;
            const req = { roleId: data.user.roleId };
            url = this.utilService.encodeURL(url, req);
            data = data.user;
          } else {
            url = url + "?userName="+data.user.userName;
            data = data.user;
          }
        }
        if (data.isPathVariable) {
          url = url + '/' + data.pathVariables.loginId;
          delete data.pathVariables;
          delete data.jioUtils;
          delete data.isPathVariable;
        }
        if (data && data.extraParams) {
          url = url + data.extraParams;
          delete data.extraParams;
        }


        if (data && data.queryParam) {
          if (data.queryParamData) {
            url = this.utilService.encodeURL(url, data.queryParamData);
          } else {
            url = this.utilService.encodeURL(url, data.queryParam);
          }
          delete data.queryParam;
          delete data.queryParamData;
        }

        if (data && data.pathParams) {
          url = this.utilService.appendHqbpidAndPartnerId(url, data);
        }

        return this.http.put(url, data, this.options).pipe(
          map(this.dataHandler),
          catchError(this.errorHandler)
        );
      case 'patch':
        if (data.id) {
          url = url + '?roleId=' + data.id;
        }
        if (data && data.extraParams) {
          url = url + data.extraParams;
          delete data.extraParams;
        }
        return this.http.patch(url, data, this.options).pipe(
          map(this.dataHandler),
          catchError(this.errorHandler)
        );
      case 'get':
        if (data) {
          if (data.donotShowError) {
            this.donotShowError = true;
          }
          delete data.jioUtils;
          if (data.appendUserId) {
            delete data.appendUserId;
            url = url + '/' + data.userId;
          }
          if (data && data.extraParams) {
            url = url + data.extraParams;
            delete data.extraParams;
          }
          if (data && data.pathParams) {
            url = this.utilService.appendHqbpidAndPartnerId(url, data);
          }
          if (data && data.previliages) {
            url = this.utilService.appendRoleIdAndModuleCode(url, data);
          }
          if (data.appendHqBpIdAndPartnerId) {
            delete data.appendHqBpIdAndPartnerId;
            delete data.jioUtils;
            url = url + '/' + data.partnerId + '/' + data.hqBpId;
          }
           url = this.utilService.encodeURL(url, data);
        }
        
        return this.http.get(url, this.options).pipe(
          map(this.dataHandler),
          catchError(this.errorHandler)
        );
      case 'delete':

        if (data.isdelete) {
          return this.http.delete(url, data.data).pipe(
            map(this.dataHandler),
            catchError(this.errorHandler)
          );
        } else {
          let extraParams = '';
          if (data && data.extraParams) {
            extraParams = data.extraParams;
            delete data.extraParams;
          }
          if (data.user) {
            if (data.user.queryParam) {
              delete data.user.queryParam;
              url = this.utilService.encodeURL(url, data.user);
            } else if (extraParams) {
              url = url + '/' + data.user.userName + extraParams;
            } else {
              url = url + '/' + data.user.userName;
            }
          } else if (data && data.type && data.type === 'multidelete') {
            url = url;
          } else {
            url = url + data;
          }

          if (data && data.type && data.type === 'multidelete') {
            delete data.type;
            this.options.body = data;
            delete data.type;
            return this.http.delete(url, this.options).pipe(
              map(this.dataHandler),
              catchError(this.errorHandler)
            );
          } else {
            return this.http.delete(url, this.options).pipe(
              map(this.dataHandler),
              catchError(this.errorHandler)
            );

          }

        }
    }
  }
  httpCallReturn(
    type,
    endUrl,
    data?,
    isLogin = false,
    formData = false
  ): Observable<any> {
    let serverUrl = this.appConfig.configData['getBaseUrl'];
    let setHttpHeader = '';

    if (data && data.responseType) {
      setHttpHeader = data.responseType;
      delete data.responseType;
    }

    let url = serverUrl + this.UrlMap.getEndUrl(endUrl);
    // if (endUrl == 'deleteProfileUserList') {
    //   serverUrl = 'http://10.162.4.78:49316';
    //   url = serverUrl + this.UrlMap.getEndUrl(endUrl);
    // }
    // if(endUrl == 'deleteModuleList' || endUrl == 'deleteGroupList' || endUrl == 'deletePriviledgeList'){
    //   serverUrl = 'http://10.162.4.78:49302/jioutils/urlmgmt';
    //   url = serverUrl + this.UrlMap.getEndUrl(endUrl);
    // }
      this.spinnerService.toggleSpinner(1);
    this.setHttpHeader({ isLogin, formData, url: endUrl, responseType: setHttpHeader });
    this.login = isLogin;
    switch (type) {
      case 'post':
        if (data && data.extraParams) {
          url = url + data.extraParams;
          delete data.extraParams;
        }
        return this.http.post(url, data, this.options);
      case 'put':
        return this.http.put(url, data, this.options);
      case 'patch':
        if (data && data.extraParams) {
          url = url + data.extraParams;
          delete data.extraParams;
        } else if (data.oldVersionNumber) {
          url = url + '' + data.oldVersionNumber;
        }
        return this.http.patch(url, data, this.options);
      case 'get':
        if (data) {
          if (data.appendValue) {
            url = url + '/' + data.id;
          } else {
            url = this.utilService.encodeURL(url, data);
          }
          if (data && data.extraParams) {
            url = url + data.extraParams;
            delete data.extraParams;
          }
        }
        return this.http.get(url, this.options);
      case 'delete':
        if (data && data.extraParams) {
          url = url + data.extraParams;
          delete data.extraParams;
        }
        return this.http.delete(url, this.options);
    }
  }
  setHttpHeader({ isLogin, formData, url, responseType }: { isLogin; formData; url; responseType; }) {
    const customOptions = {
      observe: 'response' as 'body', // to display the full response & as 'body' for type cast
      responseType: responseType ? responseType : 'json'
    };
    this.options = customOptions;
  }
  getAccessToken(isLogin) {
    const loggedInUser = this.dataService.getLocalStorage('user');
    let _accessToken;
    if (!isLogin && loggedInUser) {
      _accessToken = loggedInUser.access_token;
    } else {
      _accessToken = 'Bearer ';
    }

    return _accessToken;
  }
  dataHandler = result => {
    this.checkFlag = true;
    if (
      result.status === 'SUCCESS' ||
      result.status === 200 ||
      result.status === 201 ||
      result.status === 304 ||
      result.status === 202 ||
      result.status === 204 ||
      result.status === 205 ||
      result.responseCode == "OK"
    ) {
      this.spinnerService.toggleSpinner(0);
      return result.body;
    } else {
      this.errorHandler(result.body);
    }
    this.spinnerService.toggleSpinner(0);
  }
  errorHandler = result => {
    this.checkFlag = true;
    this.spinnerService.toggleSpinner(0);
    let errMsg;
    if (!this.donotShowError) {
      switch (result.status) {
        case 404:
          if (result.body) {
            return result.body
          } else {
            errMsg = result.error.error
              ? result.error.error : result.error && result.error.errorDetails ? result.error.errorDetails
                : this.staticErrorMessage;
            this.dataService.broadcast('alert', {
              type: 'danger',
              message: errMsg
            });
            return observableThrowError(errMsg);
          }
          break;
        case 409:
          //console.dir(result);
          //return result;
          if ((result.error && result.error.errorDetails) || (result.error && result.error.error)) {
            errMsg = result.error.errorDetails || result.error.error;
            this.dataService.broadcast('alert', {
              type: 'danger',
              message: errMsg
            });
            return observableThrowError(result);
          } else {
            errMsg = this.staticErrorMessage;
            this.dataService.broadcast('alert', {
              type: 'danger',
              message: errMsg
            });
          }
          break;
        case 0:
          if (result.error && result.error.error) {
            errMsg = result.error.error;
            this.dataService.broadcast('alert', {
              type: 'danger',
              message: errMsg
            });
            return observableThrowError(errMsg);
          } else {
            errMsg = this.staticErrorMessage;
            this.dataService.broadcast('alert', {
              type: 'danger',
              message: errMsg
            });
          }
          break;
        case 500:

          if (result.error && result.error.error) {
            errMsg = result.error.error;
            this.dataService.broadcast('alert', {
              type: 'danger',
              message: errMsg
            });
            return observableThrowError(errMsg);
          } else if (result.error && result.error.errorDetails) {
            errMsg = result.error.errorDetails;
            this.dataService.broadcast('alert', {
              type: 'danger',
              message: errMsg
            });
            return observableThrowError(errMsg);
          } else if (result.error && result.error.message) {
            errMsg = result.error.message;
            this.dataService.broadcast('alert', {
              type: 'danger',
              message: errMsg
            });
            return observableThrowError(errMsg);
          } else {
            errMsg = this.staticErrorMessage;
            this.dataService.broadcast('alert', {
              type: 'danger',
              message: errMsg
            });
          }

          break;
        case 400:
          errMsg = result.error.error
            ? result.error.error :
            result && result.error && result.error.message
              ? result.error.message : result && result.error && result.error.errorDetails
                ? result.error.errorDetails :
                result && result.error &&
                  result.error.errorDetails == undefined &&
                  result.error.message == undefined ?
                  result.error : this.staticErrorMessage;
          this.dataService.broadcast('alert', {
            type: 'danger',
            message: errMsg
          });
          return observableThrowError(errMsg);
          break;
        case 403:
          errMsg = result.error.error
            ? result.error.error :
            result && result.error && result.error.message
              ? result.error.message : this.staticErrorMessage;
          this.dataService.broadcast('alert', {
            type: 'danger',
            message: errMsg
          });
          return observableThrowError(errMsg);
          break;
        case 401:
          errMsg = result.error.error
            ? result.error.error : result && result.error && result.error.errorDetails ? result.error.errorDetails :
              this.staticErrorMessage;
          this.dataService.broadcast('alert', {
            type: 'danger',
            message: errMsg
          });
          //  sessionStorage.clear();
          return observableThrowError(errMsg);
          break;
        case 417:
          errMsg = result && result.error.message && result.error.message
            ? result.error.message : result && result.error && result.error.errorDetails ? result.error.errorDetails
              : this.staticErrorMessage;
          this.dataService.broadcast('alert', {
            type: 'danger',
            message: errMsg
          });
          return observableThrowError(errMsg);
        case 406:
          errMsg = result.error.error
            ? result.error.error : this.staticErrorMessage;
          this.dataService.broadcast('alert', {
            type: 'danger',
            message: errMsg
          });
          break;
        default:
          errMsg = result.error.error
            ? result.error.error : this.staticErrorMessage;
          this.dataService.broadcast('alert', {
            type: 'danger',
            message: errMsg
          });
          break;
      }
    } else {
      errMsg = '';
      if (result.status == 409) {
        return result;
      } else if (result.status == 400) {
        errMsg = result.error.error
          ? result.error.error : this.staticErrorMessage;
        this.dataService.broadcast('alert', {
          type: 'danger',
          message: errMsg
        });
      } else {

        return observableThrowError(errMsg);
      }
      //return result;
    }
  }

  handleError(error: HttpErrorResponse) {
    this.spinnerService.toggleSpinner(0);
    let errMsg;
    errMsg =
      error.error.error || this.staticErrorMessage;
    this.dataService.broadcast('alert', { type: 'danger', message: errMsg });
    return observableThrowError(errMsg);
  }

  deleteStorageData() {
    // deleting stored data form session and local storage
    this.dataService.removeLocalStorage('user');
    this.dataService.removeLocalStorage('role');
    this.dataService.removeLocalStorage('previlages');
    this.dataService.removeLocalStorage('refresh_token');
    this.dataService.removeLocalStorage('loginMember');
    this.dataService.removeLocalStorage('update-password');
    sessionStorage.clear();
    window.location.reload();
  }
}