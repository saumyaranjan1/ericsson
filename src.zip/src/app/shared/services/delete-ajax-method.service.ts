import { Injectable } from '@angular/core';

import $ from 'jquery';

import { AppConfigService } from './../../app-config.service';
import { DataService } from './data.service';
import { SpinnerService } from './spinner.service';
import { UrlMappingsService } from './url-mappings.service';
import { AuthorizationService } from '../authGuard/authorization.service';
import { HttpClient } from '@angular/common/http';
import { EnumsService } from './enums.service';
import { InterceptorService } from './interceptor.service';

@Injectable()
export class DeleteIntercepterService {
  options;
  login;

  constructor(
   private appConfig: AppConfigService,
    private dataService: DataService,
    private spinnerService: SpinnerService,
    private UrlMap: UrlMappingsService,
    private authorizationService: AuthorizationService,
   private http: HttpClient,
   private interceptorService: InterceptorService
  ) {}

  httpDelete(type, endUrl, data?, isLogin = false, formData = false) {
    const serverUrl = this.appConfig.configData['getBaseUrl'];
    const url = serverUrl + this.UrlMap.getEndUrl(endUrl);
    this.spinnerService.toggleSpinner(1);
    const self = this;
    // const _validToken = this.checkTokenExpiryForAjax();
    // if (_validToken) {
    //   return this.refreshTokenForAjax().done(res => {
    //     this.deleteAjaxMethod(url, data, self);
    //   });
    // } else {
      return this.deleteAjaxMethod(url, data, self);
   // }
  }

  deleteAjaxMethod(url, data, self) {
   return $.ajax({
      url: url,
      data: JSON.stringify(data),
      type: 'DELETE',
      beforeSend: function (xhr) {
        xhr.setRequestHeader('Authorization', self.authorizationService.getToken());
        xhr.setRequestHeader('Content-Type', 'application/json');
       // xhr.setRequestHeader('username', self.authorizationService.getUserName());
      },
      success: function(result) {
        self.dataService.setLocalStorage('deleted', true);
        self.spinnerService.toggleSpinner(0);
        self.dataService.broadcast('alert', {
          type: 'success',
          message: 'Successfully Deleted!'
        });
       return result;
      },
      error: function(response) {
        self.spinnerService.toggleSpinner(0);
        const result = response.responseJSON;
        let errMsg;
        switch (response.status) {
          case 404:
          case  0:
          case 500:
          case 400:
          if (result.error && result.error.error) {
            errMsg = result.error.error;
            self.dataService.broadcast('alert', { type: 'danger', message: errMsg });
          } else if (result.error && result.error.message) {
            errMsg = result.error.message;
            self.dataService.broadcast('alert', { type: 'danger', message: errMsg });
           } else {
            errMsg = result.message ? result.message : ( result.error ? result.error : 'Backend servers not responding. Please try again after some time.');
            self.dataService.broadcast('alert', { type: 'danger', message: errMsg });
          }
          break;
          default:
          errMsg = result.error
            ? result.error.error
              ? result.error.error
              : result.error.message
              ? result.error.message
              : result.error
            : (result.message ? result.message : 'Backend servers not responding. Please try again after some time.');
          self.dataService.broadcast('alert', { type: 'danger', message: errMsg });
         break;
        }
      }

    });
  }
  // checkTokenExpiryForAjax() {
  //   const myDate = new Date(); // Your timezone!
  //   const currentEpcohTime = Math.floor(myDate.getTime() / 1000.0);
  //   const loginEpcohTime = this.authorizationService.getLoginTime();
  //   const expTimeInMinutes = this.authorizationService.getExpTimeInMinutes();
  //   const diff = (currentEpcohTime - loginEpcohTime) / 60;
  //   if (EnumsService.MAX_SESSION_TIMEOUT_IN_MIN <= diff) {
  //     this.interceptorService.deleteStorageData();
  //   }
  //   return diff > expTimeInMinutes;
  // }

  // refreshTokenForAjax() {
  //   const self = this;
  //   const loginObj = {
  //     grant_type: 'refresh_token',
  //     client_id: 123,
  //     client_secret: 1234,
  //     refresh_token: this.authorizationService.getRefreshToken()
  //   };

  //    const serverUrl = this.appConfig.getJioUtilsBaseUrl();
  //    const url = serverUrl + this.UrlMap.getEndUrl('login');

  //   return $.ajax({
  //     url: url,
  //     data: JSON.stringify(loginObj),
  //     type: 'POST',
  //     beforeSend: function (xhr) {
  //       xhr.setRequestHeader('Content-Type', 'application/json');
  //     },
  //     success: function(result) {
  //       self.dataService.setLocalStorage('user', JSON.stringify(result));
  //       self.spinnerService.toggleSpinner(0);
  //       return result['tkn'];
  //     },
  //     error: function(result) {
  //       self.spinnerService.toggleSpinner(0);
  //       self.dataService.broadcast('alert', {
  //         type: 'danger',
  //         message: 'Something went wrong please try again!'
  //       });
  //     }
  //   });
  // }
}
