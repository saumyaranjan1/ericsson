import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-toggle-switch',
  templateUrl: './toggle-switch.component.html',
  styleUrls: ['./toggle-switch.component.less']
})
export class ToggleSwitchComponent implements OnInit {
  @Input() selected;
  @Input() text;
  @Output() selectedChange = new EventEmitter<boolean>();
  @Output() change = new EventEmitter<boolean>();


  constructor() { }

  ngOnInit() {
  }

  toggleSwitch() {
    this.selected = !this.selected;
    this.selectedChange.emit(this.selected);
  }

}
