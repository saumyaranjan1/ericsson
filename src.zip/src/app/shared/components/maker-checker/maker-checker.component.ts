import {
  Component,
  OnInit,
  Input,
  Output,
  EventEmitter
} from '@angular/core';

@Component({
  selector: 'app-maker-checker',
  templateUrl: './maker-checker.component.html',
  styleUrls: ['./maker-checker.component.less']
})
export class MakerCheckerComponent implements OnInit {
  @Input() data;
  @Output() submitForm = new EventEmitter();
  @Output() closeModal  = new EventEmitter();
  @Output() cancelMakerChecker = new EventEmitter();
  mainObject;
  keys;
  formatName = 'SplitWord';
  constructor() {}
  ngOnInit() {
    this.mainObject = this.data.keyValue;
    this.keys = Object.keys(this.mainObject[0]);
  }
  emitAction(type) {
    switch (type) {
      case 'ok':
        this.submitForm.emit();
        break;
      case 'cancel':
      this.cancelMakerChecker.emit();
        break;
    }
  }
  close() {
    this.closeModal.emit();
  }
}
