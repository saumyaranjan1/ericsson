import { Component, OnInit } from '@angular/core';

import { DataService } from '../../services/data.service';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.less']
})
export class LoaderComponent implements OnInit {

  loaderFlag = false;

  constructor(private dataService: DataService) { }

  ngOnInit() {
    this.dataService.on('spinner', this.setFlag);
  }

  setFlag = (res) => {
    this.loaderFlag = res;
  }

}
