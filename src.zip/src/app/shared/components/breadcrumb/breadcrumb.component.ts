
import {filter} from 'rxjs/operators';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.less']
})
export class BreadcrumbComponent implements OnInit, OnDestroy {
  public breadcrumbs = [];
  routeSubs;

  constructor(private router: Router, private activatedRoute: ActivatedRoute) {
    this.routeSubs = router.events.pipe(filter((event) => event instanceof NavigationEnd)).subscribe((val) => {
      this.breadcrumbs = [];
      this.breadcrumbs = this.generateBreadcrumbs(this.activatedRoute, this.breadcrumbs);
    });
  }


  ngOnInit() {
  }

  generateBreadcrumbs(route, breadcrumbs) {
    if (!route) {
      return breadcrumbs;
    }

    if (!breadcrumbs.filter((item) => { return item.label == route.data._value.breadcrumb.label }).length) {
      breadcrumbs.push({
        route: route.data._value.breadcrumb.route,
        label: route.data._value.breadcrumb.label
      });
    }

    console.table(breadcrumbs);



    let children = route.children && route.children[0];
    return this.generateBreadcrumbs(children, breadcrumbs);
  }

  ngOnDestroy() {
    this.routeSubs.unsubscribe();
  }


}
