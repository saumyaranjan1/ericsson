import {
  Component,
  OnInit,
  OnChanges,
  Input,
  Output,
  EventEmitter,
  ViewChildren
} from '@angular/core';
import { EnumsService } from '../../services/enums.service';
import { DataService } from '../../../shared/services/data.service';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-inline-pagenation-table',
  templateUrl: './inline-pagenation-table.component.html',
  styleUrls: ['./inline-pagenation-table.component.less']
})
export class InlinePagenationTableComponent implements OnInit {
  @Input() data;

  @Input() newRowData;

  @Output() delete = new EventEmitter();
  @Output() multiSeletChange = new EventEmitter();
  @Output() singleSeletChange = new EventEmitter();
  @Output() view = new EventEmitter();
  @Output() save = new EventEmitter();
  @Output() times = new EventEmitter();
  @Output() edit = new EventEmitter();
  @Output() share = new EventEmitter();
  @Output() key = new EventEmitter();
  @Output() approve = new EventEmitter();
  @Output() reject = new EventEmitter();
  @Output() check = new EventEmitter();
  @Output() uncheck = new EventEmitter();
  @Output() addnew = new EventEmitter();
  @Output() search = new EventEmitter();
  @Output() pending = new EventEmitter();
  @Output() viewconfig = new EventEmitter();
  @Output() load = new EventEmitter();
  @Output() viewimei = new EventEmitter();
  @Output() download = new EventEmitter();
  @Output() globalDownload = new EventEmitter();
  @Output() editChanges = new EventEmitter();
  @Output() openModal = new EventEmitter();
  @Output() getnewRowData = new EventEmitter();
  @Output() getPaginatedData = new EventEmitter();
  @Output() sendUserEmail = new EventEmitter();
  @Output() sendAppId = new EventEmitter();
  @Output() addips = new EventEmitter();
  @Output() showErrorMessage = new EventEmitter();
  @Output() sortData = new EventEmitter();

  checkedAll = false;
  dropdownSettings = EnumsService.MULTI_SELECT_DROPDOWN_OPTIONS;
  dropdownSettingsForDomain = EnumsService.SINGLE_SELECT_DROPDOWN_OPTIONS;
  enableEdit = false;
  columnValue: any;
  searchValue: String = '';
  serverSearchValue: String = '';
  editCache = {};
  newDynamic: any = {};
  sorting = {
    column: null,
    descending: false
  };
  pagination = {
    page: 0,
    startIndex: 0,
    countPerPage: EnumsService.paginationObj.recordsPerPage,
    maxSize: 10,
    displyedResults: 0,
    stratingNumberOfSelectedPage: 0
  };
  actionEdit = { type: 'edit', disableIconProp: true, title: 'Edit User' };
  totalRecords = 0;
  showSearchBox = false;
  editColom = false;
  modalOpned = false;
  selectedValue;
  searchErrorMsg = '';
  searched = false;
  removedIps = [];
  shouldFilter = true;
  constructor(private dataService: DataService) { }
  public innerWidth: any;
  ngOnInit() {
    this.getPage(1);
    this.submit = false;
    this.sorting = {
      column: this.data.columns[0].key,
      descending: false
    };
    this.innerWidth = window.innerWidth;
    this.dropdownSettingsForDomain['text'] = '';
  }

  hideActionIcon(data, action) {
    this.totalRecords = Math.ceil(
      this.data.data.length / this.pagination.countPerPage
    );
    return action.negate
      ? action['showIconProp'] && data[action['showIconProp']]
      : action['showIconProp'] && !data[action['showIconProp']];
  }

  ngOnChanges() {
    this.p = this.pagiantionObj.pageNum;
    this.data = this.data;
    this.total = this.data.total;
    this.shouldFilter = this.data.moduleName ? false : true;
  }

  selectedClass(columnName) {
    if (columnName === this.sorting.column) {
      return this.sorting.descending ? ' fa-arrow-up' : 'fa-arrow-down';
    } else {
      return 'fa-arrow-up';
    }
  }


  isDisableMaterial(item, selectedItem) {
    // if (this.data.data && this.data.data[0] && this.data.data[0].newRow) {
    //   return false
    // } else {
      if (item.appType == 'SYSTEM_DEFAULT') {
        return true;
      }
    //}
    // selectedItem.forEach(element => {
    //   if (element.id == item.id && item.appType == 'FIXED') {
    //     return true;
    //   }
    // });
  }


  disableIcon(data, action) {
    let cssClass = '';
    let disable;
    if (data.disable && action.type === 'delete') {
      disable = 'disabled';
    }
    cssClass = 'parent ' + disable;
    return cssClass;
  }

  getActionClass(data, action, edit, add) {
    let cssClass = '';
    let disable = data.status === 'Approved' ? 'disabled' : '';
    if (data.disable) {
      disable = 'disabled';
    }
    switch (action.type) {
      case 'delete': cssClass = 'fa-trash'; break;
      case 'delete':
        cssClass = 'icons table-icon delete-icon ' + disable;
        break;
      case 'save':
        cssClass = 'fas fa-save'
        break;

      case 'load':
        cssClass = 'fa fa-refresh';
        break;
      case 'times':
        if (!edit || add) {
          cssClass = 'fa fa-times'
        }
        break;
      case 'view':
        cssClass = 'fa-eye view';
        break;
      case 'edit':
        cssClass = 'fa-pencil ';
        break;
      // case 'share': cssClass = 'fa-share-alt'; break;
      case 'share':
        cssClass = 'icons table-icon share-icon';
        break;

      case 'download':
        cssClass = 'fa-download';
        break;
      // case 'approve': cssClass = 'fa-check-circle dt-icon-approve'; break;
      case 'approve':
        cssClass = 'icons table-icon approve-icon';
        break;
      // case 'reject': cssClass = 'fa-times-circle dt-icon-reject'; break;
      case 'reject':
        cssClass = 'icons table-icon approve-icon-inactive';
        break;
      // case 'key': cssClass = 'fa-key'; break;

      case 'key':
        cssClass = 'icons table-icon key-icon';
        break;

      case 'check':
        cssClass = 'fa-check-square icon-checked';
        break;
      case 'uncheck':
        cssClass = 'fa-square-o icon-unchecked';
        break;
      case 'pending':
        cssClass = 'fa-clock-o';
        break;
      case 'viewconfig':
        cssClass = 'fa-cogs';
        break;

      case 'viewimei':
        cssClass = 'fa-mobile';
        break;
      case 'addips':
        cssClass = 'fa-plus';
        break;
    }
    cssClass = action['disableIconProp'] ? cssClass : cssClass + ' disabled';
    return cssClass;
  }

  changeSorting(columnName): void {
    const sort = this.sorting;
    var param = {
      'columnName': columnName,
    }
    if (sort.column === columnName) {
      sort.descending = !sort.descending;
      param['orderBy'] = sort.descending ? 'ascending' : 'descending';

    } else {
      sort.column = columnName;
      sort.descending = false;
      param['orderBy'] = 'descending'
    }
    this.sortData.emit(param);
  }

  convertSorting(): string {
    return this.sorting.descending
      ? '-' + this.sorting.column
      : this.sorting.column;
  }

  checkRajex(rajex) {
    if (rajex) {
      return rajex
    }
  }

  checkAddMore: any;
  addNewItem(formValidation) {
    if (this.data.data.length > 0) {
      this.enableEdit = false;
      if (formValidation && !this.data.data[0].newRow) {
        if (!this.checkEditField()) {
          this.getnewRowData.emit(event);
        }
      } else {
        this.dataService.broadcast('alert', {
          type: 'danger',
          message: `Please Save Updated Changes`
        });
      }
    } else {
      this.getnewRowData.emit(event);
    }
  }

  // sortValue(list, model) {
  //   list.map((element, key) => {
  //     model.forEach(innerElement => {
  //       if (innerElement.id == element.id) {
  //         list.splice(key, 1);
  //         list.unshift(element);
  //       }
  //     });
  //   });
  //   return list;
  // }

  checkEditField() {
    var arrays = [];
    delete this.editCache['undefined'];
    arrays = Object.values(this.editCache);
    const even = (element) => element.edit == true;
    return arrays.some(even);
  }

  searchItem() {
    this.showSearchBox = !this.showSearchBox;
  }
  globalDownloadData() {
    this.globalDownload.emit();
  }
  open(event) {
    this.openModal.emit(event);
  }

  submit: any;

  emitAction(action, dataItem, index, saveOrEdit, formValidation) {
    if (action.disableIconProp && dataItem[action.disableIconProp]) {
      return;
    }

    if (!action.disableIconProp) {
      return;
    }
    switch (action.type) {
      case 'delete':
        this.delete.emit(dataItem);
        this.updateEditCache('times');
        break;
      case 'load':
        this.load.emit(dataItem);
        break;
      case 'save':
        const data = {
          'data': dataItem,
          'action': saveOrEdit
        }
        this.submit = true;
        if (formValidation) {
          this.save.emit(data);
        }
        break;
      case 'times':
        if (saveOrEdit) {
          this.data.data.splice(0, 1);
          this.submit = false;
        } else {
          if (this.removedIps.length > 0) {
            const newArray = dataItem.externalConsumerIps.concat(this.removedIps);
            dataItem.externalConsumerIps = newArray;
          }
          this.removedIps = [];
          this.times.emit(dataItem);
          this.cancelEdit(dataItem);
          this.getPaginatedData.emit(this.pagiantionObj);
          this.updateEditCache('times');
        }
        break;
      case 'view':
        this.view.emit(dataItem);
        break;
      case 'edit':
        this.modalOpned = false;
        if (formValidation) {
          this.editChanges.emit(dataItem);
          this.removedIps = [];
          if (!this.data.checkStatusBeforeEdit) {
            this.startEdit(dataItem);
          } else {
            if (dataItem.status == 'Done' || dataItem.status == 'InComplete' || dataItem.status == 'Failed') {
              this.startEdit(dataItem);
            } else {
              this.showErrorMessage.emit(dataItem);
            }
          }
        }
        break;
      case 'share':
        this.share.emit(dataItem);
        break;
      case 'key':
        this.key.emit(dataItem);
        break;
      case 'approve':
        this.approve.emit(dataItem);
        break;
      case 'reject':
        this.reject.emit(dataItem);
        break;
      case 'check':
        this.check.emit(dataItem);
        break;
      case 'uncheck':
        this.uncheck.emit(dataItem);
        break;
      case 'pending':
        this.pending.emit(dataItem);
        break;
      case 'viewconfig':
        this.viewconfig.emit(dataItem);
        break;
      case 'viewimei':
        this.viewimei.emit(dataItem);
        break;
      case 'download':
        this.download.emit(dataItem);
        break;
      case 'addips':
        this.modalOpned = true;
        this.addips.emit(dataItem);
        break;
    }
  }



  updateEditCache(param): void {
    this.columnValue = this.data.columns;
    if (param === 'edit') {
      this.data.data.forEach(item => {
        if (!this.editCache[item.id]) {
          this.editCache[item.id] = {
            edit: true,
            show: true,
            add: true,
            fixed: item.appTypeData && item.appTypeData.model == "SYSTEM DEFAULT" ? false : true
          };
        }
      });
    } else {
      this.data.data.forEach(item => {
        if (!this.editCache[item.id]) {
          this.editCache[item.id] = {
            edit: false,
            show: true,
            add: false,
            fixed: item.appTypeData && item.appTypeData.model == "SYSTEM DEFAULT" ? false : true
          };
        }
      });
    }

  }

  checkAll(event, formValidation) {
    this.data.data.forEach(item => {
      this.editCache[item.id] = {
        check: event.checked,
      };
    });
  }

  cancelEdit(editData) {
    this.editColom = false;
    this.editCache[editData.id].edit = !this.editCache[editData.id].edit;
  }

  editFieldValue;
  startEdit(editData) {
    this.editFieldValue = editData;
    this.editColom = !this.editColom;
    this.editCache[editData.id].edit = !this.editCache[editData.id].edit;
    this.editCache[editData.id].show = true;
    this.editCache[editData.id].false = true;
  }


  closeEditField(event) {
    if (!this.modalOpned) {
      if (this.data.data && this.data.data[0] && this.data.data[0].newRow) {
        if (event.target && event.target.id !== 'addNewItems' && event.target.classList[0] !== 'mat-option-pseudo-checkbox'
          && event.target.classList[0] !== 'mat-option-text'
          && event.target.classList[0] !== 'cdk-overlay-backdrop' && event.target.classList[0] !== 'itemName' && event.target.classList[0] !== 'selected') {
          this.data.data.splice(0, 1);
          this.submit = false;
        }
      } else {
        if (this.editFieldValue) {
          if (event.target && event.target.classList[0] !== 'mat-option-pseudo-checkbox'
            && event.target.classList[0] !== 'mat-option-text'
            && event.target.classList[0] !== 'cdk-overlay-backdrop' && event.target.classList[0] !== 'itemName' && event.target.classList[0] !== 'selected') {
            this.editCache[this.editFieldValue.id].edit = false;
          }
        }
      }
    }

  }

  setDataTofeld(event, name, value) {
    if (name == 'userName') {
      this.sendUserEmail.emit(value);
    }
    if(name == 'appId'){
      this.sendAppId.emit(value);
    }
  }


  onSelectChange(param, value, data) {
    const params = {
      'param': param,
      'value': value,
      'data': data
    }
    this.getnewRowData.emit(params);
  }

  ///pagenation

  pager = {};
  pageOfItems = [];
  p;
  total;
  loading: boolean;
  pagePerItems = [
    { value: 5 },
    { value: 10 },
    { value: 20 },
    { value: 30 },
    { value: 40 },
    { value: 50 },
    { value: 100 }
  ];
  pagiantionObj = {
    pageNum: 1,
    rpp: 10,
    offset: 0,
    pageSize: 10,
    pageNumber: 1
  };

  getPage(page: number) {
    this.pagiantionObj.pageNum = page;
    this.pagiantionObj.pageNumber = page;
    this.pagiantionObj.offset = (page - 1) * this.pagiantionObj.rpp;
    this.pagiantionObj.pageSize = this.pagiantionObj.rpp;
    const searchObj = {
      [this.selectedValue]: this.serverSearchValue
    };
    if (this.serverSearchValue) {
      const key = Object.keys(searchObj);
      this.pagiantionObj['searchBy'] = this.selectedValue;
      this.pagiantionObj['searchValue'] = this.serverSearchValue;
    } else {

      if (this.pagiantionObj['searchBy']) {
        delete this.pagiantionObj['searchBy'];
      }
      if (delete this.pagiantionObj['searchValue']) {
        delete this.pagiantionObj['searchValue'];
      }

    }
    this.getPaginatedData.emit(this.pagiantionObj);
    this.p = page;
  }

  getDataBynewSelection(data) {
    this.pagiantionObj.rpp = data.value;
    this.getPage(1);
  }

  changeMultyModel(event) {
    var selectedString = [];
    event.forEach(element => {
      selectedString.push(element.itemName);
    });
    return selectedString;
  }

  changeMultyModelItem(event) {



  }

  onItemSelect(item: any, row, key) {
    var param = {
      'item': item,
      'row': row,
      'key': key
    }
    this.multiSeletChange.emit(param);
  }

  onSingleChange(row, name) {
    const param = {
      'row': row,
      'name': name
    }
    this.singleSeletChange.emit(param);
  }

  makearraytoString(param) {
    return param.model;
  }

  showNameTooltip(param) {
    if (param[0]) {
      return param[0].itemName;
    }
  }
  removeIp(data, i) {
    this.modalOpned = true;
    if (data.length > 1) {
      this.removedIps.push(data[i]);
      data.splice(i, 1);
    } else {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: `Atleast One Ip should be present`
      });
    }
  }
  valueSelected(data, event?) {
    if (data === 'dropDown') {
      this.serverSearchValue = null;
      this.selectedValue = event.value;
    }
    if (this.selectedValue || this.serverSearchValue) {
      this.searchErrorMsg = '';
      this.searched = false;
    }
  }
  onKeyUp(event) {
    // Checking for Backspace or Delete if Search field is empty
    if ((event.keyCode == 8 || event.keyCode == 46) && !this.serverSearchValue) {
      this.getPage(1);
    }
  }
  serachValue() {
    this.searched = true;
    if (!this.selectedValue) {
      this.searchErrorMsg = 'Please select dropdown value!';
    } else if (!this.serverSearchValue) {
      this.searchErrorMsg = 'Please search the value according to selecttion!';
    } else {
      this.clearSearcErrors();
    }
  }
  clearSearch() {
    this.getPage(1);
    this.searched = false;
    this.selectedValue = '';
    this.serverSearchValue = '';
    this.searchErrorMsg = '';
  }
  clearSearcErrors() {
    this.searchErrorMsg = '';
    this.searched = false;
    const searchObj = {
      [this.selectedValue]: this.serverSearchValue
    };
    this.getPage(1);
  }
}
