import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InlinePagenationTableComponent } from './inline-pagenation-table.component';

describe('InlinePagenationTableComponent', () => {
  let component: InlinePagenationTableComponent;
  let fixture: ComponentFixture<InlinePagenationTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InlinePagenationTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InlinePagenationTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
