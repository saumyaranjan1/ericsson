import { Component, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FieldConfig } from "../field.interface";
@Component({
    selector: "app-select",
    template: `
    <div class="dynamic-select-field col-12" >  
        <label for="field.label" class="control-label col-12">{{field.label}}</label>
            <div class="form-group" *ngIf="configModalOptionMode && configModalOptionMode !== 'view'">  
            <mat-form-field class="demo-full-width margin-top col-12" [formGroup]="group">
                    <mat-select  class="selected-config-dropdown-value col-12"  [formControlName]="field.name">
                            <mat-option class="config-push-left" *ngFor="let item of field.options" [value]="item.value">{{item.description}}</mat-option>
                    </mat-select>  
            </mat-form-field>
           
            <ng-container *ngFor="let validation of field.validations;" ngProjectAs="mat-error">
                    <span class="help-block col-12" *ngIf="group.get(field.name).hasError(validation.name)">
                        {{validation.message}}
                    </span> 
            </ng-container>        
        </div> 
        <div class="form-group col-12" *ngIf="configModalOptionMode && configModalOptionMode === 'view'"> 
        {{field.defaultValue}}
        </div>
    </div> 
      
`,
    styles: []
})
export class SelectComponent implements OnInit {
    field: FieldConfig;
    group: FormGroup;
    configModalOptionMode: any;
    constructor() { }
    ngOnInit() {

    }
}