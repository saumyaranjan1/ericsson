import { Component, OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { FieldConfig } from "../field.interface";
@Component({
    selector: "app-input",
    template: `
<div class="dynamic-input-field col-12" [formGroup]="group">
    <label *ngIf="field.disable !== true" for="field.label" class="control-label col-12">{{field.label}}</label>
    <div class="form-group" *ngIf="configModalOptionMode && configModalOptionMode !== 'view' && field.disable !== true">
        <input
        [formControlName]="field.name" 
        [ngClass]="{'field.inputClassName':field.inputClassName}"
        [type]="field.inputType"
        class="form-control col-12 input-lg">
        <ng-container *ngFor="let validation of field.validations;" ngProjectAs="mat-error">
            <span class="help-block col-12" *ngIf="group.get(field.name).hasError(validation.name)">
              {{validation.message}}
            </span>
        </ng-container>
    </div>
    <div class="form-group col-12" *ngIf="configModalOptionMode && configModalOptionMode === 'view' && field.disable !== true">
    {{field.defaultValue}}
    </div>
    <div class="form-group col-12" *ngIf="configModalOptionMode && configModalOptionMode === 'view' && field.disable === true">
    {{field.label}}
    </div>
    <div class="form-group" *ngIf="configModalOptionMode && configModalOptionMode !== 'view' && field.disable === true">
    {{field.label}}
    </div>
</div>
`,
    styles: []
})
export class InputComponent implements OnInit {
    field: FieldConfig;
    group: FormGroup;
    configModalOptionMode:any;
    constructor() { }
    ngOnInit() {
       
    }
}