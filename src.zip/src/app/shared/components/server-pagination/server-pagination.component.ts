import {
  ChangeDetectionStrategy,
  Input,
  Output,
  Component,
  OnInit,
  EventEmitter,
  OnChanges
} from '@angular/core';

@Component({
  selector: 'app-server-pagination',
  templateUrl: './server-pagination.component.html',
  styleUrls: ['./server-pagination.component.less'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ServerPaginationComponent implements OnInit, OnChanges {
  @Output() getPaginatedData = new EventEmitter();
  @Output() addnew = new EventEmitter();
  @Output() selectedRadio = new EventEmitter();
  @Output() delete = new EventEmitter();
  @Output() view = new EventEmitter();
  @Output() edit = new EventEmitter();
  @Output() install = new EventEmitter();
  @Output() addDevice = new EventEmitter()
  @Output() stop = new EventEmitter();
  @Output() restart = new EventEmitter();
  @Output() createDevice = new EventEmitter();
  @Output() getDeviceList = new EventEmitter();
  @Output() bulkUpload = new EventEmitter();
  @Output() activateOrDeActivate = new EventEmitter();
  @Output() exportDataToCsv = new EventEmitter();
  @Output() search = new EventEmitter();
  @Output() connectionOnly = new EventEmitter();
  @Output() activationstatus = new EventEmitter();
  @Output() duplicate = new EventEmitter();
  @Input() sdata;
  @Input() columns;
  @Input() infoIcon;
  @Input() deleteFlag;
  @Input() actionsObj;
  @Input() tableHeader;
  @Input() tableHeaderActions;
  @Input() headerDropdownList;
  @Input() headerRadioList;
  @Input() showGridCheckBox;
  @Input() moduleName;

  pager = {};
  pageOfItems = [];
  p;
  total;
  rowClick;
  data;
  loading: boolean;
  pagePerItems = [
    { value: 5 },
    { value: 10 },
    { value: 20 },
    { value: 30 },
    { value: 40 },
    { value: 50 },
    { value: 100 }
  ];
  pagiantionObj = {
    page: 1,
    limit: 10,
    offset: 0,
    pageNum: 1,
    rpp: 0,
    pageNumber: 1,
    pageSize: 0
  };
  sorting = {
    column: null,
    descending: false
  };
  dataFromServer;

  searchValue: String = '';
  selectedValue: any = '';
  searchErrorMsg = '';
  editCache = {};
  searched = false;
  searchObj;


  actionEdit = { type: 'edit', disableIconProp: true, title: 'Edit User' };
  actionDelete = { type: 'delete', disableIconProp: true, title: 'Delete User' };
  actionDuplicate = { type: 'duplicate', disableIconProp: true, title: 'Duplicate' };


  constructor() { }

  ngOnInit() {
    this.getPage(1);
  }
  ngOnChanges(changes) {
    if (changes.sdata && changes.sdata.currentValue) {
      this.p = changes.sdata.currentValue.page ? changes.sdata.currentValue.page : 1;
      this.total = changes.sdata.currentValue.total
        ? changes.sdata.currentValue.total
        : changes.sdata.currentValue.length ? changes.sdata.currentValue.length : 0;

      this.data = changes.sdata.currentValue.data
        ? changes.sdata.currentValue.data
        : changes.sdata.currentValue;
      this.data = this.data;
    }

    const param = {
      'checked': false
    }
    this.checkAll(false);

  }
  getPage(page: number) {
    this.pagiantionObj.page = page;
    this.pagiantionObj.pageNum = page;
    this.pagiantionObj.offset = (page - 1) * this.pagiantionObj.limit;
    this.pagiantionObj.rpp = this.pagiantionObj.limit;

    this.pagiantionObj.pageNumber = page;
    this.pagiantionObj.pageSize = this.pagiantionObj.rpp;

    //If search Object is there
    if (this.searchValue && this.searchObj) {
      const key = Object.keys(this.searchObj);
      this.pagiantionObj['searchBy'] = key[0];
      this.pagiantionObj['searchValue'] = this.searchObj[key[0]];
    } else {

      if (this.pagiantionObj['searchBy']) {
        delete this.pagiantionObj['searchBy'];
      }
      if (this.pagiantionObj['searchValue']) {
        delete this.pagiantionObj['searchValue'];
      }

    }


    this.getPaginatedData.emit(this.pagiantionObj);
  }

  connectionOnlyUi() {
    this.connectionOnly.emit();
  }

  getDataBynewSelection(data) {
    this.pagiantionObj.limit = data.value;
    this.getPage(1);
  }

  changeSorting(columnName): void {
    const sort = this.sorting;
    if (sort.column === columnName) {
      sort.descending = !sort.descending;
    } else {
      sort.column = columnName;
      sort.descending = false;
    }
  }
  addNewItem() {
    this.addnew.emit();
  }
  selectedRadioValue(event) {
    if (event && event.value) {
      this.selectedRadio.emit(event.value);
    }
  }
  getClassForCampaign(data) {
    data = data.toLowerCase();

    let className;
    if (data == 'active') {
      className = 'campaign-active';
    } else if (data == 'closed') {
      className = 'campaign-closed'
    }
    return className;
  }
  getActionClass(data, action) {
    // console.table(data);
    let cssClass = '';
    let cssDeleteCalss = "";
    let cssStopCalss = "";
    let cssAddDevice = "";
    let cssCreatedevice = "";
    let cssSaveClass = "";
    let cssBulkUploadClass = "";
    let cssRestartCalss = "hidden-restart-class";
    let cssExecuteClass = "";
    let cssActiveStatusRuleEngine = "";
    const disable = data.status === 'Approved' ? 'disabled' : '';
    if (action.type === "stop" && data && data.moduleType && data.moduleType === 'campaign'
      && data.campaignStatus && (data.campaignStatus.trim().toLowerCase() === 'active' ||
        data.campaignStatus.trim().toLowerCase() === 'pending' ||
        data.campaignStatus.trim().toLowerCase() === 'pendingexecution')) {
      cssStopCalss = "visiable-stop-class";
    } else if (action.type === "stop" && data && data.moduleType && data.moduleType === 'campaign'
      && data.campaignStatus && (data.campaignStatus.trim().toLowerCase() !== 'active' ||
        data.campaignStatus.trim().toLowerCase() !== 'pending' ||
        data.campaignStatus.trim().toLowerCase() !== 'pendingexecution')) {
      cssStopCalss = "hidden-stop-class";
    }
    // if(action.type === "restart" && data && data.moduleType && data.moduleType === 'campaign' 
    //     && data.campaignStatus && data.campaignStatus === 'Closed'){
    //     cssRestartCalss = "visiable-restart-class";
    // }
    if (action.type === "restart" && data && data.moduleType && data.moduleType === 'campaign'
      && data.campaignStatus && data.campaignStatus.trim().toLowerCase() === 'closed') {
      cssRestartCalss = "visiable-restart-class";
    } else if (action.type === "restart" && data && data.moduleType && data.moduleType === 'campaign'
      && data.campaignStatus && data.campaignStatus.trim().toLowerCase() !== 'closed') {
      cssRestartCalss = "hidden-restart-class";
    }
    if (action.type === "adddevice" && data && data.moduleType && data.moduleType === 'campaign'
      && (data.campaignStatus.trim().toLowerCase() === 'active' ||
        data.campaignStatus.trim().toLowerCase() === 'pendingexecution')) {
      cssAddDevice = "visiable-adddevice-class";
    } else if (action.type === "adddevice" && data && data.moduleType && data.moduleType === 'campaign'
      && (data.campaignStatus.trim().toLowerCase() !== 'active' ||
        data.campaignStatus.trim().toLowerCase() !== 'pendingexecution')) {
      cssAddDevice = "hidden-adddevice-class";
    }

    if (action.type === "install" && data && data.moduleType && data.moduleType === 'campaign'
      && data.campaignStatus.trim().toLowerCase() === 'pendingexecution') {
      cssExecuteClass = "visiable-install-svg-image";
    } else if (action.type === "install" && data && data.moduleType && data.moduleType === 'campaign'
      && data.campaignStatus.trim().toLowerCase() !== 'pendingexecution') {
      cssExecuteClass = "hidden-install-svg-image";
    }

    if (action.type === "activationstatus" && data && data.moduleType && data.moduleType === 'ruleengine'
      && data.activationStatus && data.activationStatus.toLowerCase() === 'active') {
      //cssActiveStatusRuleEngine = "active-status-svg-image";
    }

    if (data.requestOrigin) {
      if (data.requestOrigin.toUpperCase() == 'ISO') {
        cssDeleteCalss = 'disabled';
        cssSaveClass = 'disabled';
        cssCreatedevice = 'disabled';
        // cssAddDevice = 'disabled';
        cssBulkUploadClass = 'disabled';
      }
    }

    switch (action.type) {
      // case 'delete': cssClass = 'fa-trash'; break;
      case 'delete':
        cssClass = cssDeleteCalss;
        break;
      case 'view':
        cssClass = '';
        break;
      case 'edit':
        cssClass = cssSaveClass;
        break;
      case 'stop':
        cssClass = cssStopCalss;
        break;
      case 'restart':
        cssClass = cssRestartCalss;
        break;
      case 'install':
        cssClass = cssExecuteClass;
        break;
      case 'getDeviceList':
        cssClass = cssAddDevice;
        break;
      case 'createDevice':
        cssClass = cssCreatedevice;
        break;
      case 'bulkupload':
        cssClass = cssBulkUploadClass;
        break;
      case 'activationstatus':
        cssClass = cssActiveStatusRuleEngine;
        break;
    }
    // cssClass = data[action['disableIconProp']] ? cssClass + ' disabled' : cssClass;
    // cssClass = action['disableIconProp'] ? cssClass : cssClass + ' disabled';
    return cssClass;
  }
  emitAction(action, dataItem, index) {
    // if (action.disableIconProp && dataItem[action.disableIconProp]) {
    //   return;
    // }
    // if (!action.disableIconProp) {
    //   return;
    // }

    switch (action.type) {
      case 'delete':
        this.delete.emit(dataItem);
        break;
      case 'view':
        this.view.emit(dataItem);
        break;
      case 'edit':
        this.edit.emit(dataItem);
        break;
      case 'stop':
        this.stop.emit(dataItem);
        break;
      case 'restart':
        this.restart.emit(dataItem);
        break;
      case 'install':
        this.install.emit(dataItem);
        break;
      case 'adddevice':
        this.addDevice.emit(dataItem);
        break;
      case 'createDevice':
        this.createDevice.emit(dataItem);
        break;
      case 'activationstatus':
        this.activationstatus.emit(dataItem);
        break;
      case 'getDeviceList':
        if (this.selectedValue && this.searchValue) {
          dataItem['selectedValue'] = this.selectedValue;
          dataItem['searchValue'] = this.searchValue;
        }

        this.getDeviceList.emit(dataItem);
        break;
      case 'activateOrDeActivate':
        this.activateOrDeActivate.emit(dataItem);
        break;
      case 'bulkupload':
        this.bulkUpload.emit(dataItem);
        break;
      case 'duplicate':
        this.duplicate.emit(dataItem);
        break;
    }
  }

  closeMultiselectField(event) {
    if (event.target) {
      if (event.target.id !== 'multiselectList' && event.target.id !== 'multiselecthevron') {
        if (this.data && this.data.length > 0) {
          this.data.forEach(value => {
            if (value && value.roleCategoryName && value.roleCategoryName.length > 0) {
              value.roleCategoryName.map(mapValue => {
                mapValue.showPopup = false;
                mapValue.activeClass = false;
                return mapValue;
              });
            }
            if (value && value.abacaction) {
              value.abacaction = false;
            }
          });
        }
      }
    }
  }

  userAbacEmitAction(index, event) {
    if (this.data && this.data.length > 0 &&
      this.data[index].abacaction === false) {
      this.data.forEach(value => {
        value.abacaction = false;
      });
    }
    this.data[index].abacaction = !this.data[index].abacaction;

  }

  hideActionIcon(data, action) {
    // this.totalRecords = Math.ceil(
    //   this.spData.data.length / this.pagination.countlimit
    // );
    return action.negate
      ? action['showIconProp'] && data[action['showIconProp']]
      : action['showIconProp'] && !data[action['showIconProp']];
  }

  hideActionByIso(data, action) {
    if (data.requestOrigin == 'iso') {
      return true;
    } else {
      return false
    }
  }

  exportToCsv() {
    this.exportDataToCsv.emit();
  }
  checkAll(event) {
    if (this.data && this.data.length > 0) {
      this.data.forEach(item => {
        item['check'] = event;
        // this.editCache[item.id] = {
        //   check: event,
        // };
      });
    }
  }
  valueSelected(data, event?) {
    if (data === 'dropDown') {
      this.searchValue = null;
      this.selectedValue = event.value;
    }
    if (this.selectedValue || this.searchValue) {
      this.searchErrorMsg = '';
      this.searched = false;
    }
  }

  onKeyUp(event) {
    // Checking for Backspace or Delete if Search field is empty
    if ((event.keyCode == 8 || event.keyCode == 46) && !this.searchValue) {
      this.getPage(1);
    }
  }

  provisionValueSelected(data, event?) {
    if (data === 'dropDown') {
      this.searchValue = null;
      this.selectedValue = event.value;
    }
    if (this.selectedValue || this.searchValue) {
      this.searchErrorMsg = '';
      this.searched = false;
    }
  }
  provisionSearchValue() {
    this.searched = true;
    if (!this.selectedValue) {
      this.searchErrorMsg = 'Please select dropdown value!';
    } else {
      if (this.searchValue) {
        this.searchProvisioningData();
      } else {
        this.selectedValue = "";
        this.getPage(1);
      }

    }
  }

  searchProvisioningData() {
    this.searchErrorMsg = '';
    this.searched = false;
    const data = {
      searchKey: this.searchValue,
      dropDownValue: this.selectedValue
    };
    this.search.emit(data);
  }
  serachValue() {
    this.searched = true;
    if (!this.selectedValue) {
      this.searchErrorMsg = 'Please select dropdown value!';
    } else if (!this.searchValue) {
      this.searchErrorMsg = 'Please search the value according to selection!';
    } else {
      if (this.selectedValue === 'phone' || this.selectedValue === 'imei') {
        if (!this.isNumber(this.searchValue)) {
          this.searchErrorMsg = 'Please search by numbers only!';
        } else {
          if (this.selectedValue === 'imei') {
            if (
              this.findLength(this.searchValue) === 15 ||
              this.findLength(this.searchValue) === 16
            ) {
              this.clearSearcErrors();
            } else {
              this.searchErrorMsg = 'IMEI minimum required numbers is 15 and max number is 16.';
            }
          } else {
            this.clearSearcErrors();
          }
        }
      } else if (this.selectedValue === 'email') {
        if (!this.isEmailAddress(this.searchValue)) {
          this.searchErrorMsg = 'Please search by valid email only!';
        } else {
          this.clearSearcErrors();
        }
      } else if (this.selectedValue === 'hqBpId' || this.selectedValue === 'bpid' ||
        this.selectedValue === 'imei' || this.selectedValue === 'msisdn') {
        if (!this.isNumber(this.searchValue)) {
          this.searchErrorMsg = 'Please search by numbers only!';
        } else {
          this.clearSearcErrors();
        }
      } else {
        this.clearSearcErrors();
      }
    }
  }
  clearSearch() {
    // this.dataService.setLocalStorage('refresh', true);
    this.getPage(1);
    // this.refreshData('refresh');
    this.searched = false;
    this.selectedValue = '';
    this.searchValue = '';
    this.searchErrorMsg = '';
  }
  clearSearcErrors() {
    this.searchErrorMsg = '';
    this.searched = false;
    const data = {
      searchKey: this.searchValue,
      dropDownValue: this.selectedValue
    };
    this.searchObj = {
      [this.selectedValue]: this.searchValue
    }

    if (this.moduleName) {
      this.getPage(1);
    } else {
      this.search.emit(data);
    }



    // this.timeIntervalMethod();
  }
  isEmailAddress(str) {
    const pattern = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    return pattern.test(str); // returns a boolean
  }

  isNotEmpty(str) {
    const pattern = /\S+/;
    return pattern.test(str); // returns a boolean
  }
  isNumber(str) {
    const pattern = /^\d+$/;
    return pattern.test(str); // returns a boolean
  }

  findLength(data) {
    return Math.ceil(Math.log10(data));
  }

  viewTableClick(dataItem) {
    this.view.emit(dataItem);
  }


  onChange(event, row) {

    this.data.forEach(item => {
      if (row.id == item.id) {
        item['check'] = event.checked;
        this.rowClick = row;
      } else {
        item['check'] = false;
        // this.rowClick = null;
      }
    });
  }

  deleteRowItem() {
    this.delete.emit(this.rowClick);
  }

  activateDeActivate() {
    this.activateOrDeActivate.emit(this.rowClick);
  }
  changeDropdownEvent(event, data, rowIndex) {
    const selectedVersion = data.findIndex(version => version.name === event.value);
    this.data[rowIndex].versions[selectedVersion].versionName = event.value;
    this.data[rowIndex].versions.map(value => {
      if (value.name === event.value) {
        value.versionStatus = true;
      } else {
        value.versionStatus = false;
      }
      return value;
    });
  }
}
