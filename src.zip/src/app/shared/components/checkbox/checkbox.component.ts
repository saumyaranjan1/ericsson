import { Component, OnInit, OnChanges, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-checkbox',
  templateUrl: './checkbox.component.html',
  styleUrls: ['./checkbox.component.less']
})
export class CheckboxComponent implements OnInit, OnChanges {

  @Input() value;
  @Input() label;
  @Input() labelclass;
  @Input() iconCondition;
  @Input() disableCheckBox;
  @Output() check = new EventEmitter();
  @Output() valueChange = new EventEmitter();
  @Output() iconClick = new EventEmitter();

  checked: any;
  constructor() { }

  ngOnInit() {
  }

  openSelectionPopup(event){
    this.iconClick.emit(event);
  }

  ngOnChanges() {
    this.checked = this.value;
  }

  toggleCheckbox(event) {
    let condition;
    if (this.disableCheckBox === 'true' || this.disableCheckBox=='view' ) {
     condition = true;
    } else if (this.disableCheckBox === 'false' || this.disableCheckBox === 'undefined') {
      condition = false;
    }
    if (!condition) {
      event.preventDefault();
      event.stopPropagation();
      this.checked = !this.checked;
      this.valueChange.emit(this.checked);
      this.check.emit(this.checked);
    }
  }

}
