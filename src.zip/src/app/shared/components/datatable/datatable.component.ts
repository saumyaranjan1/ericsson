import {
  Component,
  OnInit,
  OnChanges,
  Input,
  Output,
  EventEmitter,
  ViewChildren
} from '@angular/core';
import { EnumsService } from '../../services/enums.service';

@Component({
  selector: 'app-datatable',
  templateUrl: './datatable.component.html',
  styleUrls: ['./datatable.component.less']
})
export class DatatableComponent implements OnInit, OnChanges {
  @Input() data;
  @Output() delete = new EventEmitter();
  @Output() getRefreshData = new EventEmitter();
  @Output() view = new EventEmitter();
  @Output() edit = new EventEmitter();
  @Output() share = new EventEmitter();
  @Output() key = new EventEmitter();
  @Output() approve = new EventEmitter();
  @Output() reject = new EventEmitter();
  @Output() check = new EventEmitter();
  @Output() uncheck = new EventEmitter();
  @Output() addnew = new EventEmitter();
  @Output() install = new EventEmitter();
  @Output() clearSearch = new EventEmitter();
  @Output() search = new EventEmitter();
  @Output() pending = new EventEmitter();
  @Output() viewconfig = new EventEmitter();
  @Output() viewimei = new EventEmitter();
  @Output() download = new EventEmitter();
  @Output() globalDownload = new EventEmitter();
  @Output() globalUpload = new EventEmitter();
  @Output() createDevice = new EventEmitter();
  @Output() roleCategoryAction = new EventEmitter();
  @Output() getDeviceList = new EventEmitter();
  @Output() bulkUpload = new EventEmitter();
  @Output() redirecturl = new EventEmitter();
  @Output() activateOrDeActivate = new EventEmitter();
  @Output() searchParam = new EventEmitter();
  @Output() downloadDataFile = new EventEmitter();
  @Output() exportDataToCsv = new EventEmitter();
  @Output() uploadError = new EventEmitter();
  @Output() duplicate = new EventEmitter();
  @Output() upDownRoleCategory = new EventEmitter<{ roleLevelData: any, roleStatus: any, roleCategoryIndex: any }>();
  showEditButton;

  searchValue: String = '';

  headerDropdownList: any;
  filterData
  pagePerItems = [
    { value: 5 },
    { value: 10 },
    { value: 20 },
    { value: 30 },
    { value: 40 },
    { value: 50 },
    { value: 100 }
  ];
  pagiantionObj = {
    page: 1,
    limit: 10,
    offset: 0
  };

  sorting = {
    column: null,
    descending: false
  };
  pagination = {
    page: 0,
    startIndex: 0,
    countPerPage: EnumsService.paginationObj.recordsPerPage,
    maxSize: 5,
    displyedResults: 0,
    stratingNumberOfSelectedPage: 0
  };

  actionEdit = { type: 'edit', disableIconProp: true, title: 'Edit User' };
  actionDelete = { type: 'delete', disableIconProp: true, title: 'Delete User' };
  actionUpDown = { type: 'updown', disableIconProp: true, title: 'Up Down User' };
  actionDuplicate = { type: 'duplicate', disableIconProp: true, title: 'Duplicate' };
  roleCategoryActionType = { type: 'roleCategoryAction', disableIconProp: true, title: 'Role Category Action' };

  totalRecords = 0;
  showSearchBox = false;
  editCache = {};
  constructor() { }
  searchFilter
  filterSearch
  roleLevelData;
  ngOnInit() {
    this.headerDropdownList = [
      {
        displayName: 'PARTNER NAME',
        value: 'partnerName',
       }
      ];
    this.sorting = {
      column: this.data.columns[0].key,
      descending: false
    };

    this.searchFilter = [
      {
        key: 'value',
      }
    ]
  }


  checkAll(event) {
    this.data.data.forEach(item => {
      this.editCache[item.id] = {
        check: event,
      };
    });
  }

  hideActionIcon(data, action) {
    this.totalRecords = Math.ceil(
      this.data.data.length / this.pagination.countPerPage
    );
    return action.negate
      ? action['showIconProp'] && data[action['showIconProp']]
      : action['showIconProp'] && !data[action['showIconProp']];
  }

  ngOnChanges() {
    // may not be required
    this.data = this.data;
    const param = {
      'checked': false
    }
    this.checkAll(param);
    this.filterData = this.data.data;
  }

  selectedClass(columnName) {
    if (columnName === this.sorting.column) {
      return this.sorting.descending ? ' fa-arrow-up' : 'fa-arrow-down';
    } else {
      return 'fa-arrow-up';

    }
  }
  pageChanged() {
    const page = this.pagination.page;
    const countPerPage = this.pagination.countPerPage;
    const length = this.data.data.length;

    this.pagination.displyedResults =
      (page - 1) * countPerPage + countPerPage > length
        ? length
        : (page - 1) * countPerPage + countPerPage;

    this.pagination.stratingNumberOfSelectedPage = (page - 1) * countPerPage + 1;
  }
  disableIcon(data, action) {
    let cssClass = '';
    let disable;
    if (data.disable && action.type === 'delete') {
      disable = 'disabled';
    }
    cssClass = 'parent ' + disable;
    return cssClass;
  }
  getActionClass(data, action) {
    // console.table(data);
    let cssClass = '';
    const disable = data.status === 'Approved' ? 'disabled' : '';
    switch (action.type) {
      // case 'delete': cssClass = 'fa-trash'; break;
      case 'delete':
        cssClass = '';
        break;
      case 'view':
        cssClass = '';
        break;
      case 'edit':
        cssClass = '';
        break;
      case 'install':
        cssClass = '';
        break;
    }
    // cssClass = data[action['disableIconProp']] ? cssClass + ' disabled' : cssClass;
    // cssClass = action['disableIconProp'] ? cssClass : cssClass + ' disabled';
    return cssClass;
  }

  changeSorting(columnName, filterRowEvent): void {
    if (!filterRowEvent) {
      const sort = this.sorting;
      if (sort.column === columnName) {
        sort.descending = !sort.descending;
      } else {
        sort.column = columnName;
        sort.descending = false;
      }
    }
  }

  convertSorting(): string {
    return this.sorting.descending
      ? '-' + this.sorting.column
      : this.sorting.column;
  }

  addNewItem() {
    this.addnew.emit();
  }

  searchItem() {
    this.showSearchBox = !this.showSearchBox;
  }
  globalDownloadData() {
    this.globalDownload.emit();
  }
  globalUploadData() {
    this.globalUpload.emit();
  }
  downloadFile(dataItem) {
    this.downloadDataFile.emit(dataItem);
  }
  refreshItem() {
    this.getRefreshData.emit();
  }

  getDataBynewSelection(data) {
    this.pagination.countPerPage = data.value;
  }
  exportToCsv() {
    this.exportDataToCsv.emit();
  }
  validationUploadError() {
    this.uploadError.emit();
  }

  selectedValue: String = '';
  emitAction(action, dataItem, index, roleStatus?) {
    // if (action.disableIconProp && dataItem[action.disableIconProp]) {
    //   return;
    // }

    if (!action.disableIconProp) {
      return;
    }
    switch (action.type) {
      case 'delete':
        this.delete.emit(dataItem);
        break;
      case 'view':
        this.view.emit(dataItem);
        break;
      case 'edit':
        this.edit.emit(dataItem);
        break;
      case 'install':
        this.install.emit(dataItem);
        break;
      case 'approve':
        this.approve.emit(dataItem);
        break;
      case 'reject':
        this.reject.emit(dataItem);
        break;
      case 'createDevice':
        this.createDevice.emit(dataItem);
        break;
      case 'redirecturl':
        this.redirecturl.emit(dataItem)
        break;
      case 'getDeviceList':
        if (this.selectedValue && this.searchValue) {
          dataItem['selectedValue'] = this.selectedValue;
          dataItem['searchValue'] = this.searchValue;
        }
        this.getDeviceList.emit(dataItem);
        break;
      case 'activateOrDeActivate':
        this.activateOrDeActivate.emit(dataItem);
        break;
      case 'updown':
        this.upDownRoleCategory.emit({ roleLevelData: this.roleLevelData, roleStatus: roleStatus, roleCategoryIndex: index });
        break;
      case 'bulkupload':
        this.bulkUpload.emit(dataItem);
        break;
      case 'duplicate':
        this.duplicate.emit(dataItem);
        break;
    }
  }

  closeMultiselectField(event) {
    if (event.target) {
      if (event.target.id !== 'multiselectList' && event.target.id !== 'multiselecthevron') {
        if (this.data && this.data.data && this.data.data.length > 0) {
          this.data.data.forEach(value => {
            if (value && value.roleCategoryName && value.roleCategoryName.length > 0) {
              value.roleCategoryName.map(mapValue => {
                mapValue.showPopup = false;
                mapValue.activeClass = false;
                return mapValue;
              });
            }
            if (value && value.abacaction) {
              value.abacaction = false;
            }
          });
          this.roleLevelData = ""
        }
      }
    }
  }
  roleCategoryChangeLevel(action, dataItem, rowIndex, index, event) {
    if (!action.disableIconProp) {
      return;
    }
    switch (action.type) {
      case 'roleCategoryAction':
        if (this.data && this.data.data && this.data.data.length > 0) {
          this.data.data.forEach(value => {
            if (value && value.roleCategoryName && value.roleCategoryName.length > 0) {
              value.roleCategoryName.map(mapValue => {
                mapValue.showPopup = false;
                mapValue.activeClass = false;
                return mapValue;
              })
            }
          });
          this.data.data[rowIndex].roleCategoryName[index].activeClass = !this.data.data[rowIndex].roleCategoryName[index].activeClass;
          this.roleLevelData = dataItem;
        }
        break;
    }
  }

  roleCategoryEmitAction(action, dataItem, rowIndex, index, event) {
    if (!action.disableIconProp) {
      return;
    }
    switch (action.type) {
      case 'roleCategoryAction':
        if (this.data && this.data.data && this.data.data.length > 0 &&
          this.data.data[rowIndex].roleCategoryName[index].showPopup === false) {
          this.data.data.forEach(value => {
            if (value && value.roleCategoryName && value.roleCategoryName.length > 0) {
              value.roleCategoryName.map(mapValue => {
                mapValue.showPopup = false;
                mapValue.activeClass = false;
                return mapValue;
              })
            }
          });
        }
        this.roleLevelData = "";
        this.data.data[rowIndex].roleCategoryName[index].showPopup = !this.data.data[rowIndex].roleCategoryName[index].showPopup;
        this.roleCategoryAction.emit(dataItem);
        event.stopPropagation();
        break;
    }
  }

  userAbacEmitAction(index, event) {
    if (this.data && this.data.data && this.data.data.length > 0 &&
      this.data.data[index].abacaction === false) {
      this.data.data.forEach(value => {
        value.abacaction = false;
      });
    }
    this.data.data[index].abacaction = !this.data.data[index].abacaction;

  }


  viewTableClick(dataItem) {
    this.view.emit(dataItem);
  }


  searchParams: any;
  searchByValue: any;
  searchErrorMsg;
  serachValue() {
    const param = {
      'searchValue': this.searchByValue,
      'dropDownValue': this.searchParams
    }
    if(this.searchParams){
      this.searchParam.emit(param);
    }else{
      this.searchErrorMsg = 'Please select dropdown value!';
    }
  }

  valueSelected(event) {
    this.searchParams = event.value;
    this.searchErrorMsg = "";
  }


  clearSearchValue() {
    this.searchByValue = '';
    this.searchParams = '';
    this.clearSearch.emit();
  }

  openPopup(index) {
    this.data.columns.forEach((item, filterid) => {
      if (filterid == index) {
        item.filterShow = !item.filterShow;
      }
    });
  }

  keyList = []
  checkFilterData(event, data, key, index) {
    if (key == 'SelectAll') {
      this.data.data = this.filterData;
      this.data.columns[index].filterData.forEach(item => {
        item.check = event;
      });
    } else {
      if (event) {
        this.keyList.push(data)
      } else {
        this.keyList.forEach((item, filterid) => {
          if (data.id == item.id) {
            this.keyList.splice(filterid, 1);
          }
        });
      }
      this.data.data = [];
      this.keyList.forEach((item, filterid) => {
        this.filterData.forEach((inneritem, innerfilterid) => {
          if (item.value == inneritem[key]) {
            this.data.data.push(inneritem)
          }
        });
      });

      if (this.keyList.length === 0) {
        this.data.data = this.filterData;
      }
    }
  }

  
  showButton(row,rowIndex){
   this.data.data.forEach((element,key) => {
     if(key==rowIndex){
      element.showEditButton=!element.showEditButton;
     }else{
      element.showEditButton=false;
     }
   });
  }

  emitEditAction(dataItem,index){
    this.edit.emit(dataItem);
    this.data.data[index].showEditButton=false;
  }


}
