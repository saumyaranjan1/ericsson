import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ServerPaginationTableComponent } from './server-pagination-table.component';

describe('ServerPaginationTableComponent', () => {
  let component: ServerPaginationTableComponent;
  let fixture: ComponentFixture<ServerPaginationTableComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ServerPaginationTableComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ServerPaginationTableComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
