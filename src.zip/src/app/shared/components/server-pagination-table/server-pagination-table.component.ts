import { of as observableOf, Observable } from 'rxjs';

import { map, tap, delay } from 'rxjs/operators';
import {
  ChangeDetectionStrategy,
  Component,
  Input,
  OnInit,
  Output,
  OnChanges,
  EventEmitter,
  ChangeDetectorRef
} from '@angular/core';

import { EnumsService } from '../../services/enums.service';

import { DataService } from '../../services/data.service';

import { SpinnerService } from '../../services/spinner.service';

interface IServerResponse {
  data: any[];
  totalCount: number;
}

@Component({
  selector: 'app-server-pagination-table',
  templateUrl: './server-pagination-table.component.html',
  styleUrls: ['./server-pagination-table.component.less'],
})
export class ServerPaginationTableComponent implements OnInit, OnChanges {
  @Input() spData;
  @Input() coppyError;
  @Input() pageIndex;
  @Input() searchData?;
  @Input() actionsObj;
  @Input() filterList;
  @Output() delete = new EventEmitter();
  @Output() view = new EventEmitter();
  @Output() edit = new EventEmitter();
  @Output() share = new EventEmitter();
  @Output() key = new EventEmitter();
  @Output() approve = new EventEmitter();
  @Output() reject = new EventEmitter();
  @Output() check = new EventEmitter();
  @Output() uncheck = new EventEmitter();
  @Output() addnew = new EventEmitter();
  @Output() search = new EventEmitter();
  @Output() pending = new EventEmitter();
  @Output() viewconfig = new EventEmitter();
  @Output() viewimei = new EventEmitter();
  @Output() download = new EventEmitter();
  @Output() globalDownload = new EventEmitter();
  @Output() getPaginatedData = new EventEmitter();
  @Output() showChild = new EventEmitter();
  @Output() createDevice = new EventEmitter();
  @Output() getDeviceList = new EventEmitter();
  @Output() activateOrDeActivate = new EventEmitter();
  @Output() bulkUpload = new EventEmitter();
  @Output() exportDataToCsv = new EventEmitter();
  @Output() checkBoxCheck = new EventEmitter();
  @Output() selectaAllCheck = new EventEmitter();
  @Output() filterSelecta = new EventEmitter();
  @Output() filterValuePerField = new EventEmitter();
  @Output() copyErrorJson = new EventEmitter();

  // START:: Pagination related variables
  filterData;
  searchFilter;
  checkValue = {};
  keyList = [];
  asyncspData: Observable<any>;
  p: number = this.pageIndex ? this.pageIndex : 1;
  totalCount: number;
  itemsPerPage = EnumsService.paginationObj.recordsPerPage;

  // END:: Pagination related variables

  searchValue: String = '';
  selectedValue: String = '';
  searchErrorMsg = '';
  searched = false;
  sorting = {
    column: null,
    descending: false
  };

  actionEdit = { type: 'edit', disableIconProp: true, title: 'Edit User' };
  actionShowChild = {
    type: 'showchild',
    title: 'Show Child',
    showIconProp: null,
    disableIconProp: true,
    negate: null
  };
  constructor(
    private spinnerService: SpinnerService,
    private dataService: DataService
  ) { }

  ngOnInit() {
    this.searchFilter = [
      {
        key: 'value',
      }
    ]
  }

  ngOnChanges(changes: any) {
    this.spData = this.spData;
    this.filterData = this.spData.data;
    this.p = this.pageIndex ? this.pageIndex : 1;
  }

  exportToCsv(data) {
    this.exportDataToCsv.emit(data);
  }

  pagePerItems = [
    { value: 5 },
    { value: 10 },
    { value: 20 },
    { value: 30 },
    { value: 40 },
    { value: 50 },
    { value: 100 }
  ];
  pagiantionObj = {
    pageNum: 1,
    rpp: 10,
    offset: 0
  };

  getPage(page: number) {
    this.pagiantionObj.pageNum = page;
    this.pagiantionObj.offset = (page - 1) * this.pagiantionObj.rpp;
    this.p = page;
    this.pagiantionObj['tablename'] = this.spData.tableName;
    this.getPaginatedData.emit(this.pagiantionObj);
  }

  getDataBynewSelection(data, tablename) {
    this.pagiantionObj.rpp = data.value;
    this.pagiantionObj['tablename'] = tablename;
    this.getPaginatedData.emit(this.pagiantionObj);
  }

  openPopup(index) {
    this.spData.columns.forEach((item, filterid) => {
      if (filterid == index) {
        item.filterShow = !item.filterShow;
        if (item.filterShow) {
          this.filterValuePerField.emit(item.key);
        }
        if (!item.filterShow) {
          this.spData.data = [];
          this.spData.data = this.filterData;
          this.keyList = [];
        }
      } else {
        item.filterShow = false;
      }
    });
  }

  copyErrorJsonClick(event) {
    this.copyErrorJson.emit(event);
  }

  emitTableAction(dataItem) {
    this.view.emit(dataItem);
  }


  checkFilterData(event, data, key, index) {
    if (this.spData.serverFilter) {
      let param = {
        'ckecked': event,
        'data': data,
        'key': key
      }

      this.checkValue = param;
      this.filterSelecta.emit(param);
    } else {
      if (key == 'SelectAll') {
        this.spData.data = this.filterData;
        this.spData.columns[index].filterData.forEach(item => {
          item.check = event;
        });
        this.keyList = [];
      } else {
        if (event) {
          this.keyList.push(data)
        } else {
          this.keyList.forEach((item, filterid) => {
            if (data.id == item.id) {
              this.keyList.splice(filterid, 1);
            }
          });
        }
        this.spData.data = [];
        this.keyList.forEach((item, filterid) => {
          this.filterData.forEach((inneritem, innerfilterid) => {
            if (item.value == inneritem[key]) {
              this.spData.data.push(inneritem)
            }
          });
        });

        if (this.keyList.length === 0) {
          this.spData.data = this.filterData;
        }
      }
    }

  }

  /* single checkbox select*/

  onChangeCheck(event, row) {
    let dataItem = {
      'checked': event.checked,
      'row': row
    }
    this.checkBoxCheck.emit(dataItem);
  }


  selectAllcheck(event) {
    this.selectaAllCheck.emit(event);
  }

  closeFilterArea(event, filterindex,key) {
     if (event.target && event.target.id !== 'reloaderIcon' && event.target.id !== 'filterList'+this.spData.columns[filterindex].key ) {
      this.spData.columns[filterindex].filterShow=false;
    }
 
  }

}
