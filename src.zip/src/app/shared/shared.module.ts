import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA  } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgxPaginationModule} from 'ngx-pagination';
import { JwtHelperService } from '@auth0/angular-jwt';
import { BnNgIdleService } from 'bn-ng-idle';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';

// Pipes
import { FormatPipe } from './pipes/format.pipe';
import { OrderByPipe } from './pipes/order-by.pipe';
import { FilterPipe } from './pipes/filter.pipe';
import {ruleExpressionFilterPipe} from './pipes/rule-expression-filter.pipe';
import { SplitWord } from './pipes/split-word.pipe';
import { CharacterCountPipe } from './pipes/character-count.pipe';

// Directives
import { ClickOutsideDirective } from './directives/click-outside.directive';
import { TooltipDirective } from './directives/tooltip.directive';
import { HidepopoverDirective } from './directives/hidepopover.directive';
import { BlockCopyPasteDirective } from './directives/block-copy-paste.directive';
import { EqualValidatorDirective } from './directives/equal-validator.directive';
import { AppPasswordDirective } from '../shared/directives/app-password.directive';
import { DynamicFieldDirective } from '../shared/directives/dynamic-field';
import { ProgressBarColor } from '../shared/directives/progress-bar-color';


// Services
import { UrlMappingsService } from './services/url-mappings.service';
import { InterceptorService } from './services/interceptor.service';
import { DeleteIntercepterService } from './services/delete-ajax-method.service';
import { UtilService } from './services/util.service';
import { SpinnerService } from './services/spinner.service';
import { EnumsService} from './services/enums.service';
import { UserService } from './services/user.service';

// AuthGuard related services
import { AuthGuardService as AuthGuard } from './authGuard/auth-guard.service';
import { LoginAuthGuardService as LoginAuthGuard } from './authGuard/login-auth-guard.service';
import { AuthorizationService } from './authGuard/authorization.service';

// Components
import { ToggleSwitchComponent } from './components/toggle-switch/toggle-switch.component';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { CheckboxComponent } from './components/checkbox/checkbox.component';
import { PasswordStrengthComponent } from './components/password-strength/password-strength.component';
import { DatatableComponent } from './components/datatable/datatable.component';
import { MakerCheckerComponent } from './components/maker-checker/maker-checker.component';
import { LoaderComponent } from './components/loader/loader.component';
import { ServerPaginationTableComponent } from './components/server-pagination-table/server-pagination-table.component';
import { ServerPaginationComponent } from './components/server-pagination/server-pagination.component';
import { CommonMethodsService } from './methods/common-methods';
import { BasicAuthHtppInterceptorService } from './authGuard/basic-auth-htpp-interceptor.service';
import { MatRadioModule,MatDatepickerModule, MatCheckboxModule, MatListModule, MatSelectModule, MatFormFieldModule, MatInputModule, MatNativeDateModule  } from '@angular/material';
import {MatProgressBarModule} from '@angular/material/progress-bar';

import { MatTabsModule} from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { InlinePagenationTableComponent } from './components/inline-pagenation-table/inline-pagenation-table.component';
import { DynamicFormComponent } from './components/dynamic-form/dynamic-form.component';
import { NgxMaterialTimepickerModule} from 'ngx-material-timepicker';
import { InputComponent } from './components/dynamic-form/input/input.component';
import { ButtonComponent } from './components/dynamic-form/button/button.component';
import { SelectComponent } from './components/dynamic-form/select/select.component';
import { ScrollingModule } from '@angular/cdk/scrolling';

const providersArray = [
  UrlMappingsService,
  InterceptorService,
  DeleteIntercepterService,
  UtilService,
  SpinnerService,
  EnumsService,
  UserService,
  AuthGuard,
  LoginAuthGuard,
  HttpClientModule,
  CommonMethodsService,
  JwtHelperService,
  BnNgIdleService,
  AuthorizationService,
  {
    provide: HTTP_INTERCEPTORS, useClass: BasicAuthHtppInterceptorService, multi: true
  }
];
const exportsArray = [
  DatatableComponent,
  MakerCheckerComponent,
  CheckboxComponent,
  PasswordStrengthComponent,
  ToggleSwitchComponent,
  InlinePagenationTableComponent,
  BreadcrumbComponent,
  FormatPipe,
  OrderByPipe,
  FilterPipe,
  ruleExpressionFilterPipe,
  SplitWord,
  FormsModule,
  ReactiveFormsModule,
  NgbModule,
  ClickOutsideDirective,
  TooltipDirective,
  LoaderComponent,
  HidepopoverDirective,
  CharacterCountPipe,
  BlockCopyPasteDirective,
  EqualValidatorDirective,
  AppPasswordDirective,
  DynamicFieldDirective,
  ProgressBarColor,
  ServerPaginationTableComponent,
  DynamicFormComponent,
  InputComponent,
  ButtonComponent,
  SelectComponent,
  ServerPaginationComponent,
  MatTabsModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatRadioModule,
  MatProgressBarModule,
  MatTooltipModule,
  MatCheckboxModule,
  MatListModule,
  MatSelectModule,
  MatFormFieldModule,
  MatInputModule,
  AngularMultiSelectModule,
  NgxPaginationModule,
  NgxMaterialTimepickerModule,
  ScrollingModule
];
const declarationsArray = [
  DatatableComponent,
  MakerCheckerComponent,
  InlinePagenationTableComponent,
  FormatPipe,
  OrderByPipe,
  CheckboxComponent,
  PasswordStrengthComponent,
  ToggleSwitchComponent,
  BreadcrumbComponent,
  FilterPipe,
  ruleExpressionFilterPipe,
  SplitWord,
  ClickOutsideDirective,
  TooltipDirective,
  LoaderComponent,
  HidepopoverDirective,
  CharacterCountPipe,
  BlockCopyPasteDirective,
  EqualValidatorDirective,
  AppPasswordDirective,
  DynamicFieldDirective,
  ProgressBarColor,
  ServerPaginationTableComponent,
  DynamicFormComponent,
  InputComponent,
  ButtonComponent,
  SelectComponent,
  ServerPaginationComponent
];
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    NgbModule,
    HttpClientModule,
    NgxPaginationModule,
    MatTabsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatRadioModule,
    MatProgressBarModule,
    MatTooltipModule,
    MatCheckboxModule,
    MatListModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
    AngularMultiSelectModule,
    NgxMaterialTimepickerModule,
    ScrollingModule
  ],
  providers: providersArray,
  entryComponents: [
    InputComponent,
    ButtonComponent,
    SelectComponent
    ],
  exports: exportsArray,
  declarations: declarationsArray,
  schemas: [ CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA ]
})
export class SharedModule { }
