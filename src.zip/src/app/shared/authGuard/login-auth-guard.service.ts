import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { SpinnerService } from '../services/spinner.service';
@Injectable()
export class LoginAuthGuardService implements CanActivate {
  constructor(public router: Router, private spinnerService: SpinnerService) {}
  canActivate(): boolean {
    this.spinnerService.toggleSpinner(0);
    if (sessionStorage.getItem('user')) {
        this.router.navigate(['../main']);
      } else {
        return true;
      }
  }
}
