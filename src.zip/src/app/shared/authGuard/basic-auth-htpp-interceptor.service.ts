import { Injectable } from '@angular/core';

import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler
} from '@angular/common/http';
import { AuthorizationService } from './authorization.service';
@Injectable({
  providedIn: 'root'
})
export class BasicAuthHtppInterceptorService implements HttpInterceptor {
  
  user:any;

  constructor(
    private authorizationService: AuthorizationService
  ) {}

  intercept(req: HttpRequest<any>, next: HttpHandler) {
    this.user = sessionStorage.getItem('user') || null;
 
    if (this.user) {
      req = req.clone({
        setHeaders: {
          userId: sessionStorage.getItem('loginMember'),
          Authorization: this.authorizationService.getToken()
        }
      });
     }
    return next.handle(req);
  }
}
