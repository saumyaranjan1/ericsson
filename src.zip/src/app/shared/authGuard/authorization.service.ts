import { Injectable } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { DataService } from '../services/data.service';
@Injectable({
  providedIn: 'root'
})
export class AuthorizationService {
  constructor(
    private jwtHelperService: JwtHelperService,
    private dataService: DataService
  ) {}

  isAuthorized(allowedRoles: string[]): boolean {
    return true;
  }

  getToken() {
    // get token from local storage
    const user = this.dataService.getLocalStorage('user');
    if (user && user.access_token) {
        return user.access_token;
    } else {
      this.deleteStorage();
    }
  }

  getRefreshToken() {
    // get refresh-token from local storage
    const refreshToken = this.dataService.getLocalStorage('refresh_token');
    if (refreshToken) {
      return refreshToken;
    } else {
      this.deleteStorage();
    }
  }
  getRole() {
    const role = String.prototype.toUpperCase.apply(this.dataService.getAtobLocalStorage('role'));
    return role;
  }
  getExpTime() {
    const user = this.dataService.getLocalStorage('user');
    return user['expires_in'];
  }
  getExpTimeInMinutes() {
    const user = this.dataService.getLocalStorage('user');
    return user['expires_in'] / ( 60 * 2 );
  }
  getLoginTime() {
    const user = this.dataService.getLocalStorage('user');
    return user.loginTime ;
  }
  deleteStorage() {
    this.dataService.removeLocalStorage('user');
    this.dataService.removeLocalStorage('role');
    this.dataService.removeLocalStorage('previlages');
    sessionStorage.clear();
    window.location.reload();
  }
}
