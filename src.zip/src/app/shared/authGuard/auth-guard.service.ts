import { Injectable } from '@angular/core';
import {
  Router,
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot
} from '@angular/router';
import { AuthorizationService } from './authorization.service';
import { SpinnerService } from '../services/spinner.service';
import { EnumsService } from '../services/enums.service';
import { InterceptorService } from '../services/interceptor.service';
import { DataService } from '../services/data.service';
@Injectable()
export class AuthGuardService implements CanActivate {
  constructor(
    public router: Router,
    private authorizationService: AuthorizationService,
    private spinnerService: SpinnerService,
    private interceptorService: InterceptorService,
    private dataService: DataService
  ) { }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot
  ): boolean {
    this.spinnerService.toggleSpinner(0);
    if (!sessionStorage.getItem('user')) {
      this.router.navigate(['../login'], {
        queryParams: { returnUrl: state.url }
      });
      return false;
    } else {
      this.deleteStorageData();
    }
    return true;
  }
  canActivateChild(next: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
    if (sessionStorage.getItem('user') && sessionStorage.getItem('previlages')) {
      this.deleteStorageData();
      const rolesArray = this.getRoles(next);
      // if (!rolesArray) {
      //   // if not authorized, show access denied message
      //   this.spinnerService.toggleSpinner(0);
      //   this.router.navigate(['/access-denied']);
      //   return false;
      // } else {
      return true;
      //  }
    } else {
      const updatePassword = this.dataService.getLocalStorage('update-password');
      if (!updatePassword) {
        this.interceptorService.deleteStorageData();
        this.router.navigate(['../login'], {
          queryParams: { returnUrl: state.url }
        });
      }
    }
    return true;
  }

  getRoles(next) {
    const uri = next.data.breadcrumb.route;
    const title = next.data.breadcrumb.title;
    const moduleCode = next.data.breadcrumb.route;
    const previlages = this.dataService.getAtobLocalStorage('previlages');
    const roles = previlages.filter((item) => {
      return (item.moduleCode.toLowerCase() === moduleCode && item.isWebRole && item.isWebRole === 'Y');
    });
    return roles[0];
  }

  deleteStorageData() {
    const myDate = new Date(); // Your timezone!
    const currentEpcohTime = Math.floor(myDate.getTime() / 1000.0);
    const loginEpcohTime = this.authorizationService.getLoginTime();
    const diff = (currentEpcohTime - loginEpcohTime) / 60;
    if (EnumsService.MAX_SESSION_TIMEOUT_IN_MIN <= diff) {
      this.interceptorService.deleteStorageData();
    }
  }

}
