import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormArray,
  FormControl
} from '@angular/forms';
import { PartnerService } from './partner.service';
import { DataService } from '../shared/services/data.service';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { DatatableComponent } from '../shared/components/datatable/datatable.component';
import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';
import { AppConfigService } from '../app-config.service';
import { RoleManagementService } from '../role-management/role-management.service';

@Component({
  selector: 'app-partner',
  templateUrl: './partner.component.html',
  styleUrls: ['./partner.component.less']
})
export class PartnerComponent implements OnInit {
  @ViewChild('addPartnerContent', { static: false }) addPartnerContent: ElementRef;
  @ViewChild('deleteConfirmModalContent', { static: false }) deleteConfirmModalContent: ElementRef;
  @ViewChild(DatatableComponent, { static: false }) child: DatatableComponent;
  partnerTable=true;
  configModalOptionMode = null;
  modalConfig = {
    create: { headerText: 'Create New Partner', primeBtnText: 'Create' },
    edit: { headerText: 'Edit Partner', primeBtnText: 'Update' },
    sige: { sm: 'sm', lg: 'lg' }
  };

  data = {
    data: [],
    columns: [
      {
        displayName: 'partner Name',
        key: 'partnerName',
        filter: ''
      },
      {
        displayName: 'Admin UserName',
        key: 'userName',
        filter: ''
      },
      {
        displayName: 'URL FOR DEVICE ASSOCIATION',

        key: 'partnerUrl',
        filter: ''
      },
      {
        displayName: 'URL FOR DATA VIEW',
        key: 'portalUrl',
        filter: ''
      },
      {
        displayName: 'Organizational user email',
        key: 'orgEmailId',
        filter: ''
      }
    ],
    actions: [
      // {
      //   type: 'edit',
      //   title: 'Edit Partner',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'delete',
      //   title: 'Delete Partner',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // }

    ],
    actionsLabel: 'Actions',
    dots:true,
    tableHeader: 'List of Partners',
    tabelTooltip: 'This is the index page which shows the list of Partners',
    tableActions: {
      // search: true,
      // add: true,
      // view: false,
      // delete: true,
      // edit: true,
      // showCheck:true,
      // deleteAction:true
    }
  };
  partnerInfo;
  errorFile = false;
  errorMsg;
  uploadedFile;
  uploadedFileExtension;
  uploadedFileName;
  partnerForm: FormGroup;
  serviceValue = ['YES', 'NO'];
  radioButtonList = [
    {
      name: 'PARTNER',
      value: 'PARTNER',
      checked: true
    },
    {
      name: 'DIRECT',
      value: 'DIRECT',
      checked: false
    },
    {
      name: 'FIXED',
      value: 'FIXED',
      checked: false
    },
    {
      name: 'CONNECTION ONLY',
      value: 'CO',
      checked: false
    }
  ];

  serviceList = [
    'customerCredential',
    'streamConsumer'
  ]

  showPasswordValidationMsg = true;
  partnerDetails = '';
  actionsArr;
  hidePartnerFields = true;
  roleList;
  constructor(
    private ngbModal: NgbModal,
    private partnerService: PartnerService,
    private dataService: DataService,
    private fb: FormBuilder,
    private userService: UserService,
    private cms: CommonMethodsService,
    private roleManagementService: RoleManagementService,
    private appConfigService: AppConfigService
  ) { }

  ngOnInit() {
    this.getPartnerDetails();
    this.partnerFormBloack();
    this.getRolesByCategory();
  }

  partnerIdValidation() {
    const partnerComponent = this.partnerForm.value['partnerId'];

    if (partnerComponent) {
      this.appConfigService.configData['partnerIds'].forEach(element => {
        if (partnerComponent == element) {
          return true;
        }
      });
    }

    return null;
  }
  partnerTypeChange(event) {
    if (event.value == 'PARTNER') {
      this.hidePartnerFields = true;

      this.partnerForm.get('loginURL').setValidators([
        Validators.required,
        this.cms.patternValidator(
          /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
          { isValidUrl: true }
        )
      ]);
      this.partnerForm.get('loginURL').updateValueAndValidity();

      this.partnerForm.get('portalUrl').setValidators([
        Validators.required,
        this.cms.patternValidator(
          /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
          { isValidUrl: true }
        )
      ]);
      this.partnerForm.get('portalUrl').updateValueAndValidity();

      this.partnerForm.get('serviceNames').setValidators([Validators.required]);
      this.partnerForm.get('serviceNames').updateValueAndValidity();

      this.partnerForm.get('roleId').setValidators([Validators.required]);
      this.partnerForm.get('roleId').updateValueAndValidity();

      this.partnerForm.get('orgEmailId').setValidators([Validators.required, Validators.email]);
      this.partnerForm.get('orgEmailId').updateValueAndValidity();

      this.partnerForm.get('partnerUrl').setValidators([
        Validators.required,
        this.cms.patternValidator(
          /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
          { isValidUrl: true }
        )
      ]);
      this.partnerForm.get('partnerUrl').updateValueAndValidity();

      this.partnerForm.get('userName').setValidators([Validators.required]);
      this.partnerForm.get('userName').updateValueAndValidity();

      this.partnerForm.get('password').setValidators([Validators.required]);
      this.partnerForm.get('password').updateValueAndValidity();

      this.partnerForm.get('confirmPassword').setValidators([Validators.required]);
      this.partnerForm.get('confirmPassword').updateValueAndValidity();

      this.partnerForm.controls['engLead'].get('name').setValidators([Validators.required]);
      this.partnerForm.controls['engLead'].get('name').updateValueAndValidity();

      this.partnerForm.controls['engLead'].get('email').setValidators([Validators.required]);
      this.partnerForm.controls['engLead'].get('email').updateValueAndValidity();

      this.partnerForm.controls['engLead'].get('phone').setValidators([Validators.required]);
      this.partnerForm.controls['engLead'].get('phone').updateValueAndValidity();

      this.partnerForm.controls['opEng'].get('name').setValidators([Validators.required]);
      this.partnerForm.controls['opEng'].get('name').updateValueAndValidity();

      this.partnerForm.controls['opEng'].get('email').setValidators([Validators.required]);
      this.partnerForm.controls['opEng'].get('email').updateValueAndValidity();

      this.partnerForm.controls['opEng'].get('phone').setValidators([Validators.required]);
      this.partnerForm.controls['opEng'].get('phone').updateValueAndValidity();

      this.partnerForm.controls['businessHead'].get('name').setValidators([Validators.required]);
      this.partnerForm.controls['businessHead'].get('name').updateValueAndValidity();

      this.partnerForm.controls['businessHead'].get('email').setValidators([Validators.required]);
      this.partnerForm.controls['businessHead'].get('email').updateValueAndValidity();

      this.partnerForm.controls['businessHead'].get('phone').setValidators([Validators.required]);
      this.partnerForm.controls['businessHead'].get('phone').updateValueAndValidity();

      this.whiteListedIps.at(0).get('ip').setValidators([Validators.required]);
      this.whiteListedIps.at(0).get('ip').updateValueAndValidity();


    } else {
      this.hidePartnerFields = false;

      this.partnerForm.get('loginURL').clearValidators();
      this.partnerForm.get('loginURL').updateValueAndValidity();

      this.partnerForm.get('serviceNames').clearValidators();
      this.partnerForm.get('serviceNames').updateValueAndValidity();

      this.partnerForm.get('portalUrl').clearValidators();
      this.partnerForm.get('portalUrl').updateValueAndValidity();

      this.partnerForm.get('roleId').clearValidators();
      this.partnerForm.get('roleId').updateValueAndValidity();

      this.partnerForm.get('orgEmailId').clearValidators();
      this.partnerForm.get('orgEmailId').updateValueAndValidity();

      this.partnerForm.get('partnerUrl').clearValidators();
      this.partnerForm.get('partnerUrl').updateValueAndValidity();

      this.partnerForm.controls['engLead'].get('name').clearValidators();
      this.partnerForm.controls['engLead'].get('name').updateValueAndValidity();

      this.partnerForm.controls['engLead'].get('email').clearValidators();
      this.partnerForm.controls['engLead'].get('email').updateValueAndValidity();

      this.partnerForm.controls['engLead'].get('phone').clearValidators();
      this.partnerForm.controls['engLead'].get('phone').updateValueAndValidity();

      this.partnerForm.controls['opEng'].get('name').clearValidators();
      this.partnerForm.controls['opEng'].get('name').updateValueAndValidity();

      this.partnerForm.controls['opEng'].get('email').clearValidators();
      this.partnerForm.controls['opEng'].get('email').updateValueAndValidity();

      this.partnerForm.controls['opEng'].get('phone').clearValidators();
      this.partnerForm.controls['opEng'].get('phone').updateValueAndValidity();

      this.partnerForm.controls['businessHead'].get('name').clearValidators();
      this.partnerForm.controls['businessHead'].get('name').updateValueAndValidity();

      this.partnerForm.controls['businessHead'].get('email').clearValidators();
      this.partnerForm.controls['businessHead'].get('email').updateValueAndValidity();

      this.partnerForm.controls['businessHead'].get('phone').clearValidators();
      this.partnerForm.controls['businessHead'].get('phone').updateValueAndValidity();

      this.partnerForm.get('userName').clearValidators();
      this.partnerForm.get('userName').updateValueAndValidity();

      this.partnerForm.get('password').clearValidators();
      this.partnerForm.get('password').updateValueAndValidity();

      this.partnerForm.get('confirmPassword').clearValidators();
      this.partnerForm.get('confirmPassword').updateValueAndValidity();

      this.whiteListedIps.at(0).get('ip').clearValidators();
      this.whiteListedIps.at(0).get('ip').updateValueAndValidity();

    }


    // if (event.value == 'CO') {
    //   this.partnerForm.get('loginURL').clearValidators();
    //   this.partnerForm.get('loginURL').updateValueAndValidity();

    //   this.partnerForm.get('serviceNames').clearValidators();
    //   this.partnerForm.get('serviceNames').updateValueAndValidity();

    //   this.partnerForm.get('portalUrl').clearValidators();
    //   this.partnerForm.get('portalUrl').updateValueAndValidity();

    //   this.partnerForm.get('roleId').clearValidators();
    //   this.partnerForm.get('roleId').updateValueAndValidity();

    //   this.partnerForm.get('orgEmailId').clearValidators();
    //   this.partnerForm.get('orgEmailId').updateValueAndValidity();

    //   this.partnerForm.get('partnerUrl').clearValidators();
    //   this.partnerForm.get('partnerUrl').updateValueAndValidity();

    //   this.partnerForm.controls['engLead'].get('name').clearValidators();
    //   this.partnerForm.controls['engLead'].get('name').updateValueAndValidity();

    //   this.partnerForm.controls['engLead'].get('email').clearValidators();
    //   this.partnerForm.controls['engLead'].get('email').updateValueAndValidity();

    //   this.partnerForm.controls['engLead'].get('phone').clearValidators();
    //   this.partnerForm.controls['engLead'].get('phone').updateValueAndValidity();

    //   this.partnerForm.controls['opEng'].get('name').clearValidators();
    //   this.partnerForm.controls['opEng'].get('name').updateValueAndValidity();

    //   this.partnerForm.controls['opEng'].get('email').clearValidators();
    //   this.partnerForm.controls['opEng'].get('email').updateValueAndValidity();

    //   this.partnerForm.controls['opEng'].get('phone').clearValidators();
    //   this.partnerForm.controls['opEng'].get('phone').updateValueAndValidity();

    //   this.partnerForm.controls['businessHead'].get('name').clearValidators();
    //   this.partnerForm.controls['businessHead'].get('name').updateValueAndValidity();

    //   this.partnerForm.controls['businessHead'].get('email').clearValidators();
    //   this.partnerForm.controls['businessHead'].get('email').updateValueAndValidity();

    //   this.partnerForm.controls['businessHead'].get('phone').clearValidators();
    //   this.partnerForm.controls['businessHead'].get('phone').updateValueAndValidity();

    //   this.partnerForm.get('userName').clearValidators();
    //   this.partnerForm.get('userName').updateValueAndValidity();

    //   this.partnerForm.get('password').clearValidators();
    //   this.partnerForm.get('password').updateValueAndValidity();

    //   this.partnerForm.get('confirmPassword').clearValidators();
    //   this.partnerForm.get('confirmPassword').updateValueAndValidity();

    //   this.whiteListedIps.at(0).get('ip').clearValidators();
    //   this.whiteListedIps.at(0).get('ip').updateValueAndValidity();
    // } else {
    //   this.partnerForm.get('loginURL').setValidators([
    //     Validators.required,
    //     this.cms.patternValidator(
    //       /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
    //       { isValidUrl: true }
    //     )
    //   ]);
    //   this.partnerForm.get('loginURL').updateValueAndValidity();

    //   this.partnerForm.get('portalUrl').setValidators([
    //     Validators.required,
    //     this.cms.patternValidator(
    //       /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
    //       { isValidUrl: true }
    //     )
    //   ]);
    //   this.partnerForm.get('portalUrl').updateValueAndValidity();

    //   this.partnerForm.get('serviceNames').setValidators([Validators.required]);
    //   this.partnerForm.get('serviceNames').updateValueAndValidity();

    //   this.partnerForm.get('roleId').setValidators([Validators.required]);
    //   this.partnerForm.get('roleId').updateValueAndValidity();

    //   this.partnerForm.get('orgEmailId').setValidators([Validators.required, Validators.email]);
    //   this.partnerForm.get('orgEmailId').updateValueAndValidity();

    //   this.partnerForm.get('partnerUrl').setValidators( [
    //     Validators.required,
    //     this.cms.patternValidator(
    //       /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
    //       { isValidUrl: true }
    //     )
    //   ]);
    //   this.partnerForm.get('partnerUrl').updateValueAndValidity();

    //   this.partnerForm.get('userName').setValidators([Validators.required]);
    //   this.partnerForm.get('userName').updateValueAndValidity();

    //   this.partnerForm.get('password').setValidators([Validators.required]);
    //   this.partnerForm.get('password').updateValueAndValidity();

    //   this.partnerForm.get('confirmPassword').setValidators([Validators.required]);
    //   this.partnerForm.get('confirmPassword').updateValueAndValidity();

    //   this.partnerForm.controls['engLead'].get('name').setValidators([Validators.required]);
    //   this.partnerForm.controls['engLead'].get('name').updateValueAndValidity();

    //   this.partnerForm.controls['engLead'].get('email').setValidators([Validators.required]);
    //   this.partnerForm.controls['engLead'].get('email').updateValueAndValidity();

    //   this.partnerForm.controls['engLead'].get('phone').setValidators([Validators.required]);
    //   this.partnerForm.controls['engLead'].get('phone').updateValueAndValidity();

    //   this.partnerForm.controls['opEng'].get('name').setValidators([Validators.required]);
    //   this.partnerForm.controls['opEng'].get('name').updateValueAndValidity();

    //   this.partnerForm.controls['opEng'].get('email').setValidators([Validators.required]);
    //   this.partnerForm.controls['opEng'].get('email').updateValueAndValidity();

    //   this.partnerForm.controls['opEng'].get('phone').setValidators([Validators.required]);
    //   this.partnerForm.controls['opEng'].get('phone').updateValueAndValidity();

    //   this.partnerForm.controls['businessHead'].get('name').setValidators([Validators.required]);
    //   this.partnerForm.controls['businessHead'].get('name').updateValueAndValidity();

    //   this.partnerForm.controls['businessHead'].get('email').setValidators([Validators.required]);
    //   this.partnerForm.controls['businessHead'].get('email').updateValueAndValidity();

    //   this.partnerForm.controls['businessHead'].get('phone').setValidators([Validators.required]);
    //   this.partnerForm.controls['businessHead'].get('phone').updateValueAndValidity();

    //   this.whiteListedIps.at(0).get('ip').setValidators([Validators.required]);
    //   this.whiteListedIps.at(0).get('ip').updateValueAndValidity();
    // }

  }


  partnerFormBloack(event?) {
    this.partnerForm = this.fb.group(
      {
        loginURL: [
          event ? event.loginURL : null,
          [
            Validators.required,
            this.cms.patternValidator(
              /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
              { isValidUrl: true }
            )
          ]
        ],
        partnerId: [event ? event.partnerId : null,
        [
          Validators.required,
          this.cms.checkValidPartner({ isValidPartner: true })
        ]

        ],
        userName: [event ? event.userName : null, Validators.required],
        password: [
          event ? event.password : null,
          [
            Validators.required
          ]
        ],
        confirmPassword: [event ? event.password : null, Validators.required],
        partnerName: [event ? event.partnerName : null, Validators.required],
        partnerUrl: [
          event ? event.partnerUrl : null,
          [
            Validators.required,
            this.cms.patternValidator(
              /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
              { isValidUrl: true }
            )
          ]
        ],
        portalUrl: [
          event ? event.portalUrl : null,
          [
            Validators.required,
            this.cms.patternValidator(
              /^(?:http(s)?:\/\/)?[\w.-]+(?:\.[\w\.-]+)+[\w\-\._~:/?#[\]@!\$&'\(\)\*\+,;=.]+$/,
              { isValidUrl: true }
            )
          ]
        ],
        partnerType: [
          event ? event.partnerType : 'PARTNER',
          Validators.required
        ],
        serviceNames: [event ? event.serviceNames : null, Validators.required],
        partnerNotificationStatus: [event ? event.partnerNotificationStatus : false],
        orgEmailId: [event && event.orgEmailId ? event.orgEmailId : null, [Validators.required, Validators.email]],
        roleId: [event && event.roleId ? event.roleId : null, Validators.required],
        whiteListedIps: event && event.whiteListedIps ? this.getWhiteListedIpsTypeValues(event.whiteListedIps) : new FormArray([]),
        serviceInfo: event && event.serviceInfo ? this.getServiceTypeValues(event.serviceInfo) : new FormArray([]),
        engLead: this.fb.group({
          name: [
            event ? (event.engLead ? event.engLead.name : null) : null,
            Validators.required
          ],
          email: [
            event ? (event.engLead ? event.engLead.email : null) : null,
            [Validators.required, Validators.email]
          ],
          phone: [
            event ? (event.engLead ? event.engLead.phone : null) : null,
            [Validators.required, Validators.pattern('^[0-9]*$')]
          ]
        }),
        opEng: this.fb.group({
          name: [
            event ? (event.opEng ? event.opEng.name : null) : null,
            Validators.required
          ],
          email: [
            event ? (event.opEng ? event.opEng.email : null) : null,
            [Validators.required, Validators.email]
          ],
          phone: [
            event ? (event.opEng ? event.opEng.phone : null) : null,
            [Validators.required, Validators.pattern('^[0-9]*$')]
          ]
        }),
        businessHead: this.fb.group({
          name: [
            event
              ? event.businessHead
                ? event.businessHead.name
                : null
              : null,
            Validators.required
          ],
          email: [
            event
              ? event.businessHead
                ? event.businessHead.email
                : null
              : null,
            [Validators.required, Validators.email]
          ],
          phone: [
            event
              ? event.businessHead
                ? event.businessHead.phone
                : null
              : null,
            [Validators.required, Validators.pattern('^[0-9]*$')]
          ]
        })
      },
      {
        // check whether our password and confirm password match
        validator: this.cms.passwordMatchValidator
      }
    );
    if (!event) {
      this.addwhiteListedIps();
    }

     this.partnerTypeChange(this.partnerForm.controls['partnerType'])

    // if (this.partnerForm.controls['partnerType'].value == 'PARTNER') {
    //   this.hidePartnerFields = true;
    //   this.whiteListedIps.at(0).get('ip').setValidators([Validators.required]);
    //   this.whiteListedIps.at(0).get('ip').updateValueAndValidity();
    //   this.partnerForm.get('roleId').setValidators([Validators.required]);
    //   this.partnerForm.get('roleId').updateValueAndValidity();
    //   this.partnerForm.get('orgEmailId').setValidators([Validators.required, Validators.email]);
    //   this.partnerForm.get('orgEmailId').updateValueAndValidity();
    // }
    // else {
    //   this.hidePartnerFields = false;
    //   this.whiteListedIps.at(0).get('ip').clearValidators();
    //   this.whiteListedIps.at(0).get('ip').updateValueAndValidity();
    //   this.partnerForm.get('roleId').clearValidators();
    //   this.partnerForm.get('roleId').updateValueAndValidity();
    //   this.partnerForm.get('orgEmailId').clearValidators();
    //   this.partnerForm.get('orgEmailId').updateValueAndValidity();
    //  }
  }

  getWhiteListedIpsTypeValues(ipsInfo) {
    const len = this.whiteListedIps.length;
    for (let index = len; index >= 0; index--) {
      this.whiteListedIps.removeAt(index);
    }
    ipsInfo.forEach(ips => {
      this.addwhiteListedIps(ips);
    });
    return this.whiteListedIps;
  }
  addwhiteListedIps(value?) {
    this.whiteListedIps.push(this.fb.group({
      ip: new FormControl(value ? value : '', [Validators.required, this.cms.patternValidator(
        /\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(\.|$)){4}\b/,
        { isValidUrl: true }
      )])
    }));
  }
  removewhiteListedIps(i: number) {
    this.whiteListedIps.removeAt(i);
  }
  get whiteListedIps() { return this.partnerForm.controls['whiteListedIps'] as FormArray; }


  getServiceTypeValues(serviceInfo) {
    const len = this.serviceInfo.length;
    for (let index = len; index >= 0; index--) {
      this.serviceInfo.removeAt(index);
    }
    serviceInfo.forEach(service => {
      this.serviceInfo.push(this.fb.group({
        key: new FormControl(service.key, [Validators.required]),
        value: new FormControl(service.value, [Validators.required])
      }));
    });
    return this.serviceInfo;
  }
  addServices() {
    this.serviceInfo.push(this.fb.group({
      key: new FormControl('', [Validators.required]),
      value: new FormControl('', [Validators.required])
    }));
  }
  removeService(i: number) {
    this.serviceInfo.removeAt(i);
  }
  get serviceInfo() { return this.partnerForm.controls['serviceInfo'] as FormArray; }
  getValueStatus() {
    if (
      !this.partnerForm.controls['password'].hasError('minlength') &&
      !this.partnerForm.controls['password'].hasError('hasNumber') &&
      !this.partnerForm.controls['password'].hasError('hasCapitalCase') &&
      !this.partnerForm.controls['password'].hasError('hasSmallCase') &&
      !this.partnerForm.controls['password'].hasError('hasSpecialCharacters')
    ) {
      this.showPasswordValidationMsg = false;
    } else {
      this.showPasswordValidationMsg = true;
    }
  }

  submitForm(formData, close) {
    if (this.partnerForm.valid) {
      delete formData['confirmPassword'];
      this.createPartner(close, formData);
    } else {
      this.cms.validateAllFormFields(this.partnerForm);
    }
  }

  deviceBack(event){
    this.partnerTable=true;
  }
  addPartner(option) {
    this.radioButtonList = [
      {
        name: 'PARTNER',
        value: 'PARTNER',
        checked: true
      },
      {
        name: 'DIRECT',
        value: 'DIRECT',
        checked: false
      },
      {
        name: 'FIXED',
        value: 'FIXED',
        checked: false
      },
      {
        name: 'CONNECTION ONLY',
        value: 'CO',
        checked: false
      }
     ];

    this.partnerFormBloack();
    this.hidePartnerFields = true;
    this.configModalOptionMode = option.mode;
    this.partnerTable=false;
    //this.openModal(this.addPartnerContent, this.modalConfig.sige.lg);
  }
  editPartner(event, option) {
    this.partnerDetails = event;
    this.configModalOptionMode = option.mode;
    this.partnerFormBloack(event);
    
    ////radioButtonList radioButtonList this.partnerForm.value['partnerType']

    this.radioButtonList.forEach(element => {
      if (this.partnerForm.value['partnerType'] == element.name) {
        element.checked = true;
      } else {
        element.checked = false;
      }
    });


    this.partnerTable=false;


    //this.openModal(this.addPartnerContent, this.modalConfig.sige.lg, event);
  }
  openDeleteModal(event) {
    this.openModal(
      this.deleteConfirmModalContent,
      this.modalConfig.sige.sm,
      event
    );
  }



  openModal(content: any, size, event?: any) {
    this.partnerInfo = event;
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }

  closeModel(close: any) {
    close('Cross click');
  }

  createPartner(close, data?) {
    let req: object;
    let msg;
    if (this.configModalOptionMode === 'create') {
      msg = 'created ';
      req = {
        method: 'post',
        url: 'addPartner'
      };
    } else {
      msg = 'updated ';
      req = {
        method: 'put',
        url: 'updatePartner'
      };
      data['partnerUUID'] = this.partnerDetails['partnerUUID'];
    }
    // if (data['partnerType'] === 'Yes') {
    //   data['partnerType'] = 'PARTNER';
    // } else {
    //   data['partnerType'] = 'DIRECT';
    // }
    if (data['partnerNotificationStatus'] === null) {
      data['partnerNotificationStatus'] = false;
    }
    req['data'] = data;

    this.partnerService.createPartner(req).subscribe(res => {
      this.getPartnerDetails();
      this.partnerTable=true;
      this.dataService.broadcast('alert', {
        type: 'success',
        message: `Partner details ` + msg + ` successfully!`
      });
    });
  }

  deletePartner(close) {
    this.partnerService
      .deletePartner({partnerId:this.partnerInfo.partnerId})
      .subscribe(res => {
        this.getPartnerDetails();
        this.closeModel(close);
      });
  }
  getPartnerDetails() {
    this.getActions();
    this.partnerService.getPartnerDetails().subscribe(res => {
      if (res) {
        this.data.data = [];
        this.data.data = res;
        this.data.data.map(item => {
          item['disable'] = true;
        });
        //this.child.checkAll(false);
      }
    });
  }
  getActions() {
    const _module = EnumsService.PARTNER_UI_API;

    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe(prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

      this.data.actions = this.actionsArr.actionsArray;
      this.data.tableActions = this.actionsArr.headerRights;
      // this.data.tableActions['showCheck']=true;
      // this.data.tableActions['deleteAction']=this.actionsArr.headerRights.delete;
      this.data.tableActions['showCheck'] = false;
      this.data.tableActions['deleteAction'] = false;

      this.data.tableActions['searchActiom'] = true;

    });
  }

  getRolesByCategory() {
    const _req = { appendUserId: true, userId: 'PARTNER_ADMIN' };
    this.roleList = [];
    this.roleManagementService.getRoles(_req).subscribe(res => {
      res.data.forEach(role => {
        this.roleList.push({ roleId: role.roleId, roleName: role.name });
      });
    });
  }

  searchParam(event){
    this.partnerService.getPartnerByName(event).subscribe(res => {
      if (res) {
        this.data.data = [];
        this.data.data = res;
        this.data.data.map(item => {
          item['disable'] = true;
        });
        this.child.checkAll(false);
       }
    });
  }

}