import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { SharedModule } from '../shared/shared.module';
import { PartnerRoutingModule } from './partner-routing.module';
import { PartnerComponent } from './partner.component';
import { PartnerService } from './partner.service';
import { RoleManagementService } from '../role-management/role-management.service';

@NgModule({
  imports: [
    CommonModule,
    PartnerRoutingModule,
    AngularMultiSelectModule,
    SharedModule
  ],
  declarations: [PartnerComponent],
  providers: [PartnerService, RoleManagementService],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class PartnerModule { }
