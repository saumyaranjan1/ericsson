import { PartnerRoutingModule } from './partner-routing.module';

describe('PartnerRoutingModule', () => {
  let partnerRoutingModule: PartnerRoutingModule;

  beforeEach(() => {
    partnerRoutingModule = new PartnerRoutingModule();
  });

  it('should create an instance', () => {
    expect(partnerRoutingModule).toBeTruthy();
  });
});
