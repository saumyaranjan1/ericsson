import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';
import { DeleteIntercepterService } from '../shared/services/delete-ajax-method.service';

@Injectable({
  providedIn: 'root'
})
export class PartnerService {

  constructor(private interceptorService: InterceptorService, private deleteIntercepterService: DeleteIntercepterService) { }
  createPartner(request) {
    let ips = [];
    // Checking if we have the IP's or not
    if(request.data.whiteListedIps.length > 0) {
      request.data.whiteListedIps.forEach(ip => {
        ips.push(Object.values(ip)[0]);
      });
      request.data.whiteListedIps = ips;
    }
    
    // If the request type is post we have to send partner id as query param
    if(request.method == "put") {
      request.data.queryParam = true;
      request.data.queryParamData = {partnerId: request.data.partnerId};
    }
    return this.interceptorService.httpCall(request.method, request.url, request.data);
  }

  getPartnerDetails() {
    return this.interceptorService.httpCall('get', 'getPartnerDetails');
  }

  deletePartner(request) {
    //request.extraParams = "?partnerId=" + request.partnerId;
    return this.interceptorService.httpCall('delete', 'deletePartner', request);
  }

  getPartnerByName(request) {
     var param ={
      'partnerName':request.searchValue
    }
    return this.interceptorService.httpCall('get', 'getPartnerByName',param);
  }
  

}
