import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { RoleManagementEnumService } from '../role-management-enum';
import { RoleManagementService } from '../role-management.service';
import { EnumsService } from '../../shared/services/enums.service';
import { DatatableComponent } from '../../shared/components/datatable/datatable.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../../shared/services/data.service';
import { UserService } from '../../shared/services/user.service';
import { CommonMethodsService } from '../../shared/methods/common-methods';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
@Component({
  selector: 'app-draft',
  templateUrl: './draft.component.html',
  styleUrls: ['./draft.component.less']
})
export class DraftComponent implements OnInit {
  @ViewChild(DatatableComponent,{ static: false }) child: DatatableComponent;
  @ViewChild('approvalModalContent' , { static: true }) approvalModalContent: ElementRef;
  @ViewChild('roleMgmtModalContent' , { static: true }) roleMgmtModalContent: ElementRef;
  @ViewChild('deleteConfirmModalContent' ,{ static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('conformDefaultTemplate',{ static: true }) conformDefaultTemplate: ElementRef;
  @ViewChild('confirmSubmitRole',{static:true}) confirmSubmitRole: ElementRef;
  @ViewChild('confirmDraftRole', {static:true}) confirmDraftRole: ElementRef;

  approvedRolesList = RoleManagementEnumService.draftsRolesList;
  categorysArray;
  approveForm: FormGroup;
  searchValue: String = '';
  deleteItems: any;
  searchColumns:any;
  actionsArr;
  constructor(
    private roleManagementService: RoleManagementService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private dataService: DataService,
    private userService: UserService,
    private cms: CommonMethodsService
    ){}

  ngOnInit() {
    this.getPendingRoles();
    this.getCategorys();
    this.searchColumns=[
      {
         key: 'description',
      }
    ]
  }

  configModalOptionMode: null;
  openAddRoleModal(content, option) {
    this.configModalOptionMode = option.mode;
    this.modalService
      .open(content, {
        windowClass: 'jio-modal',
        size: 'sm',
        keyboard: false
      })
      .result.then(result => {}, reason => {});
  }

  submitAnddraftClose;
  confirmRoleStatus(close){
    this.submitAnddraftClose = close;
    this.openAddRoleModal(this.confirmSubmitRole, {
      mode:  this.configModalOptionMode
     });
  }
  confirmDraftRoleStatus(close){
    this.submitAnddraftClose = close;
    this.openAddRoleModal(this.confirmDraftRole, {
      mode:  this.configModalOptionMode
     });
  }
  
  openModal(item, content) {
    this.deleteItems = item;
    this.modalService
      .open(content, {
        windowClass: 'jio-modal jio-small-modal',
        size: 'sm',
        keyboard: false
      })
      .result.then(result => {}, reason => {});
  }

  openShowRoles(content, option) {
    this.configModalOptionMode = option.mode;
    this.modalService
      .open(content, {
        windowClass: 'jio-modal',
        size: 'lg',
        keyboard: false
      })
      .result.then(result => {}, reason => {});
  }

  back(close,event){
    this.closeModal(close);
    this.updatingApprovedRecords = true;
    this.createDeviceFormBlock(event);
    this.openAddRoleModal(this.approvalModalContent, {
      mode:  this.configModalOptionMode
     });
   
   }
   getActions() {
    const _module = RoleManagementEnumService.ROLEMGMT;

     // Form object to get the previliiages from server
     const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    }; 

     // API to get Previliages
     this.userService.getPreViliages(obj).subscribe( prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

      if (this.actionsArr.actionsArray) {
        this.actionsArr.actionsArray = this.actionsArr.actionsArray.filter(function(
          obj
        ) {
            return obj.type === 'view' || obj.type === 'delete' || obj.type === 'edit';
        });
        this.approvedRolesList.actions = this.actionsArr.actionsArray;
        //  data.tableActions = this.actionsArr.headerRights;
        //  data.tableActions.showCheck=true;
        //  data.tableActions.deleteAction=this.actionsArr.headerRights.delete;
      }
      
    });
   

   
   
  }

  getPendingRoles() {
     this.approvedRolesList.data = [];
    this.approvedRolesList.actions= [
      // {
      //   type: 'view',
      //   title: 'Edit approved',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'delete',
      //   title: 'Delete approved',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'edit',
      //   title: 'Edit approved',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // }
    ];
    this.getActions();
    this.roleManagementService.getDraftsRoles().subscribe(
      res => {
        if (res.data) {
          this.approvedRolesList.data = res.data;
          this.approvedRolesList.data.map(item => {
            item['roleName'] = item.name;
          });
        }
        this.child.checkAll(false);
      },
      err => {}
    );
  }

   
   getCategorys() {
    this.roleManagementService.getCategory().subscribe(res => {
      this.categorysArray = res.data;
    });
  }

   editItem(event){
    this.updatingApprovedRecords = true;
    
    this.createDeviceFormBlock(event);
    this.openAddRoleModal(this.approvalModalContent, {
      mode: RoleManagementEnumService.EDIT
     });
   }
 
   async verifyIsExistInMakerTable(event) {
    const data = {
      appendUserId: true,
      userId: event.roleId,
      donotShowError: true
    };
    const result = await this.roleManagementService.verifyIsExistInMakerTable(
      data
    );
    if (result.data && result.data.length > 0) {
          this.dataService.broadcast('alert', {
          type: RoleManagementEnumService.ERROR,
          message: RoleManagementEnumService.ROLE_EDIT_ERROR
        });
    } else {
     
    }
  }
  
  editModelData:any;
  createDeviceFormBlock(event?) {
    this.populateValues(event);
    this.approveForm = this.fb.group({
      roleName: [
        event ? event.roleName || event.name : null,
        [
          Validators.required,
        ]
      ],
      category: [
          event.category,
        [
          Validators.required,
        ]
      ],
      isDefault:  event ? event.isDefault : false
    });
  }

  populateValues(item) {
    this.moduleroles=[];
    const _req = {
      roleId: item.roleId
    };
    this.roleManagementService.getMakerValues(_req).subscribe(
      res => {
        this.modulePrevelage=res.data.moduleGroups;
        this.editModelData=res.data;
        this.modulePrevelage.forEach(item => {
        if(item.isChecked){
         this.moduleItemCheck(true,item.groupCode);
        }   
        });
      },
      error => {}
    );
  }


  modulePrevelage;
  moduleroles=[];
  moduleItemCheck(event,groupName){
    if(event){
      this.modulePrevelage.forEach(item => {
        if(groupName  == item.groupCode){
          item.modules.forEach(inneritem => {
              this.moduleroles.push(inneritem);
          });
        }
      });
    }else{
      this.modulePrevelage.forEach(item => {
        if(!item.isChecked && item.modules){
            item.modules.forEach(inneritem => {
              this.moduleroles.forEach((modelitem,filterid) => {
                if(modelitem.moduleCode==inneritem.moduleCode){
                  this.moduleroles.splice(filterid,1);
                }
             });
             });
        }
      });
    }
    this.editModelData.modulePrivilege=this.moduleroles;
    }




  nextModel(event){
      this.closeModal(event);
      this.openShowRoles(this.roleMgmtModalContent, {
        mode: this.configModalOptionMode
      });
    }

  onChange(event){
      const req = {
        category: event
      };
      this.roleManagementService.getRoleMasterData(req).subscribe(
        res => {
          if(this.configModalOptionMode === 'create'){
            this.editModelData={};
            this.editModelData.name=this.approveForm.value.roleName;
            this.editModelData.modulePrivilege=res.data;
           }else{
            this.modulePrevelage=res.data.moduleGroups;
            this.editModelData=res.data;
            this.modulePrevelage.forEach(item => {
            if(item.isChecked){
             this.moduleItemCheck(true,item.groupCode);
            }   
            });
           }
         },
        error => {}
      );
  }
  closeModal(close) {
    close('Cross click');
  }

  submitRole(close,type){
   if(type=='save'){
      this.editModelData.status = RoleManagementEnumService.MAKER_CHECKER.UD;
    }else{
      this.editModelData.status = RoleManagementEnumService.MAKER_CHECKER.UI;
    }
     this.closeModal(this.submitAnddraftClose);
     this.updateRole(close,type);
    }
   updatingDrafts;
   updatingApprovedRecords;
   
   async updateRole(close,type) {
     this.editModelData.isDefault=this.approveForm.value.isDefault ? this.approveForm.value.isDefault : false;
     if(type==='save'){
      this.editModelData.status = RoleManagementEnumService.MAKER_CHECKER.UD;
     }
    let url;
    let method;
      url = RoleManagementEnumService.UPDATE_ROLE_DRAFT;
    
    method = 'put';
    this.editModelData['updatedBy'] = this.userService.username();
    this.editModelData['updatedDate'] = new Date();
    const roleInfo = this.cms.deepCopyOfObject(this.editModelData);
    roleInfo.modulePrivilege.map(item => {
      delete item.checkAll;
        item.privilege = item.privilege.filter(data => {
          return data.isChecked === true;
        });
    });
    roleInfo['queryParam'] = true;
    const req = {
      user: roleInfo
    };
    const isChecked = this.roleManagementService.validatePrivileges(this.editModelData.modulePrivilege);
        if (isChecked) {
        delete roleInfo.createdDate;
        delete roleInfo.updatedDate;
        roleInfo.modulePrivilege.map((item, key) => {
          if (item.privilege.length === 0) {
            roleInfo.modulePrivilege.splice(key, 1);
          } else {
            item.privilege = item.privilege.map(privilege => ({
              code:  privilege.code
            }));
          }
        });

        const result = await this.roleManagementService.updateRolePromise(
          method === 'put' ? req : roleInfo, url, method
        );
        this.closeModal(this.submitAnddraftClose);
        if(result.status && result.status === 409) {
            this.closeModal(close);
            this.openConfirmModal(method === 'put' ? req : roleInfo, result.error.msg, close, true, method, url);  
          } else { 
            this.updatingDrafts = false;
            this.updatingApprovedRecords = false;
            this.getPendingRoles();
            this.getCategorys();
            this.closeModal(close);
            this.closeModal(this.updateWindowClose);

            this.closeModalAndFetchData(close, RoleManagementEnumService.ROLE_UPDATED_SUCCESSFULLY);
            this.updateWindowClose = '';
          }
        } else {
          this.dataService.broadcast('alert', {
            type: 'danger',
            message: RoleManagementEnumService.ATLEAST_ONE_PRIVILEGE_ERROR
          });
        }
  }
  
  checkItem(event, panel) {
    panel.checkAll =
      panel.privilege.filter(item => {
        return item.isChecked === true;
      }).length === panel.privilege.length;
  }

  addNewRole(content, option) {
    this.updatingApprovedRecords = true;
      this.openAddRoleModal(this.approvalModalContent, {
        mode: RoleManagementEnumService.CREATE
       });
      this.createDeviceFormBlock(event);
  }

 

  viewItemFromChecker(event, options){
    this.createDeviceFormBlock(event);
  //  this.populateValues(event);
     this.configModalOptionMode = options.mode;
     this.openAddRoleModal(this.approvalModalContent, {
      mode:  RoleManagementEnumService.VIEW
    });
  }

  deleteItem(event) {
    this.openModal(event, this.deleteConfirmModalContent);
  }

  roleStatusChange(status, close) {
    if (status === RoleManagementEnumService.DELETE) {
      let url;
      url = RoleManagementEnumService.UPDATE_ROLE_DRAFT;
      const data = {
        user: { roleId: this.deleteItems.roleId, queryParam: true }
      };
      this.roleManagementService.deleteRole(data, url).subscribe(
        res => {
          const message = this.updatingDrafts
          ? RoleManagementEnumService.ROLE_DELETED_SUCCESSFULLY
          : RoleManagementEnumService.DELETED_INTIALTION_SUCCESS;
          this.closeModal(close);
          this.getPendingRoles();
          this.getCategorys();
        },
        error => {}
      );
    } else {
      const data = {
        user: { roleId: this.deleteItems.roleId, queryParam: true, status: status }
      };
      this.roleManagementService.updateStatus(data).subscribe(
        res => {
          this.closeModal(close);
          this.getPendingRoles();
          this.getCategorys();
        },
        error => {}
      );
    }
  }


  defaultRoleData;
  isApprove;
  closeMainModal;
  defaultRoleErrorMsg;
  method;
  url;
  updateWindowClose;
  openConfirmModal(defaultData, msg, close, isApprove, method?, url?) {
   this.defaultRoleData = defaultData;
   this.isApprove = isApprove;
   this.closeMainModal = close;
   this.defaultRoleErrorMsg = msg;
   this.method = method;
   this.url = url;
   this.openModal(null, this.conformDefaultTemplate);
 }

 closeModalAndFetchData(close, message) {
   this.getPendingRoles();
   this.getCategorys();
   this.closeModal(close);
   this.dataService.broadcast('alert', {
     type: RoleManagementEnumService.SUCCESS,
     message: message
   });
 }

 confirmDefaultRole(data, close) {
  if(this.method) {
  const req = this.defaultRoleData;
  if(req.user) {
   req.user['isUserConfirmed'] = data;
   req.user['queryParam'] = true;
  
  } else {
   req['isUserConfirmed'] = data;
   req['queryParam'] = true;
  }
      this.roleManagementService
     .updateRole(req, this.url, this.method)
     .subscribe(
       res => {
         if (res) {
           this.updatingDrafts = false;
           this.updatingApprovedRecords = false;
           this.closeModal(this.updateWindowClose);
           this.closeModalAndFetchData(close, RoleManagementEnumService.ROLE_UPDATED_SUCCESSFULLY);
           this.updateWindowClose = '';
         }
       },
       error => {}
     );
   } else {
     this.defaultRoleData['isUserConfirmed'] = data;
     if(this.isApprove)  {
       this.roleManagementService.approveOrReject(this.defaultRoleData).subscribe(
           res => {
             if (res) {

               const message =
               this.editModelData.status ===
                 RoleManagementEnumService.MAKER_CHECKER.AP ||
                 this.editModelData.status ===
                 RoleManagementEnumService.MAKER_CHECKER.DL
                 ? RoleManagementEnumService.ROLE_HAS_BEEN_APPROVED
                 : RoleManagementEnumService.ROLE_REJECTED;

               this.closeModalAndFetchData(close, message);
               this.closeModal(this.closeMainModal);
             }
           },
           error => {}
         );
     } else {
     this.roleManagementService.addRoleWithUserConfirmed(this.defaultRoleData).subscribe(result => {
       this.closeModalAndFetchData(close, RoleManagementEnumService.ROLE_ADDED_SUCCESSFULLY);
       this.closeModal(this.closeMainModal);
     });
   }
   }
 }

 
}
