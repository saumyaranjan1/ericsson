import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { RoleManagementEnumService } from '../role-management-enum';
import { RoleManagementService } from '../role-management.service';
import { EnumsService } from '../../shared/services/enums.service';
import { DatatableComponent } from '../../shared/components/datatable/datatable.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../../shared/services/data.service';
import { UserService } from '../../shared/services/user.service';
import { CommonMethodsService } from '../../shared/methods/common-methods';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
@Component({
  selector: 'app-approved',
  templateUrl: './approved.component.html',
  styleUrls: ['./approved.component.less']
})
export class ApprovedComponent implements OnInit {
  @ViewChild(DatatableComponent,{ static: false }) child: DatatableComponent;
  @ViewChild('approvalModalContent' , { static: true }) approvalModalContent: ElementRef;
  @ViewChild('roleMgmtModalContent' , { static: true }) roleMgmtModalContent: ElementRef;
  @ViewChild('deleteConfirmModalContent' ,{ static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('confirmDisableModalContent',{ static: true }) confirmDisableModalContent: ElementRef;
  @ViewChild('conformDefaultTemplate',{ static: true }) conformDefaultTemplate: ElementRef;
  @ViewChild('confirmEnableModalContent', { static: true}) confirmEnableModalContent: ElementRef;
  @ViewChild('approveTemplate' , { static: true }) approveTemplate: ElementRef;
  @ViewChild('confirmSubmitRole',{static:true}) confirmSubmitRole: ElementRef;
  @ViewChild('confirmDraftRole', {static:true}) confirmDraftRole: ElementRef;

  approvedRolesList = RoleManagementEnumService.approvedRolesList;
  categorysArray;
  approveForm: FormGroup;
  searchValue: String = '';
  deleteItems: any;
  actionsArr: any;
  remarks:'';
  module=['Manage','Dashboard','Provision','Configure','TroubleShoot','Report'];
  constructor(
    private roleManagementService: RoleManagementService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private dataService: DataService,
    private userService: UserService,
    private cms: CommonMethodsService
    ){}

   searchColumns:any;
  ngOnInit() {
    this.getApprovedRoles();
    this.getCategorys();
    this.searchColumns=[
      {
         key: 'description',
      }
    ]
  }

  configModalOptionMode: null;
  openAddRoleModal(content, option) {
    this.configModalOptionMode = option.mode;
    this.modalService
      .open(content, {
        windowClass: 'jio-modal',
        size: 'sm',
         keyboard: false
      })
      .result.then(result => {}, reason => {});
  }

  
  openModal(item, content) {
    this.deleteItems = item;
    this.modalService
      .open(content, {
        windowClass: 'jio-modal jio-small-modal',
        size: 'sm',
         keyboard: false
      })
      .result.then(result => {}, reason => {});
  }

  openShowRoles(content, option) {
    this.configModalOptionMode = option.mode;
    this.modalService
      .open(content, {
        windowClass: 'jio-modal',
        size: 'lg',
         keyboard: false
      })
      .result.then(result => {}, reason => {});
  }

  getActions(data) {
    const _module = RoleManagementEnumService.ROLEMGMT;
  // Form object to get the previliiages from server
  const obj = {
    moduleCode: _module,
    roleId: this.dataService.getAtobLocalStorage('roleId'),
    previliages: true
  };

   // API to get Previliages
   this.userService.getPreViliages(obj).subscribe( prev => {
    this.actionsArr = this.userService.getModulePermission(
      EnumsService.ACTIONS[_module],
      prev.data.privilege // Passing privilege to the methos to get thr actions array
    );
    if (this.actionsArr.actionsArray) {
      console.log(this.actionsArr.actionsArray);

      // this.actionsArr.actionsArray = this.actionsArr.actionsArray.filter(function(
      //   obj
      // ) {
      //     return obj.type !== RoleManagementEnumService.CREATE_APPROVE;
      // });
      let hasApprove = false;
      this.actionsArr.actionsArray.forEach(element => {
        if(element.type == 'approve') {
           hasApprove = true;
          element.title = 'Disable Role';
        }
      });
      data.actions = this.actionsArr.actionsArray;
      if(hasApprove) {
        data.actions.push(EnumsService.ROLE_REJECT);
      } 
      
       data.tableActions = this.actionsArr.headerRights;
       data.tableActions.showCheck=true;
       data.tableActions.deleteAction=this.actionsArr.headerRights.delete;
    }
    
    
  });

   
  }
  getApprovedRoles() {
    this.getActions(this.approvedRolesList);
    this.approvedRolesList.data = [];

    this.approvedRolesList.actionsLabel='Actions',
    this.roleManagementService.getApprovedRoles().subscribe(
      res => {
        if (res.data) {
          this.approvedRolesList.data = res.data;
           this.approvedRolesList.data.map(item => {
            item['roleName'] = item.name;
            if (item.status === 'AP') {
              item['showApproveIcon'] = true;
            } else {
              item['showApproveIcon'] = false;
            }
          });
          const _rejectAction = this.approvedRolesList.actions.filter(function(
            item
          ) {
            return item.type === 'approve';
          });
          this.approvedRolesList.actions.map(member => {
            if (
              member.type === EnumsService.TYPE_APPROVE ||
              member.type === EnumsService.TYPE_REJECT
            ) {
              member['showIconProp'] = 'showApproveIcon';
            }
            if (member.type === EnumsService.TYPE_REJECT && _rejectAction.length > 0) {
              member['disableIconProp'] = _rejectAction[0].disableIconProp;
              member['title'] = _rejectAction[0].title;
            }
          });
          console.log('this.approvedRolesList.actions', this.approvedRolesList.actions);
           this.child.checkAll(false);
         }
      },
      err => {}
    );
   }
 
  getCategorys() {
    this.roleManagementService.getCategory().subscribe(res => {
      this.categorysArray = res.data;
    });
  }

   editItem(event){
     
    this.verifyIsExistInMakerTable(event);
   }
 

   back(close,event){
    this.closeModal(close);
    this.updatingApprovedRecords = true;
    this.openAddRoleModal(this.approvalModalContent, {
      mode:  this.configModalOptionMode
     });
    this.createDeviceFormBlock(event);
   }


   async verifyIsExistInMakerTable(event) {
    const data = {
      appendUserId: true,
      roleId: event.roleId,
      donotShowError: true
    };
    const result = await this.roleManagementService.verifyIsExistInMakerTable(
      data
    );
    console.log(result.data)
    if (result.data && result.data.length > 0) {
          this.dataService.broadcast('alert', {
          type: RoleManagementEnumService.ERROR,
          message: RoleManagementEnumService.ROLE_EDIT_ERROR
        });
    } else {
      this.updatingApprovedRecords = true;
      this.openAddRoleModal(this.approvalModalContent, {
        mode: RoleManagementEnumService.EDIT
       });
      this.createDeviceFormBlock(event);
    }
  }
  
  editModelData:any;
  createDeviceFormBlock(event?) {
    if(this.configModalOptionMode !== 'create'){ 
      this.populateValues(event);
    }
    this.approveForm = this.fb.group({
      roleName: [
        event.roleName ? event.roleName : event.name,
        [
          Validators.required,
          Validators.pattern("^[a-zA-Z0-9-_ \r\n]+$")
        ]
      ],
      category: [
          event.category,
        [
          Validators.required,
        ]
      ],
      isDefault:  event ? event.isDefault : false
     });
  }


  populateValues(item) {
    this.moduleroles=[];
    const _req = {
      roleId: item.roleId
    };
    this.roleManagementService.getUpdateData(_req).subscribe(
      res => {
        this.modulePrevelage=res.data.moduleGroups;
        this.editModelData=res.data;
        this.modulePrevelage.forEach(item => {
        if(item.isChecked){
         this.moduleItemCheck(true,item.groupCode);
        }   
        });
        this.editModelData['modulePrivilege']=this.moduleroles;
      },
      error => {}
    );
  }

  nextModel(event){
      this.closeModal(event);
      this.openShowRoles(this.roleMgmtModalContent, {
        mode: this.configModalOptionMode
      });
    }

  modulePrevelage;
  moduleroles=[];
  onChange(event){
      const req = {
        category: event
      };
      this.roleManagementService.getRoleMasterData(req).subscribe(
        res => {
          if(res.data){
            if(this.configModalOptionMode === 'create'){
              this.modulePrevelage=res.data;
              this.moduleroles=[];
              if(this.modulePrevelage.length > 0){
               this.modulePrevelage[0]['isChecked']=true;
               this.moduleItemCheck(true,this.modulePrevelage[0].groupCode);
               this.editModelData={};
               this.editModelData.name=this.approveForm.value.roleName;
               this.editModelData['modulePrivilege']=this.moduleroles;
              }
              }else{
              // this.editModelData.modulePrivilege=res.data;
               this.modulePrevelage=res.data.moduleGroups;
               this.editModelData=res.data;
               this.modulePrevelage.forEach(item => {
               if(item.isChecked){
                this.moduleItemCheck(true,item.groupCode);
               }   
               });
               this.editModelData['modulePrivilege']=this.moduleroles;
              }
          }
         },
        error => {}
      );
  }

  moduleItemCheck(event,groupName){
    if(event){
      this.modulePrevelage.forEach(item => {
        if(groupName  == item.groupCode){
          item.modules.forEach(inneritem => {
              this.moduleroles.push(inneritem);
          });
        }
      });
    }else{
      this.modulePrevelage.forEach(item => {
        if(!item.isChecked && item.modules){
            item.modules.forEach(inneritem => {
              this.moduleroles.forEach((modelitem,filterid) => {
                if(modelitem.moduleCode==inneritem.moduleCode){
                  this.moduleroles.splice(filterid,1);
                }
             });
             });
        }
      });
    }
    //this.editModelData['modulePrivilege']=this.moduleroles;
    }

  closeModal(close) {
    close('Cross click');
  }

  submitRole(close){
    this.editModelData.name=this.approveForm.value.roleName;
    if (this.configModalOptionMode !== 'create') {
      this.editModelData.status = RoleManagementEnumService.MAKER_CHECKER.UI;
    } else {
     this.editModelData.status = RoleManagementEnumService.MAKER_CHECKER.CD;
    }
    if (this.configModalOptionMode === 'create') {
      //<-------------->
      this.editModelData.status = RoleManagementEnumService.MAKER_CHECKER.CI;
      this.editModelData.category=this.approveForm.value.category;
      this.editModelData.isDefault=this.approveForm.value.isDefault ? this.approveForm.value.isDefault : false;
      const roleInfo = this.cms.deepCopyOfObject(this.editModelData);
      roleInfo.modulePrivilege.map(item => {
        delete item.checkAll;
        item.privilege = item.privilege.filter(data => {
          return data.isChecked === true;
        });
      });
      const isChecked = this.roleManagementService.validatePrivileges(this.editModelData.modulePrivilege);
      if (isChecked) {
          roleInfo.modulePrivilege.filter((item, key) => {
         return item.privilege.length !== 0;
        });
        const result = this.roleManagementService.addRole(
          roleInfo
        );
        this.closeModal(close);
        this.closeModal(this.submitAnddraftClose);
    } else {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: RoleManagementEnumService.ATLEAST_ONE_PRIVILEGE_ERROR
      });
    }
  //<===============>
     }else{
     // this.updateRole(close);
    }
   }
   updatingDrafts;
   updatingApprovedRecords;
   
   async updateRole(close,type) {
    let url;
    let method;
    if (this.updatingDrafts) {
      url = RoleManagementEnumService.UPDATE_ROLE_DRAFT;
    } else {
      url = RoleManagementEnumService.UPDATE_ROLE;
    }
    method = 'put';

    if(type=='save'){
      method = 'post';
      url = RoleManagementEnumService.UPDATE_ROLE_DRAFT;
      this.editModelData.status = RoleManagementEnumService.MAKER_CHECKER.UD;
    }else{
      this.updateWindowClose = close;
      method = 'put';
      url = RoleManagementEnumService.UPDATE_ROLE;
      this.editModelData.status = RoleManagementEnumService.MAKER_CHECKER.UI;
    }
    this.editModelData['updatedBy'] = this.userService.username();
    this.editModelData['updatedDate'] = new Date();
    this.editModelData.category=this.approveForm.value.category;
    this.editModelData.isDefault=this.approveForm.value.isDefault ? this.approveForm.value.isDefault : false;
    const roleInfo = this.cms.deepCopyOfObject(this.editModelData);
    roleInfo['modulePrivilege'] = [];
    roleInfo.moduleGroups.map(group => {
      group.modules.forEach(mod=> {
        if(group.isChecked==true){
          roleInfo['modulePrivilege'].push(mod);
        }
      });
    });
    roleInfo.modulePrivilege.map(item => {
      delete item.checkAll;
        item.privilege = item.privilege.filter(data => {
          return data.isChecked === true;
        });
    });
    roleInfo['queryParam'] = true;
    const req = {
      user: roleInfo
    };
    const isChecked = this.roleManagementService.validatePrivileges(this.editModelData.modulePrivilege);
        if (isChecked) {
        delete roleInfo.createdDate;
        delete roleInfo.updatedDate;
        roleInfo.modulePrivilege.map((item, key) => {
          if (item.privilege.length === 0) {
            roleInfo.modulePrivilege.splice(key, 1);
          } else {
            item.privilege = item.privilege.map(privilege => ({
              code:  privilege.code
            }));
          }
        });

        const result = await this.roleManagementService.updateRolePromise(
          method === 'put' ? req : roleInfo, url, method
        );
       
        if(result.status && result.status === 409) {
            this.closeModal(close);
           } else { 
            this.updatingDrafts = false;
            this.updatingApprovedRecords = false;
            this.closeModal(close);
            this.getApprovedRoles();
            this.getCategorys();
           }
        } else {
          this.dataService.broadcast('alert', {
            type: 'danger',
            message: RoleManagementEnumService.ATLEAST_ONE_PRIVILEGE_ERROR
          });
        }
         this.closeModal(this.submitAnddraftClose);
  }
  
  checkItem(event, panel) {
    panel.checkAll =
      panel.privilege.filter(item => {
        return item.isChecked === true;
      }).length === panel.privilege.length;
  }

  addNewRole(content, option) {
    this.updatingApprovedRecords = true;
      this.openAddRoleModal(this.approvalModalContent, {
        mode: RoleManagementEnumService.CREATE
       });
      this.createDeviceFormBlock(event);
  }

  viewItemFromChecker(event, options){
    this.createDeviceFormBlock(event);
  //  this.populateValues(event);
     this.configModalOptionMode = options.mode;
     this.openAddRoleModal(this.approvalModalContent, {
      mode:  RoleManagementEnumService.VIEW
    });
  }

  deleteItem(event) {
    this.openModal(event, this.deleteConfirmModalContent);
  }

  disableItem(event) {
    this.openModal(event, this.confirmDisableModalContent);
  }
  enableItem(event) {
    this.openModal(event, this.confirmEnableModalContent);
  }

  roleStatusChange(status, close) {
    if (status === RoleManagementEnumService.DELETE) {
      let url;
      if (this.updatingDrafts) {
        url = RoleManagementEnumService.UPDATE_ROLE_DRAFT;
      } else {
        url = RoleManagementEnumService.UPDATE_ROLE;
      }
      const data = {
        user: { roleId: this.deleteItems.roleId, queryParam: true }
      };
      this.roleManagementService.deleteRole(data, url).subscribe(
        res => {
          const message = this.updatingDrafts
          ? RoleManagementEnumService.ROLE_DELETED_SUCCESSFULLY
          : RoleManagementEnumService.DELETED_INTIALTION_SUCCESS;
          this.closeModal(close);
          this.getApprovedRoles();
          this.getCategorys();
        },
        error => {}
      );
    } else {
      const data = {
        user: { roleId: this.deleteItems.roleId, queryParam: true, status: status }
      };
      this.roleManagementService.updateStatus(data).subscribe(
        res => {
          this.closeModal(close);
          this.getApprovedRoles();
          this.getCategorys();
        },
        error => {}
      );
    }
  }


  async saveOrUpdateRole(close,type){
    this.editModelData.name=this.approveForm.value.roleName;
    if (this.configModalOptionMode === 'create') {
      if(type=='save'){
        this.editModelData.status = RoleManagementEnumService.MAKER_CHECKER.CD;
      }else{
        this.editModelData.status = RoleManagementEnumService.MAKER_CHECKER.CI;
      }
      this.editModelData.category=this.approveForm.value.category;
      this.editModelData.isDefault=this.approveForm.value.isDefault ? this.approveForm.value.isDefault : false;
      const roleInfo = this.cms.deepCopyOfObject(this.editModelData);
      roleInfo.modulePrivilege.map(item => {
        delete item.checkAll;
        item.privilege = item.privilege.filter(data => {
          return data.isChecked === true;
        });
      });
      const isChecked = this.roleManagementService.validatePrivileges(this.editModelData.modulePrivilege);
      if (isChecked) {
          roleInfo.modulePrivilege.filter((item, key) => {
         return item.privilege.length !== 0;
        });
        const result = await this.roleManagementService.addRole(
          roleInfo
        );
       
        if(result.status && result.status === 409) {
          this.openConfirmModal(roleInfo, result.error.error, close, false);  
        } else {
          this.closeModalAndFetchData(close, RoleManagementEnumService.ROLE_ADDED_SUCCESSFULLY); 
        }
        this.closeModal(this.submitAnddraftClose);
        this.closeModal(close);
    } else {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: RoleManagementEnumService.ATLEAST_ONE_PRIVILEGE_ERROR
      });
    }
  //<===============>
     }else{
      this.updateRole(close,type);
    }
   }
   defaultRoleData;
   isApprove;
   closeMainModal;
   defaultRoleErrorMsg;
   method;
   url;
   updateWindowClose;
   openConfirmModal(defaultData, msg, close, isApprove, method?, url?) {
    this.defaultRoleData = defaultData;
    this.isApprove = isApprove;
    this.closeMainModal = close;
    this.defaultRoleErrorMsg = msg;
    this.method = method;
    this.url = url;
    this.openModal(null, this.conformDefaultTemplate);
  }

  submitAnddraftClose;
  confirmRoleStatus(close){
    this.submitAnddraftClose = close;
    this.openAddRoleModal(this.confirmSubmitRole, {
      mode:  this.configModalOptionMode
     });
  }

  confirmDraftRoleStatus(close){
    this.submitAnddraftClose = close;
    this.openAddRoleModal(this.confirmDraftRole, {
      mode:  this.configModalOptionMode
     });
  }


  closeModalAndFetchData(close, message) {
    this.getApprovedRoles();
    this.getCategorys();
    this.closeModal(close);
    this.dataService.broadcast('alert', {
      type: RoleManagementEnumService.SUCCESS,
      message: message
    });
  }

   modelChanged(event){
     return event;
   }

   confirmDefaultRole(data, close) {
    if(this.method) {
    const req = this.defaultRoleData;
    if(req.user) {
     req.user['isUserConfirmed'] = data;
     req.user['queryParam'] = true;
    
    } else {
     req['isUserConfirmed'] = data;
     req['queryParam'] = true;
    }
        this.roleManagementService
       .updateRole(req, this.url, this.method)
       .subscribe(
         res => {
           if (res) {
             this.updatingDrafts = false;
             this.updatingApprovedRecords = false;
             this.closeModal(this.updateWindowClose);
             this.closeModalAndFetchData(close, RoleManagementEnumService.ROLE_UPDATED_SUCCESSFULLY);
             this.updateWindowClose = '';
           }
         },
         error => {}
       );
     } else {
       this.defaultRoleData['isUserConfirmed'] = data;
       if(this.isApprove)  {
         this.roleManagementService.approveOrReject(this.defaultRoleData).subscribe(
             res => {
               if (res) {

                 const message =
                 this.editModelData.status ===
                   RoleManagementEnumService.MAKER_CHECKER.AP ||
                   this.editModelData.status ===
                   RoleManagementEnumService.MAKER_CHECKER.DL
                   ? RoleManagementEnumService.ROLE_HAS_BEEN_APPROVED
                   : RoleManagementEnumService.ROLE_REJECTED;

                 this.closeModalAndFetchData(close, message);
                 this.closeModal(this.closeMainModal);
               }
             },
             error => {}
           );
       } else {
       this.roleManagementService.addRoleWithUserConfirmed(this.defaultRoleData).subscribe(result => {
         this.closeModalAndFetchData(close, RoleManagementEnumService.ROLE_ADDED_SUCCESSFULLY);
         this.closeModal(this.closeMainModal);
       });
     }
     }
   }

    
  
}
