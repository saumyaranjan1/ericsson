import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { RoleManagementRoutingModule } from './role-management-routing.module';
import { RoleManagementComponent } from './role-management.component';
import { RoleManagementService } from './role-management.service';
import { SharedModule } from './../shared/shared.module';
import { ApprovedComponent } from './approved/approved.component';
import { DraftComponent } from './draft/draft.component';
import { PendingComponent } from './pending/pending.component';

@NgModule({
  imports: [
    CommonModule,
    RoleManagementRoutingModule,
    SharedModule
  ],
  declarations: [RoleManagementComponent, ApprovedComponent, DraftComponent, PendingComponent],
  providers:[RoleManagementService]
})
export class RoleManagementModule { }
