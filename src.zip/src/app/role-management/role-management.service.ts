import { Injectable } from '@angular/core';

import { InterceptorService } from './../shared/services/interceptor.service'

@Injectable()
export class RoleManagementService {

 constructor(private interceptor: InterceptorService) { }

getApprovedRoles() {
  const request = {
    jioUtils : true
  };
    return this.interceptor.httpCall('get', 'getApprovedRoles', request);
  }
  getPendingRoles() {
    const request = {
      jioUtils : true
    };
      return this.interceptor.httpCall('get', 'getPendingRoles', request);
    }
    getDraftsRoles() {
      const request = {
        jioUtils : true
      };
        return this.interceptor.httpCall('get', 'getDraftsRoles', request);
      }

  getRoleMasterData(request) {
    // request.jioUtils = true;
    // request.appendUserId=true;
    // request.userId=request.category;
    request['extraParams'] =  "?category="+request.category;
    delete request.category;
    return this.interceptor.httpCall('get', 'getRoleMasterData', request);
  }
  getUpdateData(request) {
    request.jioUtils = true;
    return this.interceptor.httpCall('get', 'getUpdateData', request);
  }
  getMakerValues(request) {
    request.jioUtils = true;
    return this.interceptor.httpCall('get', 'getMakerValues', request);
  }
  addRole(request){
    request.jioUtils = true;
    return this.interceptor.httpPromise('post', 'addRole', request);
  }
  addRoleWithUserConfirmed(request) {
    request.jioUtils = true;
    return this.interceptor.httpCall('post', 'addRole', request);
  }
  approveOrRejectPromise(request) {
      request.jioUtils = true;
      return this.interceptor.httpPromise('patch', 'approveOrReject', request);
  }
  approveOrReject(request) {
    request.jioUtils = true;
    return this.interceptor.httpCall('patch', 'approveOrReject', request);
}
  getRole(request) {
    request.jioUtils = true;
    return this.interceptor.httpCall('get', 'getRole', request);
  }
  getRoles(request) {
    //request.jioUtils = true;
    request['extraParams'] =  "?category="+request.userId;
    delete request.userId;
    delete request.appendUserId;
    return this.interceptor.httpCall('get', 'getRoles', request);
  }
  updateRole(request, url, method) {
    request.jioUtils = true;
    return this.interceptor.httpCall(method, url, request);
  }

  updateRolePromise(request, url, method) {
    request.jioUtils = true;
    return this.interceptor.httpPromise(method, url, request);
  }
  updateStatus(request) {
    request.jioUtils = true;
    return this.interceptor.httpCall('put', 'updateStatus', request);
  }
  deleteRole(request, url) {
    request.jioUtils = true;
    return this.interceptor.httpCall('delete', url, request);
  }
  getCategory() {
    const request = {
      jioUtils : true
    };
    return this.interceptor.httpCall('get', 'category', request);
  }
  validatePrivileges(modulePrivilege) {
    let isChecked = false;
    modulePrivilege.forEach(element => {
        element.privilege.forEach(privilege => {
         if (privilege.isChecked) {
            isChecked = privilege.isChecked;
          }
        });
    });
    return isChecked;
  }
  verifyIsExistInMakerTable(request) {
    request.jioUtils = true;
    delete request.appendUserId;
    return this.interceptor.httpPromise('get', 'verifyIsExistInMakerTable', request);
  }
}
