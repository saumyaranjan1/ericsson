import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';

import { RoleManagementService } from './role-management.service';
import { DataService } from './../shared/services/data.service';
import { UtilService } from './../shared/services/util.service';
import { UserService } from './../shared/services/user.service';
import { EnumsService } from './../shared/services/enums.service';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { RoleManagementEnumService } from './role-management-enum';
import { DatatableComponent } from '../shared/components/datatable/datatable.component';


@Component({
  selector: 'app-role-management',
  templateUrl: './role-management.component.html',
  styleUrls: ['./role-management.component.less']
})
export class RoleManagementComponent implements OnInit {
  @ViewChild('roleMgmtModalContent' , { static: true }) roleMgmtModalContent: ElementRef;
  @ViewChild('deleteConfirmModalContent' ,{ static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('confirmDisableModalContent',{ static: true })
  confirmDisableModalContent: ElementRef;
  @ViewChild('confirmEnableModalContent',{ static: true }) confirmEnableModalContent: ElementRef;
  @ViewChild('updateConfirmModalContent',{ static: true }) updateConfirmModalContent: ElementRef;
  @ViewChild('conformDefaultTemplate',{ static: true }) conformDefaultTemplate: ElementRef;
  @ViewChild(DatatableComponent,{ static: false }) child: DatatableComponent;


  modalConfig = RoleManagementEnumService.modalConfig;
  configModalOptionMode: null;
  userData: any;
  item: any;
  _statusReq = {};
  _active = EnumsService.ACTIVE;
  defaultRoleData;
  defaultRoleErrorMsg;
  closeMainModal;
  isApprove;
  method;
  url;
  roleInfo = {
    name: '',
    category: '',
    status: '',
    modulePrivilege: [],
    remarks: '',
    isDefault: false
  };

  approvedRolesList = RoleManagementEnumService.approvedRolesList;
  pendingRolesList = RoleManagementEnumService.pendingRolesList;
  draftsRolesList = RoleManagementEnumService.draftsRolesList;

  roleMasterData = [];
  actionsArr: any;
  categorysArray;
  updateWindowClose;
  isChecker;
  updatingApprovedRecords;
  updatingDrafts;

  constructor(
    private modalService: NgbModal,
    private roleManagementService: RoleManagementService,
    private dataService: DataService,
    private userService: UserService,
    private utilService: UtilService,
    private cms: CommonMethodsService
  ) {}

  ngOnInit() {
    this.fetchRolesList();
    this.getCategorys();
  }

  fetchRolesList(event?) {
    this.isChecker = false;
    this.getApprovedRoles();
    this.getPendingRoles();
    this.getDraftsRoles();
  }
  getCategorys() {
    this.roleManagementService.getCategory().subscribe(res => {
      this.categorysArray = res.data;
    });
  }

  getApprovedRoles() {
    this.getActions(this.approvedRolesList);
    this.approvedRolesList.data = [];
    this.roleManagementService.getApprovedRoles().subscribe(
      res => {
        if (res.data) {
          this.approvedRolesList.data = res.data;
          this.approvedRolesList.data.map(item => {
            item['roleName'] = item.name;
            if (item.status === 'AP') {
              item['showApproveIcon'] = true;
            } else {
              item['showApproveIcon'] = false;
            }
          });
          const _rejectAction = this.approvedRolesList.actions.filter(function(
            item
          ) {
            return item.type === 'approve';
          });
          this.approvedRolesList.actions.map(member => {
            if (
              member.type === EnumsService.TYPE_APPROVE ||
              member.type === EnumsService.TYPE_REJECT
            ) {
              member['showIconProp'] = 'showApproveIcon';
            }
            if (member.type === EnumsService.TYPE_REJECT && _rejectAction.length > 0) {
              member['disableIconProp'] = _rejectAction[0].disableIconProp;
              member['title'] = _rejectAction[0].title;
            }
          });
          this.child.checkAll(false);
         }
      },
      err => {}
    );
  }

  getPendingRoles() {
    this.getActions(this.pendingRolesList);
    this.pendingRolesList.data = [];
    this.roleManagementService.getPendingRoles().subscribe(
      res => {
        if (res.data) {
          this.pendingRolesList.data = res.data;
          this.pendingRolesList.data.map(item => {
            item['roleName'] = item.name;
          });
        }
      },
      err => {
        console.log(err, 'err');
      }
    );
  }
  getDraftsRoles() {
    this.getActions(this.draftsRolesList);
    this.draftsRolesList.data = [];
    this.roleManagementService.getDraftsRoles().subscribe(
      res => {
        if (res.data) {
          this.draftsRolesList.data = res.data;
          this.draftsRolesList.data.map(item => {
            item['roleName'] = item.name;
          });
        }
      },
      err => {}
    );
  }

  getActions(data) {
    const _module = RoleManagementEnumService.ROLEMGMT;
    this.actionsArr = this.userService.getModulePermission(
      _module,
      EnumsService.ACTIONS[_module]
    );
    if (this.actionsArr.actionsArray) {
      this.actionsArr.actionsArray = this.actionsArr.actionsArray.filter(function(
        obj
      ) {
        if (data.tableHeader === RoleManagementEnumService.pendingRoles) {
          return (
            obj.type !== RoleManagementEnumService.EDIT &&
            obj.type !== RoleManagementEnumService.DELETE &&
            obj.type !== RoleManagementEnumService.APPROVE &&
            obj.type !== RoleManagementEnumService.ADD
          );
        } else if (data.tableHeader === RoleManagementEnumService.draftdRoles) {
          return (
            obj.type !== RoleManagementEnumService.APPROVE &&
            obj.type !== RoleManagementEnumService.ADD &&
            obj.type !== RoleManagementEnumService.CREATE_APPROVE &&
            obj.type !== RoleManagementEnumService.EDIT_APPROVE
          );
        } else {
          return obj.type !== RoleManagementEnumService.CREATE_APPROVE;
        }
      });
      data.actions = this.actionsArr.actionsArray;
      if (data.tableHeader === RoleManagementEnumService.approvedRoles) {
        data.actions.push(EnumsService.ROLE_REJECT);
        data.tableActions = this.actionsArr.headerRights;
      } else {
        this.actionsArr.headerRights.add = false;
        data.tableActions = this.actionsArr.headerRights;
      }
    }
  }

  getMasterData(data?) {
    if (data) {
      const req = {
        category: data
      };
      this.roleManagementService.getRoleMasterData(req).subscribe(
        res => {
          this.roleMasterData = [];
          this.roleMasterData = res.data;
          this.dataService.setData(
            RoleManagementEnumService.ROLE_MASTER_DATA,
            this.roleMasterData
          );
          this.roleInfo.modulePrivilege = this.utilService.deepCopy(
            this.roleMasterData
          );
        },
        error => {}
      );
    } else {
      this.roleMasterData = [];
      this.dataService.setData(
        RoleManagementEnumService.ROLE_MASTER_DATA,
        this.roleMasterData
      );
      this.roleInfo.modulePrivilege = this.utilService.deepCopy(
        this.roleMasterData
      );
    }
  }
  openAddRoleModal(content, option) {
    this.configModalOptionMode = option.mode;
    this.modalService
      .open(content, {
        windowClass: 'jio-modal',
        size: 'lg',
        backdrop: 'static',
        keyboard: false
      })
      .result.then(result => {}, reason => {});
  }

  addNewRole(content, option) {
    this.getMasterData();
    this.roleInfo = {
      name: '',
      category: '',
      status: '',
      remarks: '',
      isDefault: false,
      modulePrivilege: this.utilService.deepCopy(this.roleMasterData)
    };
    this.openAddRoleModal(content, option);
  }

  viewItemFromChecker(event) {
    this.populateValues(event);
    this.openAddRoleModal(this.roleMgmtModalContent, {
      mode: RoleManagementEnumService.VIEW
    });
  }
  viewItemFromMaker(event) {
    this.populateMakerValues(event);
    this.openAddRoleModal(this.roleMgmtModalContent, {
      mode: RoleManagementEnumService.VIEW
    });
  }
  populateValues(item) {
    const _req = {
      roleId: item.roleId
    };
    this.roleManagementService.getUpdateData(_req).subscribe(
      res => {
        this.updateData(res.data);
      },
      error => {}
    );
  }
  populateMakerValues(item) {
    const _req = {
      roleId: item.roleId
    };
    this.roleManagementService.getMakerValues(_req).subscribe(
      res => {
        this.updateData(res.data);
      },
      error => {}
    );
  }
  updateData(item) {
    this.roleInfo = JSON.parse(JSON.stringify(item));
    this.roleInfo.modulePrivilege.map(item => {
      item.checkAll =
        item.privilege.filter(ev => {
          return ev.isChecked === true;
        }).length === item.privilege.length;
    });
    this.roleInfo.modulePrivilege.map(data => {
      data.privilege.map(ev => {
        ev.isChecked = JSON.parse(ev.isChecked);
      });
    });
  }
  editItem(event) {
   this.verifyIsExistInMakerTable(event);
  }
  async verifyIsExistInMakerTable(event) {
    const data = {
      appendUserId: true,
      userId: event.roleId,
      donotShowError: true
    };
    const result = await this.roleManagementService.verifyIsExistInMakerTable(
      data
    );
    if (result.data && result.data.length > 0) {
          this.dataService.broadcast('alert', {
          type: RoleManagementEnumService.ERROR,
          message: RoleManagementEnumService.ROLE_EDIT_ERROR
        });
    } else {
        this.updatingApprovedRecords = true;
        this.populateValues(event);
        this.openAddRoleModal(this.roleMgmtModalContent, {
          mode: RoleManagementEnumService.EDIT
        });
    }
  }

  createApprove(event) {
    this.isChecker = true;
    this.populateMakerValues(event);
    this.openAddRoleModal(this.roleMgmtModalContent, {
      mode: RoleManagementEnumService.APPROVE
    });
  }
  editDrafts(event) {
    this.updatingDrafts = true;
    this.populateMakerValues(event);
    this.openAddRoleModal(this.roleMgmtModalContent, {
      mode: RoleManagementEnumService.EDIT
    });
  }

  deleteItem(event) {
    this.openModal(event, this.deleteConfirmModalContent);
  }
  deleteDraft(event) {
    this.updatingDrafts = true;
    this.openModal(event, this.deleteConfirmModalContent);
  }

  enableItem(event) {
    this.openModal(event, this.confirmDisableModalContent);
  }

  disableItem(event) {
    this.openModal(event, this.confirmEnableModalContent);
  }

  openModal(item, content) {
    this.item = item;
    this.modalService
      .open(content, {
        windowClass: 'jio-modal jio-small-modal',
        size: 'sm',
        backdrop: 'static',
        keyboard: false
      })
      .result.then(result => {}, reason => {});
  }
  enableDisableItem(event) {
    if (event.status === this._active) {
      this.enableItem(event);
    } else {
      this.disableItem(event);
    }
  }

  checkAll(event, data) {
    data = data.map(item => {
      item.isChecked = event;
      return item;
    });
  }

  checkItem(event, panel) {
    panel.checkAll =
      panel.privilege.filter(item => {
        return item.isChecked === true;
      }).length === panel.privilege.length;
  }

 async submitRole(close, type) {
    let status;

    switch (this.configModalOptionMode) {
      case RoleManagementEnumService.CREATE:
        if (type === RoleManagementEnumService.SAVE) {
          status = RoleManagementEnumService.MAKER_CHECKER.CD;
        } else {
          status = RoleManagementEnumService.MAKER_CHECKER.CI;
        }
        break;
      case RoleManagementEnumService.EDIT:
        if (type === RoleManagementEnumService.SAVE) {
          status = RoleManagementEnumService.MAKER_CHECKER.UD;
        } else {
          status = RoleManagementEnumService.MAKER_CHECKER.UI;
        }
        break;
      case RoleManagementEnumService.APPROVE:
        if (type === RoleManagementEnumService.SAVE) {
          if (
            this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.CI
          ) {
            status = RoleManagementEnumService.MAKER_CHECKER.AP;
          } else if (
            this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.UI
          ) {
            status = RoleManagementEnumService.MAKER_CHECKER.AP;
          } else if (
            this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.DI
          ) {
            status = RoleManagementEnumService.MAKER_CHECKER.DL;
          }
        } else {
          if (
            this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.CI
          ) {
            status = RoleManagementEnumService.MAKER_CHECKER.CR;
          } else if (
            this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.UI
          ) {
            status = RoleManagementEnumService.MAKER_CHECKER.UR;
          } else if (
            this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.DI
          ) {
            status = RoleManagementEnumService.MAKER_CHECKER.DR;
          }
        }
        break;
    }

    this.roleInfo.status = status;
    switch (this.configModalOptionMode) {
      case RoleManagementEnumService.CREATE:
        const roleInfo = this.cms.deepCopyOfObject(this.roleInfo);
        roleInfo.modulePrivilege.map(item => {
          delete item.checkAll;
          item.privilege = item.privilege.filter(data => {
            return data.isChecked === true;
          });
        });
        const isChecked = this.roleManagementService.validatePrivileges(this.roleInfo.modulePrivilege);
        if (isChecked) {

          // roleInfo.modulePrivilege.map((item, key) => {
          //   if (item.privilege.length === 0) {
          //     roleInfo.modulePrivilege.splice(key, 1);
          //   }
          // });

          roleInfo.modulePrivilege.filter((item, key) => {
           return item.privilege.length !== 0;
          });

          const result = await this.roleManagementService.addRole(
            roleInfo
          );
         
          if(result.status && result.status === 409) {
              this.openConfirmModal(roleInfo, result.error.msg, close, false);  
            } else {
              this.closeModalAndFetchData(close, RoleManagementEnumService.ROLE_ADDED_SUCCESSFULLY);
            }
      } else {
        this.dataService.broadcast('alert', {
          type: 'danger',
          message: RoleManagementEnumService.ATLEAST_ONE_PRIVILEGE_ERROR
        });
      }
        break;

      case RoleManagementEnumService.EDIT:
        this.updateWindowClose = close;
        this.modalService
          .open(this.updateConfirmModalContent, {
            windowClass: 'jio-modal jio-small-modal',
            size: 'sm',
            backdrop: 'static',
            keyboard: false
          })
          .result.then(result => {}, reason => {});
        break;
      case RoleManagementEnumService.APPROVE:
        const _req = {
          id: this.roleInfo['roleId'],
          remarks: this.roleInfo.remarks,
          status: this.roleInfo.status
        };
        const result = await this.roleManagementService.approveOrRejectPromise(
          _req
        );
       
        if(result.status && result.status === 409) {
            this.openConfirmModal(_req, result.error.msg, close, true);  
          } else {
            const message =
              this.roleInfo.status ===
                RoleManagementEnumService.MAKER_CHECKER.AP ||
              this.roleInfo.status ===
                RoleManagementEnumService.MAKER_CHECKER.DL
                ? RoleManagementEnumService.ROLE_HAS_BEEN_APPROVED
                : RoleManagementEnumService.ROLE_REJECTED;
              this.closeModalAndFetchData(close, message);
          }
        break;
    } 
  }
  openConfirmModal(defaultData, msg, close, isApprove, method?, url?) {
    this.defaultRoleData = defaultData;
    this.isApprove = isApprove;
    this.closeMainModal = close;
    this.defaultRoleErrorMsg = msg;
    this.method = method;
    this.url = url;
    this.openModal(null, this.conformDefaultTemplate);
  }
  confirmDefaultRole(data, close) {
   if(this.method) {
   const req = this.defaultRoleData;
   if(req.user) {
    req.user['isUserConfirmed'] = data;
    req.user['queryParam'] = true;
   
   } else {
    req['isUserConfirmed'] = data;
    req['queryParam'] = true;
   }
       this.roleManagementService
      .updateRole(req, this.url, this.method)
      .subscribe(
        res => {
          if (res) {
            this.updatingDrafts = false;
            this.updatingApprovedRecords = false;
            this.closeModal(this.updateWindowClose);
            this.closeModalAndFetchData(close, RoleManagementEnumService.ROLE_UPDATED_SUCCESSFULLY);
            this.updateWindowClose = '';
          }
        },
        error => {}
      );
    } else {
      this.defaultRoleData['isUserConfirmed'] = data;
      if(this.isApprove)  {
        this.roleManagementService.approveOrReject(this.defaultRoleData).subscribe(
            res => {
              if (res) {
                const message =
                this.roleInfo.status ===
                  RoleManagementEnumService.MAKER_CHECKER.AP ||
                this.roleInfo.status ===
                  RoleManagementEnumService.MAKER_CHECKER.DL
                  ? RoleManagementEnumService.ROLE_HAS_BEEN_APPROVED
                  : RoleManagementEnumService.ROLE_REJECTED;
                this.closeModalAndFetchData(close, message);
                this.closeModal(this.closeMainModal);
              }
            },
            error => {}
          );
      } else {
      this.roleManagementService.addRoleWithUserConfirmed(this.defaultRoleData).subscribe(result => {
        this.closeModalAndFetchData(close, RoleManagementEnumService.ROLE_ADDED_SUCCESSFULLY);
        this.closeModal(this.closeMainModal);
      });
    }
    }
  }
 async updateRole(close) {
    let url;
    let method;
    if (this.updatingDrafts) {
      url = RoleManagementEnumService.UPDATE_ROLE_DRAFT;
    } else {
      url = RoleManagementEnumService.UPDATE_ROLE;
    }
    method = 'put';
    if (this.updatingApprovedRecords) {
      if (this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.UI) {
        method = 'put';
        url = RoleManagementEnumService.UPDATE_ROLE;
      } else {
        method = 'post';
        url = RoleManagementEnumService.UPDATE_ROLE_DRAFT;
      }
    }
    this.roleInfo['updatedBy'] = this.userService.username();
    this.roleInfo['updatedDate'] = new Date();
    const roleInfo = this.cms.deepCopyOfObject(this.roleInfo);
    roleInfo.modulePrivilege.map(item => {
      delete item.checkAll;
        item.privilege = item.privilege.filter(data => {
          return data.isChecked === true;
        });
    });
    roleInfo['queryParam'] = true;
    const req = {
      user: roleInfo
    };
    const isChecked = this.roleManagementService.validatePrivileges(this.roleInfo.modulePrivilege);
        if (isChecked) {
        delete roleInfo.createdDate;
        delete roleInfo.updatedDate;
        roleInfo.modulePrivilege.map((item, key) => {
          if (item.privilege.length === 0) {
            roleInfo.modulePrivilege.splice(key, 1);
          } else {
            item.privilege = item.privilege.map(privilege => ({
              code:  privilege.code
            }));
          }
        });

        const result = await this.roleManagementService.updateRolePromise(
          method === 'put' ? req : roleInfo, url, method
        );
       
        if(result.status && result.status === 409) {
            this.closeModal(close);
            this.openConfirmModal(method === 'put' ? req : roleInfo, result.error.msg, close, true, method, url);  
          } else { 
            this.updatingDrafts = false;
            this.updatingApprovedRecords = false;
            this.closeModal(this.updateWindowClose);
            this.closeModalAndFetchData(close, RoleManagementEnumService.ROLE_UPDATED_SUCCESSFULLY);
            this.updateWindowClose = '';
          }
    
        } else {
          this.dataService.broadcast('alert', {
            type: 'danger',
            message: RoleManagementEnumService.ATLEAST_ONE_PRIVILEGE_ERROR
          });
        }
  }

  roleStatusChange(status, close) {
    if (status === RoleManagementEnumService.DELETE) {
      let url;
      if (this.updatingDrafts) {
        url = RoleManagementEnumService.UPDATE_ROLE_DRAFT;
      } else {
        url = RoleManagementEnumService.UPDATE_ROLE;
      }
      const data = {
        user: { roleId: this.item.roleId, queryParam: true }
      };
      this.roleManagementService.deleteRole(data, url).subscribe(
        res => {
          const message = this.updatingDrafts
          ? RoleManagementEnumService.ROLE_DELETED_SUCCESSFULLY
          : RoleManagementEnumService.DELETED_INTIALTION_SUCCESS;
          this.closeModalAndFetchData(close, message);
        },
        error => {}
      );
    } else {
      const data = {
        user: { roleId: this.item.roleId, queryParam: true, status: status }
      };
      this.roleManagementService.updateStatus(data).subscribe(
        res => {
          this.closeModalAndFetchData(close, RoleManagementEnumService.STATUS_CHANGED_SUCCESSFULLY);
        },
        error => {}
      );
    }
  }
  closeModalAndFetchData(close, message) {
    this.fetchRolesList();
    this.closeModal(close);
    this.dataService.broadcast('alert', {
      type: RoleManagementEnumService.SUCCESS,
      message: message
    });
  }
  closeModal(close) {
    close('Cross click');
  }
}
