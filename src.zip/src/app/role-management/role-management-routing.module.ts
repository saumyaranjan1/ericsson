import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RoleManagementComponent } from './role-management.component'

import { ApprovedComponent } from '../role-management/approved/approved.component'
import { DraftComponent } from '../role-management/draft/draft.component'
import { PendingComponent } from '../role-management/pending/pending.component'
 
const routes: Routes = [
  
  { path: '', component: ApprovedComponent },
  { path: 'aprovd', component: ApprovedComponent },
  { path: 'pendng', component: PendingComponent },
  { path: 'mdraft', component: DraftComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RoleManagementRoutingModule { }
