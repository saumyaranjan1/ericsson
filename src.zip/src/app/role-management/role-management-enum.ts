import { Injectable } from '@angular/core';

@Injectable()
export class RoleManagementEnumService {
  public static ROLEMGMT = 'ROLMGM';
  public static approvedRoles = 'Approved Roles';
  public static pendingRoles = 'Pending Roles';
  public static draftdRoles = 'Draft Roles';
  public static VIEW = 'view';
  public static EDIT = 'edit';
  public static EDIT_APPROVE = 'editapprove';
  public static DELETE = 'delete';
  public static DELETE_APPROVE = 'deleteapprove';
  public static APPROVE = 'approve';
  public static REJECT = 'reject';
  public static CREATE = 'create';
  public static ADD = 'add';
  public static SAVE = 'save';
  public static SUBMIT = 'submit';
  public static CREATE_APPROVE = 'createapprove';
  public static ROLE_MASTER_DATA = 'roleMasterData';
  public static ROLE_ADDED_SUCCESSFULLY = 'Role Added Successfully';
  public static SUCCESS = 'success';
  public static ERROR = 'danger';
  public static ROLE_HAS_BEEN_APPROVED = 'Role has been Approved';
  public static ROLE_REJECTED = 'Role Rejected';
  public static ROLE_UPDATED_SUCCESSFULLY = 'Role updated Successfully';
  public static ROLE_DELETED_SUCCESSFULLY = 'Role Deleted Successfully';
  public static DELETED_INTIALTION_SUCCESS =
    'Delete role Intiation is Successfully';
  public static STATUS_CHANGED_SUCCESSFULLY = 'Status Changed Successfully';
  public static UPDATE_ROLE_DRAFT = 'updateRoleDraft';
  public static UPDATE_ROLE = 'updateRole';
  public static ATLEAST_ONE_PRIVILEGE_ERROR =
    'Atleast One Privilege should be seleted!';
  public static ROLE_EDIT_ERROR =
    'This record is already in draft or pending for approval items. Pleasse take action on the the existing record.';

  // macker-checker codes

  public static MAKER_CHECKER = {
    CD: 'CD',
    UD: 'UD',
    CI: 'CI',
    UI: 'UI',
    DI: 'DI',
    AP: 'AP',
    DL: 'DL',
    CR: 'CR',
    UR: 'UR',
    DR: 'DR'
  };

  public static modalConfig = {
    create: {
      headerText: 'Create Role',
      primeBtnText: 'Draft',
      secodaryBtnText: 'Submit'
    },
    view: { headerText: 'View Role', primeBtnText: 'Ok' },
    edit: {
      headerText: 'Edit Role',
      primeBtnText: 'Draft',
      secodaryBtnText: 'Submit'
    },
    approve: {
      headerText: 'Approve/Reject Role',
      primeBtnText: 'Approve',
      secodaryBtnText: 'Reject'
    }
  };
  public static approvedRolesList = {
    data: [],
    columns: [
      {
        displayName: 'Name',
        key: 'roleName',
        filter: ''
      },
      {
        displayName: 'Status',
        key: 'status',
        filter: ''
      },
      {
        displayName: 'Created By',
        key: 'createdBy',
        filter: 'lowercase'
      },
      {
        displayName: 'Created On',
        key: 'createdDate',
        filter: 'date'
      }
    ],
    actions: [],
    actionsLabel: 'Actions',
    tableHeader: RoleManagementEnumService.approvedRoles,
    tableActions: {
     
    },
    tabelTooltip:'This is the index page Role Management',
  };
  public static pendingRolesList = {
    data: [],
    columns: [
      {
        displayName: 'Name',
        key: 'roleName',
        filter: ''
      },
      {
        displayName: 'Status',
        key: 'status',
        filter: ''
      },
      {
        displayName: 'Created By',
        key: 'createdBy',
        filter: 'lowercase'
      },
      {
        displayName: 'Created On',
        key: 'createdDate',
        filter: 'date'
      }
    ],
    actions: [],
    actionsLabel: 'Actions',
    tableHeader: RoleManagementEnumService.pendingRoles,
    tabelTooltip:'This is the index page Role Management',
    tableActions: {
      
    }
  };
  public static draftsRolesList = {
    data: [],
    columns: [
      {
        displayName: 'Name',
        key: 'roleName',
        filter: ''
      },
      {
        displayName: 'Status',
        key: 'status',
        filter: 'status'
      },
      {
        displayName: 'Created By',
        key: 'createdBy',
        filter: 'lowercase'
      },
      {
        displayName: 'Created On',
        key: 'createdDate',
        filter: 'date'
      }
    ],
    actions: [],
    actionsLabel: 'Actions',
    tableHeader: RoleManagementEnumService.draftdRoles,
    tabelTooltip:'This is the index page Role Management',
    tableActions: {
      showCheck:true,
      search:true
    }
  };
}
