import { Component, OnInit,ViewChild,ElementRef } from '@angular/core';
import { RoleManagementEnumService } from '../role-management-enum';
import { RoleManagementService } from '../role-management.service';
import { EnumsService } from '../../shared/services/enums.service';
import { DatatableComponent } from '../../shared/components/datatable/datatable.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../../shared/services/data.service';
import { UserService } from '../../shared/services/user.service';
import { CommonMethodsService } from '../../shared/methods/common-methods';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
@Component({
  selector: 'app-pending',
  templateUrl: './pending.component.html',
  styleUrls: ['./pending.component.less']
})
export class PendingComponent implements OnInit {
  @ViewChild(DatatableComponent,{ static: false }) child: DatatableComponent;
  @ViewChild('roleMgmtModalContent' , { static: true }) roleMgmtModalContent: ElementRef;
  @ViewChild('conformDefaultTemplate', {static: true}) conformDefaultTemplate: ElementRef;
  @ViewChild('approvalModalContent' , { static: true }) approvalModalContent: ElementRef;
  @ViewChild('rejectTemplate' , { static: true }) rejectTemplate: ElementRef;

  pendingRolesList = RoleManagementEnumService.pendingRolesList;
  actionsArr;
  searchValue: String = '';
  editModelData:any;
  approveForm: FormGroup;
  configModalOptionMode: null;
  roleInfo = {
    id: '',
    remarks:'',
    status: ''
  };
  isApprove;
  defaultRoleData;
  closeMainModal;
  defaultRoleErrorMsg;
  item;
  method;
  url;
  searchColumns:any;
  categorysArray;
  moduleroles;
  modulePrevelage;
  constructor(  private roleManagementService: RoleManagementService,
    private modalService: NgbModal,
     private dataService: DataService,
    private userService: UserService,
    private cms: CommonMethodsService,
    private fb: FormBuilder) { }

  ngOnInit() {
    this.getPendingRoles();
    this.getCategorys();
    this.searchColumns=[
      {
         key: 'description',
      }
    ]
  }
  getCategorys() {
    this.roleManagementService.getCategory().subscribe(res => {
      this.categorysArray = res.data;
    });
  }
  getActions(data) {
    const _module = RoleManagementEnumService.ROLEMGMT;

    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

 // API to get Previliages
 this.userService.getPreViliages(obj).subscribe( prev => {
  this.actionsArr = this.userService.getModulePermission(
    EnumsService.ACTIONS[_module],
    prev.data.privilege // Passing privilege to the methos to get thr actions array
  );
  if (this.actionsArr.actionsArray) {
    this.actionsArr.actionsArray = this.actionsArr.actionsArray.filter(function(
      obj
    ) {
       return (
          obj.type !== RoleManagementEnumService.EDIT &&
          obj.type !== RoleManagementEnumService.DELETE &&
          obj.type !== RoleManagementEnumService.ADD
        );
    });
     data.actions = this.actionsArr.actionsArray;
     data.tableActions = this.actionsArr.headerRights;
     data.tableActions.add=false;
     data.tableActions.search=true;
     data.tableActions.showCheck=true;
     data.tableActions.deleteAction=true;

   }
  
  
});

  }
 
  getPendingRoles(){
    this.roleInfo = {
      id: '',
      remarks:'',
      status: ''
    };
    this.getActions(this.pendingRolesList);
    this.pendingRolesList.data = [];
    this.pendingRolesList.actionsLabel='Actions',
    this.roleManagementService.getPendingRoles().subscribe(
      res => {
        if (res.data) {
          this.pendingRolesList.data = res.data;
          this.pendingRolesList.data.map(item => {
            item['roleName'] = item.name;
          });
          this.child.checkAll(false);
        }
      },
      err => {
        console.log(err, 'err');
      }
    );
  }
  openShowRoles(content, option) {
    this.configModalOptionMode = option.mode;
    this.modalService
      .open(content, {
        windowClass: 'jio-modal',
        size: 'lg',
        keyboard: false
      })
      .result.then(result => {}, reason => {});
  }
  openAddRoleModal(content, option) {
    this.configModalOptionMode = option.mode;
    this.modalService
      .open(content, {
        windowClass: 'jio-modal',
        size: 'sm',
         keyboard: false
      })
      .result.then(result => {}, reason => {});
  }
  
  nextModel(event){
    this.closeModal(event);
    this.openShowRoles(this.roleMgmtModalContent, {
      mode: this.configModalOptionMode
    });
  }
  back(close,event){
    this.closeModal(close);
    this.openAddRoleModal(this.approvalModalContent, {
      mode:  this.configModalOptionMode
     });
    this.createDeviceFormBlock(event);
   }
  viewItem(event){
    this.createDeviceFormBlock(event);
     this.openAddRoleModal(this.approvalModalContent, {
      mode:  RoleManagementEnumService.VIEW
    });
  }
  populateValues(item) {
    this.moduleroles=[];
    const _req = {
      roleId: item.roleId
    };
    this.roleManagementService.getMakerValues(_req).subscribe(
      res => {
        this.modulePrevelage=res.data.moduleGroups;
        this.editModelData=res.data;
        this.modulePrevelage.forEach(item => {
        if(item.isChecked){
         this.moduleItemCheck(true,item.groupCode);
        }   
        });
      },
      error => {}
    );
  }
  onChange(event){
    const req = {
      category: event
    };
    this.roleManagementService.getRoleMasterData(req).subscribe(
      res => {
        if(this.configModalOptionMode === 'create'){
          this.editModelData={};
          this.editModelData.name=this.approveForm.value.roleName;
          this.editModelData.modulePrivilege=res.data;
         }else{
          this.modulePrevelage=res.data.moduleGroups;
               this.editModelData=res.data;
               this.modulePrevelage.forEach(item => {
               if(item.isChecked){
                this.moduleItemCheck(true,item.groupCode);
               }   
               });
         }
       },
      error => {}
    );
} 


moduleItemCheck(event,groupName){
  if(event){
    this.modulePrevelage.forEach(item => {
      if(groupName  == item.groupCode){
        item.modules.forEach(inneritem => {
            this.moduleroles.push(inneritem);
        });
      }
    });
  }else{
    this.modulePrevelage.forEach(item => {
      if(!item.isChecked && item.modules){
          item.modules.forEach(inneritem => {
            this.moduleroles.forEach((modelitem,filterid) => {
              if(modelitem.moduleCode==inneritem.moduleCode){
                this.moduleroles.splice(filterid,1);
              }
           });
           });
      }
    });
  }
  this.editModelData.modulePrivilege=this.moduleroles;
  }
createDeviceFormBlock(event?) {
  if(this.configModalOptionMode !== 'create'){ 
    this.populateValues(event);
  }
  this.approveForm = this.fb.group({
    roleName: [
      event.roleName ? event.roleName : event.name,
      [
        Validators.required,
      ]
    ],
    category: [
        event.category,
      [
        Validators.required,
      ]
    ],
    isDefault:  event ? event.isDefault : false
   });
}
closeModal(close) {
  close('Cross click');
}
approveOrReject(event, option) {
  this.isApprove = true;
  this.roleInfo.status = event['status'];
  this.roleInfo.id = event['roleId'];
  this.configModalOptionMode = option.mode;
  this.createDeviceFormBlock(event);
     this.openAddRoleModal(this.approvalModalContent, {
      mode:  option.mode
    });
}
async submit(type,close) {
  
  let status;

  if (type === RoleManagementEnumService.SAVE) {
    if (
      this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.CI
    ) {
      status = RoleManagementEnumService.MAKER_CHECKER.AP;
    } else if (
      this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.UI
    ) {
      status = RoleManagementEnumService.MAKER_CHECKER.AP;
    } else if (
      this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.DI
    ) {
      status = RoleManagementEnumService.MAKER_CHECKER.DL;
    }
  } else {
    if (
      this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.CI
    ) {
      status = RoleManagementEnumService.MAKER_CHECKER.CR;
    } else if (
      this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.UI
    ) {
      status = RoleManagementEnumService.MAKER_CHECKER.UR;
    } else if (
      this.roleInfo.status === RoleManagementEnumService.MAKER_CHECKER.DI
    ) {
      status = RoleManagementEnumService.MAKER_CHECKER.DR;
    }
  }
   this.roleInfo.status = status;

  console.log(this.roleInfo);
  const result = await this.roleManagementService.approveOrRejectPromise(
    this.roleInfo
  );
 
  if(result.status && result.status === 409) {
      this.openConfirmModal( this.roleInfo, result.error.error, close, true);  
    } else {
      this.getPendingRoles();
      const message =
        this.roleInfo.status ===
          RoleManagementEnumService.MAKER_CHECKER.AP ||
        this.roleInfo.status ===
          RoleManagementEnumService.MAKER_CHECKER.DL
          ? RoleManagementEnumService.ROLE_HAS_BEEN_APPROVED
          : RoleManagementEnumService.ROLE_REJECTED;
          this.modalService.dismissAll();
          this.closeModal(close);
          this.closeModal(this.roleMgmtModalContent);
    }
}

rejectStatus(){
  this.openAddRoleModal(this.rejectTemplate, {
    mode:  this.configModalOptionMode
   });
}

closeModalAndFetchData(close, message) {
  this.getPendingRoles();
  this.closeModal(close);
  this.dataService.broadcast('alert', {
    type: RoleManagementEnumService.SUCCESS,
    message: message
  });
}
openConfirmModal(defaultData, msg, close, isApprove, method?, url?) {
  this.defaultRoleData = defaultData;
  this.isApprove = isApprove;
  this.closeMainModal = close;
  this.defaultRoleErrorMsg = msg;
  this.method = method;
  this.url = url;
  this.openModal(null, this.conformDefaultTemplate);
}
openModal(item, content) {
  this.item = item;
  this.modalService
    .open(content, {
      windowClass: 'jio-modal jio-small-modal',
      size: 'sm',
      keyboard: false
    })
    .result.then(result => {}, reason => {});
}
confirmDefaultRole(data, close) {
 
     this.defaultRoleData['isUserConfirmed'] = data;
     if(this.isApprove)  {
       this.roleManagementService.approveOrReject(this.defaultRoleData).subscribe(
           res => {
             if (res) {
               const message =
               this.roleInfo.status ===
                 RoleManagementEnumService.MAKER_CHECKER.AP ||
               this.roleInfo.status ===
                 RoleManagementEnumService.MAKER_CHECKER.DL
                 ? RoleManagementEnumService.ROLE_HAS_BEEN_APPROVED
                 : RoleManagementEnumService.ROLE_REJECTED;
               this.closeModalAndFetchData(close, message);
               this.closeModal(this.closeMainModal);
             }
           },
           error => {}
         );
     } else {
     this.roleManagementService.addRoleWithUserConfirmed(this.defaultRoleData).subscribe(result => {
       this.closeModalAndFetchData(close, RoleManagementEnumService.ROLE_ADDED_SUCCESSFULLY);
       this.closeModal(this.closeMainModal);
     });
   }
   }

}
