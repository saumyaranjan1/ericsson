import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommongSoonComponent } from './comming-soon.component';

describe('CommongSoonComponent', () => {
  let component: CommongSoonComponent;
  let fixture: ComponentFixture<CommongSoonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CommongSoonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommongSoonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
