import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comming-soon',
  templateUrl: './comming-soon.component.html',
  styleUrls: ['./comming-soon.component.less']
})
export class CommingSoonComponent implements OnInit {

  constructor() { }

  ngOnInit() {
     sessionStorage.clear();
  }

}
