import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CommingSoonComponent } from './comming-soon.component';
import { ComingSoonRoutingModule } from './coming-soon-routing.module';


@NgModule({
  declarations: [CommingSoonComponent],
  imports: [
    CommonModule,
    ComingSoonRoutingModule
  ]
})
export class CommingSoonModule { }
