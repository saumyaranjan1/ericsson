import { TestBed, async } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule
      ],
      declarations: [
        AppComponent
      ],
    }).compileComponents();
  }));

  describe(':', () => {

    function setup() {
      const fixture = TestBed.createComponent(AppComponent);
      const app = fixture.debugElement.componentInstance;
      return { fixture, app };
    }

    it('should create the app', () => {
      const { app } = setup();
      expect(app).toBeTruthy();
    });

    it(`should have as title 'JIOUtils-Public-Portal-UI'`, () => {
      const { app } = setup();
      expect(app.title).toEqual('JIOUtils-Public-Portal-UI');
    });

    xit('should render title', () => {
      const { fixture } = setup();
      fixture.detectChanges();
      const compiled = fixture.debugElement.nativeElement;
      expect(compiled.querySelector('.content span').textContent).toContain('JIOUtils-Public-Portal-UI app is running!');
    });
  });
});
