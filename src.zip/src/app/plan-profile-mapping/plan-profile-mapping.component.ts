import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { EnumsService } from '../shared/services/enums.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { PlanProfileMappingService } from './plan-profile-mapping.service';
import { forkJoin } from 'rxjs';
import { DataService } from '../shared/services/data.service';
import { InlinePagenationTableComponent } from '../shared/components/inline-pagenation-table/inline-pagenation-table.component';
import { UserService } from '../shared/services/user.service';


@Component({
  selector: 'app-plan-profile-mapping',
  templateUrl: './plan-profile-mapping.component.html',
  styleUrls: ['./plan-profile-mapping.component.less']
})
export class PlanProfileMappingComponent implements OnInit {
  @ViewChild('mapPlanAndProfile', { static: false }) mapPlanAndProfile: ElementRef;
  @ViewChild('deleteConfirmModalContent', { static: false }) deleteConfirmModalContent: ElementRef;
  @ViewChild(InlinePagenationTableComponent, { static: false }) child: InlinePagenationTableComponent;

  modalConfig = {
    create: { headerText: 'Map Plan And Profile', primeBtnText: 'Map' },
    edit: { headerText: 'Edit Map Plan And Profile', primeBtnText: 'Update' },
    view: { headerText: 'View of Plan Mapping' },
    sige: { sm: 'sm', lg: 'lg' }
  };
  configModalOptionMode = null;
  profileList = [];
  profileListTemp = [];
  selectedProfiles = [];
  dropdownSettings = EnumsService.MULTI_SELECT_DROPDOWN_OPTIONS;

  domainList = [];
  selectedDomains = [];
  dropdownSettingsForDomain = EnumsService.SINGLE_SELECT_DROPDOWN_OPTIONS;

  mapPlanAndProfileForm: FormGroup;
  planAndProfileInfo;
  serviceLoginStatus;
  data = {
    data: [],
    columns: [
      {
        displayName: 'plan Id',
        key: 'planid',
        filter: '',
        input: true,
        dropdown: false,
        textArea: false,
        singleSelect: false,
        showOnEdit: false,
        editvalue: false
      },
      {
        displayName: 'plan name',
        key: 'planName',
        filter: '',
        input: true,
        dropdown: false,
        textArea: false,
        singleSelect: false,
        showOnEdit: false,
        editvalue: true
      },
      {
        displayName: 'Notification Channel',
        key: 'configTypeSelect',
        filter: '',
        input: false,
        dropdown: false,
        textArea: false,
        singleSelect: true,
        showOnEdit: false,
        editvalue: true
      },
      {
        displayName: 'Domain name',
        key: 'domainSelect',
        filter: '',
        input: false,
        dropdown: true,
        textArea: false,
        showOnEdit: false,
        singleSelect: false,
        editvalue: true
      }
      , {
        // displayName: 'ProfileName',
        // key: 'profileSelect',
        // filter: '',
        // input: false,
        // dropdown: true,
        // textArea: false,
        // singleSelect: false,
        // editvalue: true,
        // showOnEdit: true

        displayName: 'ProfileName',
        key: 'profileSelect',
        filter: '',
        input: false,
        dropdown: true,
        textArea: false,
        save: true,
        editvalue: true
      },
    ],
    actions: [
    ],
    actionsLabel: 'Actions',
    tableHeader: 'Plan Profile Mapping',
    tableActions: {
      // search: true,
      // add: true,
      // view: false,
      // delete: true,
      // edit: true
    }
  };
  configTypeList = [
    {
      name: 'REDBEND',
      value: 'REDBEND'
    },
    {
      name: 'AGENTCONFIG',
      value: 'AGENTCONFIG'
    },
    {
      name: 'JNOPS INTERNAL',
      value: 'JNOPS INTERNAL'
    }
  ];
  editeScreenPlanInfo;
  actionsArr;
  constructor(
    private formBuilder: FormBuilder,
    private ngbModal: NgbModal,
    private cms: CommonMethodsService,
    private userService: UserService,
    private planProfileMappingService: PlanProfileMappingService,
    //private sidenavService: SidenavService,
    private dataService: DataService
  ) { }

  ngOnInit() {
    this.dropdownSettings.text = 'Please Select Profiles';
    this.dropdownSettings.selectAllText = 'Select All Profiles';
    this.dropdownSettings.unSelectAllText = 'UnSelect All Profiles';

    this.dropdownSettingsForDomain.text = 'Please Select Domain';

    this.profileFormBlock();
    setTimeout(() => {
      this.getPlanAndProfileMappingLists();
    });
    this.serviceLoginStatus = this.dataService.getData(
      'serviceLoginStatus'
    );
    if (this.serviceLoginStatus === undefined) {
      this.getServiceLoginStatus();
    }
  }
  getServiceLoginStatus() {
    // this.sidenavService.getServiceLoginStatus().subscribe(res => {
    //   if (res.data) {
    //     this.serviceLoginStatus = res.data;
    //      this.dataService.setData(
    //       'serviceLoginStatus', this.serviceLoginStatus
    //     );
    //   }
    // });
  }

  profileFormBlock(event?) {
    this.selectedProfiles = [];
    this.selectedDomains = [];
    if (event) {
      this.profileList.forEach(element => {
        if (event.profileids && event.profileids.includes(element.id)) {
          element.check = true;
          this.selectedProfiles.push(element);
        }
      });
      this.domainList.forEach(element => {
        if (event.domainid && event.domainid === element.id) {
          element.check = true;
          this.selectedDomains.push(element);
        }
      });


    }
    this.mapPlanAndProfileForm = this.formBuilder.group({
      planid: [event ? event.planid : null, [Validators.required, Validators.pattern('^[a-zA-Z0-9 ]*$')]],
      configType: [event ? event.configType : '', Validators.required],
      planName: [event ? event.planName : null, Validators.required],
      profileList: [event ? this.selectedProfiles : null],
      domainList: [event ? this.selectedDomains : null, Validators.required]
    });
  }
  newRowData: any;
  addMapPlanAndProfile(option) {
    this.profileFormBlock();
    this.newRowData = {
      'planid': '',
      'planName': '',
      'configTypeSelect': {},
      'domainSelect': {},
      'profileSelect': {},
      'newRow': true
    };
    this.newRowData.configTypeSelect.showItem = [];
    this.newRowData.configTypeSelect.model = [];
    this.newRowData.configTypeSelect.values = this.configTypeList;

    this.newRowData.domainSelect.showItem = [];
    this.newRowData.domainSelect.model = [];
    this.newRowData.domainSelect.values = this.domainList;

    this.newRowData.profileSelect.showItem = [];
    this.newRowData.profileSelect.model = [];
    this.newRowData.profileSelect.values = [];
    this.newRowData.profileSelect['multySelect'] = true;


    this.data.data.splice(0, 0, this.newRowData);
    this.child.updateEditCache('edit');
  }
  openModal(content, size, event?) {
    this.planAndProfileInfo = event;
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }
  closeModel(close) {
    close('Cross click');
  }
  submitForm(form, close) {
    const param = {
      'configType': form.data.configTypeSelect.showItem,
      'planName': form.data.planName,
      'planid': form.data.planid,
      "profileids": [],
      "domainid": form.data.domainSelect.showItem[0].id
    }
    form.data.profileSelect.showItem.forEach(element => {
      param.profileids.push(element.id)
    });

    this.createMapAndProfile(form, param);
  }
  createMapAndProfile(form, data) {
    const _req = {};
    if (form.action) {
      _req['url'] = 'createPlanProfileInfo';
      _req['method'] = 'post';
    } else {
      _req['url'] = 'updateProfile';
      _req['method'] = 'put';
    }
    this.planProfileMappingService
      .createPlanProfileMap(_req, data)
      .subscribe(res => {
        if (!form.action) {
          this.dataService.broadcast('alert', {
            type: 'success',
            message: `Update successfully!`
          });
        } else {
          this.dataService.broadcast('alert', {
            type: 'success',
            message: `Save successfully!`
          });
        }
        this.closeModel(close);
        this.getPlanAndProfileMappingLists();
        this.child.cancelEdit(form.data);
        this.child.submit = false;
      });
  }
  async editMapPlanAndProfile(event, option) {
    this.editeScreenPlanInfo = event;
    const req = {
      appendUserId: true,
      userId: event.domainid
    };
    const result = await this.planProfileMappingService.loadProfilesFromLocalDbAsPromise(
      req
    );
    if (result.data) {
      this.mapProfiles(result.data);
    }
    this.configModalOptionMode = option.mode;
    this.profileFormBlock(event);
    if (option.mode === 'view') {
      this.mapPlanAndProfileForm.disable();
      this.dropdownSettings.disabled = true;
      this.dropdownSettingsForDomain.disabled = true;
    } else {
      this.dropdownSettings.disabled = false;
      this.dropdownSettingsForDomain.disabled = false;
    }
    //this.openModal(this.mapPlanAndProfile, this.modalConfig.sige.lg);
    var profileSelectList = [];
    var profileSelectValue = [];

    result.data.forEach(element => {
      profileSelectList.push({ 'id': element.profileid, 'itemName': element.name })

      event.profileids.forEach(innerElement => {
        if (innerElement == element.profileid) {
          profileSelectValue.push({ 'id': innerElement, 'itemName': element.name })
        }
      });
    });

    this.data.data.forEach(element => {
      if (element.planid == event.planid) {
        element.profileSelect.values = profileSelectList;
        element.profileSelect.showItem = profileSelectValue;
        result.data.forEach(element => {
          profileSelectList.push({ 'id': element.profileid, 'itemName': element.name })
        });
      }
    });
  }
 
  setId() {
    this.data.data.forEach(function (item, key) {
      item["id"] = key;
    });
  }
  getActions() {
    const _module = EnumsService.PLAN_PROFILE_UI_API;

    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

     // API to get Previliages
     this.userService.getPreViliages(obj).subscribe( prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

    this.data.tableActions = this.actionsArr;
    this.data.tableActions['search'] = this.actionsArr.headerRights.search;
    this.data.tableActions['add'] = this.actionsArr.headerRights.add;
    this.data.tableActions['delete'] = this.actionsArr.headerRights.delete;
    this.data.actions = this.actionsArr.actionsArray;
    this.data.actions.push({
      'disableIconProp': true,
      'negate': null,
      'showIconProp': null,
      'title': "Load Profiles from Redbend",
      'type': "load"
    })
      
    });
    }

  getPlanAndProfileMappingLists() {
    this.getActions();
    const getDomainsList = this.planProfileMappingService.getDomainsList();
    const profileMappingDetails = this.planProfileMappingService.getPlanProfileMapDetails();
    forkJoin([getDomainsList, profileMappingDetails]).subscribe(
      results => {
        if (results[0] && Array.isArray(results[0].data)) {
          this.domainList = [];
          results[0].data.map(res => {
            this.domainList.push({
              id: res.domainid,
              itemName: res.domainName,
              check: true
            });
          });
          this.setId();
          this.child.updateEditCache('notEdit');
        } else {
          this.domainList = [];
        }
        if (results[1] && Array.isArray(results[1].data)) {
          this.data.data = results[1].data;
          this.data.data.map(item => {
            const domainSelectItems = [];
            if (item.profileids) {
              this.domainList.forEach(domain => {
                if (item.domainid === domain.id) {
                  item['domainName'] = domain.itemName;
                  domainSelectItems.push(domain);
                }
              });


              item['configTypeSelect'] = {};
              item['configTypeSelect']['showItem'] = item.configType;
              item['configTypeSelect']['model'] = item.configType;
              item['configTypeSelect']['values'] = this.configTypeList;

              item['domainSelect'] = {};
              item['domainSelect']['showItem'] = domainSelectItems;
              item['domainSelect']['model'] = item.domainName;
              item['domainSelect']['multySelect'] = false;
              item['domainSelect']['values'] = this.domainList;

              // item['profileSelect'] = {};
              // item['profileSelect']['showItem'] = [];
              // item['profileSelect']['model'] = item.profileids;
              // item['profileSelect']['multySelect'] = true;
              // item['profileSelect']['values'] = [];


              item['profileSelect'] = {};
              item['profileSelect']['showItem'] = [];
              item['profileSelect']['model'] = item.profileids;
              item['profileSelect']['values'] = [];
              item['profileSelect']['multySelect'] = true;
            }
          });
          this.setId();
          this.child.updateEditCache('notEdit');
        } else {
          this.data.data = [];
        }
      },
      error => { }
    );
  }
  loadProfilesFromRedBend(event) {
     const req = {
      appendUserId: true,
      userId: event.domainSelect.showItem[0].id
    };
    this.planProfileMappingService.profilesByDomain(req).subscribe(res => {
      this.loadProfilesFromLocalDb(event);
    });
  }

  loadProfilesFromLocalDb(event) {
    const req = {
      appendUserId: true,
      userId: event.domainSelect.showItem[0].id
    };
    this.planProfileMappingService.profilesByDomainFromLocalDb(req).subscribe(res => {
      if (res.data) {
        var profileSelectList=[];
        res.data.forEach(element => {
          profileSelectList.push({ 'id': element.profileid, 'itemName': element.name })
        });
  
        this.data.data.forEach(element => {
          if(element.planid==event.planid){
            element.profileSelect.values=profileSelectList;
          }else if(element.newRow){
            this.data.data[0].profileSelect.values=profileSelectList;
          }else{
            element.profileSelect.values=[];
          }
        });
      }
    });
  }
  mapProfiles(data) {
    this.profileList = [];
    data.map(item => {
      this.profileList.push({
        id: item.profileid,
        itemName: item.name + ' ( ' + item.profileid + ' )',
        check: true
      });
    });
  }
  loadDomains() {
    this.planProfileMappingService.loadDomains().subscribe(res => {
      this.getPlanAndProfileMappingLists();
    });
  }
  deletePlanAndprofileMap(close) {
    this.planProfileMappingService.deletePlanAndprofileMap(this.planAndProfileInfo.planid).subscribe(res => {
      this.getPlanAndProfileMappingLists();
      this.closeModel(close);
    });
  }
  openDeleteModal(event) {
    this.openModal(
      this.deleteConfirmModalContent,
      this.modalConfig.sige.sm,
      event
    );
  }
  checkItem(event, profile) {
    if (!event && this.configModalOptionMode !== 'view') {
      this.selectedProfiles = this.selectedProfiles.filter(
        sProfile => sProfile.id !== profile.id
      );
    }
  }
  onItemSelect(item: any) {
    if (!item.check) {
      item.check = !item.check;
    }
  }
  onDomainSelect(item: any) {
    if(item.key=='domainSelect'){
      if (!item.check) {
        item.check = !item.check;
      }
      this.selectedProfiles = [];
      const req = {
        appendUserId: true,
        userId: item.item.id
      };
      this.planProfileMappingService.profilesByDomainFromLocalDb(req).subscribe(res => {
        if (res.data) {
        var profileSelectList=[];
        res.data.forEach(element => {
          profileSelectList.push({ 'id': element.profileid, 'itemName': element.name })
        });
  
        this.data.data.forEach(element => {
          if(element.planid==item.row.planid){
            element.profileSelect.values=profileSelectList;
          }else if(element.newRow){
            this.data.data[0].profileSelect.values=profileSelectList;
          }else{
            element.profileSelect.values=[];
          }
        });
        }
      });
    }
  
  }
  onSelectAll(items: any) {
    items.forEach(item => {
      if (!item.check) {
        item.check = !item.check;
      }
    });
  }
}
