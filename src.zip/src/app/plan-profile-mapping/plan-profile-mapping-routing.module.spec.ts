import { PlanProfileMappingRoutingModule } from './plan-profile-mapping-routing.module';

describe('PlanProfileMappingRoutingModule', () => {
  let planProfileMappingRoutingModule: PlanProfileMappingRoutingModule;

  beforeEach(() => {
    planProfileMappingRoutingModule = new PlanProfileMappingRoutingModule();
  });

  it('should create an instance', () => {
    expect(planProfileMappingRoutingModule).toBeTruthy();
  });
});
