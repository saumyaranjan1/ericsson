import { PlanProfileMappingModule } from './plan-profile-mapping.module';

describe('PlanProfileMappingModule', () => {
  let planProfileMappingModule: PlanProfileMappingModule;

  beforeEach(() => {
    planProfileMappingModule = new PlanProfileMappingModule();
  });

  it('should create an instance', () => {
    expect(planProfileMappingModule).toBeTruthy();
  });
});
