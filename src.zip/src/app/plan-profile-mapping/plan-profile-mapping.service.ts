import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class PlanProfileMappingService {

  constructor(private interceptorService: InterceptorService) { }
  getPlanProfileMapDetails() {
    return this.interceptorService.httpCall('get', 'getPlanProfileList');
  }
  createPlanProfileMap(data, request) {
    return this.interceptorService.httpCall(data.method, data.url, request);
  }
  deletePlanAndprofileMap(request) {
    return this.interceptorService.httpCall('delete', 'deletePlanAndprofileMap', request);
  }
  getProfileDetails() {
    return this.interceptorService.httpCall('get', 'getProfileList');
  }
  loadProfilesFromLocalDbAsPromise(request) {
    return this.interceptorService.httpPromise('get', 'getProfileList', request);
  }
  profilesByDomain(request) {
    return this.interceptorService.httpCall('get', 'profilesByDomain', request);
  }
  profilesByDomainFromLocalDb(request) {
    return this.interceptorService.httpCall('get', 'getProfileList', request);
  }
  getDomainsList() {
    return this.interceptorService.httpCall('get', 'getDomainsList');
  }
  loadDomains() {
    return this.interceptorService.httpCall('get', 'loadDomains');
  }
}
