import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PlanProfileMappingComponent } from './plan-profile-mapping.component';

describe('PlanProfileMappingComponent', () => {
  let component: PlanProfileMappingComponent;
  let fixture: ComponentFixture<PlanProfileMappingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PlanProfileMappingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PlanProfileMappingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
