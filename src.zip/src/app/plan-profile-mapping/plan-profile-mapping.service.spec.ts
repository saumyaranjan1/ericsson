import { TestBed } from '@angular/core/testing';

import { PlanProfileMappingService } from './plan-profile-mapping.service';

describe('PlanProfileMappingService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: PlanProfileMappingService = TestBed.get(PlanProfileMappingService);
    expect(service).toBeTruthy();
  });
});
