import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PlanProfileMappingRoutingModule} from './plan-profile-mapping-routing.module';
import { SharedModule } from '../shared/shared.module';
import { PlanProfileMappingComponent } from './plan-profile-mapping.component';
import { PlanProfileMappingService } from './plan-profile-mapping.service';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { SidenavService } from '../main/sidenav/sidenav.service';

@NgModule({
  imports: [
    CommonModule,
    PlanProfileMappingRoutingModule,
    SharedModule,
    AngularMultiSelectModule
  ],
  declarations: [PlanProfileMappingComponent],
  providers : [PlanProfileMappingService, SidenavService]
})
export class PlanProfileMappingModule { }
