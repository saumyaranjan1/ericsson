import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { PlanProfileMappingComponent } from './plan-profile-mapping.component';

const routes: Routes = [{ path: '', component: PlanProfileMappingComponent }];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  declarations: [],
  exports : [RouterModule]
})
export class PlanProfileMappingRoutingModule { }
