import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class ForgotPasswordServiceService {
  constructor(private interceptor: InterceptorService) { }

  forgotPassword(request,privatevar) {
    return this.interceptor.httpCall('put', privatevar?'forgotPasswordPrivate':'forgotPasswordPublic', request);
  }

}
