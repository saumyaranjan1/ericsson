import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import { ForgotPasswordServiceService } from './forgot-password-service.service';
import { DataService } from '../shared/services/data.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.less']
})
export class ForgotPasswordComponent implements OnInit {

  constructor(private router: Router,private dataService: DataService,private activeRouter: ActivatedRoute , private forgotPasswordService:ForgotPasswordServiceService ) { }

  routData : any;

  ngOnInit() { 
    this.activeRouter.queryParams.subscribe(params => {
      this.routData=params;
    });
  }

  changePassword(){
    this.dataService.setBtoaLocalStorage('key1', this.routData.key1);
    this.dataService.setBtoaLocalStorage('key2', this.routData.key2);
    this.router.navigate(['/forgot-password/change-password']);
  }
  
}
