import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ForgotPasswordComponent } from './forgot-password.component';
import { ForgotPasswordRoutingModule } from './forgot-password-routing.module';
import { ChangepasswordComponent } from './component/changepassword/changepassword.component';
import {  MatFormFieldModule, MatInputModule } from '@angular/material';
import { MatRadioModule, MatCheckboxModule, MatListModule, MatSelectModule, MatNativeDateModule,  } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ForgotPasswordServiceService } from './forgot-password-service.service';
import { SharedModule } from '../shared/shared.module';
@NgModule({
  imports: [
    CommonModule,
    ForgotPasswordRoutingModule,
    MatInputModule,
    MatFormFieldModule,
    MatRadioModule,
    MatCheckboxModule,
    MatListModule,
    MatSelectModule,
    MatNativeDateModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
  ],
  declarations: [ForgotPasswordComponent, ChangepasswordComponent],
  providers: [ForgotPasswordServiceService]
})
export class ForgotPasswordModule { }
