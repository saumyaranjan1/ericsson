import { Component, OnInit } from '@angular/core';
import {ErrorStateMatcher} from '@angular/material/core';
import { FormGroup, FormBuilder, Validators , FormControl, FormGroupDirective, NgForm } from '@angular/forms';
import { ForgotPasswordServiceService } from '../../forgot-password-service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AppConfigService } from './../../../app-config.service';
import { CommonMethodsService } from './../../../shared/methods/common-methods';
import { DataService } from './../../../shared/services/data.service';
import { SpinnerService } from './../../../shared/services/spinner.service';

class CrossFieldErrorMatcher implements ErrorStateMatcher {
  isErrorState(control: FormControl | null, form: FormGroupDirective | NgForm | null): boolean {
    const isSubmitted = form && form.submitted && form.invalid;
    return (control.dirty && form.invalid) || isSubmitted ;
  }
}

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.less']
})
export class ChangepasswordComponent implements OnInit {
  signupForm: FormGroup;
  passwordIsValid = false;
  errorMatcher = new CrossFieldErrorMatcher();
  keys:any;
  privateVar;
  routData:any;
  alert: any;
  alertSubs: any;
  constructor(private fb: FormBuilder,
              private forgotPasswordService:ForgotPasswordServiceService,
              private activeRouter: ActivatedRoute,
              private acs: AppConfigService,
              private cms: CommonMethodsService,
              private router: Router,
              private dataService: DataService,
              private spinnerService: SpinnerService
              ) {}

  ngOnInit() {
    this.privateVar = this.acs.configData['private'];
    this.alertSubs = this.dataService.on('alert', this.displayAlert);
    this.signupForm = this.fb.group({
      password: ['', Validators.required],
      confirmPassword:['', Validators.required]
    },{
      validator: this.cms.passwordValidatorMatrialInput
    });
  }

  closeAlert() {
    this.alert = null;
  }

  displayAlert = res => {
    this.alert = res;
    setTimeout(() => {
      this.alert = null;
      this.spinnerService.toggleSpinner(0);
    }, 4000);
  }
 
  changePassword(){
    if (this.signupForm.invalid) {
      return;
    }else{
      
      const param= {
        'lid':this.dataService.getAtobLocalStorage('key2'),
        'newPassword': this.cms.encryptData(this.signupForm.value.password, this.acs.configData['encryptKeyForSha256']),
        'passwordRresetId': this.dataService.getAtobLocalStorage('key1')  
     }
    this.forgotPasswordService.forgotPassword(param,this.privateVar).subscribe(result => {
      if (result) {
        this.dataService.clearSession();
        this.router.navigate(['/login']);
      }
    }, error => {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: error
      });
    });
    }
  }

  passwordValid(event) {
    this.passwordIsValid = event;
  }

  clear(event) {
     this.signupForm.setValue({password: '', confirmPassword: ''}); 
  }

}
