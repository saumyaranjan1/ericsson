import { B2cModule } from './b2c.module';

describe('B2cModule', () => {
  let b2cModule: B2cModule;

  beforeEach(() => {
    b2cModule = new B2cModule();
  });

  it('should create an instance', () => {
    expect(b2cModule).toBeTruthy();
  });
});
