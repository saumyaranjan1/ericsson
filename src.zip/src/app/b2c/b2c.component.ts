import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { B2cService } from './b2c.service';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { Router, ActivatedRoute } from '@angular/router';
import { DataService } from './../shared/services/data.service';
import { DatatableComponent } from '../shared/components/datatable/datatable.component';
import { UserService } from '../shared/services/user.service';
import { EnumsService } from './../shared/services/enums.service';


@Component({
  selector: 'app-b2c',
  templateUrl: './b2c.component.html',
  styleUrls: ['./b2c.component.less']
})
export class B2cComponent implements OnInit {
  @ViewChild('addDomainContent',{ static: false }) addDomainContent: ElementRef;
  @ViewChild('deleteConfirmModalContent',{ static: false }) deleteConfirmModalContent: ElementRef;
  @ViewChild('addDeviceContent',{ static: false }) addDeviceContent: ElementRef;
  @ViewChild('serverPaginationTableComponent', {static: true}) ServerPaginationTableComponent: ElementRef;
  @ViewChild('bulkUploadModalContent', {static: true}) bulkUploadModalContent: ElementRef;
  @ViewChild(DatatableComponent,{ static: false }) child: DatatableComponent;


  configModalOptionMode = null;
  modalConfig = {
    create: { headerText: 'Create Retail Customer:', primeBtnText: 'Save' },
    edit: { headerText: 'Edit Domain', primeBtnText: 'Update' },
    view: { headerText: 'View Domain', primeBtnText: ''}
  };
  modalDeviceConfig = {
    create: { headerText: 'Add Device to : Customer', primeBtnText: 'Save' },
    edit: { headerText: 'Edit Device', primeBtnText: 'Update' }
  };
  createDomainForm: FormGroup;
  createDeviceForm: FormGroup;
  eventInfo;
  planIsRequired = false;
  checkEmailAndRmn = 0;
  showErrorMsgForEmailOrPhone = false;
  searchData = {
    dropDownValue: '',
    searchKey: ''
  };
 
  data = {
     data: [],
     page: 1,
     total: 10,
     columns: [
      {
        displayName: 'CUSTOMER NAME',
        key: 'fullName',
        filter: ''
      }, {
        displayName: 'CUSTOMER ID',
        key: 'bpid',
        filter: ''
      },
      {
        displayName: 'Mobile',
        key: 'registeredMobileNumber',
        filter: ''
      },
      {
        displayName: 'MSISDN',
        key: 'msisdn',
        filter: ''
      },
      {
        displayName: 'email',
        key: 'email',
        filter: ''
      },
      {
        displayName: 'Service Status',
        key: 'serviceStatus',
        filter: ''
      }
    ],
    tableHeader: 'Retail Customer List',
    actions: [
      // {
      //   type: 'edit',
      //   title: 'Edit Partner',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'delete',
      //   title: 'Delete Domain',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'createDevice',
      //   title: 'Create Device',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'getDeviceList',
      //   title: 'Get Device List',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // }
    ],
    actionsLabel: 'Actions',
    tableActions: {
      // search: true,
      // searchActiom:true,
      // add: true,
      // edit: true,
      // dropDown: true,
      // refreshData: true,
      // showCheck:true,
      // deleteAction:true
    },
    dropDownsList: ['bpid',
    'email',
    'phone'],
    totalCount: 0,
    tabelTooltip:'This is the index page which shows list of Enterprise'
  };

  selectedDomainData;
  selectedDeviceData;
  serviceStatusArray = ['ACTIVE', 'SUSPEND', 'RESUME'];
  isEdit = false;
  actionsArr;
  constructor(
    private fb: FormBuilder,
    private ngbModal: NgbModal,
    private b2cService: B2cService,
    private cms: CommonMethodsService,
    private router: Router,
    private route: ActivatedRoute,
    private dataService: DataService,
    private userService: UserService
  ) {}

  ngOnInit() {
    setTimeout(() => {
    const deviceData = this.route.snapshot.queryParams['deviceData'];
    this.selectedDomainData = this.route.snapshot.queryParams['domainData'];
    if (this.selectedDomainData) {
      const selectedDomainValues = JSON.parse(this.selectedDomainData);
      if (selectedDomainValues.selectedValue && selectedDomainValues.searchValue) {
        this.searchData = {
          dropDownValue: selectedDomainValues.selectedValue,
          searchKey: selectedDomainValues.searchValue
        };
        this.getDataBySearch(this.searchData);
      }
    }
    if (deviceData && this.selectedDomainData) {
      this.createDevice(this.selectedDomainData, 'edit');
      this.createDeviceFormBlock(JSON.parse(deviceData));
    }
  });

  this.getPaginatedData(null)
  }

  getActions() {
    const _module = EnumsService.B2C_UI_API;
 // Form object to get the previliiages from server
 const obj = {
  moduleCode: _module,
  roleId: this.dataService.getAtobLocalStorage('roleId'),
  previliages: true
};

// API to get Previliages
this.userService.getPreViliages(obj).subscribe( prev => {

  this.actionsArr = this.userService.getModulePermission(
    EnumsService.ACTIONS[_module],
    prev.data.privilege // Passing privilege to the methos to get thr actions array
  );
  this.data.tableActions = this.actionsArr.headerRights;
  this.data.actions = this.actionsArr.actionsArray;
    this.data.tableActions['exportToCsv'] = true;
    this.data.tableActions['searchActiom'] = true;
    this.data.tableActions['search'] = true;
    this.data.tableActions['refreshData'] = true;
    this.data.tableActions['showCheck'] = true;
  
});
  }

  clearSearch(){
    this.getPaginatedData(null);
  }

   createDomainFormBlock(event?) {
    if (event) {
      this.isEdit = true;
    } else {
      this.isEdit = false;
    }
  
    this.createDomainForm = this.fb.group({
      bpid: [
        event ? event.bpid : null,
        [
          Validators.required,
          Validators.maxLength(50),
          Validators.pattern('^[0-9]*$')
        ]
      ],
      rmn: [
        event ? event.registeredMobileNumber : null,
        [
           Validators.pattern('^((\\+-?)|0)?[0-9]{10,15}$')
        ]
      ],
      email: [
        event ? event.email : null,
        [Validators.email, Validators.maxLength(240)]
      ],
      serviceStatus: [event ? event.serviceStatus : 'ACTIVE', Validators.required],
      msisdn: [
        event ? event.msisdn : null,
        [
          Validators.required,
          Validators.minLength(15),
          Validators.maxLength(15),
          Validators.pattern('^[0-9]*$')
        ]
      ],
      userDetails: this.fb.group({
        firstName: [
          event ? event.firstName : null,
          [Validators.pattern('^[a-zA-Z0-9 ]*$'), Validators.maxLength(50)]
        ],
        lastName: [
          event ? event.lastName : null,
          [Validators.pattern('^[a-zA-Z0-9 ]*$'), Validators.maxLength(50)]
        ]
      }),
      plan: this.fb.group({
        code: [event ? event.plan.code : null],
        name: [event ? event.plan.name : null],
        description: [event ? event.plan.description : null],
        startDate: [
          event ? this.cms.getTimeFromEpcoh(event.plan.startDate) : null
        ],
        endDate: [event ? (event.plan.endDate ? this.cms.getTimeFromEpcoh(event.plan.endDate) : null ) : null]
      })
    },
    {
      validator: this.cms.startDateAndEndDateValidation
    });
    this.setPlanValidations();
    // If event is there we are treating them as edit case
    if (event) {
      this.enableOrDisable('plan');
    }
  }
  setPlanValidations() {
    const plan = this.createDomainForm.controls['plan'];
    plan
      .get('code')
      .setValidators([Validators.required, Validators.maxLength(32)]);
    plan
      .get('name')
      .setValidators([Validators.required, Validators.maxLength(40)]);
    plan
      .get('description')
      .setValidators([Validators.required, Validators.maxLength(1024)]);
    plan.get('startDate').setValidators([Validators.required]);
    plan.get('endDate').setValidators([Validators.required]);
    this.updatePlanValues();
  }
  updatePlanValues() {
    const plan = this.createDomainForm.controls['plan'];
    plan.get('code').updateValueAndValidity();
    plan.get('name').updateValueAndValidity();
    plan.get('description').updateValueAndValidity();
    plan.get('startDate').updateValueAndValidity();
    plan.get('endDate').updateValueAndValidity();
  }
  enableOrDisable(data) {
    let condition;
    if (data === 'plan') {
      condition = this.planIsRequired;
    }
    if (!condition) {
      this.createDomainForm.controls[data].disable();
      if (this.configModalOptionMode !== 'edit' && this.configModalOptionMode !== 'view') {
        this.removeDataFromInputFields(this.createDomainForm.controls[data]);
      }
    } else {
      this.createDomainForm.controls[data].enable();
      this.setPlanValidations();
    }
  }

  removeDataFromInputFields(formControl) {
    Object.keys(formControl.controls).forEach(field => {
      formControl.get(field).setValue(null);
    });
  }

  submitForm(form, close, formName) {
    const formData = form.value;
    this.showErrorMsgForEmailOrPhone = false;
    this.validateAllFormFields(form);
    if (formName === 'domain') {
      if (this.checkEmailAndRmn === 2) {
        this.showErrorMsgForEmailOrPhone = true;
      } else {
        this.checkEmailAndRmn = 0;
        if (form.valid) {
          this.saveDomain(close, formData);
        }
      }
    } else {
      //  this.createEnterprise(close, formData);
      if (form.valid) {
        this.saveDevice(close, formData);
      }
    }
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field);
      if (field === 'email' || field === 'rmn') {
        if (!control.value) {
          this.checkEmailAndRmn++;
        }
      }
      if (control instanceof FormControl) {
        if (control.status !== 'DISABLED') {
          control.markAsTouched({ onlySelf: true });
        }
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }
  getValueOfRmnOrEmail(event) {
    if (event.target.value) {
      this.checkEmailAndRmn = 0;
      this.showErrorMsgForEmailOrPhone = false;
    }
  }
  saveDomain(close, formData) {
    const req = {
      data: formData
    };

    if (this.configModalOptionMode === 'edit') {
      req['method'] = 'put';
    } else {
      req['method'] = 'post';
    }

    if (formData.plan) {
      req.data.plan.startDate = isNaN(formData.plan.startDate)
        ? this.cms.getEpcohTIme(formData.plan.startDate)
        : formData.plan.startDate;
      req.data.plan.endDate = isNaN(formData.plan.endDate)
        ? this.cms.getEpcohTIme(formData.plan.endDate)
        : formData.plan.endDate;
    }

    this.b2cService.domainB2c(req).subscribe(res => {
      this.dataService.broadcast('alert', {
        type: 'success',
        message: 'Domain has been created successfully !'
      });
      this.closeModel(close);
       // Refreshing the component
       setTimeout(() => {
       this.router.navigateByUrl('../main/devices', {skipLocationChange: true}).then(() =>
       this.router.navigate(['../main/b2c_ui_api']));
    }, 2500);
  });
  }

  deleteDomain(event) {
     this.openModal(this.deleteConfirmModalContent, event, 'sm');
  }

  deleteDomainApi(close) {
    const _req = { bpid: this.eventInfo.bpid };
    this.b2cService.deleteDomain(_req).done(res => {
      this.dataService.broadcast('alert', {
        type: 'success',
        message: 'Domain has been deleted successfully !'
      });
      this.closeModel(close);
       // Refreshing the component
       setTimeout(() => {
       this.router.navigateByUrl('../main/devices', {skipLocationChange: true}).then(() =>
       this.router.navigate(['../main/b2c_ui_api']));
       }, 2500);
    });
  }

  modelHeader:any;
   createDeviceFormBlock(event?) {
    this.modelHeader=event.bpid;
    this.createDeviceForm = this.fb.group({
      imei: [
        event ? event.imei : null,
        [
          Validators.required,
          Validators.minLength(15),
          Validators.maxLength(16),
          Validators.pattern('^[0-9]*$')
        ]
      ],
      imsi: [
        event ? event.imsi : null,
        [
          Validators.required,
          Validators.minLength(15),
          Validators.maxLength(15),
          Validators.pattern('^[0-9]*$')
        ]
      ],
      msisdn: [
        event ? event.msisdn : null,
        [
          Validators.required,
          Validators.minLength(15),
          Validators.maxLength(15),
          Validators.pattern('^[0-9]*$')
        ]
      ],bpid: [
        event ? event.bpid : null,
        [
          Validators.maxLength(50),
          Validators.pattern('^[0-9]*$')
        ]
      ],
	     firstName: [
          event ? event.firstName : null,
          [Validators.pattern('^[a-zA-Z0-9 ]*$'), Validators.maxLength(50)]
        ]
    });
  }

  
  saveDevice(close, formData) {
    const req = {
      data: formData
    };
    this.b2cService.deviceB2c(req).subscribe(res => {
       this.closeModel(close);
       setTimeout(() => {
       this.getDevicesList(this.isValidJSONString(this.selectedDomainData) ? JSON.parse(this.selectedDomainData) : this.selectedDomainData);
       }, 2500);
       this.dataService.broadcast('alert', {
        type: 'success',
        message: 'Device has been saved successfully !'
      });
    });
  }

  isValidJSONString(str) {
    try {
        JSON.parse(str);
    } catch (e) {
        return false;
    }
    return true;
}

  openAddDomainModal(content, option) {
    this.configModalOptionMode = option.mode;
    this.showErrorMsgForEmailOrPhone = false;
    this.createDomainFormBlock();
    this.openModal(content, close);
  }
  openModal(content, event?, size?) {
    this.eventInfo = event ? event : '';
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size ? size : 'lg',
        keyboard: false,
      })
      .result.then(result => {}, reason => {});
  }
  closeModel(close) {
    close('Cross click');
  }
  updateDomain(event) {
    this.selectedDeviceData = event;
    this.configModalOptionMode = 'edit';
    this.planIsRequired = false;
    this.createDomainFormBlock(event);
    this.openModal(this.addDomainContent, event);
  }
  viewDomain(event) {
    this.selectedDeviceData = event;
    this.configModalOptionMode = 'view';
    this.planIsRequired = false;
    this.createDomainFormBlock(event);
    this.openModal(this.addDomainContent, event);
    this.createDomainForm.disable();
  }

  createDevice(event, mode) {
    this.selectedDomainData = event;
    this.configModalOptionMode = mode;
    this.createDeviceFormBlock(event);
    this.openModal(this.addDeviceContent, event);
  }
  getDevicesList(event) {
    event['selectedValue'] = this.searchData.dropDownValue;
    event['searchValue'] = this.searchData.searchKey;
    this.selectedDomainData = event;
    this.router.navigate(['../main/b2c-devices'], {
      queryParams: {
        event: JSON.stringify(event)
      },
      skipLocationChange: true
    });
  }
  getDataBySearch(event) {
    const obj = this.b2cService.getObject(event);
    this.searchData = event;
    this.b2cService.getDomainsList(obj).subscribe(
      res => {
        const resArray = [];
        resArray.push(res);
        this.data.data.length = 0;
        this.data.data = resArray;
        this.data.data.map(item => {
          item['fullName'] =
            item.firstName + ' ' + item.lastName;
        });
        this.data.data.length = resArray.length;
        this.data.totalCount = resArray.length;
      },
      error => {
        this.data.data.length = 0;
        this.data.totalCount = 0;
      }
    );
  }
  
  searchParam(event){
    this.getActions();
  const param ={};
  param[event.dropDownValue]=event.searchValue;
    this.b2cService.getDomainsList(param).subscribe(
      res => {
        const resArray = [];
        resArray.push(res);
        this.data.data.length = 0;
        this.data.data = resArray;
        this.child.checkAll(false);
       
       },
      error => {
       }
    );
  }

  getPaginatedData(obj) {
    this.getActions();
    this.searchData = {
      dropDownValue: '',
      searchKey: ''
    };
     this.b2cService.getTopTenUserDetails().subscribe( res => {
      this.data.data = res;
      this.data.data.length = res.length;
      this.data.total = res.length;
      this.data.page=1
      this.child.checkAll(false);
       });
  }

}
