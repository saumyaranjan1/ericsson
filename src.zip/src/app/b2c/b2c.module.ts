import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { B2cRoutingModule } from './b2c-routing.module';
import { B2cService } from './b2c.service';
import { B2cComponent } from './b2c.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    B2cRoutingModule
  ],
  declarations: [B2cComponent],
  providers: [B2cService]
})
export class B2cModule { }
