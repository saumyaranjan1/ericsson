import { B2cRoutingModule } from './b2c-routing.module';

describe('B2cRoutingModule', () => {
  let b2cRoutingModule: B2cRoutingModule;

  beforeEach(() => {
    b2cRoutingModule = new B2cRoutingModule();
  });

  it('should create an instance', () => {
    expect(b2cRoutingModule).toBeTruthy();
  });
});
