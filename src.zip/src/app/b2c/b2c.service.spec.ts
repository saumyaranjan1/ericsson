import { TestBed } from '@angular/core/testing';

import { B2cService } from './b2c.service';

describe('B2cService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: B2cService = TestBed.get(B2cService);
    expect(service).toBeTruthy();
  });
});
