import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';
import { DeleteIntercepterService } from '../shared/services/delete-ajax-method.service';

@Injectable({
  providedIn: 'root'
})
export class B2cService {

  constructor(private interceptor: InterceptorService, private deleteIntercepterService: DeleteIntercepterService) { }

  domainB2c(request) {
    return this.interceptor.httpCall(request.method, 'domainB2c', request.data);
  }
  getDomainsList(request) {
    return this.interceptor.httpCall('get', 'domainB2cList', request);
  }

  deleteDomain(request) {
    return this.deleteIntercepterService.httpDelete('delete', 'domainB2c', request);
  }
  deviceB2c(request) {
    return this.interceptor.httpCall('post', 'deviceB2c', request.data);
  }
  getObject(request) {
    const dataObj = {};
    if (request.dropDownValue === 'phone') {
      dataObj['registeredMobileNumber'] = request.searchKey;
    } else if (request.dropDownValue === 'email') {
      dataObj['email'] = request.searchKey;
    } else if (request.dropDownValue === 'bpid') {
      dataObj['bpid'] = request.searchKey;
    }
    return dataObj;
  }
  getTopTenUserDetails() {
    return this.interceptor.httpCall('get', 'getTopTenUserDetails');
  }
  changeDeviceStatus(request) {
    return this.interceptor.httpCall('post', 'changeDeviceStatus', request);
  }
}
