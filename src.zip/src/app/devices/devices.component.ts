import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  ChangeDetectionStrategy,
  ChangeDetectorRef
} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { forkJoin } from 'rxjs';
import { DevicesService } from './devices.service';
import { DataService } from './../shared/services/data.service';
import { UserService } from './../shared/services/user.service';
import { EnumsService } from './../shared/services/enums.service';
import { ngxCsv } from 'ngx-csv/ngx-csv';
import { interval } from 'rxjs';
import * as Excel from 'exceljs';
import * as FileSaver from 'file-saver';

import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { SpinnerService } from '../shared/services/spinner.service';
import { DeviceEnumService } from './device-enum-service';

@Component({
  selector: 'app-devices',
  templateUrl: './devices.component.html',
  styleUrls: ['./devices.component.less']
})
export class DevicesComponent implements OnInit {
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('deActivateDeviceModalContent', { static: true })
  deActivateDeviceModalContent: ElementRef;
  @ViewChild('serverPaginationComponent', { static: true }) serverPaginationComponent: ElementRef;
  @ViewChild('reconciliationModalContent', { static: false }) reconciliationModalContent: ElementRef;
  @ViewChild('imeiAndMsisdnModalContent', { static: false }) imeiAndMsisdnModalContent: ElementRef;
  @ViewChild('singleUploadModalContent', { static: false }) singleUploadModalContent: ElementRef;


  columns = DeviceEnumService.DATA.columns;
  actionsObj = {
    actionsLabel: DeviceEnumService.DATA.actionsLabel,
    actions: DeviceEnumService.DATA.actions
  };
  tableHeader = DeviceEnumService.DATA.tableHeader;
  tableHeaderActions;
  data = {
    page: 1,
    total: 1,
    data: []
  };
  progress = 40;

  color = 'blue';
  mode = 'determinate';
  value = 50;
  bufferValue = 75;




  userId;
  hqBpId;
  changeImei;
  hqBpName;
  bpid;
  partnerValue;
  pageNum;
  svcValue;
  noOfDownload;
  fileId;
  versionTwo;
  versionOne;
  partnerIds;
  showSvcList = true;
  uploadReconciliation = false;
  deviceInfo: any = {};
  loggedUser = null;
  errorSvcRequared = false;
  userData: any;
  svcValueModule;
  actionsArr: any;
  deActivateDevice: FormGroup;
  uploadedFile;
  uploadedFileName;
  partnerId;
  fileSubmitReq;
  fileExtension;
  reconciliationList;
  serviceStatusArray = ['ACTIVE', 'SUSPEND', 'BLACKLIST'];
  svcList = [];
  p;
  roleList: any;
  requestOrigin;
  reConcileDeviceList;
  userName;
  reConcileDeviceCount
  pagePerItems = [
    { value: 5 },
    { value: 10 },
    { value: 20 },
    { value: 30 },
    { value: 40 },
    { value: 50 },
    { value: 100 }
  ];
  pagiantionObj = {
    page: 1,
    limit: 10,
    offset: 0,
    pageNum: 1,
    rpp: 0,
    pageNumber: 1,
    pageSize: 0,
    svcCode: '',
    connectivityType: ''
  };
  nonReConciledDeviceCount;
  constructor(
    private ngbModal: NgbModal,
    private devicesService: DevicesService,
    private dataService: DataService,
    private userService: UserService,
    private route: ActivatedRoute,
    private router: Router,
    private fb: FormBuilder,
    private cdr: ChangeDetectorRef,
    private cms: CommonMethodsService,
    private spinnerService: SpinnerService
  ) { }

  ngOnInit() {
    this.loggedUser = this.userService.getLoggedUserName();
    this.userId = this.route.snapshot.queryParams['userId'];
    this.hqBpId = this.route.snapshot.queryParams['hqBpId'];
    this.hqBpName = this.route.snapshot.queryParams['hqBpName'];
    this.partnerIds = this.route.snapshot.queryParams['partnerIds'];
    this.partnerId = this.route.snapshot.queryParams['partnerId'];
    this.requestOrigin = this.route.snapshot.queryParams['requestOrigin'];
    this.tableHeader = 'Devices List : ' + this.hqBpName;
    this.version(this.dataService.getParseFromSession('version'));
    this.userName = this.dataService.getFromStorage('login_user_name');
    // this.pageNum = this.route.snapshot.queryParams['pageNum'];

    this.userName = this.dataService.getParseAndAtob(
      'loginMember'
    ).split('@')[0].replace('.', ' ');

  }

  addnew() {
    this.dataService.setLocalStorage('version', JSON.stringify(this.dataService.getParseFromSession('version')));
    this.router.navigate(['../main/b2b_ui_api'], {
      queryParams: { hqBpId: this.hqBpId, isDeviceCreate: true, partnerIds: this.partnerIds },
      skipLocationChange: true,
    });
  }

  deleteDeviceModal(event) {
    if (event !== null && event !== undefined) {
      this.openModal(event, this.deleteConfirmModalContent);
    } else {
      this.dataService.broadcast('alert',
        { type: 'danger', message: 'Please select Device' });
    }

  }

  //getDataBySearch(data) {
  // const objGet = this.vendorService.getObject(data);
  // this.vendorService.getSearchData(objGet).subscribe(
  //   res => {
  //     if (res) {
  //       const result = this.vendorService.getMappedObjectArray(res);
  //       this.data.data.length = 0;
  //       this.data.data.push(result);
  //       this.data.totalCount = 1;
  //     }
  //   },
  //   error => {
  //     this.data.data.length = 0;
  //     this.data.totalCount = 0;
  //   }
  // );
  // }
  getActions() {
    const _module = EnumsService.B2B_DEVICES;
    const _parentModule = EnumsService.B2B_UI_API;

    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _parentModule,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };
    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe(prev => {
      this.actionsArr = this.userService.getModulePermission(
        //  _parentModule,
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

      if (this.actionsArr.actionsArray) {
        this.actionsObj.actions = this.actionsArr.actionsArray.filter((obj) => {
          return (
            obj.type === 'view' || obj.type === 'delete' || obj.type === 'edit' || obj.type === 'activateOrDeActivate'
          );
        });
        this.actionsObj.actions = this.cms.changeArrayElementsPosition(this.actionsObj.actions, 1, 0)
      } else {
        this.actionsObj.actions = [];
      }

      this.actionsArr.headerRights.search = false;
      this.tableHeaderActions = this.actionsArr.headerRights;
      this.tableHeaderActions['exportToCsv'] = true;
      this.tableHeaderActions.refreshData = false;


      this.tableHeaderActions['deviceRequest'] = false;
      // this.tableHeaderActions['connectionUi'] = this.partnerIds.length > 0 ? true : false;
      this.actionsObj.actions.forEach(element => {
        if (element.type === 'activateOrDeActivate') {
          this.tableHeaderActions['deviceRequest'] = true;
          // this.tableHeaderActions['connectionUi'] = this.partnerIds.length > 0 ? true : false;
        }
      });
      this.getConOnlyDeviceList();
      this.tableHeaderActions['search'] = true;
      this.tableHeaderActions['add'] = this.requestOrigin.toUpperCase() == 'UI' ? true : false;
      this.tableHeaderActions['isDevice'] = true;
      this.tableHeaderActions['dropDown'] = true;
    });

  }

  headerDropdownList = [{ 'key': 'bpid', 'value': 'DEVICE CONNECTION MAPPING ID' },
  { 'key': 'imei', 'value': 'imei' },
  { 'key': 'msisdn', 'value': 'msisdn' }
  ]

  deleteDevice(close) {
    const _req = {
      bpid: this.bpid
    };
    let version = this.versionOne ? 'v1' : 'v2';
    this.devicesService.deleteDevice(_req, version).done(
      res => {
        this.refreshComponent(close);
      },
      error => { }
    );
  }


  getDataBySearch(data) {
    const objGet = this.devicesService.getObject(data);
    this.data = {
      page: 1,
      total: 0,
      data: []
    };
    let version = this.versionOne ? 'v1' : 'v2'
    this.devicesService.getSearchData(objGet, version).subscribe(
      res => {
        if (res) {
          //const result = this.vendorService.getMappedObjectArray(res);
          this.data = {
            page: 1,
            total: 0,
            data: [res]
          };
        }
      },
      error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
      }
    );
  }

  activateDevice(close) {
    const _req = {
      deviceStatus: this.deActivateDevice.controls['serviceStatus'].value,
      devices: [{ imei: this.deviceInfo.imei }]
    };
    this.devicesService.changeDeviceStatus(_req).subscribe(res => {
      this.refreshComponent(close);
    });
  }

  refreshComponent(close?) {
    this.closeModel(close);
    // Refreshing the component
    this.router
      .navigateByUrl('../main', { skipLocationChange: true })
      .then(
        () => {
          this.router.navigate(['../main/devices'], {
            queryParams: {
              userId: this.userId,
              hqBpId: this.hqBpId,
              hqBpName: this.hqBpName,
              requestOrigin: this.requestOrigin,
              partnerIds: this.partnerIds
            },
            skipLocationChange: true
          });
        },
        error => { }
      );
  }

  updateDevice(event) {

    if (event.imei.charAt(0) == 'm') {
      event.imei = '';
    }

    this.router.navigate(['../main/b2b_ui_api'], {
      queryParams: { deviceData: JSON.stringify(event) },
      skipLocationChange: true
    });
  }
  viewDevicedate(event) {
    event['view'] = true;
    this.router.navigate(['../main/b2b_ui_api'], {
      queryParams: { deviceData: JSON.stringify(event) },
      skipLocationChange: true
    });
  }

  activateOrDeActivate(event) {
    this.deActivateDevice = this.fb.group({
      serviceStatus: [event ? event.activeStatus : '', Validators.required]
    });

    if (event !== null && event !== undefined) {
      this.openModal(event, this.deActivateDeviceModalContent);
    } else {
      this.dataService.broadcast('alert',
        { type: 'danger', message: 'Please select Device' });
    }

  }

  openConnectionModel(content, size) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        keyboard: false,
      })
      .result.then(result => { }, reason => { });
  }

  openReconcileModel(content, size) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        keyboard: false,
        backdrop: 'static',
      })
      .result.then(result => { }, reason => { });
  }

  openModal(event, content) {
    this.deviceInfo = event;
    this.bpid = event.bpid;
    setTimeout(() => {
      this.ngbModal
        .open(content, {
          windowClass: 'jio-modal jio-small-modal',
          size: 'sm'
        })
        .result.then(result => { }, reason => { });
    });
  }
  async exportDataToCsv() {
    this.spinnerService.toggleSpinner(1);
    if (this.userId) {
      const objCount = { userId: this.userId };
      let countOfDeices;
      const result = await this.devicesService.getTotalCountDevicesAsPromise(
        objCount
      );
      if (result.data && result.data > 0) {
        if (result.data > 1000) {
          countOfDeices = Math.ceil(result.data / 1000);
        } else {
          countOfDeices = 1;
        }
        const totalResultArray: any = [];
        for (let i = 0; i < countOfDeices; i++) {
          const obj = {
            rpp: 1000,
            pageNum: i + 1
          };
          obj['userId'] = this.userId;
          //obj['appendUserId'] = true;
          const totalResult = await this.devicesService.getDeviceListAsPromise(
            obj
          );
          totalResult.data.forEach(element => {
            element['enterpriseId'] = element.userID;
            delete element.serviceStatus;
            delete element.userID;
            delete element.plmid;
            delete element.isDeleted;
            delete element.id;
            if (element.plan) {
              element['planCode'] = element.plan.code;
              element['planDescription'] = element.plan.description;
              element['planName'] = element.plan.name;
              element['planStartDate'] = this.cms.getTimeFromEpcohToCsv(
                element.plan.startDate
              );
              element['planEndDate'] = this.cms.getTimeFromEpcohToCsv(
                element.plan.endDate
              );
              delete element.plan;
            }
            if (element.deviceData) {
              const vehicle = JSON.parse(element.deviceData);
              element['vMake'] = vehicle.make;
              element['vModel'] = vehicle.model;
              element['vYear'] = vehicle.year;
              element['vRegistrationNumber'] = vehicle.registrationNumber;
              element['vFuelType'] = vehicle.fuelType;
              delete element.deviceData;
            }
            totalResultArray.push(element);
            totalResultArray.sort();
          });
        }
        const csvArray = [];
        var isMachineInfo = false;

        totalResultArray.forEach((row) => {
          if (row.machineInfo) {
            isMachineInfo = true;
            row['fuelType'] = row.machineInfo.fuelType;
            row['make'] = row.machineInfo.make;
            row['model'] = row.machineInfo.model;
            row['registrationNumber'] = row.machineInfo.registrationNumber;
            row['year'] = row.machineInfo.year;
            delete row.machineInfo;
          }
          csvArray.push(Object.keys(row).map(key => row[key]));
        });
        let csv = this.versionOne ? EnumsService.deviceCsvHeadersvone : isMachineInfo ? EnumsService.deviceCsvHeadersForMachineInfo : EnumsService.deviceCsvHeaders;

        csvArray.forEach((row) => {
          csv += row.join(',');
          csv += '\n';
        });
        const hiddenElement = document.createElement('a');
        hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
        hiddenElement.target = '_blank';
        hiddenElement.download = this.hqBpName + '_' + this.userId + '_of_devices.csv';
        hiddenElement.click();
        this.spinnerService.toggleSpinner(0);
      } else {
        this.spinnerService.toggleSpinner(0);
      }
    }
  }
  getPaginatedData(obj) {
    if (this.userId) {
      obj.userId = this.userId;
      //obj.appendUserId = true;
      const objCount = { userId: this.userId };
      const totalCount = this.devicesService.getTotalCountDevices(objCount);
      const totalResult = this.devicesService.getDeviceList(obj);
      this.getConOnlyDeviceList();
      this.getActions();
      forkJoin([totalCount, totalResult]).subscribe(
        results => {
          if (results[0].data && results[1].data) {

            results[1].data.forEach(key => {
              key['userId'] = this.userId;
              key['hqBpId'] = this.hqBpId;
              key['hqBpName'] = this.hqBpName;
            });

            this.data = {
              page: obj.page,
              total: results[0].data,
              data: results[1].data
            };

            // this.cdr.detectChanges();
          }
        },
        error => {
          this.data = {
            page: 1,
            total: 0,
            data: []
          };
        }
      );
    } else {
      this.goBack();
    }
  }

  closeModel(close) {
    close('Cross click');
  }

  closeInterval(close) {
    clearInterval(this.interval);
    close('Cross click');
  }

  goBack() {
    this.router.navigate(['../main/b2b_ui_api'], {
      queryParams: {
        // pageNum: this.pageNum
      },
      skipLocationChange: true
    });
  }


  version(type) {
    if (type == 'v2') {
      this.versionTwo = true;
      this.versionOne = false;
    } else {
      this.versionTwo = false;
      this.versionOne = true;
    }
    this.dataService.setLocalStorage('version', JSON.stringify(type));
  }



  /** connection only part */


  /** Ger Svc List*/

  connectionOnly() {
    if (this.data.data.length > 0) {
      const _req = {
        'partnerIds': this.partnerIds ? this.partnerIds : [this.partnerId],
        'hqBpId': this.hqBpId
      }
      this.devicesService.getSvcWithPartnerId(_req).subscribe(res => {

        this.svcList = res;
        this.showSvcList = true;
        this.uploadReconciliation = false;
        this.uploadedFileName = '';
        this.openConnectionModel(this.reconciliationModalContent, 'sm');
        this.errorForCsvSubmit = false;
      });
    } else {
      this.dataService.broadcast('alert',
        { type: 'danger', message: 'Add device for reconciliation' });
    }

  }


  svcValueSelected(event) {
    this.svcValue = event.value.svcCode;
    this.partnerValue = event.value.partnerId;
  }

  next(close) {
    this.devicesService.getTransationId({'svcCode':this.svcValue}).subscribe(res => {
      if(res.data.status=='COMPLETED' || res.data.status=='NOTSTARTED'){
        if (this.svcValue) {
          this.showSvcList = false;
          //this.uploadReconciliation = true;
          this.closeModel(close);
          this.getPage(1);
          this.openConnectionModel(this.singleUploadModalContent, 'lg');
          this.errorSvcRequared = false;
        } else {
          this.errorSvcRequared = true;
        }
      }else{
        this.spinnerService.toggleSpinner(1);
        setTimeout(() => {
          this.fileId = res.data.transactionId;
          this.reconciliationCount = 0;
          // this.dataService.broadcast('alert', { type: 'success', message: res.responseCode });
          this.openReconcileModel(this.imeiAndMsisdnModalContent, 'lg');
          this.getReConcilePage(1);
          this.closeModel(close);
          this.errorForCsvSubmit = false;
          var param = {
            'limit': 10,
            'offset': 0,
            'page': 1,
            'pageNum': 1,
            'pageNumber': 1,
            'pageSize': 10,
            'rpp': 10
          }
          this.getPaginatedData(param);
        }, 2000);

      }
     });
   }

  callSaveService(data, index) {
    if (data.imei && this.changeImei) {
      this.changeImei = false;
      this.reConcileDeviceList[index].isEmptyImei = false;
      let param = {
        "msisdn": data.msisdn,
        "imei": data.imei,
        "partnerId": data.partnerId,
        "svc": data.svc,
        "eid": data.eid
      }
      this.devicesService.callSaveService(param).subscribe(res => {
        var param = {
          'limit': 10,
          'offset': 0,
          'page': 1,
          'pageNum': 1,
          'pageNumber': 1,
          'pageSize': 10,
          'rpp': 10
        }
        this.reConcileDeviceList[index].isImeiWithm = false;
        this.getPaginatedData(param);
      });
    } else if (data.imei == '') {
      this.reConcileDeviceList[index].isEmptyImei = true;
    }
  }


  onImeiChange(event, index) {
    if (event.length == 15 || event.length == 16) {
      this.changeImei = true;
      this.reConcileDeviceList[index].isEmptyImei = false;
      this.reConcileDeviceList[index].isEmptyLength = false;
    } else {
      this.reConcileDeviceList[index].isEmptyImei = true;
      this.reConcileDeviceList[index].isEmptyLength = true;
    }
  }


  getPage(page: number) {
    this.p = page;
    this.pagiantionObj.page = page;
    this.pagiantionObj.pageNum = page;
    this.pagiantionObj.offset = (page - 1) * this.pagiantionObj.limit;
    this.pagiantionObj.rpp = this.pagiantionObj.limit;
    this.pagiantionObj.pageNumber = page;
    this.pagiantionObj.pageSize = this.pagiantionObj.rpp;
    this.pagiantionObj.svcCode = this.svcValue;
    this.pagiantionObj.connectivityType = 'co'
    this.getDeviceListForReConcile(this.pagiantionObj)
  }


  getReConcilePage(page: number) {
    this.p = page;
    this.pagiantionObj.page = page;
    this.pagiantionObj.pageNum = page;
    this.pagiantionObj.offset = (page - 1) * this.pagiantionObj.limit;
    this.pagiantionObj.rpp = this.pagiantionObj.limit;
    this.pagiantionObj.pageNumber = page;
    this.pagiantionObj.pageSize = this.pagiantionObj.rpp;
    this.pagiantionObj['transactionId'] = this.fileId
    delete this.pagiantionObj.rpp;
    delete this.pagiantionObj.pageNumber;
    delete this.pagiantionObj.connectivityType;
    this.getDeviceList(this.pagiantionObj);
  }


  getDeviceListForReConcile(param) {
    param.userId = this.userId
    this.devicesService.getDeviceListForReConcile(param).subscribe(res => {
      this.reConcileDeviceList = res.data;
      this.reConcileDeviceList.forEach((value, key) => {
        if (value.imei.slice(0, 1) == 'm') {
          value.imei = '';
          value['isEmptyImei'] = false;
          value['isImeiWithm'] = true;
        } else {
          value['isImeiWithm'] = false;
        }
      });
      this.getDeviceCountForReConcile();
    });
  }

  getDeviceCountForReConcile() {
    var param = {
      'userId': this.userId,
      'svcCode': this.svcValue,
      'connectivityType': 'CO'
    };
    let paramForNonReconciled = {
      'userId': this.userId,
      'svcCode': this.svcValue,
      'connectivityType': 'CO',
      'isNonReconciled': true
    }
    this.devicesService.getDeviceCountForReConcile(param).subscribe(res => {
      this.reConcileDeviceCount = res.data;
    });
    this.devicesService.getDeviceCountForReConcile(paramForNonReconciled).subscribe(res => {
      this.nonReConciledDeviceCount = res.data;
    });
  }


  getConOnlyDeviceList() {
    var param = {
      'userId': this.userId,
      'connectivityType': 'CO'
    }
    this.devicesService.getDeviceCountForReConcile(param).subscribe(res => {
      this.tableHeaderActions['connectionUi'] = res.data > 0 ? true : false;
    });
  }


  maxRecordToDownload
  backToUpload(close) {
    this.closeModel(close);
    this.uploadReconciliation = true;
    let paramForNonReconciled = {
      'userId': this.userId,
      'svcCode': this.svcValue,
      'connectivityType': 'CO',
      'isNonReconciled': true
    }
    this.devicesService.getDeviceCountForReConcile(paramForNonReconciled).subscribe(res => {
      this.maxRecordToDownload = res.data;
      if(this.maxRecordToDownload >= 100000){
         this.maxRecordToDownload=100000;
      }
       this.openConnectionModel(this.reconciliationModalContent, 'sm');
    });
   
  }

  downLoadCsvForReconcil() {
    if(this.noOfDownload || this.noOfDownload==0){
      let workBook = new Excel.Workbook();
      let workSheet = workBook.addWorksheet("New");
      workSheet.columns = [
        { header: 'MSISDN', key: 'msisdn', width: 18 },
        { header: 'IMSI', key: 'imsi', width: 18 },
        { header: 'IMEI', key: 'imei', style: { numFmt: '@'}, width: 18 }
      ]
      this.pagiantionObj['userId'] = this.userId;
      this.pagiantionObj.pageNum = 1;
      this.pagiantionObj.rpp = this.noOfDownload;
      this.pagiantionObj['isNonReconciled'] = true;
      this.devicesService.getDeviceListForReConcile(this.pagiantionObj).subscribe(res => {
  
        if (res.data.length!==0) {
          this.reConcileDeviceList = res.data;
          delete this.pagiantionObj['isNonReconciled'];
          var data = [];
          this.reConcileDeviceList.forEach((value, key) => {
            workSheet.addRow({msisdn: value.msisdn, imsi: value.imsi, imei: '' });
            workSheet.getCell('C' + (key + 2)).protection = { locked: false };
          });
          
          workSheet.protect("", {});
          
          workBook.xlsx.writeBuffer().then(function (data) {
            var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
            FileSaver.saveAs(blob, "deviceReconciliation.xlsx");
          });
  
          if (this.nonReConciledDeviceCount >= 100000 ) {
            this.dataService.broadcast('alert',
            { type: 'danger', message: `You can download upto 1 Lakh non-reconciled device info. Incase you have more 
            than 1 Lakh non-reconciled devices, download and reconcile 1st 1 Lakh device then repeat the same` });
          }
    
        }else{
          this.dataService.broadcast('alert',
          { type: 'danger', message: 'All devices are already reconciled' });
        }
      });
    }
    else{
      this.dataService.broadcast('alert',
      { type: 'danger', message: 'Please select No. records to reconcile' });
    }
  }

  /***
     * Upload File
     */

  fileEvent($event) {
    this.uploadedFile = $event.target.files[0];
    this.uploadedFileName = this.uploadedFile.name;
    const dotPos = this.uploadedFile.name.lastIndexOf('.');
    if (this.uploadedFile.name.lastIndexOf('.') > 0) {
      this.fileExtension = this.uploadedFile.name.substring(
        dotPos + 1,
        this.uploadedFile.name.length
      );
    }
    this.fileSubmitReq = new FormData();
    this.fileSubmitReq.append('file', this.uploadedFile);
    this.fileSubmitReq.append('partnerId', this.partnerValue);
    this.fileSubmitReq.append('hqBpId', this.hqBpId);
    this.fileSubmitReq.append('svc', this.svcValue);
    this.fileSubmitReq.append('pageSize', 10);
    this.errorForCsvSubmit = false;
  }

  errorForCsvSubmit = false;
  finish(close) {
    if (this.fileSubmitReq) {
      this.devicesService.uploadDeviceList(this.fileSubmitReq).subscribe(res => {
        this.spinnerService.toggleSpinner(1);
        this.noOfDownload='';
        setTimeout(() => {
          this.fileId = res.data.transactionId;
          this.reconciliationCount = 0;
          this.dataService.broadcast('alert', { type: 'success', message: res.responseCode });
          this.openReconcileModel(this.imeiAndMsisdnModalContent, 'lg');
          this.getReConcilePage(1);
          this.closeModel(close);
          this.errorForCsvSubmit = false;
          var param = {
            'limit': 10,
            'offset': 0,
            'page': 1,
            'pageNum': 1,
            'pageNumber': 1,
            'pageSize': 10,
            'rpp': 10
          }
          this.getPaginatedData(param);
        }, 2000);
      });
    } else {
      this.errorForCsvSubmit = true;
    }
  }

  reconciliationCount
  interval: any;

  getDeviceList(param) {
    delete param.userId;
    this.devicesService.getUploadDeviceList(param).subscribe(res => {
      this.reconciliationList = res.data;
      this.spinnerService.toggleSpinner(0);
      if (this.reconciliationList.length == 0 && param.pageNum == 1) {
        this.spinnerService.toggleSpinner(1);
        setTimeout(() => {
          this.getReConcilePage(1);
        }, 2000);
      }

      this.interval = setInterval(() => {
        this.getDeviceProgressCount();
      }, 2000);

    });
  }

  getPercentage
  totalRecord;
  getDeviceProgressCount() {
    let param = {
      'transactionId': this.fileId,
      'isCount': true
    }
    this.devicesService.getDeviceProgressCount(param).subscribe(res => {
      this.totalRecord=res.data.totalCoRecordCnt;
      this.getPercentage = (res.data.processedCoRecordCnt / res.data.totalCoRecordCnt) * 100;
      this.reconciliationCount = res.data.processedCoRecordCnt;
      if (this.getPercentage == 100) {
        clearInterval(this.interval);
      }
    });
  }

  updateCoDevice(row, close) {
   // this.closeModel(close);
    var param = {
      "msisdn": row.msisdn,
      "imei": row.imei,
      "imsi": row.imsi,
      "transactionId": this.fileId,
      "partnerId": this.partnerValue,
      "hqBpId": this.hqBpId,
      "svc": this.svcValue
    }
    this.devicesService.editUploadDeviceList(param).subscribe(res => {
      this.dataService.broadcast('alert', { type: 'success', message: 'Update successfully' });
      this.pagiantionObj.page = this.p;
      this.pagiantionObj.pageNum = this.p;
      this.pagiantionObj.offset = (this.p - 1) * this.pagiantionObj.limit;
      this.pagiantionObj.rpp = this.pagiantionObj.limit;
      this.pagiantionObj.pageNumber = this.p;
      this.pagiantionObj.pageSize = this.pagiantionObj.rpp;
      this.pagiantionObj['transactionId'] = this.fileId

      this.getDeviceList(this.pagiantionObj);
      var param = {
        'limit': 10,
        'offset': 0,
        'page': 1,
        'pageNum': 1,
        'pageNumber': 1,
        'pageSize': 10,
        'rpp': 10
      }
      this.getPaginatedData(param);
    });
  }


  showButton(index) {
    this.reconciliationList.forEach((element, key) => {
      if (key == index) {
        element.showButton = !element.showButton;
        if (!element.showButton) {
          element.modify = false;
        }
      }
    });
  }

  modify(index) {
    this.reconciliationList.forEach((element, key) => {
      if (key == index) {
        element.modify = !element.modify;
      }
    });
  }

}

