import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class DeviceEnumService {
  public static DATA = {
    data: [],
    columns: [
     
      {
        displayName: 'Device Category',
        key: 'category',
        filter: 'lowercase'
      },
      {
        displayName: 'Device Status',
        key: 'activeStatus',
        filter: ''
      },
      {
        displayName: 'IMEI/MAKE',
        key: 'imei',
        filter: 'lowercase'
      },
      {
        displayName: 'IMSI/MODEL',
        key: 'imsi',
        filter: 'lowercase'
      },
      {
        displayName: 'MSISDN/REG NUM',
        key: 'msisdn',
        filter: ''
      },{
        displayName: 'partnerId',
        key: 'partnerId',
        filter: ''
      }
      // {
      //   displayName: 'BPID',
      //   key: 'bpid',
      //   filter: 'lowercase'
      // }
    ],
    actions: [],
    actionsLabel: 'Actions',
    tableHeader: 'Devices List : ', // + this.route.snapshot.queryParams['hqBpName'],
    tableActions: {
      search: true,
      add: false,
      delete: true,
      edit: true,
      save: true,
      times: true,
      dropDown:true,
      refreshData:false
    },
    dropDownsList: ['imei'],
    totalCount: 0
  };
  public static FUEL_TYPE_ARRAY = [
    'PETROL',
    'DIESEL',
    'LPG',
    'CNG',
    'CNG-PETROL',
    'LPG-PETROL',
    'GASOHOL',
    'FLEX',
    'ETHANOL'
  ];
  public static SERVICE_STATUS_ARRAY = ['ACTIVE', 'SUSPEND', 'RESUME'];
  public static RADIO_BUTTONS_LIST = [
    {
      name: 'NEW UPLOAD',
      value: 'add'
    },
    {
      name: 'UPDATE DATA',
      value: 'update'
    },
    {
      name: 'DELETE DATA',
      value: 'delete'
    }
  ];
  constructor() { }
}



