import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SharedModule } from './../shared/shared.module';
import { DevicesRoutingModule } from './devices-routing.module';
import { DevicesComponent } from './devices.component';
import { DevicesService } from './devices.service';

@NgModule({
  imports: [
    CommonModule,
    DevicesRoutingModule,
    SharedModule
  ],
  providers: [DevicesService],
  declarations: [DevicesComponent]
})
export class DevicesModule { }
