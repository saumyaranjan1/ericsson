import { Injectable } from '@angular/core';
import { InterceptorService } from './../shared/services/interceptor.service'
import { DeleteIntercepterService } from '../shared/services/delete-ajax-method.service';

@Injectable()
export class DevicesService {

  constructor(private interceptor: InterceptorService, private deleteIntercepterService: DeleteIntercepterService) { }

  getUserList(request) {
    return this.interceptor.httpCall('get', 'getUserList', request);
  }
  getRoleList() {
    return this.interceptor.httpCall('get', 'getRoleList');
  }
  addUser(request) {
    return this.interceptor.httpCall('post', 'addUser', request)
  }
  changeUserStatus(request) {
    return this.interceptor.httpCall('post', 'changeUserStatus', request)
  }
   editUser(request) {
    return this.interceptor.httpCall('post', 'editUser', request)
  }
  getDeviceList(request) {
    return this.interceptor.httpCall('get', 'getDeviceList', request);
  }
  getDeviceListAsPromise(request) {
    return this.interceptor.httpPromise('get', 'getDeviceList', request);
  }
  getTotalCountDevices(request) {
    return this.interceptor.httpCall('get', 'getTotalCountDevices', request);
  }
  getTotalCountDevicesAsPromise(request) {
    return this.interceptor.httpPromise('get', 'getTotalCountDevices', request);
  }
  deleteDevice(request,version) {
    if(version=='v1'){
      return this.deleteIntercepterService.httpDelete('delete', 'createUpdateDeleteDevice', request);
    }else{
      return this.deleteIntercepterService.httpDelete('delete', 'createUpdateDeleteDeviceVtwo', request);
    }
    
  }
  changeDeviceStatus(request) {
    return this.interceptor.httpCall('post', 'changeDeviceStatus', request);
  }

  getObject(request) {
    const dataObj = {};
    if (request.dropDownValue === 'bpid') {
      dataObj['bpid'] = request.searchKey;
    } else if (request.dropDownValue === 'imei') {
      dataObj['imei'] = request.searchKey;
    } else if (request.dropDownValue === 'hqBpid') {
      dataObj['hqBpid'] = request.searchKey;
    } else if (request.dropDownValue === 'msisdn') {
      dataObj['msisdn'] = request.searchKey;
    }
    return dataObj;
  }

  getSearchData(request,version) {
    if(version=='v1'){
      return this.interceptor.httpCall('get', 'getDeviceListById', request);
    }else{
      return this.interceptor.httpCall('get', 'getDeviceListById', request);
    }
  }

  getSvcWithPartnerId(request) {
    return this.interceptor.httpCall('post', 'svcWithPartnerIdco', request)
  }

  uploadDeviceList(request) {
    return this.interceptor.httpCall('post', 'uploadCoDevice', request)
  }

  getUploadDeviceList(request) {
    return this.interceptor.httpCall('get', 'getCoDevice', request)
  }

  editUploadDeviceList(request) {
    request.extraParams = '?transactionId='+request.transactionId;
    delete request.transactionId;

    return this.interceptor.httpCall('put', 'updateCoDevice', request)
  }

  getDeviceListForReConcile(request){
     return this.interceptor.httpCall('get', 'getDeviceListForReConcile', request)
  }

  getDeviceCountForReConcile(request){
    return this.interceptor.httpCall('get', 'getDeviceCountForReConcile',request)
  }

  callSaveService(request){
    return this.interceptor.httpCall('put', 'updateSingleCoDevice',request)
  }

  getDeviceProgressCount(request){

    request['noSpiner']=true;

    return this.interceptor.httpCall('get', 'getDeviceProgressCount',request)
  }

  getTransationId(request){
    return this.interceptor.httpCall('get', 'getTransationId',request)
  }

}
