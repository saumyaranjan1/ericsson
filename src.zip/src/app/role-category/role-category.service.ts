import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';
import { DeleteIntercepterService } from '../shared/services/delete-ajax-method.service';

@Injectable()
export class RoleCategoryService {

  constructor(
    private interceptor: InterceptorService,
    private deleteIntercepterService: DeleteIntercepterService
  ) { }

  /**sssssssssss
  * Create Role Category
  */
  createRoleCategory(method, request) {
    return this.interceptor.httpCall(method, 'createRoleCategory', request);
  }

  /**
  * Update Role Category
  */
  updateRoleCategory(method: string, request: any) {
    request['extraParams'] = '?id=' + request.categoryId;
    return this.interceptor.httpCall(method, 'updateRoleCategory', request);
  }


  /**
 * Delete Role Category
 */
  deleteRoleCategory(request) {
    request['extraParams'] = '?id=' + request.categoryId;
    return this.interceptor.httpCall('delete', 'deleteRoleCategory', request.extraParams);
  }



  /**
   * Get Role Category Data
   */
  getRoleCategoryData() {
    const request = { responseType: 'json' };
    return this.interceptor.httpCall('get', 'getRoleCategoryData', request);
  }


}
