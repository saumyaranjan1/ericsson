import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RoleCategoryEnumService {
  public static ROLECATEGORYDATA = {
    data: [],
    page: 1,
    total: 10,
    columns: [
      {
        displayName: 'Level',
        key: 'level',
        filter: ''
      },
      {
        displayName: 'Role Categories',
        key: 'roleCategoryName',
        filter: ''
      },
      {
        displayName: 'Level UP/Down',
        key: 'roleCategory',
        filter: ''
      }
    ],
    tableHeader: 'Role Category',
    actions: [

    ],
    actionsLabel: '',
    tableActions: {
      search: false,
      searchActiom: false,
      add: false,
      edit: false,
      dropDown: false,
      refreshData: false,
      showCheck: false,
      deleteAction: false,
    },
    dropDownsList: [],
    totalCount: 0,
    tabelTooltip: 'This is the index page which shows list of Role Category'


  }



}



