import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { SharedModule } from '../shared/shared.module';
import { RoleCategoryRoutingModule } from './role-category-routing.module';
import { RoleCategoryComponent } from './role-category.component';
import { RoleCategoryService } from './role-category.service';
import { VendorService } from './../vendor/vendor.service'

@NgModule({
  imports: [
    CommonModule,
    RoleCategoryRoutingModule,
    AngularMultiSelectModule,
    SharedModule
  ],
  providers: [RoleCategoryService, VendorService],
  declarations: [RoleCategoryComponent]
})
export class RoleCategoryModule { }
