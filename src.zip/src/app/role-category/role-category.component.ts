import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  ChangeDetectionStrategy
} from '@angular/core';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';
import { RoleCategoryService } from './role-category.service';
import { RoleCategoryEnumService } from './role-category-enum.service';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { DataService } from '../shared/services/data.service';
import { forkJoin } from 'rxjs';
import { VendorService } from './../vendor/vendor.service';
import { SpinnerService } from '../shared/services/spinner.service';
import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';
import { HeaderService } from './../main/header/header.service';


@Component({
  selector: 'app-role-category',
  templateUrl: './role-category.component.html',
  styleUrls: ['./role-category.component.less']
})
export class RoleCategoryComponent implements OnInit {
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('addRoleCategoryContent', { static: true }) addRoleCategoryContent: ElementRef;
  constructor(
    private ngbModal: NgbModal,
    public router: Router,
    private fb: FormBuilder,
    private RoleCategoryService: RoleCategoryService,
    private dataService: DataService,
    private userService: UserService,
    private SpinnerService: SpinnerService,
    private cms: CommonMethodsService,
  ) { }

  roleCategoryData = RoleCategoryEnumService.ROLECATEGORYDATA;
  createRoleCategoryForm: FormGroup;
  event;
  categoryStatus = ["ACTIVE", "INACTIVE"];
  modalConfig = {
    create: { headerText: 'Create Role Category', primeBtnText: 'Save' },
    edit: { headerText: 'Edit Role Category', primeBtnText: 'Update' },
    view: { headerText: 'View Role Category', primeBtnText: 'View' }
  };
  configModalOptionMode = null;
  searchFilter: any;
  filterSearch: any;
  actionsArr: any;

  /**
  * Click Edit button
  */
  updateRoleCategory(event) {
    this.event = event;
    event.mode = 'edit';
    this.openAddRoleCategoryModal(this.addRoleCategoryContent, { mode: 'edit' }, 'sm', event);
  }
  /**
   * Click View button
   */
  viewRoleCategory(event: any) {
    this.event = event;
    event.mode = 'view';
    this.openAddRoleCategoryModal(this.addRoleCategoryContent, { mode: 'view' }, 'sm', event);
  }

  addRoleCategoryForm(content, option, modalClass) {
    this.openAddRoleCategoryModal(this.addRoleCategoryContent, { mode: 'create' }, 'sm', '');
  }

  /**
   * Create Add / Edit Role Category form
   */
  openAddRoleCategoryModal(content, option, modalClass, event) {
    this.configModalOptionMode = option.mode;
    this.initalForms(event);

    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal role-category-popup',
        size: modalClass,
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }

  /*
  **Create form method
  */
  initalForms(event?) {
    this.createRoleCategoryInitialForm(event);
  }

  /**
   * Create form rules with validation
   */
  createRoleCategoryInitialForm(event?) {
    let maxValue = { level: 0 };
    if (this.roleCategoryData && this.roleCategoryData.data && this.roleCategoryData.data.length > 0) {
      maxValue = this.roleCategoryData.data.reduce(function (prev, current) {
        return (prev.level > current.level) ? prev : current
      })
    }

    this.createRoleCategoryForm = this.fb.group({
      categoryId: [{
        value: event && event.categoryId ? event.categoryId : '', disabled: event &&
          event.mode === 'view' ? true : false
      }],
      categoryName: [{
        value: event && event.categoryName ? event.categoryName : '',
        disabled: event && event.mode === 'view' ? true : false
      },
      [Validators.required, this.noWhitespaceValidator]],
      level: [{ value: event && event.level ? event.level : '', disabled: event && event.mode === 'view' ? true : false },
      [Validators.required, Validators.min(1), Validators.max(maxValue.level + 1)]],
      status: [{ value: event && event.status ? event.status : 'ACTIVE', disabled: event && event.mode === 'view' ? true : false },
      Validators.required],
    })
  }


  /**
   * White space validation
   */
  public noWhitespaceValidator(control: FormControl) {
    if (control.value) {
      const isWhitespace = (control.value || '').trim().length === 0;
      const isValid = !isWhitespace;
      return isValid ? null : { 'whitespace': true };
    }
    return { 'whitespace': false };
  }

  /***
   * Submit Add / Edit Form
   */
  submitForm(form, close, formName) {
    const formData = form.value;
    if (form.valid) {
      if (formData.categoryId) {
        this.updateRoleCategoryForm(formData, close);
      } else {
        this.addRoleCategory(formData, close);
      }

    } else {
      this.cms.validateAllFormFields(form);
    }
  }


  /**
   * Add Role Category
   */
  addRoleCategory(params, close) {
    const postParams = {
      "categoryName": params.categoryName.trim(),
      "level": params.level,
      //"status": params.status
      "status": 'ACTIVE'
    }
    this.SpinnerService.toggleSpinner(1);
    this.RoleCategoryService.createRoleCategory('post', postParams).subscribe(
      res => {
        if (res) {
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Create Role Category Successfully'
          });
          this.getInitialData();
          this.closeModel(close);
        }
        this.SpinnerService.toggleSpinner(0);
      },
      error => {
        this.SpinnerService.toggleSpinner(0);
        // this.failureCase(error);
      }
    );
  }

  /**
   * Update Role Category
   */
  updateRoleCategoryForm(formData, close) {
    const params = {
      'categoryId': formData.categoryId,
      "categoryName": formData.categoryName.trim(),
      //"status": formData.status
      "status": 'ACTIVE'
    }
    this.SpinnerService.toggleSpinner(1);
    this.RoleCategoryService.updateRoleCategory('patch', params).subscribe(
      res => {
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Update Role Category successfully'
        });
        this.getInitialData();
        this.closeModel(close);
        this.SpinnerService.toggleSpinner(0);
      },
      error => {
        this.SpinnerService.toggleSpinner(0);
        //this.failureCase(error);
      }
    );
  }

  /**
   * Error Response
   */
  failureCase(error) {
    this.SpinnerService.toggleSpinner(0);
    this.dataService.broadcast('alert', {
      type: 'danger',
      message: error.error && error.error.errorDetails ? error.error.errorDetails : error.error && error.error.error
        ? error.error.error : 'Network error please try again'
    });
  }

  /**
   * Close Popup Window
   */
  closeModel(close) {
    close('Cross click');
  }
  /**
   * Click On Delete open delete Popup
   */
  deleteItem(event) {
    this.event = event;
    this.openModel(this.deleteConfirmModalContent, event);
  }

  /**
   * Open Model Popup
   */
  openModel(content, event) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: 'sm',
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }

  /**
   * Delete Role Category
   */
  deleteRoleCategory(close: any) {
    const _req = { 'categoryId': this.event.categoryId };
    this.RoleCategoryService.deleteRoleCategory(_req).subscribe((res: any) => {
      this.dataService.broadcast('alert', {
        type: 'success',
        message: 'Delete Role Category successfully'
      });
      this.getInitialData();
      this.closeModel(close);
    }, error => {
      this.failureCase(error);
    });
  }


  /**
   * Get Initial Data
   **/
  ngOnInit() {
    this.getInitialData();
  }

  roleCategoryChangeActionType(event) {
    return false;
  }

  getInitialData() {
    this.getActions('');
    var roleCategoryData = this.RoleCategoryService.getRoleCategoryData();
    let roleCategoryArr = [];
    forkJoin([roleCategoryData]).subscribe(results => {
      if (results[0] && results[0].data) {
        const resultArr = results[0].data.sort(function (a, b) {
          return a.level - b.level;
        });
        const maxLevel = results[0].data.reduce(function (prev, current) {
          return (prev.level > current.level) ? prev : current
        }) //returns object
        resultArr.forEach((value, index) => {
          let categoryArr = [];
          value['showPopup'] = false;
          value['activeClass'] = false;
          categoryArr.push(value);
          const selectedLevel = roleCategoryArr.filter(filterValue => {
            return filterValue.level === value.level;
          });
          if (selectedLevel && selectedLevel.length > 0) {
            const index = roleCategoryArr.findIndex(data => data.categoryId === selectedLevel[0].categoryId);
            roleCategoryArr[index].roleCategoryName.push(value);
          } else {
            if (index === 0 && resultArr.length == 1 && value.level == 1) {
              value['roleCategory'] = "";
            } else if (index === 0 && resultArr.length == 1 && value.level != 1) {
              value['roleCategory'] = "up";
            } else if (index === 0 && resultArr.length > 1 && value.level == 1) {
              value['roleCategory'] = "down";
            } else if (index === 0 && resultArr.length > 1 && value.level !== 1) {
              value['roleCategory'] = "updown";
            } else if (index + 1 === resultArr.length) {
              value['roleCategory'] = "up";
            } else if (value.level == maxLevel.level) {
              value['roleCategory'] = "up";
            } else {
              value['roleCategory'] = "updown";
            }
            // if(value.level == maxLevel.level && value.level !== 1){
            //   value['roleCategory'] = "up";
            // }else if(value.level == 1){
            //   value['roleCategory'] = "";
            // }else if(value.level < maxLevel.level && value.level !== 1){
            //   value['roleCategory'] = "updown";
            // }
            roleCategoryArr.push({
              categoryId: value.categoryId,
              roleCategoryName: categoryArr,
              categoryName: value.categoryName,
              activeClass: false,
              level: value.level,
              status: value.status,
              showPopup: false,
              roleCategory: value.roleCategory
            });
          }
        });
        this.roleCategoryData.data = roleCategoryArr;
        this.roleCategoryData.data.length = roleCategoryArr.length;
        this.roleCategoryData.total = roleCategoryArr.length;
        this.roleCategoryData.page = 1
      } else {
        this.roleCategoryData.data = [];
        this.roleCategoryData.data.length = 0;
        this.roleCategoryData.total = 0;
        this.roleCategoryData.page = 1
      }
    }, error => {
      this.roleCategoryData.data = [];
      this.roleCategoryData.data.length = 0;
      this.roleCategoryData.total = 0;
      this.roleCategoryData.page = 1
      this.failureCase(error);
    });
  }





  /* 
  * Get Actions previliges for Role Category
  */
  getActions(type) {
    // let _module;
    // if (type == 'ap') {
    //   _module = EnumsService.AUTOPS_APP;
    // } else if (type == 'cp') {
    //   _module = EnumsService.AUTOPS_CONFIG;
    // } else {
    //   _module = EnumsService.AUTOPS_FIRMWARE;
    // }

    // const main_module = EnumsService.AUTOPS;
    // // Form object to get the previliiages from server
    // const obj = {
    //   moduleCode: main_module,
    //   roleId: this.dataService.getAtobLocalStorage('roleId'),
    //   previliages: true
    // };
    // // API to get Previliages
    // this.userService.getPreViliages(obj).subscribe(prev => {

    //   const headerActions = this.userService.getModulePermission(
    //     // EnumsService.ACTIONS[_module],
    //     EnumsService.ACTIONS[main_module],
    //     prev.data.privilege // Passing privilege to the methos to get thr actions array
    //   );
    //   headerActions.actionsArray.forEach(element => {
    //     if (element.type === 'apRead') {
    //       this.apRead = true;
    //     }
    //     if (element.type === 'cpRead') {
    //       this.cpRead = true;
    //     }
    //     if (element.type === 'fpRead') {
    //       this.fpRead = true;
    //     }
    //   });
    //   this.actionsArr = this.userService.getModulePermission(
    //     EnumsService.ACTIONS[_module],
    //     prev.data.privilege // Passing privilege to the methos to get thr actions array
    //   );
    //   if (this.actionsArr && this.actionsArr.actionsArray && this.actionsArr.actionsArray.length > 0) {
    //     this.actionsArr.actionsArray.forEach(element => {
    //       if (element.type == 'add') {
    //         element.title = 'Create Rule Group';
    //       } if (element.type == 'edit') {
    //         element.title = 'Edit Rule Group';
    //       } if (element.type == 'delete') {
    //         element.title = 'Delete Rule Group';
    //       } if (element.type == 'redirecturl') {
    //         element.title = 'Redirect to create rule';
    //       }
    //     });
    //   }
    //   this.roleCategoryData.tableActions = this.actionsArr;
    //   this.roleCategoryData.tableActions.search = this.actionsArr.headerRights.search;
    //   this.roleCategoryData.tableActions.add = this.actionsArr.headerRights.add;
    //   this.roleCategoryData.actions = this.actionsArr.actionsArray;
    // });
    this.actionsArr = {
      "actionsArray": [{
        disableIconProp: true,
        negate: null,
        showIconProp: null,
        title: "Create Role Category",
        type: "add"
      }]
    };
    this.actionsArr['headerRights'] = { add: true };
    this.roleCategoryData.tableActions = this.actionsArr;
    this.roleCategoryData.tableActions.add = this.actionsArr.headerRights.add;
    this.roleCategoryData.actions = this.actionsArr.actionsArray;
  }

  upDownChangeLevel(event) {
    if (event && event.roleLevelData == undefined || event.roleLevelData == null || event.roleLevelData == '') {
      this.dataService.broadcast('alert', {
        type: 'danger',
        message: 'Please Select Role Categories'
      });
      return false;
    } else {
      // if (event && event.roleCategoryIndex &&
      //   this.roleCategoryData && this.roleCategoryData.data
      //   && this.roleCategoryData.data.length > 0
      //   && this.roleCategoryData.data[event.roleCategoryIndex].roleCategoryName
      //   && this.roleCategoryData.data[event.roleCategoryIndex].roleCategoryName.length < 2) {
      //   this.dataService.broadcast('alert', {
      //     type: 'danger',
      //     message: 'At least two role categories should be there'
      //   });
      //   return false;
      // }
      let roleStatus = 1;
      if (event && event.roleLevelData && event.roleLevelData.level && event.roleStatus === 'down') {
        roleStatus = event.roleLevelData.level + 1;
      } else if (event && event.roleLevelData && event.roleLevelData.level && event.roleStatus === 'up') {
        roleStatus = event.roleLevelData.level - 1;
      }
      const params = {
        'categoryId': event && event.roleLevelData && event.roleLevelData.categoryId ? event.roleLevelData.categoryId : '',
        'categoryName': event && event.roleLevelData && event.roleLevelData.categoryName ? event.roleLevelData.categoryName.trim() : '',
        "level": roleStatus,
        //"status": formData.status
        "status": 'ACTIVE'
      }
      this.SpinnerService.toggleSpinner(1);
      this.RoleCategoryService.updateRoleCategory('patch', params).subscribe(
        res => {
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Update Role Category successfully'
          });
          this.getInitialData();
          this.closeModel(close);
          this.SpinnerService.toggleSpinner(0);
        },
        error => {
          this.SpinnerService.toggleSpinner(0);
          // this.failureCase(error);
        }
      );
    }
  }
}
