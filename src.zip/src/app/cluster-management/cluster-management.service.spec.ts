import { TestBed } from '@angular/core/testing';

import { ClusterManagementService } from './cluster-management.service';

describe('ClusterManagementService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ClusterManagementService = TestBed.get(ClusterManagementService);
    expect(service).toBeTruthy();
  });
});
