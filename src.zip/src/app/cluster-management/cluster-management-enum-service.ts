import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ClusterManagementEnumService {
  public static DATA = {
    data: [],
    columns: [
      {
        displayName: 'Make',
        key: 'make',
        filter: ''
      },
      {
        displayName: 'Device Type',
        key: 'deviceType',
        filter: ''
      },
      {
        displayName: 'Application Name',
        key: 'applicationName',
       filter: ''
      },
      {
        displayName: 'Domain',
        key: 'domain',
        filter: ''
      },
      {
        displayName: 'Partner Name',
        key: 'partnerName',
        filter: ''
      },
      {
        displayName: 'Enterprise Name',
        key: 'enterpriseName',
        filter: ''
      },
      {
        displayName: 'Cluster ID',
        key: 'clusterId',
        filter: ''
      }
    ],
    actions: [
    ],
    actionsLabel: 'Actions',
    tableHeader: 'Cluster Management',
    tableActions: {
      add: true,
      search: true,
      dropdown: true
    }
  };
  constructor() { }
}