import { Component, ViewChild, OnInit, ElementRef } from '@angular/core';
import { ClusterManagementEnumService } from './cluster-management-enum-service';
import { ClusterManagementService } from './cluster-management.service';
import { InlinePagenationTableComponent } from '../shared/components/inline-pagenation-table/inline-pagenation-table.component';
import { HttpHeaders } from '@angular/common/http';

import { DataService } from '../shared/services/data.service';
import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';

@Component({
  selector: 'app-cluster-management',
  templateUrl: './cluster-management.component.html',
  styleUrls: ['./cluster-management.component.less']
})
export class ClusterManagementComponent implements OnInit {
  @ViewChild(InlinePagenationTableComponent, { static: false }) child: InlinePagenationTableComponent;
  @ViewChild('addLabelContent', { static: false }) addLabelContent: ElementRef;

  titles = [];
  newRowData: any;
  editabelField = false;
  data = {
    data: [],
    moduleName: true,
    headerDropdownList: [],
    columns: [
      {
        displayName: 'make',
        key: 'make',
        filter: '',
        filterRowEvent:true,
        input: true,
        dropdown: false,
        editvalue: true
      },
      {
        displayName: 'deviceType',
        key: 'deviceType',
        filter: '',
        filterRowEvent:true,
        input: true,
        dropdown: false,
        editvalue: true
      },
      {
        displayName: 'applicationName',
        key: 'applicationName',
        filter: '',
        filterRowEvent:true,
        input: true,
        dropdown: false,
        editvalue: true
      },
      {
        displayName: 'domain',
        key: 'domain',
        filter: '',
        filterRowEvent:true,
        input: true,
        dropdown: false,
        editvalue: true
      },
      {
        displayName: 'partnerId',
        key: 'partnerId',
        filter: '',
        filterRowEvent:true,
        input: true,
        dropdown: false,
        editvalue: true
      },
      {
        displayName: 'enterpriseName',
        key: 'enterpriseName',
        filter: '',
        filterRowEvent:true,
        input: true,
        dropdown: false,
        editvalue: true
      },
      {
        displayName: 'clusterid',
        key: 'clusterId',
        filter: '',
        filterRowEvent:true,
        input: true,
        dropdown: false,
        editvalue: false
      }
    ],
    actions: [
      // {
      //   type: 'edit',
      //   title: 'Edit Label',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'delete',
      //   title: 'Delete Label',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'save',
      //   title: 'Save Label',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'times',
      //   title: 'Cancel',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // }
    ],
    actionsLabel: 'Actions',
    total: 0,
    tableHeader: 'Cluster Management',
    tableActions: {
      // search: true,
      // add: true,
      // view: true,
      // delete: true,
      // edit: true,
      // save: true,
      // times: true
    }
  };
  actionsArr;

  constructor(private clusterService: ClusterManagementService,
    private userService: UserService,
    private dataService: DataService) { }

  ngOnInit() {
    this.getDetailsTotal();
    this.getActions();
  }

  editDetails(event) {
    this.editabelField = true;
  }

 

  saveData(event) {
    const param = {
      "make": event.data.make,
      "deviceType": event.data.deviceType,
      "applicationName": event.data.applicationName,
      "domain": event.data.domain,
      "partnerId": event.data.partnerId,
      "enterpriseName": event.data.enterpriseName,
      "clusterId": event.data.clusterId,
      "reservedField1": event.data.reservedField1,
      "reservedField2": event.data.reservedField2
    }
    if (!event.action) {
      this.clusterService.updateData(param).subscribe((res: any) => {
        this.dataService.broadcast('alert', {
          type: 'success',
          message: `Update successfully!`
        });
        this.child.getPage(1);
        this.child.cancelEdit(event.data);
        this.child.submit = false;
      });
    } else {
      param.reservedField1 = "value1";
      param.reservedField2 = "value2";
      this.clusterService.saveDetails(param).subscribe((res: any) => {
        this.editabelField = true;
        this.dataService.broadcast('alert', {
          type: 'success',
          message: `Save successfully!`
        });
        this.child.getPage(1);
        this.editabelField = true;
        this.child.submit = false;
      });
    }
  }

  getDetailsTotal() {
    this.clusterService.getTitleDetailsTotal().subscribe((res: any) => {
      this.data.total = res.data;
     
    },
      (error) => {
      });
  }

  sortData(event){
    var param = {
      'pageNum': 1,
      'rpp': 10,
      'sortingkey': event.columnName,
      'orderByKey': event.orderBy
    }
    this.getDetails(param)

   }

  getDetails(params) {
    this.clusterService.getTitleDetails(params).subscribe((res: any) => {
      this.data.data = [];
      this.data.data = res.data;
      if(res.count){
        this.data.total = res.count;
      }else{
        this.getDetailsTotal();
      }
      this.data.headerDropdownList = [
        { 'key': 'make', 'value': 'MAKE' },
        { 'key': 'deviceType', 'value': 'DEVICE TYPE' },
        { 'key': 'domain', 'value': 'DOMAIN' },
        { 'key': 'partnerId', 'value': 'PARTNER ID' },
        { 'key': 'clusterId', 'value': 'CLUSTER ID' },
        { 'key': 'applicationName', 'value': 'APPLICATION NAME' },
        { 'key': 'enterpriseName', 'value': 'ENTERPRISE NAME' },
      ]
      this.setId();
      this.child.updateEditCache('notEdit');
    },
      (error) => {
       // console.log(error);
      });
  }
  getActions() {
    const _module = EnumsService.CLUSTER_UI_API;
    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe(prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );
      this.data.tableActions = this.actionsArr;
      this.data.tableActions['search'] = this.actionsArr.headerRights.search;
      this.data.tableActions['add'] = this.actionsArr.headerRights.add;
      this.data.tableActions['delete'] = this.actionsArr.headerRights.delete;
      this.data.actions = this.actionsArr.actionsArray;
      this.data.tableActions['dropDown'] = true;

    });



  }

  setId() {
    this.data.data.forEach(function (item, key) {
      item["id"] = key;
    });
  }

  getnewRowData(event) {
    this.editabelField = false;
    this.newRowData = {
      'make': '',
      'deviceType': '',
      'domain': '',
      'partnerId': '',
      'enterpriseName': '',
      'clusterId': '',
      'applicationName': '',
      'newRow': true
    };
    this.data.data.splice(0, 0, this.newRowData);
    this.child.updateEditCache('edit');
  }

  deleteTitleDetails(event) {
    const options = {
      'clusterId': event.clusterId
    }
    options['jioUtils'] = true;
    this.clusterService.deleteTitle(options).subscribe((res: any) => {
      this.child.getPage(1);
    });
  }
}
