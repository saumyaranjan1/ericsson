import { ClusterManagementModule } from './cluster-management.module';

describe('ClusterManagementModule', () => {
  let clusterManagementModule: ClusterManagementModule;

  beforeEach(() => {
    clusterManagementModule = new ClusterManagementModule();
  });

  it('should create an instance', () => {
    expect(clusterManagementModule).toBeTruthy();
  });
});
