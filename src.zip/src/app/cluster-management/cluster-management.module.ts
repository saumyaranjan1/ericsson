import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClusterManagementRoutingModule } from './cluster-management-routing.module';
import { SharedModule } from '../shared/shared.module';
import { ClusterManagementComponent } from './cluster-management.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    ClusterManagementRoutingModule
  ],
  declarations: [ClusterManagementComponent]
})
export class ClusterManagementModule { }
