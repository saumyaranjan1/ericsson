import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class ClusterManagementService {

  constructor(private interceptor: InterceptorService) { }

  getTitleDetailsTotal() {
    return this.interceptor.httpCall('get', 'getClusterDetailsTotal');
  }
 
  getTitleDetails(request) {
    const param={};
    if(request.sortingkey){
    param['sortingkey']=request.sortingkey;
    param['orderByKey']=request.orderByKey;
    }
    if(request.searchBy){
      param['textSearchInColumn']=request.searchBy;
      param['textToSearch']=request.searchValue;
       return this.interceptor.httpCall('get', 'searchUrl', param);
    }else{
      param['pageNum']=request.pageNum;
      param['rpp']=request.rpp;
      return this.interceptor.httpCall('get', 'getClustersDetail', param);
    }
   
  }

  saveDetails(request) {
    return this.interceptor.httpCall('post', 'saveData', request);
  }

  updateData(request) {
    return this.interceptor.httpCall('post', 'updateData', request);
  }

  deleteTitle(request) {
    request.user={ 'clusterId' : request.clusterId ,queryParam: true }
     return this.interceptor.httpCall('delete', 'deleteData', request);
   }

}
