import { Injectable } from '@angular/core';

@Injectable()
export class DomainEnumsService {
  public static DOMAIN_DETAILS = {
    data: [],
    columns: [
     {
        displayName: 'Domain ID',
        key: 'domainid',
        filter: '',
        input: true,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:true
      },
      {
        displayName: 'Domain Name',
        key: 'domainName',
        input: true,
        dropdown: false,
        textArea:false,
        save:true,
        editvalue:true
      }
    ],
    actionsLabel: 'Actions',
    actions: [
      // {
      //   type: 'delete',
      //   title: 'Delete Domain',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'save',
      //   title: 'Save Label',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'times',
      //   title: 'Time Label',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // }
    ],

    tableHeader: 'Device Management:Available Domains',
    tableActions: {
      search: true,  
      add: true,
      view: false,
      delete: true,
      edit: false,
      times: true
    }
  };
  public static MODAL_CONFIG = {
    create: { headerText: 'Add Partner Details', primeBtnText: 'Create' },
    edit: { headerText: 'Edit Partner', primeBtnText: 'Update' },
    sige: { sm: 'sm', lg: 'lg' }
  };
  constructor() {}
}
