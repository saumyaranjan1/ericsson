export interface IDomain {
    DomainId ?: string;
    DomainName?: string;
}
