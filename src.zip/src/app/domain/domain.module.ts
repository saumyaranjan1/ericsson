import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './../shared/shared.module';
import { DomainRoutingModule } from './domain-routing.module';
import { DomainService } from './domain.service';
import { DomainComponent } from './domain.component';

@NgModule({
  imports: [
    CommonModule,
    DomainRoutingModule,
    SharedModule
  ],
  declarations: [DomainComponent],
  providers: [DomainService]
})
export class DomainModule { }
