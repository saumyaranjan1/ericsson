import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class DomainService {

  constructor(private interceptorService: InterceptorService) { }
  getDomainDetailsList() {
    return this.interceptorService.httpCall('get', 'getDomainsList');
  }
  createDomain(request) {
    return this.interceptorService.httpCall('post', 'createDomain', request);
  }
  deleteDomain(request) {
    return this.interceptorService.httpCall('delete', 'deleteDomain', request);
  }
}
