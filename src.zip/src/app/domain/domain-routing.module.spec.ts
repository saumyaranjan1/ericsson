import { DomainRoutingModule } from './domain-routing.module';

describe('DomainRoutingModule', () => {
  let domainRoutingModule: DomainRoutingModule;

  beforeEach(() => {
    domainRoutingModule = new DomainRoutingModule();
  });

  it('should create an instance', () => {
    expect(domainRoutingModule).toBeTruthy();
  });
});
