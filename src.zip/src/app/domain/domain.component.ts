import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { IDomain } from './domain';
import { DomainEnumsService as des} from './domain.enums.service';
import { DomainService } from './domain.service';
import { DataService } from '../shared/services/data.service';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { InlinePagenationTableComponent } from '../shared/components/inline-pagenation-table/inline-pagenation-table.component';
import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';

@Component({
  selector: 'app-domain',
  templateUrl: './domain.component.html',
  styleUrls: ['./domain.component.less']
})
export class DomainComponent implements OnInit {
  @ViewChild(InlinePagenationTableComponent,{ static: true }) child: InlinePagenationTableComponent;
  @ViewChild('deleteConfirmModalContent', {static: true}) deleteConfirmModalContent: ElementRef;
  @ViewChild('addDomainContent', {static: true}) addDomainContent: ElementRef;
  domainDetails = des.DOMAIN_DETAILS;
  configModalOptionMode = null;
  modalConfig = des.MODAL_CONFIG;
  domainInfo;
  deleatParam:any;
  newRowData:any;
  domainForm: FormGroup;
  actionsArr;
  constructor(private ds: DomainService,
    private ngbModal: NgbModal,
    private formBuilder: FormBuilder,
    private dataService: DataService,
    private userService: UserService,
    private cms: CommonMethodsService) { }

  ngOnInit() {
    this.getDomainDetailsList();
    this.domainFormBloack();
  }
  domainFormBloack(event?) {
    this.domainForm = this.formBuilder.group({
      'domainid': [event ? event.domainid : null, Validators.required],
      'domainName': [event ? event.domainName : null, Validators.required]
    });
  }

  submitForm(event){
    console.log(event);
      this.createDomain(event.data,event.action);
   }

  createDomain(data, formData) {
  //  const data: IDomain = formData;
    this.ds.createDomain(data).subscribe(res => {
      this.getDomainDetailsList();
      this.dataService.broadcast('alert', {
        type: 'success',
        message: `Domain created successfully!`
      });
      this.child.cancelEdit(data);
    });
  }


  deleteDomain(close) {
    this.ds.deleteDomain(this.domainInfo.domainid).subscribe(res => {
      this.getDomainDetailsList();
      this.closeModel(close);
    });
  }

  getDomainDetailsList() {
    this.getActions();
    this.ds.getDomainDetailsList().subscribe( result => {
     if (result.data) {
        const data: IDomain[] = result.data;
        this.domainDetails.data = data;
        this.setId();
        this.child.updateEditCache('notEdit');       
      }
    });
  }
  getActions() {
    const _module = EnumsService.DOMAIN_DETAILS_UI_API;

     // Form object to get the previliiages from server
     const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };


    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe( prev => {
    console.log(prev);
      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

    this.domainDetails.tableActions = this.actionsArr;
    this.domainDetails.tableActions['search']=this.actionsArr.headerRights.search;
    this.domainDetails.tableActions['add']=this.actionsArr.headerRights.add;
    this.domainDetails.actions =  this.actionsArr.actionsArray;
      
    });

   
   
    }

  getnewRowData(event){
    this.newRowData = {
      'domainid': '',
      'domainName': '',
      'newRow': true
   };
    this.domainDetails.data.splice(0,0,this.newRowData);
    this.child.updateEditCache('edit');
  }

  openModal(content: any, size, event?: any) {
    this.domainInfo = event;
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        backdrop: 'static',
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }

  closeModel(close: any) {
    close('Cross click');
  }

  openDeleteModal(event) {
    console.log(event);
    this.deleatParam=event.appName
    this.openModal(
      this.deleteConfirmModalContent,
      this.modalConfig.sige.sm,
      event
    );
  }

  setId() {
    this.domainDetails.data.forEach(function (item, key) {
      item["id"] = key;
    });
  }
  

  openCreateDomainModal(option) {
    this.configModalOptionMode = option.mode;
    //this.openModal(this.addDomainContent, this.modalConfig.sige.lg);
  }

}
