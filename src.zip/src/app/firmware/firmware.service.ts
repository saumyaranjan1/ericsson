import { Injectable } from '@angular/core';

import { InterceptorService } from '../shared/services/interceptor.service';
import { DataService } from '../shared/services/data.service';

@Injectable({
  providedIn: 'root'
})
export class FirmwareService {

  constructor(private interceptor: InterceptorService,
    private dataService: DataService) { }
  /**
   * Get Total Enterprise Count
   */
  getTotalCountEnterprises() {
    return this.interceptor.httpCall('get', 'getfirmwareTotalCountEnterprises');
  }

  /**
   * Get Domain Info
   */
  getDomainData(){
    let _res = sessionStorage.getItem('domain');
    return JSON.parse(_res);
  }

  /**
   * Get Total Enterprise List
   */
  getVendorList(request) {
    return this.interceptor.httpCall('get', 'getFirmwareEnterpriseList', request);
  }

  /**
   * Get Firmware List
   */
  getFirmwareDetails(request) {
    return this.interceptor.httpCallReturn('get', 'getAllFirmwareList', request);
  }

  /**
   * Update Firmware Version
   */
  updateNewVersionData(request) {
    return this.interceptor.httpCallReturn('post', 'updateNewVersionData', request);
  }

  /**
   * Update Version
   */
  updateVersionFirmware(request,id,oldVersionNumber) {
    if(request['domain'] && request['domain'].domainId && request['domain'].domainName){
      request.extraParams = "?id="+id+"&versionNumber="+oldVersionNumber+"&domainName="+request['domain'].domainName+
                            "&shortDescription="+request.shortDescription+"&longDescription="+request.longDescription
                            +"&estimatedUpdateTime="+request.estimatedUpdateTime
                            +"&firmwareName="+request.firmwareName
                            +"&versionName="+request.versionName
                            +"&updateVersionNo="+request.updateVersionNo
                            +"&releaseNotes="+request.releaseNotes
                            +"&status="+request.status;
    }else{
      request.extraParams = "?id="+id+"&versionNumber="+oldVersionNumber+
                            "&shortDescription="+request.shortDescription+"&longDescription="+request.longDescription
                            +"&estimatedUpdateTime="+request.estimatedUpdateTime
                            +"&firmwareName="+request.firmwareName
                            +"&versionName="+request.versionName
                            +"&updateVersionNo="+request.updateVersionNo
                            +"&releaseNotes="+request.releaseNotes
                            +"&status="+request.status;
    }
    return this.interceptor.httpCall('patch', 'updateVersionFirmware', request, false, true);
  }
  /**
   * Search with object
   */
  getObject(request) {
    const key = request['dropDownValue'].trim();
    const value = request['searchKey'].trim();
    const dataObj = {};
    if (request.dropDownValue.trim() === 'firmwarename') {
      dataObj['name'] = request['searchKey'].trim();
    } else if (request.dropDownValue === 'domain') {
      dataObj['domains'] = new Array(request.searchKey);
    } else if (request.dropDownValue.trim() === 'devicemodel') {
      let deviceSpace = request.searchKey.split(" ");
      let deviceName = "";
      let vendorName = "";
      let deviceModalParams = {};
      if (deviceSpace && deviceSpace[0]) {
        deviceName = deviceSpace[0];
      } if (deviceSpace && deviceSpace[1]) {
        vendorName = deviceSpace[1];
      }
      deviceModalParams = { name: vendorName, vendor: deviceName };
      //dataObj['deviceModels'] = new Array(deviceModalParams);
      dataObj['deviceModels'] = request['searchKey'].trim();
    } else {
      dataObj[key] = new Array(value);
    }
    return dataObj;
  }

  /**
   * Get Plat Form
   */
  getPlatforms(params) {
    let request = {}
    if(params && params.id && params.name){
      request['extraParams'] = "&domainName="+params.name;
    }
    return this.interceptor.httpCall('get', 'getFirmwarePlatforms',request);
  }

  /**
   * Get Device Vendor Modal
   */
  getDeviceVendorModal(action) {
    const params = {extraParams:'?platformId='+action};
    return this.interceptor.httpCall('get', 'getFirmwareDeviceVendor',params);
  }

  /**
   *  Firmware By ID
   */
  firmwareByID(action,domainInfo) {
    let params = {};
    if(domainInfo && domainInfo.domain && domainInfo.domain.id && domainInfo.domain.name){
      params = {extraParams:'?name='+action.id+"&domainId="+domainInfo.domain.id+"&domainName="+domainInfo.domain.name};
    }else{
      params = {extraParams:'?name='+action.id};
    }
  
    return this.interceptor.httpCall('get', 'getFirmwareByIDVersion',params);
  }

   /**
   *  Firmware By Version
   */
  firmwareByVersion(id,name,domainInfo) {
    let params = {};
    if(domainInfo && domainInfo.id && domainInfo.name){
      params = {extraParams:'?id='+id+'&versionNumber='+name+"&domainId="+domainInfo.id+"&domainName="+domainInfo.name};
    }else{
     params = {extraParams:'?id='+id+'&versionNumber='+name};
    }
    
    return this.interceptor.httpCall('get', 'getFirmwareByVersion',params);
  }

  /**
   * Get Device Modal
   */
  getFirmwareDeviceModal(action,domainInfo) {
    let params = {};
    if(domainInfo && domainInfo.id && domainInfo.name){
      params = {extraParams:'?platformId='+action+'&domainName='+domainInfo.name+"&domainId="+domainInfo.id};
    }else{
     params = {extraParams:'?platformId='+action};
    }
    return this.interceptor.httpCall('get', 'getFirmwareDeviceModal',params);
  }

  /**
   * Upload New Version
   */
  uploadNewVersionData(request, newVersion,requestPrams) {
    request.extraParams = "?domainName="+requestPrams.domainName+"&id="+requestPrams.id+"&domainId="+requestPrams.domainId+
    "&status="+requestPrams.status+"&versionName="+requestPrams.versionName+"&versionNumber="+requestPrams.versionNumber
    +"&estimatedUpdateTime="+requestPrams.estimatedUpdateTime+"&releaseNotes="+requestPrams.releaseNotes
    +"&shortDescription="+requestPrams.shortDescription;
    return this.interceptor.httpCallReturn('post', 'updateFileFirmwareVersion', request, false, true);
  }

  /**
   * Populate Upload form
   */
  populateOtherFields(request) {
    return this.interceptor.httpCallReturn('get', 'populateFirmwareVersion', request);
  }

  /**
   * Save Firmware
   */
  saveFirmware(request) {
    return this.interceptor.httpCallReturn('post', 'createFirmware', request);
  }

  /**
   * Get Timezone
   */
  getDefaultTimeZones(request) {
    let params = {};
    if(request && request.name && request.id){
      params['extraParams'] = "?domainName="+request.name;
    }
    return this.interceptor.httpCall('get', 'defaultFirmwareTimeZones',params);
  }

  /**
   * Install Software
   */
  installSoftwareWithDevices(request) {
    return this.interceptor.httpCallReturn('post', 'installFirmwarePackage', request);
  }

  /**
   * Get Device Associate
   */
  getDeviceDetailsAssociatedWithDeviceModel(request,params) {
    return this.interceptor.httpCall('get', 'getFirmwareDevices', request);
  }

  /**request
   * Delete Firmware
   */
  deleteFirmware(request) {
    request.extraParams =  "?domainId="+request.domainId+"&domainName="+request.domainName+"&id="+request.id;
    return this.interceptor.httpCallReturn('delete', 'deleteFirmware', request);
  }

  deleteFirmwareVersion(request) {
    request.extraParams =  "?id="+request.id+"&versionNumber="+request.versionNumber+"&domainName="+request.domainName;
    return this.interceptor.httpCallReturn('delete', 'deleteFirmwareVersion', request);
  }

  getEnterpriseSearchName(request) {
    return this.interceptor.httpCall('get', 'getFirmwareEnterpriseSearchName', request);
  }

  
}
