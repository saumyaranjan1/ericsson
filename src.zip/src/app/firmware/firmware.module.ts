import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FirmwareComponent } from './firmware.component';
import { FirmwareRoutingModule } from './firmware-routing.module';
import { SharedModule } from '../shared/shared.module';
import { VendorService } from './../vendor/vendor.service';

@NgModule({
  declarations: [FirmwareComponent],
  imports: [
    CommonModule,
    FirmwareRoutingModule,
    SharedModule
  ],
  providers: [VendorService],
})
export class FirmwareModule { }
