import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FirmwareEnumService } from './firmware-enum.service';
import { FirmwareService } from './firmware.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';

import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { SpinnerService } from '../shared/services/spinner.service';
import { DataService } from '../shared/services/data.service';
import { Router } from '@angular/router';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { forkJoin } from 'rxjs';
import { VendorService } from './../vendor/vendor.service';
import * as jsonURL from "./../../assets/dropdown-json/dropdown.json";
import { HeaderService } from './../../app/main/header/header.service';

import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';

@Component({
  selector: 'app-firmware',
  templateUrl: './firmware.component.html',
  //styleUrls: ['./firmware.component.less','./../shared/components/server-pagination/server-pagination.component.less']
  styleUrls: ['./firmware.component.less']
})
export class FirmwareComponent implements OnInit {
  // @ViewChild('mapModelsTemplate', { static: false }) mapModelsTemplate: ElementRef;
  // @ViewChild('mapEnterpriseTemplate', { static: false }) mapEnterpriseTemplate: ElementRef;
  // @ViewChild('devicesTemplate', { static: false }) devicesTemplate: ElementRef;
  // @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('devicesTemplate', { static: false }) devicesTemplate: ElementRef;
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('deleteVersionConfirmModalContent', { static: true }) deleteVersionConfirmModalContent: ElementRef;
  columns = FirmwareEnumService.DATA.columns;
  hideListTable = false;
  selectedValue;
  domainInfo = [];
  platformList = [];
  firmwareDeviceList = [];
  isRoleAdd = true;
  isRoleEdit = true;
  isRoleDelete = true;
  isRoleInstall = true;
  zones;
  startTime = '';
  endTime = '';
  searchFilter;
  firmwareDeviceListData = [];
  deviceVendorDataList = [];
  isCreateNew = false;
  isInstallSoftware = false;
  selectedDevicesCount = 0;
  viewenterpriseIds = []; //View enterprise ID
  isView = false;
  isEdit = false;
  isversionView = false;
  isNewVersion = false;
  searchModel;
  models = [];
  headerDropdownList;
  selectedDeviceIds = [];
  oldVersionNumber;
  modelsColumns = FirmwareEnumService.MODELS_COLUMNS;
  enterpriseModelsColumns = FirmwareEnumService.ENTERPRISE_COLUMNS;
  updateFileColumns = FirmwareEnumService.UPDATEFILE_COLUMNS;
  deviceModalsColumns = FirmwareEnumService.DEVICE_MODELS_COLUMNS;
  viewColumn = FirmwareEnumService.VIEWDATA.viewColumn;
  actionsObj = {
    actionsLabel: FirmwareEnumService.DATA.actionsLabel,
    actions: FirmwareEnumService.DATA.actions
  };
  viewFirmwareData;
  notSelectAnyDevices;
  configModalOptionMode = null;
  installversionNumber = 0;
  testingTool = [];
  uploadedFile;
  uploadedFileName;
  fileExtension;
  fileSubmitReq;
  selectAllDevices;
  installSoftwareDetails;
  currentPageOfDeviceModal = 1;
  createNewFirmwareForm: FormGroup;
  createNewVersionFirmwareForm: FormGroup;
  enterpriseIdsArray;
  installModels;
  serverPlatformsList = [];
  deviceVendorList = [];
  deviceModelsList = [];
  platformSelection = "";
  installSoftwareForm: FormGroup;
  selectedDeviceModal = [];
  selectedDeviceNames = [];
  selectEnterpriseAll = false;
  selectedEnterpriseCount;
  deviceModelsListCount;
  tableHeader = FirmwareEnumService.DATA.tableHeader;
  tableHeaderActions = FirmwareEnumService.DATA.tableActions;
  deleteFlag = FirmwareEnumService.DATA.deleteIcon;
  showGridCheckBox = FirmwareEnumService.DATA.showGridCheckBox;
  jsonData: any = (jsonURL as any).default;
  data = {
    page: 1,
    total: 1,
    data: []
  };
  diffDays;
  selectedEnterpriseModals = [];
  //today's date   
  todayDate: Date = new Date();
  testingStatus = [];
  enterprisemodels = [];
  packageId;
  newVersionPackageId;
  scheduleType = false;
  domainParams;
  event;
  actionsArr;
  pageSize = 1;
  selectedEnterpriseList = [];
  filterSearch = "";
  showEnterpriseList = false;
  constructor(
    private firmwareService: FirmwareService,
    private http: HttpClient,
    private ngbModal: NgbModal,
    private fb: FormBuilder,
    private spinnerService: SpinnerService,
    private cms: CommonMethodsService,
    private dataService: DataService,
    private userService: UserService,
    public router: Router,
    private VendorService: VendorService,
    private HeaderService: HeaderService
  ) { }

  /**
   *  initial Data
  **/
  ngOnInit() {
    this.getDomainInfo();
    this.headerDropdownList = this.jsonData.firmwaredropdown;
    this.searchFilter = [{ key: 'hqBpName', }]
  }

  changeDomain(event) {
    let domainValue;
    const domainData = this.domainInfo.filter(data => {
      return data.id === event.value;
    });
    if (domainData && domainData.length > 0) {
      domainValue = { id: domainData[0].id, name: domainData[0].name };
      this.domainParams = { id: domainData[0].id, name: domainData[0].name };
    }
    this.HeaderService.setDomain(domainValue);
    let params = { "limit": 10, "offset": 0, domain: this.domainParams };
    this.hideListTable = true;
    this.hideTable();
    this.getData(params);
    this.getPlatforms();
    this.getActions();
  }


  getDomainInfo() {
    this.HeaderService.getDomainInfo().subscribe(result => {
      let domainData = [];
      if (result) {
        domainData = result;
        if (domainData && domainData.length > 0) {
          const selectedDomain = this.HeaderService.getSelectedDomain();
          if (selectedDomain && selectedDomain.id) {
            this.selectedValue = selectedDomain.id;
            this.domainParams = { name: selectedDomain.name, id: selectedDomain.id }
          } else {
            const deviceData = { id: domainData[0].domainId, name: domainData[0].domainName };
            this.HeaderService.setToStorage('domain', deviceData);
            this.selectedValue = domainData[0].domainId;
            this.domainParams = { name: domainData[0].domainName, id: domainData[0].domainId }
          }
          domainData.forEach(value => {
            this.domainInfo.push({ id: value.domainId, name: value.domainName });
          });
          this.getPlatforms();
          this.getActions();
        }
      }
    }, error => {
    });
  }

  /**
   * Get Actions for FirmWare module
   */

  getActions() {
    const _module = EnumsService.PSFIRM;


    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe(prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

      const actionsArray = this.actionsArr.actionsArray.filter((obj) => {
        return (
          obj.disableIconProp !== false &&
          obj.type !== 'add'
        );
      });
      if (this.actionsArr.headerRights) {
        this.isRoleAdd = this.actionsArr.headerRights['add'];
        this.isRoleInstall = this.actionsArr.headerRights['add'];
        this.isRoleDelete = this.actionsArr.headerRights['delete'];
        this.isRoleEdit = this.actionsArr.headerRights['edit'];
      }
      this.tableHeaderActions = this.actionsArr.headerRights;
      this.tableHeaderActions['exportToCsv'] = false;
      this.tableHeaderActions['provisiondropDown'] = true;
      this.tableHeaderActions['provisionsearch'] = true;
      this.tableHeaderActions['deleteAction'] = false;
      this.actionsObj.actions = actionsArray;
      this.actionsObj.actions.forEach(element => {
        if (element.type == "install") {
          element.title = 'Install Firmware provisioning service';
        }
      });
    });
  }

  /**
   * Change server status
   */
  changeServerStatus(event) {
    if (event && event.value && event.value === 'scheduled') {
      this.scheduleType = true;
    } else {
      this.scheduleType = false;
    }
  }

  /**
   * Delete Firmware
   */
  deleteFirmware(event) {
    this.event = event;
    this.openModal(this.deleteConfirmModalContent, 'sm');
  }

  /**
   *  delete with version
   */
  deleteWithVersion(event, rowData) {
    this.event = event;
    this.event['versionNumber'] = rowData.number;
    this.event['latestVersionName'] = rowData.name;
    this.isInstallSoftware = false;
    this.isCreateNew = false;
    this.isView = true;
    this.isEdit = false;
    this.isversionView = false;
    this.packageId = false;
    this.isNewVersion = false;
    this.openModal(this.deleteVersionConfirmModalContent, 'sm');
  }

  saveSelectedModals(close) {
    if (this.installModels) {
      const selectedModal = this.installModels[this.installModels.findIndex(deviceModal => deviceModal.name == this.selectedDeviceModal[0])];
      const selcetedDevicesCount = this.selectedDeviceNames.filter(data => {
        return data.model === selectedModal['name'];
      });

      if (this.notSelectAnyDevices) {
        selectedModal['indeterminate'] = false;
        selectedModal['checked'] = false;
      } else if (this.selectAllDevices) {
        if (selcetedDevicesCount.length === this.deviceModelsListCount) {
          selectedModal['indeterminate'] = false;
          selectedModal['checked'] = true;
        } else {
          selectedModal['indeterminate'] = true;
          selectedModal['checked'] = false;
        }
      } else {
        selectedModal['indeterminate'] = true;
        selectedModal['checked'] = false;
      }
    }

    this.closeModal(close);
  }

  selcetAllDevices(event) {
    this.deviceModelsList.map(device => {
      device.selected = event.checked;
    });
    this.checkAllSelectdOrNotForDevices();
  }
  selectSingleOne(event, model) {
    return (model.selected = event.checked);
  }


  installWithVersion(event, gridData) {
    this.event['modals'] = event.deviceModelRepresentations;
    this.event['installVersionId'] = gridData.id;
    this.hideListTable = false;
    this.installSoftware(event);
  }

  /**
   *  Install Software
   */
  installSoftware(event, value?) {
    this.event = event;
    this.diffDays = "";
    this.selectedDeviceNames = [];
    this.installSoftwareFormBlock();
    if (!value) {
      this.hideTable();
    }
    this.selectedDeviceIds = [];
    this.isInstallSoftware = !this.isInstallSoftware;
    this.isCreateNew = false;
    this.scheduleType = false;
    this.isEdit = false;
    this.isversionView = false;
    this.isView = false;
    this.isNewVersion = false;
    if (event.modals) {
      this.installModels = event.modals.map(element => {
        element['indeterminate'] = false;
        element['checked'] = false;
        return element;
      });
    } else {
      this.installModels = [];
    }
    if (this.deviceModelsList && this.deviceModelsList.length > 0) {
      this.deviceModelsList.map(element => {
        element['selected'] = false;
        element['checked'] = false;
        return element;
      });
    }
    this.installSoftwareDetails = event;
    if (this.installSoftwareDetails && this.installSoftwareDetails && this.installSoftwareDetails.versions && this.installSoftwareDetails.versions.length > 0) {
      if (this.event && this.event.installVersionId) {
        const selcetedInstallIds = this.installSoftwareDetails.versions.filter(install => {
          return install.id === this.event.installVersionId;
        });
        if (selcetedInstallIds && selcetedInstallIds.length > 0) {
          this.event['installversionNumber'] = selcetedInstallIds[0].number;
        }
      }
    }
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = this.domainParams;
    }
    this.firmwareService.getDefaultTimeZones(params).subscribe(result => {
      const res = result.data ? result.data : [];
      this.zones = res;
      this.spinnerEnd();
    },
      error => {
        this.displayErrorMsg(error);
      });
  }

  /**
   * Get device associate model
   */
  getDeviceDetailsAssociatedWithDeviceModel(req) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = this.domainParams;
      req['domainName']=this.domainParams.name;
    }
    this.firmwareService.getDeviceDetailsAssociatedWithDeviceModel(req, params).subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        const res = result;
        this.deviceModelsList = res.deviceRepresentationInfo.map(device => {
          const deviceArray = device.status.terminal.split('.');
          device.status = deviceArray[1];
          if (this.selectedDeviceIds.includes(device.deviceDescription.deviceId)) {
            device.selected = true;
          } else {
            device.selected = false;
          }
          return device;
        });
        this.deviceModelsListCount = res.totalCount;
        this.selectAllDevices = this.deviceModelsList.every(device => {
          return device.selected === true;
        });
        this.notSelectAnyDevices = this.deviceModelsList.every(device => {
          return device.selected !== true;
        });
      },
      error => {
        this.displayErrorMsg(error);
      }
    );
  }

  /**
   * Install Form Block
   */
  installSoftwareFormBlock() {
    this.installSoftwareForm = this.fb.group({
      modal: [''],
      targetDevices: 'All',
      campaignRetries: ['3'],
      campaignPriority: 'REGULAR',
      successMessage: '',
      failureMessage: '',
      isDraft: false,
      isServerInitiated: false,
      serverInitiatedInTimeZone: 'Asia/Kolkata',//Default India
      serverInitiatedFromTime: '',
      serverInitiatedToTime: '',
      campaignStartTime: '',
      campaignEndTime: '',
      downloadFromTime: '',
      downloadToTime: '',
      networkUsage: '',
      wifiExpirationDate: '',
      wifiExpirationTime: '',
      Quota: '',
      Timeframe: '',
      quotaType: '',
      timeFrameType: ''
    });
  }

  /**
   * Get Device Model
   */
  getDeviceModels(page) {
    this.currentPageOfDeviceModal = page;
    const req = {
      deviceModelNames: this.selectedDeviceModal,
      limit: 5,
      offset: (page - 1) * 5
    };
    this.getDeviceDetailsAssociatedWithDeviceModel(req);
  }

  /**
   * Change Platform selected value
   */
  changePlatform(event) {
    this.platformSelection = "";
    this.firmwareDeviceListData = [];
    this.deviceVendorDataList = [];
    this.createNewFirmwareForm.patchValue({ deviceVendor: '' });
    this.createNewFirmwareForm.patchValue({ deviceModel: '' });
    if (event.value !== undefined) {
      this.serverPlatformsList.forEach(platform => {
        if (platform.id === event.value) {
          this.platformSelection = platform.platformName;
        }
      });
      //this.getDeviceVendorModal(event.value);
      this.getFirmwareDeviceModal(event.value);
    }
  }

  /**
   * Edit Firmware
   */
  editData(event, name) {
    this.spinnerStar();
    let editData = this.event;
    this.hideListTable = true;
    this.isInstallSoftware = false;
    this.isCreateNew = false;
    this.isView = false;
    this.isNewVersion = false;
    this.isEdit = true;
    this.isversionView = false;
    this.testingStatus = FirmwareEnumService.TESTING_STATUS;
    this.testingTool = FirmwareEnumService.TESTING_TOOL;
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = this.domainParams;
    }
    const id = this.event && this.event.firmwareId ? encodeURIComponent(this.event.firmwareId) : this.event.id;
    this.firmwareService.firmwareByVersion(id, name, params).subscribe(result => {
      this.spinnerEnd();
      const res = result;
      this.event = res;
      if (res && res.deviceModel) {
        this.event['devicemodel'] = res.deviceModel.modelName + ' ' + res.deviceModel.modelVendor + ' ' + res.deviceModel.modelName;
      }
      if (this.event && this.event.status) {
        const splitStatus = this.event.status.split(".");
        if (splitStatus && splitStatus.length > 0) {
          this.event['testingStatus'] = splitStatus[1] ? splitStatus[1] : '';
        }
      }
      this.event['platform'] = editData && editData.vendor ? editData.vendor : '-';
      this.event['firmwarename'] = editData && editData.name ? editData.name : '-';
      this.event['vendor'] = editData.vendor;
      this.event['description'] = this.event.description;
      this.event['esttimeInSec'] = this.event.estimatedUpdateTime;
      this.event['releaseNotes'] = this.event.releaseNotes;
      this.event['versionNumber'] = this.event.versionNumber;
      this.event['status'] = editData && editData.status ? editData.status : '';
      this.event['toolVersion'] = FirmwareEnumService.TESTING_TOOL[0].name;
      this.event['versionName'] = this.event.name;
      this.event['deviceModelRepresentations'] = editData && editData.deviceModelRepresentations
        ? editData.deviceModelRepresentations : '-';
      this.event['firmwareId'] = editData.firmwareId ? editData.firmwareId : editData.id;
      this.createFirmwareVersionFormBlock(this.event);
    }, error => {
      this.displayErrorMsg(error);
    });
    this.event['name'] = editData.name;
    this.event['testingStatus'] = editData.status;
    this.event['deviceVendor'] = '';
    this.event['versionName'] = event.name;
    this.event['versionNumber'] = event.versionNumber;
    this.event['toolVersion'] = FirmwareEnumService.TESTING_TOOL[0].name;
  }

  /**
   * Add New Version
   */
  addNewVersion(event) {
    this.isInstallSoftware = false;
    this.isCreateNew = false;
    this.isEdit = false;
    this.isversionView = false;
    this.isNewVersion = true;
    this.isView = !this.isView;
    this.testingStatus = FirmwareEnumService.TESTING_STATUS;
    this.testingTool = FirmwareEnumService.TESTING_TOOL;
    event.testingStatus = this.event && this.event.status ? this.event.status : '';
    this.createFirmwareVersionFormBlock(event);
  }

  /***
   * Upload File
   */
  fileEvent($event) {
    this.uploadedFile = $event.target.files[0];
    this.uploadedFileName = this.uploadedFile.name;
    const dotPos = this.uploadedFile.name.lastIndexOf('.');
    if (this.uploadedFile.name.lastIndexOf('.') > 0) {
      this.fileExtension = this.uploadedFile.name.substring(
        dotPos + 1,
        this.uploadedFile.name.length
      );
    }
    if (this.fileExtension.toLowerCase() === 'zip') {
      this.createNewVersionFirmwareForm.controls.uploadFile.setValue(
        this.uploadedFileName
      );
      this.fileSubmitReq = new FormData();
      this.fileSubmitReq.append('file', this.uploadedFile);
    }
  }

  openDevicesModel(event, data) {
    if (event.checked) {
      this.selectedDeviceModal = [];
      this.selectedDeviceModal.push(data.name);
      const selcetedDevicesIds = this.selectedDeviceNames.filter(selectedDevice => {
        return selectedDevice.model === data.name;
      });
      this.selectedDevicesCount = selcetedDevicesIds.length;
      this.deviceModelsList = [];
      this.openModal(this.devicesTemplate, 'lg');
      this.getDeviceModels(1);
    } else {

    }

  }

  /**
   * Update irmware
   */
  updateFirmware() {
    this.spinnerStar();
    let EnterpriseId = [];
    let req = {};
    req['shortDescription'] = encodeURIComponent(this.createNewVersionFirmwareForm.controls.description.value);
    req['longDescription'] = encodeURIComponent(this.createNewVersionFirmwareForm.controls.longDescription.value);
    req['estimatedUpdateTime'] = this.createNewVersionFirmwareForm.controls.esttimeInSec.value;
    req['firmwareName'] = this.event && this.event.firmwarename ? encodeURIComponent(this.event.firmwarename) : encodeURIComponent(this.event.name);
    req['versionName'] = encodeURIComponent(this.createNewVersionFirmwareForm.controls.versionName.value);
    req['versionNumber'] = this.event && this.event.versionNumber ? this.event.versionNumber : '';
    req['updateVersionNo'] = this.createNewVersionFirmwareForm.controls.versionNumber.value;
    req['releaseNotes'] = encodeURIComponent(this.createNewVersionFirmwareForm.controls.releaseNotes.value);
    req['status'] = 'ComponentVersionStatus.' + this.createNewVersionFirmwareForm.controls.testingStatus.value;
    this.domainParams = this.HeaderService.getSelectedDomain();
    if (this.domainParams) {
      req['domain'] = { domainId: this.domainParams.id, domainName: this.domainParams.name };
    };
    const oldVersionNumber = this.event.versionNumber ? this.event.versionNumber : '';
    this.firmwareService.updateVersionFirmware(req, encodeURIComponent(this.event.firmwareId), oldVersionNumber).subscribe(
      result => {
        this.spinnerEnd();
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Version Update successfully'
        });
        this.hideTable();
        this.router
          .navigateByUrl('../main', { skipLocationChange: true })
          .then(() => this.router.navigate(['../main/psfirm']));
      },
      error => {
        this.displayErrorMsg(error);
      }
    );
  }
  /**
   * upload new version
   */
  uploadFileData() {
    this.spinnerStar();
    // this.fileSubmitReq.append(
    //   'longDescription', this.createNewVersionFirmwareForm.controls.longDescription.value
    // );
    this.domainParams = this.HeaderService.getSelectedDomain();

    // this.fileSubmitReq.append(
    //   'domainId', this.domainParams.id
    // );
    const requestParams = {
      domainName: this.domainParams.name,
      id: this.event && this.event.firmwareId ? encodeURIComponent(this.event.firmwareId) : this.event && this.event.id ? encodeURIComponent(this.event.id) : '',
      domainId: this.domainParams.id,
      status: 'ComponentVersionStatus.' + this.createNewVersionFirmwareForm.controls.testingStatus.value,
      versionName: encodeURIComponent(this.createNewVersionFirmwareForm.controls.versionName.value),
      versionNumber: this.createNewVersionFirmwareForm.controls.versionNumber.value,
      estimatedUpdateTime: this.createNewVersionFirmwareForm.controls.esttimeInSec.value,
      releaseNotes: encodeURIComponent(this.createNewVersionFirmwareForm.controls.releaseNotes.value),
      shortDescription: encodeURIComponent(this.createNewVersionFirmwareForm.controls.description.value)
    }
    this.firmwareService.uploadNewVersionData(this.fileSubmitReq, this.isNewVersion, requestParams).subscribe(
      result => {
        this.spinnerEnd();
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Version Created successfully'
        });
        this.hideTable();
        this.router
          .navigateByUrl('../main', { skipLocationChange: true })
          .then(() => this.router.navigate(['../main/psfirm']));

      },
      error => {
        this.fileSubmitReq = new FormData();
        this.fileSubmitReq.append('file', this.uploadedFile);
        this.displayErrorMsg(error);
      }
    );
  }

  /**
   * View Version Data
   */
  viewVersionDetails(event, name) {
    let eventData = this.event;
    this.hideListTable = false;
    this.hideTable();
    this.isInstallSoftware = false;
    this.isCreateNew = false;
    this.isEdit = false;
    this.isversionView = true;
    this.isNewVersion = false;
    this.isView = false;
    let params = {};
    if (this.domainParams) {
      params = this.domainParams;
    }
    this.spinnerStar();
    this.firmwareService.firmwareByVersion(encodeURIComponent(this.event.id), name, params).subscribe(result => {
      this.spinnerEnd();
      const res = result;
      this.event = res;
      if (res && res.deviceModel) {
        this.event['devicemodel'] = res.deviceModel.modelName + ' ' + res.deviceModel.modelVendor + ' ' + res.deviceModel.modelName;
      }
      if (this.event && this.event.status) {
        const splitStatus = this.event.status.split(".");
        if (splitStatus && splitStatus.length > 0) {
          this.event['status'] = splitStatus[1] ? splitStatus[1] : '';
        }
      }
      this.event['platform'] = eventData && eventData.vendor ? eventData.vendor : '-';
      //this.event['status'] = eventData && eventData.status ? eventData.status : '';
      this.event['firmwarename'] = eventData && eventData.name ? eventData.name : '-';
      this.event['vendor'] = eventData.vendor;
      this.event['deviceModelRepresentations'] = eventData && eventData.deviceModelRepresentations ? eventData.deviceModelRepresentations : '-';
      this.createFirmwareVersionFormBlock(event);
    }, error => {
      this.displayErrorMsg(error);
    });
  }

  /**
   * View Firmware
   */
  viewData(event) {
    this.event = event;
    this.event['firmwareId'] = event.id;
    this.hideTable();
    this.isInstallSoftware = false;
    this.isCreateNew = false;
    this.isEdit = false;
    this.isversionView = false;
    this.isNewVersion = false;
    this.isView = !this.isView;
    this.createFirmwareVersionFormBlock(event);
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = { domain: this.domainParams };
    }
    const firmwareId = { id: encodeURIComponent(event.name) };
    this.firmwareService.firmwareByID(firmwareId, params).subscribe(result => {
      const res = result && result.data && result.data.items && result.data.items.length > 0 ? result.data.items[0] : '';
      this.event = res;
      this.spinnerEnd();
      if (res) {
        const deviceArr = [];
        const deviceModelsView = deviceArr.toString();
        this.event['name'] = res.name;
        this.event['vendor'] = res.vendor;
        this.event['platform'] = res.platform && res.platform.platformName ? res.platform.platformName : event.platform.platformName;
        this.event['deviceModelRepresentations'] = [{ vendor: res.deviceModel.modelVendor, name: res.deviceModel.modelName }];
        this.event['devicemodel'] = deviceModelsView.replace(/,/g, "\n");
        this.event['platform'] = event.platform && event.platform.platformName ? event.platform.platformName : '';;
        this.event['status'] = event.status ? event.status : '';
        this.event['firmwarename'] = event.name ? event.name : '-';
        this.event['firmwareId'] = event.id;
      }
    }, error => {
      this.displayErrorMsg(error);
    });

  }

  /**
  * Suceess Case
  */
  successCase(result) {
    this.spinnerService.toggleSpinner(0);
    if (
      result.status === 200 ||
      result.status === 201 ||
      result.status === 202
    ) {
      return result.body.data || result.body;
    }
  }

  /**
   * Delete Firmware
   */
  deleteFirmwareData(close) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = { domainId: this.domainParams.id, domainName: this.domainParams.name, id: encodeURIComponent(this.event.id) };
    }
    this.spinnerStar();
    this.firmwareService.deleteFirmware(params).subscribe(result => {
      this.spinnerEnd();
      this.dataService.broadcast('alert', {
        type: 'success',
        message: 'Delete successfully'
      });
      this.hideTable();
      this.router
        .navigateByUrl('../main', { skipLocationChange: true })
        .then(() => this.router.navigate(['../main/psfirm']));
      this.closeModal(close);
    },
      error => {
        this.displayErrorMsg(error);
      });
  }

  /**
   * Delete Firmware Version
   */
  deleteFirmwareVersionData(close) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    const _req = { id: encodeURIComponent(this.event.firmwareId), versionNumber: this.event.versionNumber, domainName: this.domainParams.name };
    this.spinnerStar();
    this.firmwareService.deleteFirmwareVersion(_req).subscribe(result => {
      this.spinnerEnd();
      this.dataService.broadcast('alert', {
        type: 'success',
        message: 'Delete successfully'
      });
      this.hideTable();
      this.router
        .navigateByUrl('../main', { skipLocationChange: true })
        .then(() => this.router.navigate(['../main/psfirm']));
      this.closeModal(close);
    },
      error => {
        this.displayErrorMsg(error);
      });
  }

  /**
   * Get Plat Form
   */
  getPlatforms() {
    let params = {};
    this.domainParams = this.HeaderService.getSelectedDomain();
    if (this.domainParams && this.domainParams.id && this.domainParams.name) {
      params = { id: this.domainParams.id, name: this.domainParams.name }
    }
    this.firmwareService.getPlatforms(params).subscribe(
      result => {
        if (result) {
          if (result.data && result.data.platforms) {
            this.serverPlatformsList = result.data.platforms;
            this.platformList = [];
            this.serverPlatformsList.forEach(platform => {
              this.platformList.push({
                platformName: platform.name,
                platformId: platform.id
              });
            });
          }
        }
      },
      error => {
        this.displayErrorMsg(error);
      }
    );
  }

  /**
   * Get Device Vendor MOdal
   */
  getDeviceVendorModal(value) {
    this.firmwareService.getDeviceVendorModal(value).subscribe(
      result => {
        if (result) {
          const data = result && result.data ? result.data : '';
          if (data && data.domain) {
            this.deviceVendorList = data.domain;
            this.deviceVendorDataList = [];
            this.deviceVendorList.forEach(vendor => {
              this.deviceVendorDataList.push({
                name: vendor.name,
                id: vendor.id
              });
            });
          }
        }
      },
      error => {
        this.displayErrorMsg(error);
      }
    );
  }

  /**
   * Get FirmWare Device Modal
   */
  getFirmwareDeviceModal(value) {
    let params = {};
    this.domainParams = this.HeaderService.getSelectedDomain();
    if (this.domainParams && this.domainParams.id && this.domainParams.name) {
      params = { id: this.domainParams.id, name: this.domainParams.name }
    }
    this.firmwareService.getFirmwareDeviceModal(value, params).subscribe(
      result => {
        this.spinnerEnd();
        if (result) {
          const data = result && result.data ? result.data : '';
          if (data && data.deviceModelRepresentation) {
            this.firmwareDeviceList = data.deviceModelRepresentation;
            this.deviceVendorList = data.deviceModelRepresentation;
            this.firmwareDeviceListData = [];
            this.deviceVendorDataList = [];
            this.firmwareDeviceList.forEach(model => {
              this.firmwareDeviceListData.push({
                modelName: model.name,
                modelId: model.id,
                modelVendor: model.vendor
              });
            });
            this.deviceVendorList.forEach(vendor => {
              this.deviceVendorDataList.push({
                name: vendor.vendor,
                id: vendor.id
              });
            });
          }
        }
      },
      error => {
        this.displayErrorMsg(error);
      }
    );
  }

  /**
   * Submit Form
   */
  submitForm(form, button) {
    if (button === 'update') {
      this.createNewVersionFirmwareForm.get('uploadFile').clearValidators();
      this.createNewVersionFirmwareForm.get('uploadFile').updateValueAndValidity();
    }
    if (form.valid) {
      this.searchFilter = "";
      if (button === 'save') {
        if (this.isCreateNew) {
          this.saveFirmware();
        } else {
          this.hideTable();
          this.router
            .navigateByUrl('../main', { skipLocationChange: true })
            .then(() => this.router.navigate(['../main/psfirm']));
        }
      }
      else if (button === 'saveversion') {
        this.uploadFileData();
      }
      else if (button === 'update') {
        this.updateFirmware();
      } else if (button === 'execute' || button === 'executeSave') {
        this.installSoftwareWithDevices(button);
        // } else if (button === 'openModal') {
        //   this.getModalsData();
        // } else if (button === 'openEnterpriseModal') {
        //   this.openEnterpriseModal();
        // }
      }
    } else {
      this.cms.validateAllFormFields(form);
    }
  }

  /**
   * Save Firmware
   */
  saveFirmware() {
    let req = {};
    let enterpriseId = [];
    this.spinnerStar();
    if (this.isCreateNew) {
      req['firmwareName'] = this.createNewFirmwareForm.controls.firmwareName &&
        this.createNewFirmwareForm.controls.firmwareName.value ?
        this.createNewFirmwareForm.controls.firmwareName.value : '';
      req['firmwareVendor'] = this.createNewFirmwareForm.controls.firmwareVendor &&
        this.createNewFirmwareForm.controls.firmwareVendor.value ?
        this.createNewFirmwareForm.controls.firmwareVendor.value : '';
        if (this.createNewFirmwareForm.controls.enterpriseIds && this.createNewFirmwareForm.controls.enterpriseIds.value
          && this.createNewFirmwareForm.controls.enterpriseIds.value.length > 0) {
          this.createNewFirmwareForm.controls.enterpriseIds.value.forEach(element => {
            enterpriseId.push({ "id": element.hqBpId, "name": element.hqBpName });
          });
        }
      req['enterpriseIds'] = enterpriseId;
      if (this.createNewFirmwareForm.controls.deviceModel && this.createNewFirmwareForm.controls.deviceModel.value) {
        let device = this.firmwareDeviceListData.filter(value => value.modelId === this.createNewFirmwareForm.controls.deviceModel.value);
        if (device && device.length > 0) {
          req['deviceModel'] = {
            "modelName": device[0].modelName,
            "modelId": device[0].modelId,
            "modelVendor": device[0].modelVendor
          }
        }
      }

      this.domainParams = this.HeaderService.getSelectedDomain();
      if (this.domainParams) {
        req['domain'] = {
          "name": this.domainParams.name,
          "id": this.domainParams.id
        }
      }
      if (this.createNewFirmwareForm.controls.platform && this.createNewFirmwareForm.controls.platform.value) {
        let platform = this.platformList.filter(value => value.platformId === this.createNewFirmwareForm.controls.platform.value);
        if (platform && platform.length > 0) {
          req['platform'] = {
            "platformName": platform[0].platformName,
            "platformId": platform[0].platformId
          }
        }
      }
    }
    this.firmwareService.saveFirmware(req).subscribe(
      result => {
        this.spinnerEnd();
        this.hideTable();
        this.router
          .navigateByUrl('../main', { skipLocationChange: true })
          .then(() => this.router.navigate(['../main/psfirm']));
      },
      error => {
        this.displayErrorMsg(error);
      }
    );


  }

  /**
   * Failure Case
   */
  failureCase(error) {
    this.spinnerService.toggleSpinner(0);
    this.spinnerEnd();
    // this.dataService.broadcast('alert', {
    //   type: 'danger',
    //   message: error && error.error ? error.error.errorDetails : 'Network error please try again'
    // });
  }

  displayErrorMsg(error) {
    this.spinnerService.toggleSpinner(0);
    this.spinnerEnd();
    this.dataService.broadcast('alert', {
      type: 'danger',
      message: error
        && error.error
        && error.error.errorDetails ? error.error.errorDetails :
        error ? error : 'Network error please try again'
    });
  }

  /**
   * Spinner Start
   */
  spinnerStar() {
    this.spinnerService.toggleSpinner(1);
  }

  /**
  * Spinner End
  */
  spinnerEnd() {
    this.spinnerService.toggleSpinner(0);
  }

  /**
  * Get EnterPrise Ids
  */
  getEnterPriseId(page?) {
    this.spinnerEnd();
    let obj;
    if (page) {
      let pageOffset = this.pageSize * 200;
      this.pageSize = this.pageSize + 1;
      obj = { limit: 200, offset: pageOffset, page: this.pageSize, pageNum: this.pageSize, rpp: 200 };
    } else {
      obj = { limit: 200, offset: 0, page: 1, pageNum: 1, rpp: 200 };
    }
    const totalEnterPriseCount = this.firmwareService.getTotalCountEnterprises();
    const totalEnterpriseResult = this.firmwareService.getVendorList(obj);
    this.selectedEnterpriseCount = 0;
    forkJoin([totalEnterPriseCount, totalEnterpriseResult]).subscribe(results => {
      this.spinnerEnd();
      if (results[1] && results[1].data && results[1].data.length > 0) {
        this.enterpriseIdsArray = this.enterpriseIdsArray.concat(results[1].data);
        this.enterpriseIdsArray.forEach(element => {
          if (this.selectedEnterpriseList && this.selectedEnterpriseList.length > 0) {
            this.selectedEnterpriseList.forEach(inneerElement => {
              if (element.hqBpId == inneerElement.hqBpId) {
                element['isCheck'] = true;
              }
            });
          }
        });
      }
    }, error => {
      this.enterpriseIdsArray = [];
      this.failureCase(error);
    });

  }


  /**
   * Hide Table
   */
  hideTable() {
    this.hideListTable = !this.hideListTable;
    if (!this.hideListTable) {
      this.isInstallSoftware = false;
      this.isCreateNew = false;
      this.isView = false;
      this.isEdit = false;
      this.isversionView = false;
      this.packageId = false;
      this.isNewVersion = false;
    }
  }



  /**
   * Form Group create New Version
   */
  createFirmwareVersionFormBlock(event) {
    this.createNewVersionFirmwareForm = this.fb.group({
      testingStatus: [event && event.testingStatus ? event.testingStatus : '', Validators.required],
      versionName: [event && event.versionName ? event.versionName : '', Validators.required],
      versionNumber: [event && event.versionNumber ? event.versionNumber : '',
      [
        Validators.required,
        Validators.min(1)
      ]],
      toolVersion: event && event.toolVersion ? event.toolVersion : '',
      description: [event && event.description ? event.description : ''],
      esttimeInSec: [event && event.esttimeInSec ? event.esttimeInSec : '', Validators.min(1)],
      longDescription: [event && event.longDescription ? event.longDescription : ''],
      releaseNotes: [event && event.releaseNotes ? event.releaseNotes : ''],
      uploadFile: [event && event.uploadFile ? event.uploadFile : '', Validators.required],
    });
  }

  /**
   * Form Group
   */
  createFirmwareFormBlock(event) {
    if (this.isView || this.isEdit) {
      let enterpriseIdsArr = [];
      if (this.enterpriseIdsArray.length > 0 && event.enterpriseIds && event.enterpriseIds.length > 0) {
        this.enterpriseIdsArray.forEach(value => {
          event.enterpriseIds.forEach(enterPriseId => {
            if (value.id === enterPriseId) {
              enterpriseIdsArr.push(value.hqBpName);
            }
          });
        })
      }
      this.viewenterpriseIds = enterpriseIdsArr;
    }
    this.createNewFirmwareForm = this.fb.group({
      firmwareName: [event && event.name ? event.name : '', Validators.required],
      firmwareVendor: [event && event.firmwareVendor ? event.firmwareVendor : '', Validators.required],
      platform: [event && event.platform ? event.platform : '', Validators.required],
      deviceVendor: [event && event.deviceVendor ? event.deviceVendor : '', Validators.required],
      deviceModel: [event && event.deviceModel ? event.deviceModel : '', Validators.required],
      enterpriseIds: [event && event.enterpriseIds ? event.enterpriseIds : '', Validators.required]
    });
  }

  /**
   * Add New Firmware
   */
  addNewFirmware(event) {
    this.platformSelection = "";
    this.createFirmwareFormBlock(event);
    this.hideTable();
    this.isCreateNew = !this.isCreateNew;
    this.isInstallSoftware = false;
    this.isEdit = false;
    this.isversionView = false;
    this.isView = false;
    this.enterpriseIdsArray = [];
    this.filterSearch = '';
    this.showEnterpriseList = false;
    this.selectedEnterpriseList = [];
    this.pageSize = 1;
    this.getEnterPriseId();
  }
  getEmptyData(obj) {
    this.data = {
      page: 1,
      total: 1,
      data: []
    };
  }

  /*
  ** Get Firmware Data
  **/
  getData(obj) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    this.spinnerStar();
    let params = {};
    if (this.domainParams) {
      params = {
        "limit": obj.limit, "offset": obj.offset,
        domains: this.domainParams.name
      };
    } else {
      params = { "limit": obj.limit, "offset": obj.offset }
    }
    this.firmwareService.getFirmwareDetails(params).subscribe(
      result => {
        this.spinnerEnd();
        const res = this.successCase(result);
        let packages = [];
        if (res && res.items && res.items.length > 0) {
          packages = res.items.map(data => {
            data.status = "";
            if (data.versions && data.versions.length > 0) {
              const splitStatus = data.versions[0].status ? data.versions[0].status.split(".") : '';
              if (splitStatus && splitStatus.length > 0) {
                data.status = splitStatus[1] ? splitStatus[1] : '';
              }
            }
            let deviceModel = [];
            data.vendor = data.platform && data.platform.platformName ? data.platform.platformName : '';
            if (data.versions && data.versions.length > 0) {
              data.versionNames = data.versions[data.versions.length - 1].name + ((data.versions && data.versions.length > 1) ? '(+' + (data.versions.length - 1) + ')' : '');
            } else {
              data.versionNames = "";
            }
            if (data.deviceModel) {
              // deviceModel.push({ name: data.deviceModel.modelName, vendor: data.deviceModel.modelVendor });
              deviceModel.push({ name: data.deviceModel.modelName });
            }
            data.modals = deviceModel;
            data.description = data.versions && data.versions.length > 0 ?
              data.versions && data.versions[0].shortDescription : '';
            data.domain = data.domain.name;
            return data;
          });
        }
        this.data = {
          page: obj.page,
          total: res.totalCount,
          data: packages
        };
      },
      error => {
        this.data = {
          page: 1,
          total: 1,
          data: []
        };
        this.displayErrorMsg(error);
      }
    );
  }

  /**
   * Get Firmware Search Data
   */
  getDataBySearch(data) {
    this.spinnerStar();
    let obj;
    obj = this.firmwareService.getObject(data);
    obj.limit = 10;
    obj.offset = 0;
    if (this.domainParams) {
      obj.domains = this.domainParams.name;
    }
    this.firmwareService.getFirmwareDetails(obj).subscribe(
      result => {
        this.spinnerEnd();
        const res = this.successCase(result);
        let packages = [];
        if (res && res.items && res.items.length > 0) {
          packages = res.items.map(data => {
            data.status = "";
            if (data.versions && data.versions.length > 0) {
              const splitStatus = data.versions[0].status ? data.versions[0].status.split(".") : '';
              if (splitStatus && splitStatus.length > 0) {
                data.status = splitStatus[1] ? splitStatus[1] : '';
              }
            }
            let deviceModel = [];
            data.vendor = data.platform && data.platform.platformName ? data.platform.platformName : '';
            if (data.versions && data.versions.length > 0) {
              data.versionNames = data.versions[data.versions.length - 1].name + ((data.versions && data.versions.length > 1) ? '(+' + (data.versions.length - 1) + ')' : '');
            } else {
              data.versionNames = "";
            }

            if (data.deviceModel) {
              //deviceModel.push({ name: data.deviceModel.modelName, vendor: data.deviceModel.modelVendor });
              deviceModel.push({ name: data.deviceModel.modelName });
            }
            data.modals = deviceModel;
            data.description = data.versions && data.versions.length > 0 ?
              data.versions && data.versions[0].shortDescription : '';
            data.domain = data.domain.name;
            return data;
          });
        }
        this.data = {
          page: obj.page,
          total: res.totalCount,
          data: packages
        };

      },
      error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.displayErrorMsg(error);
      }
    );
  }

  setStartTime(event) {
    this.startTime = event;
  }

  setEndTime(event) {
    this.endTime = event;
  }

  checkAllSelectdOrNotForDevices() {
    this.deviceModelsList.forEach(device => {
      if (device.selected) {
        if (!this.selectedDeviceIds.includes(device.deviceDescription.deviceId)) {
          this.selectedDevicesCount++;
          this.selectedDeviceIds.push(device.deviceDescription.deviceId);
          this.selectedDeviceNames.push({ model: device.deviceDescription.model, id: device.deviceDescription.deviceId });
        }
      } else {
        if (this.selectedDeviceIds.includes(device.deviceDescription.deviceId)) {
          this.selectedDevicesCount--;
          const index = this.selectedDeviceIds.indexOf(device.deviceDescription.deviceId);
          const deviceNameIndex = this.selectedDeviceNames.findIndex(selectedDevice => selectedDevice.id === device.deviceDescription.deviceId);
          this.selectedDeviceIds.splice(index, 1);
          this.selectedDeviceNames.splice(deviceNameIndex, 1);
        }
      }
    });
    this.selectAllDevices = this.deviceModelsList.every(device => {
      return device.selected === true;
    });
    this.notSelectAnyDevices = this.deviceModelsList.every(device => {
      return device.selected !== true;
    });
  }


  installSoftwareWithDevices(button) {
    let installversionNumber = 0;
    if (this.event && this.event.installversionNumber) {
      installversionNumber = this.event.installversionNumber;
    } else if (this.installSoftwareDetails && this.installSoftwareDetails.versions &&
      this.installSoftwareDetails.versions.length > 0) {
      installversionNumber = this.installSoftwareDetails.versions[this.installSoftwareDetails.versions.length - 1].number;
    }
    const req = {
      deviceIds: this.selectedDeviceIds,
      firmwares: [
        {
          id: this.installSoftwareDetails.id,
          versionNumber: installversionNumber
        }
      ],

      isDraft: (button == 'executeSave' ? true : false),

      description: 'FirmwareInstall_' + this.event.domain + '_' + this.dataService.getParseAndAtob('loginMember') + '_' + new Date()
    };
    if (this.installSoftwareForm.value.isServerInitiated == 'None') {
      req['isServerInitiated'] = false;
    }
    if (this.installSoftwareForm.value.isServerInitiated == 'immediate') {
      req['isServerInitiated'] = true;
    }

    if (this.installSoftwareForm.value.isServerInitiated == 'scheduled') {
      req['isServerInitiated'] = true;
      req['serverInitiatedInTimeZone'] = this.installSoftwareForm.value.serverInitiatedInTimeZone;
      req['serverInitiatedFromTime'] = this.installSoftwareForm.value.serverInitiatedFromTime ? this.cms.convertTime12to24(this.installSoftwareForm.value.serverInitiatedFromTime) : '';
      req['serverInitiatedToTime'] = this.installSoftwareForm.value.serverInitiatedToTime ? this.cms.convertTime12to24(this.installSoftwareForm.value.serverInitiatedToTime) : '';
    }

    if (this.installSoftwareForm.value.campaignRetries) {
      req['campaignRetries'] = this.installSoftwareForm.value.campaignRetries;
    }


    if (this.installSoftwareForm.value.campaignPriority) {
      req['campaignPriority'] = this.installSoftwareForm.value.campaignPriority;
    }

    if (this.installSoftwareForm.value.successMessage) {
      req['successMessage'] = this.installSoftwareForm.value.successMessage;
    }
    if (this.installSoftwareForm.value.failureMessage) {

      req['failureMessage'] = this.installSoftwareForm.value.failureMessage;
    }

    if (this.installSoftwareForm.value.campaignStartTime) {
      req['campaignStartTime'] = this.cms.getEpochTimeForInstallStartDayAndTime(this.installSoftwareForm.value.campaignStartTime, this.startTime);
    }

    if (this.installSoftwareForm.value.campaignEndTime) {
      req['campaignEndTime'] = this.cms.getEpochTimeForInstallStartDayAndTime(this.installSoftwareForm.value.campaignEndTime, this.endTime);
    }
    if (this.installSoftwareForm.value.downloadFromTime) {
      req['downloadFromTime'] = this.cms.convertTime12to24(this.installSoftwareForm.value.downloadFromTime);
    }
    if (this.installSoftwareForm.value.downloadToTime) {
      req['downloadToTime'] = this.cms.convertTime12to24(this.installSoftwareForm.value.downloadToTime);
    }
    if (this.installSoftwareForm.value.networkUsage) {
      req['networkUsage'] = this.installSoftwareForm.value.networkUsage;
    }
    if (this.installSoftwareForm.value.wifiExpirationDate) {
      req['wifiExpirationDate'] = this.cms.getEpochTimeForInstallStartDay(this.installSoftwareForm.value.wifiExpirationDate);
      if (this.installSoftwareForm.value.wifiExpirationTime) {
        let dateTimeepoch = this.cms.getEpochFromDateAndTime(this.installSoftwareForm.value.wifiExpirationDate, this.installSoftwareForm.value.wifiExpirationTime);
        req['wifiExpirationDate'] = dateTimeepoch;
      }
    }
    if (this.installSoftwareForm.value.Quota) {
      if (this.installSoftwareForm.value.quotaType == 'MB') {
        req['Quota'] = this.installSoftwareForm.value.Quota * 1024;
      } else {
        req['Quota'] = this.installSoftwareForm.value.Quota;
      }

    }
    if (this.installSoftwareForm.value.Timeframe) {

      if (this.installSoftwareForm.value.timeFrameType == 'hours') {
        req['Timeframe'] = this.installSoftwareForm.value.Timeframe * 60;
      } else {
        req['Timeframe'] = this.installSoftwareForm.value.Timeframe;
      }
    }
    if (this.domainParams) {
      req['domain'] = this.domainParams;
    }
    this.spinnerStar();
    this.firmwareService.installSoftwareWithDevices(req).subscribe(
      result => {
        this.spinnerEnd();
        const res = this.successCase(result);
        if (!req.isDraft) {
          this.hideTable();
        } else {
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Saved successfully'
          });
          this.hideTable();
        }
      },
      error => {
        this.displayErrorMsg(error);
        this.spinnerEnd();
      }
    );
  }


  differenceInDays() {
    if (this.installSoftwareForm.value.campaignStartTime && this.installSoftwareForm.value.campaignEndTime) {
      if (new Date(this.installSoftwareForm.value.campaignEndTime) > new Date(this.installSoftwareForm.value.campaignStartTime)) {
        this.diffDays = this.cms.dateDiffIndays(this.installSoftwareForm.value.campaignStartTime, this.installSoftwareForm.value.campaignEndTime)
      } else {
        this.diffDays = "";
      }

    }

  }

  /**
   * Open Model
   */
  openModal(content, size) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal user-onboard',
        size,
        backdrop: 'static',
        keyboard: false
      })
      .result.then(
        result => { },
        reason => { }
      );
  }

  /**
   * Close Model
   */
  closeModal(close) {
    close('Cross click');
  }

  searchWithEnterpriseName(evt) {
    if (evt.target.value) {
      this.filterSearch = evt.target.value;
      const obj = { hqBpName: evt.target.value };
      this.enterpriseIdsArray = [];
      const totalEnterpriseResult = this.firmwareService.getEnterpriseSearchName(obj);
      this.spinnerStar();
      forkJoin([totalEnterpriseResult]).subscribe(results => {
        this.spinnerEnd();
        if (results[0] && results[0].data && results[0].data.length > 0) {
          this.enterpriseIdsArray = results[0].data;
          this.enterpriseIdsArray.forEach(element => {
            if (this.selectedEnterpriseList && this.selectedEnterpriseList.length > 0) {
              this.selectedEnterpriseList.forEach(inneerElement => {
                if (element.hqBpId == inneerElement.hqBpId) {
                  element['isCheck'] = true;
                }
              });
            }
          });
          this.spinnerEnd();
        } else {
          this.spinnerEnd();
        }
      }, error => {
        this.spinnerEnd();
        this.enterpriseIdsArray = [];
      });
    } else {
      this.enterpriseIdsArray = [];
      this.filterSearch = '';
      this.pageSize = 1;
      this.getEnterPriseId();
    }
  }

  showCheckList() {
    this.enterpriseIdsArray.forEach(element => {
      this.selectedEnterpriseList.forEach(inneerElement => {
        if (element.hqBpId == inneerElement.hqBpId) {
          element.isCheck = true;
        }
      });
    });
    // this.filterSearch = '';
    this.showEnterpriseList = !this.showEnterpriseList;
  }

  onItemDeSelect(event) {
    this.enterpriseIdsArray.forEach(element => {
      if (event == element.hqBpId) {
        element.isCheck = false;
      }
    });

    this.selectedEnterpriseList.forEach((element, keyId) => {
      if (event == element.hqBpId) {
        this.selectedEnterpriseList.splice(keyId, 1);
      }
    });
    this.setEnterpriseValue();
  }

  setEnterpriseValue() {
    this.createNewFirmwareForm.patchValue({
      enterpriseIds: this.selectedEnterpriseList,
      firmwareName: this.createNewFirmwareForm.controls['firmwareName'].value,
      firmwareVendor: this.createNewFirmwareForm.controls['firmwareVendor'].value,
      platform: this.createNewFirmwareForm.controls['platform'].value,
      deviceVendor: this.createNewFirmwareForm.controls['deviceVendor'].value,
      deviceModel: this.createNewFirmwareForm.controls['deviceModel'].value,
    });
  }

  closeMultiselectField(event) {
    if (event.target) {
      if (event.target.id !== 'multiselectList' && event.target.id !== 'multiselecthevron') {
        this.showEnterpriseList = false;
      }
    }
  }

  checkEnterprise(event, hqBpId) {
    if (event.checked) {
      this.enterpriseIdsArray.forEach((element, keyId) => {
        if (hqBpId == element.hqBpId) {
          this.enterpriseIdsArray[keyId].isCheck = true;
          this.selectedEnterpriseList.push(element);
        }
      });
    } else {
      this.selectedEnterpriseList.forEach((element, keyId) => {
        if (hqBpId == element.hqBpId) {
          this.enterpriseIdsArray[keyId].isCheck = false;
          this.selectedEnterpriseList.splice(keyId, 1);
        }
      });
    }
    this.setEnterpriseValue();
  }
  fetchMore(event) {
    if (event > 0 && this.filterSearch == '') {
      if (this.enterpriseIdsArray.length == this.pageSize * 200) {
        this.getEnterPriseId(event);
      }
    }
  }
}
