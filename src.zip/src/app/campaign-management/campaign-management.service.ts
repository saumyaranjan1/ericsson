import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';

@Injectable({
  providedIn: 'root'
})
export class CampaignManagementService {

  constructor(private interceptor: InterceptorService) { }

  getCampaignDetails(request) {
    return this.interceptor.httpCallReturn('get', 'getCampaignDetails', request);
  }
  getConfigDetails(request) {
    return this.interceptor.httpCallReturn('get', 'getCampaignConfigDetails', request);
  }
  getAppAutoProvisioning(request) {
    return this.interceptor.httpCallReturn('get', 'getCampaignAppAutoProvisioningDetails', request);
  }
  getConfigAutoProvisioning(request) {
    return this.interceptor.httpCallReturn('get', 'getConfigAutoProvisioning', request);
  }
  getFirmwarAutoCampaign(request) {
    return this.interceptor.httpCallReturn('get', 'getFirmwarAutoCampaign', request);
  }
  getFirmwarenConfigDetails(request) {
    return this.interceptor.httpCallReturn('get', 'getFirmwarenConfigDetails', request);
  }
  getCampaignProvisioningDetails(request) {
    return this.interceptor.httpCallReturn('get', 'getCampaignProvisioningDetails', request);
  }
  getCampaignInfo(request, domainInfo) {
    request['appendValue'] = true;
    request['id'] = request.id;
    let params = {};
    if (domainInfo.id && domainInfo.name) {
      params['extraParams'] = "?campaignId=" + request.id + "&domainId=" + domainInfo.id + "&domainName=" + domainInfo.name;
    } else {
      params['extraParams'] = "?id=" + request.id;
    }
    return this.interceptor.httpCall('get', 'getCampaignInfo', params);
  }
  getConfigCampaignInfo(request, domainInfo) {
    request['appendValue'] = true;
    request['id'] = request.id;
    let params = {};
    if (domainInfo.id && domainInfo.name) {
      params['extraParams'] = "?campaignId=" + request.id + "&domainId=" + domainInfo.id + "&domainName=" + domainInfo.name+"&isAutoCampaign=true";
    } else {
      params['extraParams'] = "?id=" + request.id+"&isAutoCampaign=true";
    }
    return this.interceptor.httpCall('get', 'getConfigCampaignInfo', params);
  }
  getFimrwareCampaignInfo(request, domainInfo) {
    request['appendValue'] = true;
    request['id'] = request.id;
    let params = {};
    if (domainInfo.id && domainInfo.name) {
      params['extraParams'] = "?campaignId=" + request.id + "&domainId=" + domainInfo.id + "&domainName=" + domainInfo.name+"&isAutoCampaign=true";
    } else {
      params['extraParams'] = "?id=" + request.id+"&isAutoCampaign=true";
    }
    return this.interceptor.httpCall('get', 'getFirmwareCampaignInfo', params);
  }
  getAppAutoCampaignInfo(request, domainInfo) {
    request['appendValue'] = true;
    request['id'] = request.id;
    let params = {};
    if (domainInfo.id && domainInfo.name) {
      params['extraParams'] = "?campaignId=" + request.id + "&domainId=" + domainInfo.id + "&domainName=" + domainInfo.name+"&isAutoCampaign=true";
    } else {
      params['extraParams'] = "?id=" + request.id+"&isAutoCampaign=true";
    }
    return this.interceptor.httpCall('get', 'getAppAutoCampaignInfo', params);
  }
  /**
     * Get Domain Info
     */
  getDomainData() {
    let _res = sessionStorage.getItem('domain');
    return JSON.parse(_res);
  }
  getObject(request) {
    const key = request['dropDownValue'].trim();
    const value = request['searchKey'].trim();
    const dataObj = {};
    if (request.dropDownValue.trim() === 'name') {
      dataObj['campaignName'] = new Array(request.searchKey);
    } else if (request.dropDownValue.trim() === 'domain') {
      dataObj['domains'] = new Array(request.searchKey);
    } else if (request.dropDownValue.trim() === 'devicemodel') {
      let deviceSpace = request.searchKey.split(" ");
      let deviceName = "";
      let vendorName = "";
      let deviceModalParams = {};
      if (deviceSpace && deviceSpace[0]) {
        deviceName = deviceSpace[0];
      } if (deviceSpace && deviceSpace[1]) {
        vendorName = deviceSpace[1];
      }
      deviceModalParams = { name: deviceName, vendor: vendorName };
      dataObj['deviceModels'] = new Array(deviceModalParams);
    } else {
      dataObj[key] = new Array(value);
    }
    return dataObj;
  }

  uploadFileData(request, actions,data) {
    if (actions.domain.name && actions.domain.id && actions.fileName) {
      request.extraParams = "?id=" + actions.id + "&domainName="
        + actions.domain.name + "&fileName=" + actions.fileName;
    } else if (actions.domain.name && actions.domain.id && !actions.fileName) {
      request.extraParams = "?id=" + actions.id + "&domainName="
        + actions.domain.name;
    } else {
      request.extraParams = "?id=" + actions.id + "&fileName=" + actions.fileName;
    }
    if(data.isApplication){
      return this.interceptor.httpCall('post', 'uploadDeviceFileDetails', request, false, true);
    }else if(data.isfirmware){
      return this.interceptor.httpCall('post', 'uploadFirmwareDeviceFileDetails', request, false, true);
    }else if(data.isConfig){
      return this.interceptor.httpCall('post', 'uploadConfigDeviceFileDetails', request, false, true);
    }else if(data.isAppAutoCampaign){
      return this.interceptor.httpCall('post', 'uploadAppAutoDeviceFileDetails', request, false, true);
    }else if(data.isFirmwarAutoCampaign){
      return this.interceptor.httpCall('post', 'uploadIsFormwareAutoDeviceFileDetails', request, false, true);
    }else if(data.isConfigAutoCampaign){
      return this.interceptor.httpCall('post', 'uploadConfigAutoDeviceFileDetails', request, false, true);
    }
   
  }
  deleteCampaignData(profileAction, domainDetails) {
    let params = {};
    if (domainDetails && domainDetails.domain && domainDetails.domain.id && domainDetails.domain.name) {
      params['extraParams'] = "?id=" + profileAction.id + "&domainId=" + domainDetails.domain.id +
        "&domainName=" + domainDetails.domain.name;
    } else {
      params['extraParams'] = "?id=" + profileAction.id;
    }

    return this.interceptor.httpCallReturn('delete', 'deleteCampign', params);
  }
  executeCampaignData(profileAction, domainDetails) {
    let params = {};
    if (domainDetails && domainDetails.domain && domainDetails.domain.id && domainDetails.domain.name) {
      params['extraParams'] = "?id=" + profileAction.id + "&domainId=" + domainDetails.domain.id +
        "&domainName=" + domainDetails.domain.name;
    } else {
      params['extraParams'] = "?id=" + profileAction.id;
    }

    return this.interceptor.httpCall('put', 'executeCampign', params);
  }
  deleteConfigCampaignData(profileAction, domainDetails) {
    let params = {};
    if (domainDetails && domainDetails.domain && domainDetails.domain.id && domainDetails.domain.name) {
      params['extraParams'] = "?id=" + profileAction.id + "&domainId=" + domainDetails.domain.id +
        "&domainName=" + domainDetails.domain.name;
    } else {
      params['extraParams'] = "?id=" + profileAction.id;
    }

    return this.interceptor.httpCallReturn('delete', 'deleteConfigCampign', params);
  }
  executeConfigCampaignData(profileAction, domainDetails) {
    let params = {};
    if (domainDetails && domainDetails.domain && domainDetails.domain.id && domainDetails.domain.name) {
      params['extraParams'] = "?id=" + profileAction.id + "&domainId=" + domainDetails.domain.id +
        "&domainName=" + domainDetails.domain.name;
    } else {
      params['extraParams'] = "?id=" + profileAction.id;
    }

    return this.interceptor.httpCall('put', 'executeConfigCampign', params);
  }
  deleteFirmwareCampaignData(profileAction, domainDetails) {
    let params = {};
    if (domainDetails && domainDetails.domain && domainDetails.domain.id && domainDetails.domain.name) {
      params['extraParams'] = "?id=" + profileAction.id + "&domainId=" + domainDetails.domain.id +
        "&domainName="+ domainDetails.domain.name;
    } else {
      params['extraParams'] = "?id=" + profileAction.id;
    }

    return this.interceptor.httpCallReturn('delete', 'deleteFirmwareCampign', params);
  }
  executeFirmwareCampaignData(profileAction, domainDetails) {
    let params = {};
    if (domainDetails && domainDetails.domain && domainDetails.domain.id && domainDetails.domain.name) {
      params['extraParams'] = "?id=" + profileAction.id + "&domainId=" + domainDetails.domain.id +
        "&domainName="+ domainDetails.domain.name;
    } else {
      params['extraParams'] = "?id=" + profileAction.id;
    }

    return this.interceptor.httpCall('put', 'executeFirmwareCampign', params);
  }
  deleteAutoAppPushCampaignData(profileAction, domainDetails) {
    let params = {};
    if (domainDetails && domainDetails.domain && domainDetails.domain.id && domainDetails.domain.name) {
      params['extraParams'] = "?id=" + profileAction.id + "&domainId=" + domainDetails.domain.id +
        "&domainName="+ domainDetails.domain.name+"&isAutoCampaign=true";
    } else {
      params['extraParams'] = "?id=" + profileAction.id+"&isAutoCampaign=true";
    }

    return this.interceptor.httpCallReturn('delete', 'deleteAutoAppPushCampign', params);
  }
  executeAutoAppPushCampaignData(profileAction, domainDetails) {
    let params = {};
    if (domainDetails && domainDetails.domain && domainDetails.domain.id && domainDetails.domain.name) {
      params['extraParams'] = "?id=" + profileAction.id + "&domainId=" + domainDetails.domain.id +
        "&domainName="+ domainDetails.domain.name+"&isAutoCampaign=true";
    } else {
      params['extraParams'] = "?id=" + profileAction.id+"&isAutoCampaign=true";
    }

    return this.interceptor.httpCall('put', 'executeAutoAppPushCampign', params);
  }
  deleteAutoConfigPushCampaignData(profileAction, domainDetails) {
    let params = {};
    if (domainDetails && domainDetails.domain && domainDetails.domain.id && domainDetails.domain.name) {
      params['extraParams'] = "?id=" + profileAction.id + "&domainId=" + domainDetails.domain.id +
        "&domainName="+ domainDetails.domain.name+"&isAutoCampaign=true";
    } else {
      params['extraParams'] = "?id=" + profileAction.id+"&isAutoCampaign=true";
    }

    return this.interceptor.httpCallReturn('delete', 'deleteAutoConfigPushCampign', params);
  }
  executeAutoConfigPushCampaignData(profileAction, domainDetails) {
    let params = {};
    if (domainDetails && domainDetails.domain && domainDetails.domain.id && domainDetails.domain.name) {
      params['extraParams'] = "?id=" + profileAction.id + "&domainId=" + domainDetails.domain.id +
        "&domainName="+ domainDetails.domain.name+"&isAutoCampaign=true";
    } else {
      params['extraParams'] = "?id=" + profileAction.id+"&isAutoCampaign=true";
    }

    return this.interceptor.httpCall('put', 'executeAutoConfigPushCampign', params);
  }
  deleteAutoFirmwarePushCampaignData(profileAction, domainDetails) {
    let params = {};
    if (domainDetails && domainDetails.domain && domainDetails.domain.id && domainDetails.domain.name) {
      params['extraParams'] = "?id=" + profileAction.id + "&domainId=" + domainDetails.domain.id +
        "&domainName="+ domainDetails.domain.name+"&isAutoCampaign=true";
    } else {
      params['extraParams'] = "?id=" + profileAction.id+"&isAutoCampaign=true";
    }

    return this.interceptor.httpCallReturn('delete', 'deleteAutoFirmwarePushCampign', params);
  }
  executeAutoFirmwarePushCampaignData(profileAction, domainDetails) {
    let params = {};
    if (domainDetails && domainDetails.domain && domainDetails.domain.id && domainDetails.domain.name) {
      params['extraParams'] = "?id=" + profileAction.id + "&domainId=" + domainDetails.domain.id +
        "&domainName="+ domainDetails.domain.name+"&isAutoCampaign=true";
    } else {
      params['extraParams'] = "?id=" + profileAction.id+"&isAutoCampaign=true";
    }

    return this.interceptor.httpCall('put', 'executeAutoFirmwarePushCampign', params);
  }
  stopCampaignData(request) {
    if (request && request.domain && request.domain.id && request.domain.name) {
      request.extraParams = "?id=" + request.id + "&domainId=" + request.domain.id + "&domainName=" + request.domain.name;;
    } else {
      request.extraParams = "?id=" + request.id;
    }
    return this.interceptor.httpCall('put', 'stopCampign', request);
  }
  stopConfigCampaignData(request) {
    if (request && request.domain && request.domain.id && request.domain.name) {
      request.extraParams = "?id=" + request.id + "&domainId=" + request.domain.id + "&domainName=" + request.domain.name;;
    } else {
      request.extraParams = "?id=" + request.id;
    }
    return this.interceptor.httpCall('put', 'stopConfigCampign', request);
  }
  stopFirmwareCampaignData(request) {
    if (request && request.domain && request.domain.id && request.domain.name) {
      request.extraParams = "?id=" + request.id + "&domainId=" + request.domain.id + "&domainName=" + request.domain.name;;
    } else {
      request.extraParams = "?id=" + request.id;
    }
    return this.interceptor.httpCall('put', 'stopFirmwareCampign', request);
  }
  stopAutoAppCampaignData(request) {
    if (request && request.domain && request.domain.id && request.domain.name) {
      request.extraParams = "?id=" + request.id + "&domainId=" + request.domain.id + "&domainName=" + request.domain.name;;
    } else {
      request.extraParams = "?id=" + request.id;
    }
    return this.interceptor.httpCall('put', 'stopAutoAppCampaignData', request);
  }
  stopAutoConfigCampaignData(request) {
    if (request && request.domain && request.domain.id && request.domain.name) {
      request.extraParams = "?id=" + request.id + "&domainId=" + request.domain.id + "&domainName=" + request.domain.name;;
    } else {
      request.extraParams = "?id=" + request.id;
    }
    return this.interceptor.httpCall('put', 'stopAutoConfigCampaignData', request);
  }
  stopAutoFirmwareCampaignData(request) {
    if (request && request.domain && request.domain.id && request.domain.name) {
      request.extraParams = "?id=" + request.id + "&domainId=" + request.domain.id + "&domainName=" + request.domain.name;;
    } else {
      request.extraParams = "?id=" + request.id;
    }
    return this.interceptor.httpCall('put', 'stopAutoFirmwareCampaignData', request);
  }
  restartCampaignData(request) {
    return this.interceptor.httpCall('put', 'restartCampign', request);
  }
  restartConfigCampaignData(request) {
    return this.interceptor.httpCall('put', 'restartConfigCampign', request);
  }
  restartFirmwareCampaignData(request) {
    return this.interceptor.httpCall('put', 'restartFirmwareCampign', request);
  }
  restartAppAutoCampaignData(request) {
    return this.interceptor.httpCall('put', 'restartAppAutoCampign', request);
  }
  restartConfigAutoCampaignData(request) {
    return this.interceptor.httpCall('put', 'restartConfigAutoCampaignData', request);
  }
  restartFirmwareAutoCampaignData(request) {
    return this.interceptor.httpCall('put', 'restartFirmwareAutoCampaignData', request);
  }
}
