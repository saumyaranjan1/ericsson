import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CampaignManagementEnumService {
  public static DATA = {
    data: [],
    columns: [
      {
        displayName: 'campaign Name',
        key: 'campaignName',
        filter: ''
      },
      {
        displayName: 'Status',
        key: 'campaignStatus',
        filter: ''
      },
      {
        displayName: 'Creation Time',
        key: 'creationTime',
        filter: 'dateWithTime'
      },
      {
        displayName: 'Start Time',
        key: 'startTime',
        filter: 'dateWithTime'
      },
      {
        displayName: 'Completed Time',
        key: 'completedTime',
        filter: 'dateWithTime'
      },
      {
        displayName: 'end Time',
        key: 'endTime',
        filter: 'dateWithTime'
      },
      {
        displayName: 'Operations',
        key: 'numberOfOperations',
        filter: ''
      },
      {
        displayName: 'Success %',
        key: 'updateSucceededPercent',
        filter: ''
      },
      {
        displayName: 'Rejected %',
        key: 'rejectedPercent',
        filter: ''
      },
      {
        displayName: 'Domain',
        key: 'domain',
        filter: ''
      }
    ],
    actions: [

      {
        type: 'view',
        title: 'view'
      }, {
        type: 'restart',
        title: 'Rerun'
      }, {
        type: 'stop',
        title: 'Stop'
      },
      {
        type: 'delete',
        title: 'Delete'
      },
      {
        type: 'adddevice',
        title: 'Add Devices'
      }
    ],
    actionsLabel: 'Actions',
    tableHeader: 'Campaign Management',
    deleteIcon:true,
    showGridCheckBox:true,
    tableActions: {
      add: false,
      search: false,
      dropDown: false,
      exportToCsv: false,
      showCheck: false,
      radio: false
    },
    radioHeaderList: [{
      check: true,
      value: "App Campaign"
    },{
      check: false,
      value: "Config Campaign"
    },{
      check: false,
      value: "Firmware Campaign"
    }]
  };

  public static ROUTE_NAME = "/main/campps";

  constructor() { }
}
