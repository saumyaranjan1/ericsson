import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { CampaignManagementEnumService } from './campaign-management-enum.service';
import { CampaignManagementService } from './campaign-management.service';
import { SpinnerService } from '../shared/services/spinner.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DataService } from '../shared/services/data.service';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { CommonMethodsService } from '../shared/methods/common-methods';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';
import { HeaderService } from './../main/header/header.service';
import { Router } from '@angular/router';

import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';

@Component({
  selector: 'app-campaign-management',
  templateUrl: './campaign-management.component.html',
  styleUrls: ['./campaign-management.component.less']
})
export class CampaignManagementComponent implements OnInit {
  @ViewChild('campaignDetails', { static: true }) campaignDetails: ElementRef;
  @ViewChild('deviceCampaignDetails', { static: true }) deviceCampaignDetails: ElementRef;
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('executeConfirmModalContent', { static: true }) executeConfirmModalContent: ElementRef;
  @ViewChild('stopConfirmModalContent', { static: true }) stopConfirmModalContent: ElementRef;
  @ViewChild('restartConfirmModalContent', { static: true }) restartConfirmModalContent: ElementRef;
  @ViewChild('deviceConfirmModalContent', { static: true }) deviceConfirmModalContent: ElementRef;
  @ViewChild('deviceSuccessModalContent', { static: true }) deviceSuccessModalContent: ElementRef;
  columns = CampaignManagementEnumService.DATA.columns;
  selectedValue;
  domainInfo = [];
  deleteFlag = CampaignManagementEnumService.DATA.deleteIcon;
  headerDropdownList;
  deviceModelsView;
  fileExtension;
  domainParams;
  fileSubmitReq;
  uploadedFile;
  uploadedFileName;
  isApplication = true;
  isfirmware = false;
  isConfig = false;
  isProvisioning = false;
  isAppAutoCampaign = false;
  isFirmwarAutoCampaign = false;
  isConfigAutoCampaign = false;
  event;
  actionsObj = {
    actionsLabel: CampaignManagementEnumService.DATA.actionsLabel,
    actions: CampaignManagementEnumService.DATA.actions
  };
  diffDays;
  scheduleType = false;
  installSoftwareForm: FormGroup;
  deviceSoftwareForm: FormGroup;
  //today's date   
  todayDate: Date = new Date();
  deviceModelView = true;
  tableHeader = CampaignManagementEnumService.DATA.tableHeader;
  headerRadioList = CampaignManagementEnumService.DATA.radioHeaderList;
  tableHeaderActions = CampaignManagementEnumService.DATA.tableActions;
  showGridCheckBox=CampaignManagementEnumService.DATA.showGridCheckBox;
  data = {
    page: 1,
    total: 1,
    data: []
  };
  viewCampaignData;
  viewDeviceCampaignData;
  apRead = false;
  cpRead = false;
  fpRead = false;
  actionsArr : any;
  showSuccessDevices = {
    alreadyInCampaignNumber : '',
    devicesAdded: '',
    resultMessage:''
  }
  constructor(private cms: CampaignManagementService,
    private spinnerService: SpinnerService,
    private ngbModal: NgbModal,
    private dataService: DataService,
    private fb: FormBuilder,
    private userService: UserService,
    private commonMethod: CommonMethodsService,
    private http: HttpClient,
    public router: Router,
    private HeaderService: HeaderService) { }

  ngOnInit() {
    this.domainParams = this.HeaderService.getSelectedDomain();
    this.getDomainInfo();
    this.getDropDownData();
  }

  epockTimeToDateFormat(UNIX_timestamp){
    const date = new Date(UNIX_timestamp);
    return date;
  }

  changeDomain(event){
    let domainValue;
    const domainData = this.domainInfo.filter(data => {
      return data.id === event.value;
    });
    if(domainData && domainData.length > 0){
      domainValue = {id:domainData[0].id,name:domainData[0].name};
      this.domainParams = {id:domainData[0].id,name:domainData[0].name};
    }
    this.HeaderService.setDomain(domainValue);
    let params = { "limit": 10, "offset": 0, domain: this.domainParams };
    this.getData(params);
  }


  getDomainInfo(){
    this.HeaderService.getDomainInfo().subscribe(result => {
      let domainData = [];
      if(result){
        domainData = result;
        if(domainData && domainData.length > 0){
          const selectedDomain = this.HeaderService.getSelectedDomain();
          if(selectedDomain && selectedDomain.id){
            this.selectedValue = selectedDomain.id;
            this.domainParams = {name:selectedDomain.name,id:selectedDomain.id}
          }else{
            const deviceData = {id:domainData[0].domainId,name:domainData[0].domainName};
            this.HeaderService.setToStorage('domain',deviceData);
            this.selectedValue = domainData[0].domainId;
            this.domainParams = {name:domainData[0].domainName,id:domainData[0].domainId}
          }
          domainData.forEach(value => {
            this.domainInfo.push({id:value.domainId,name:value.domainName});
          });
          this.getActions('App Campaign');
        }
      }
    }, error => {
    });
  }
   /**
   * 
   * Get Actions previliges for Campaign
   */
  getActions(type) {
    let _module ;
    if(type == 'App Campaign') {
      _module = EnumsService.CAMPPS_APP;
    } else if (type == 'Config Campaign') {
      _module = EnumsService.CAMPPS_CONFIG;
    } else if (type == 'AppAutoCampaign') {
      _module = EnumsService.CAMPPS_AUTO_APP;
    } else if (type == 'ConfigAutoCampaign') {
      _module = EnumsService.CAMPPS_AUTO_CONFIG;
    }else if (type == 'FirmwarAutoCampaign') {
      _module = EnumsService.CAMPPS_AUTO_FIRMWARE;
    } else {
      _module = EnumsService.CAMPPS_FIRMWARE;
    }
    
    const main_module = EnumsService.CAMPPS;
 // Form object to get the previliiages from server
 const obj = {
  moduleCode: main_module,
  roleId: this.dataService.getAtobLocalStorage('roleId'),
  previliages: true
};

 // API to get Previliages
 this.userService.getPreViliages(obj).subscribe( prev => {
 
  const headerActions = this.userService.getModulePermission(
    // EnumsService.ACTIONS[_module],
     EnumsService.ACTIONS[main_module],
     prev.data.privilege // Passing privilege to the methos to get thr actions array
   );
   headerActions.actionsArray.forEach(element => {
     if(element.type === 'apRead') {
       this.apRead = true;
     }
     if(element.type === 'cpRead') {
       this.cpRead = true;
     }
     if(element.type === 'fpRead') {
       this.fpRead = true;
     }
   });
  this.actionsArr = this.userService.getModulePermission(
    EnumsService.ACTIONS[_module],
    prev.data.privilege // Passing privilege to the methos to get thr actions array
  );
  if(type == 'AppAutoCampaign' || type == 'ConfigAutoCampaign' || type == 'FirmwarAutoCampaign'){
    if(this.actionsArr && this.actionsArr.actionsArray && this.actionsArr.actionsArray.length > 0){
      const checkType = this.actionsArr.actionsArray.filter(data => {
        return data.type == 'adddevice';
      });
     if(checkType && checkType.length > 0){
      this.actionsArr.actionsArray.splice(0, 1);
     }
    }
  }
  
  this.actionsArr.actionsArray.forEach((element,index,object) => {
    if(element.type == 'stop') {
      element.title = 'Stop Campaign';
      this.actionsArr.actionsArray.push({
        type: 'restart',
        title: 'Rerun Campaign'
      });
    }
  });
  //for execute
  this.actionsArr.actionsArray.push({
    type: 'install',
    title: 'Execute Campaign'
  });
  this.tableHeaderActions = this.actionsArr.headerRights;
  this.tableHeaderActions['exportToCsv'] = false;
  this.tableHeaderActions['add'] = false;
  this.tableHeaderActions['dropDown'] = false;
  this.tableHeaderActions['search'] = false;
  this.tableHeaderActions['deleteAction'] = false;
  this.actionsObj.actions = this.actionsArr.actionsArray;

  this.actionsObj.actions.forEach(element => {
    if(element.type=="adddevice"){
      element.title='Add Device to Campaign';
    }
  });
  // this.ruleGroupData.tableActions = this.actionsArr;
  // this.ruleGroupData.tableActions.search=this.actionsArr.headerRights.search;
  // this.ruleGroupData.tableActions.add=this.actionsArr.headerRights.add;
  // this.ruleGroupData.actions =  this.actionsArr.actionsArray;
});
}
  getDropDownData() {
    return new Promise((resolve, reject) => {
      this.http.get('assets/dropdown-json/dropdown.json').subscribe((response: any) => {
        this.headerDropdownList = response.campaigndropdown;
        resolve(true);
      });
    });
  }
  successCase(result) {
    if (result.status === 200 || result.status === 201 || result.status === 202) {
      this.spinnerService.toggleSpinner(0);
      return result.body;
    }
  }
  /**
   * Error Response
   */
  displayErrorMsg(error) {
    this.spinnerService.toggleSpinner(0);
    this.dataService.broadcast('alert', {
      type: 'danger',
      message: error && error.error && error.error.errorDetails ? error.error.errorDetails :
        error && error.error && error.error.message ? error.error.message : 'Network error please try again'
    });
  }
  failureCase(error) {
    this.spinnerService.toggleSpinner(0);
    this.dataService.broadcast('alert', {
      type: 'danger',
      message: error && error.error && error.error.errorDetails ? error.error.errorDetails :
        error && error.error && error.error.message ? error.error.message :
        error ? error :  'Network error please try again'
    });
  }
  getEmptyData(obj){
    this.data = {
      page: 1,
      total: 0,
      data: []
    };
  }
  getData(obj) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = {
        "limit": obj.limit, "offset": obj.offset, domainName: this.domainParams.name
      };
    } else {
      params = { "limit": obj.limit, "offset": obj.offset }
    }
    if(this.isApplication === true){
      this.spinnerService.toggleSpinner(1);
      this.cms.getCampaignDetails(params).subscribe(result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        if(res && res.data && res.data.items && res.data.items.length > 0){
          res.data.items.map(campaign => {
          campaign['domain'] = campaign.domainRepresentation.name;
          campaign['campaignStatus'] = campaign.status;
          campaign['moduleType'] = 'campaign';
        });
      }
       this.data = {
          page: obj.page,
          total: res && res.data && res.data.totalCount ? res.data.totalCount : 0,
          data: res && res.data && res.data.items && res.data.items.length > 0  ? res.data.items : []
        };
      }, error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.failureCase(error);
      });
    }else if(this.isfirmware === true){
      this.spinnerService.toggleSpinner(1);
      this.cms.getFirmwarenConfigDetails(params).subscribe(result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        if(res && res.data && res.data.items && res.data.items.length > 0){
          res.data.items.map(campaign => {
          campaign['domain'] = campaign.domainRepresentation.name;
          campaign['campaignStatus'] = campaign.status;
          campaign['moduleType'] = 'campaign';
        });
      }
       this.data = {
        page: obj.page,
        total: res && res.data && res.data.totalCount ? res.data.totalCount : 0,
        data: res && res.data && res.data.items && res.data.items.length > 0  ? res.data.items : []
        };
      }, error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.failureCase(error);
      });
    }else if(this.isConfig === true){
      this.spinnerService.toggleSpinner(1);
      this.cms.getConfigDetails(params).subscribe(result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        if(res && res.data && res.data.items && res.data.items.length > 0){
          res.data.items.map(campaign => {
          campaign['domain'] = campaign.domainRepresentation.name;
          campaign['campaignStatus'] = campaign.status;
          campaign['moduleType'] = 'campaign';
        });
      }
       this.data = {
        page: obj.page,
        total: res && res.data && res.data.totalCount ? res.data.totalCount : 0,
        data: res && res.data && res.data.items && res.data.items.length > 0  ? res.data.items : []
        };
      }, error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.failureCase(error);
      });
    }else if(this.isAppAutoCampaign === true){
      this.spinnerService.toggleSpinner(1);
      this.cms.getAppAutoProvisioning(params).subscribe(result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        if(res && res.data && res.data.items && res.data.items.length > 0){
          res.data.items.map(campaign => {
          campaign['domain'] = campaign.domainRepresentation.name;
          campaign['campaignStatus'] = campaign.status;
          campaign['moduleType'] = 'campaign';
        });
      }
       this.data = {
        page: obj.page,
        total: res && res.data && res.data.totalCount ? res.data.totalCount : 0,
        data: res && res.data && res.data.items && res.data.items.length > 0  ? res.data.items : []
        };
      }, error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.failureCase(error);
      });
    }else if(this.isConfigAutoCampaign === true){
      this.spinnerService.toggleSpinner(1);
      this.cms.getConfigAutoProvisioning(params).subscribe(result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        if(res && res.data && res.data.items && res.data.items.length > 0){
          res.data.items.map(campaign => {
          campaign['domain'] = campaign.domainRepresentation.name;
          campaign['campaignStatus'] = campaign.status;
          campaign['moduleType'] = 'campaign';
        });
      }
       this.data = {
        page: obj.page,
        total: res && res.data && res.data.totalCount ? res.data.totalCount : 0,
        data: res && res.data && res.data.items && res.data.items.length > 0  ? res.data.items : []
        };
      }, error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.failureCase(error);
      });
    }else if(this.isFirmwarAutoCampaign === true){
      this.spinnerService.toggleSpinner(1);
      this.cms.getFirmwarAutoCampaign(params).subscribe(result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        if(res && res.data && res.data.items && res.data.items.length > 0){
          res.data.items.map(campaign => {
          campaign['domain'] = campaign.domainRepresentation.name;
          campaign['campaignStatus'] = campaign.status;
          campaign['moduleType'] = 'campaign';
        });
      }
       this.data = {
        page: obj.page,
        total: res && res.data && res.data.totalCount ? res.data.totalCount : 0,
        data: res && res.data && res.data.items && res.data.items.length > 0  ? res.data.items : []
        };
      }, error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.failureCase(error);
      });
    }else if(this.isProvisioning === true){
      this.spinnerService.toggleSpinner(1);
      this.cms.getCampaignProvisioningDetails(params).subscribe(result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        if(res && res.data && res.data.items && res.data.items.length > 0){
          res.data.items.map(campaign => {
          campaign['domain'] = campaign.domainRepresentation.name;
          campaign['campaignStatus'] = campaign.status;
          campaign['moduleType'] = 'campaign';
        });
      }
       this.data = {
        page: obj.page,
        total: res && res.data && res.data.totalCount ? res.data.totalCount : 0,
        data: res && res.data && res.data.items && res.data.items.length > 0  ? res.data.items : []
        };
      }, error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.failureCase(error);
      });
    }
    
  };
  getDataBySearch(data) {
    let obj;
    obj = this.cms.getObject(data);
    obj.limit = 10;
    obj.offset = 0;
    this.domainParams = this.HeaderService.getSelectedDomain();
    if (this.domainParams) {
      obj.domainID = this.domainParams.id;
      obj.domainName = this.domainParams.name;
    }
    if(this.isApplication){
      this.spinnerService.toggleSpinner(1);
      this.cms.getCampaignDetails(obj).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          const res = this.successCase(result);
          if(res && res.data && res.data && res.data.items && res.data.items.length > 0){
            res.data.items.map(campaign => {
              campaign['domain'] = campaign.domainRepresentation.name;
              campaign['campaignStatus'] = campaign.status;
              campaign['moduleType'] = 'campaign';
            });
          }
        this.data = {
            page: obj.page,
            total: res && res.data.totalCount ? res.data.totalCount : 0,
            data: res && res.data && res.data && res.data.items && res.data.items.length > 0 
                ?  res.data.items : []
          };
        },
        error => {
          this.data = {
            page: 1,
            total: 0,
            data: []
          };
          this.failureCase(error);
        }
      );
    }
    else if(this.isConfig){
      this.spinnerService.toggleSpinner(1);
      this.cms.getConfigDetails(obj).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          const res = this.successCase(result);
          if(res && res.data && res.data && res.data.items && res.data.items.length > 0){
            res.data.items.map(campaign => {
              campaign['domain'] = campaign.domainRepresentation.name;
              campaign['campaignStatus'] = campaign.status;
              campaign['moduleType'] = 'campaign';
            });
          }
        this.data = {
            page: obj.page,
            total: res && res.data.totalCount ? res.data.totalCount : 0,
            data: res && res.data && res.data && res.data.items && res.data.items.length > 0 
                ?  res.data.items : []
          };
        },
        error => {
          this.data = {
            page: 1,
            total: 0,
            data: []
          };
          this.failureCase(error);
        }
      );
    }else if(this.isfirmware){
      this.spinnerService.toggleSpinner(1);
      this.cms.getFirmwarenConfigDetails(obj).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          const res = this.successCase(result);
          if(res && res.data && res.data && res.data.items && res.data.items.length > 0){
            res.data.items.map(campaign => {
              campaign['domain'] = campaign.domainRepresentation.name;
              campaign['campaignStatus'] = campaign.status;
              campaign['moduleType'] = 'campaign';
            });
          }
        this.data = {
            page: obj.page,
            total: res && res.data.totalCount ? res.data.totalCount : 0,
            data: res && res.data && res.data && res.data.items && res.data.items.length > 0 
                ?  res.data.items : []
          };
        },
        error => {
          this.data = {
            page: 1,
            total: 0,
            data: []
          };
          this.failureCase(error);
        }
      );
    }else if(this.isAppAutoCampaign){
      this.spinnerService.toggleSpinner(1);
      this.cms.getAppAutoProvisioning(obj).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          const res = this.successCase(result);
          if(res && res.data && res.data && res.data.items && res.data.items.length > 0){
            res.data.items.map(campaign => {
              campaign['domain'] = campaign.domainRepresentation.name;
              campaign['campaignStatus'] = campaign.status;
              campaign['moduleType'] = 'campaign';
            });
          }
        this.data = {
            page: obj.page,
            total: res && res.data.totalCount ? res.data.totalCount : 0,
            data: res && res.data && res.data && res.data.items && res.data.items.length > 0 
                ?  res.data.items : []
          };
        },
        error => {
          this.data = {
            page: 1,
            total: 0,
            data: []
          };
          this.failureCase(error);
        }
      );
    }
    else if(this.isConfigAutoCampaign){
      this.spinnerService.toggleSpinner(1);
      this.cms.getConfigAutoProvisioning(obj).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          const res = this.successCase(result);
          if(res && res.data && res.data && res.data.items && res.data.items.length > 0){
            res.data.items.map(campaign => {
              campaign['domain'] = campaign.domainRepresentation.name;
              campaign['campaignStatus'] = campaign.status;
              campaign['moduleType'] = 'campaign';
            });
          }
        this.data = {
            page: obj.page,
            total: res && res.data.totalCount ? res.data.totalCount : 0,
            data: res && res.data && res.data && res.data.items && res.data.items.length > 0 
                ?  res.data.items : []
          };
        },
        error => {
          this.data = {
            page: 1,
            total: 0,
            data: []
          };
          this.failureCase(error);
        }
      );
    }
    else if(this.isFirmwarAutoCampaign){
      this.spinnerService.toggleSpinner(1);
      this.cms.getFirmwarAutoCampaign(obj).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          const res = this.successCase(result);
          if(res && res.data && res.data && res.data.items && res.data.items.length > 0){
            res.data.items.map(campaign => {
              campaign['domain'] = campaign.domainRepresentation.name;
              campaign['campaignStatus'] = campaign.status;
              campaign['moduleType'] = 'campaign';
            });
          }
        this.data = {
            page: obj.page,
            total: res && res.data.totalCount ? res.data.totalCount : 0,
            data: res && res.data && res.data && res.data.items && res.data.items.length > 0 
                ?  res.data.items : []
          };
        },
        error => {
          this.data = {
            page: 1,
            total: 0,
            data: []
          };
          this.failureCase(error);
        }
      );
    }
    
  }

  viewCampaignDetails(data) {
    this.viewCampaignData = '';
    const req = {
      id: data.campaignId
    };
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = this.domainParams;
    };
    if(this.isApplication){
      this.spinnerService.toggleSpinner(1);
      this.cms.getCampaignInfo(req, params).subscribe(result => {
        this.spinnerService.toggleSpinner(0);
        const res = result && result.data ? result.data : '';
        this.deviceModelView = true;
        if (res) {
          let deviceArr = [];
          let device = "";
          if (res && res.operations && res.operations.representationObjects && res.operations.representationObjects.length > 0) {
            res.operations.representationObjects.forEach(element => {
              let deviceVendor = element.deviceVendor ? element.deviceVendor : '-';
              let deviceModel = element.deviceModel ? element.deviceModel : '';
              device = deviceVendor + ' ' + deviceModel;
              deviceArr.push(device);
            });
            const deviceModelsView = deviceArr.toString();
            this.deviceModelsView = deviceModelsView.replace(/,/g, "\n");
          }
  
          this.viewCampaignData = res;
        }
      });
    }else if(this.isConfig){
      this.spinnerService.toggleSpinner(1);
      this.cms.getConfigCampaignInfo(req, params).subscribe(result => {
        const res = result && result.data ? result.data : '';
        this.spinnerService.toggleSpinner(0);
        this.deviceModelView = true;
        if (res) {
          let deviceArr = [];
          let device = "";
          if (res && res.operations && res.operations.representationObjects && res.operations.representationObjects.length > 0) {
            res.operations.representationObjects.forEach(element => {
              let deviceVendor = element.deviceVendor ? element.deviceVendor : '-';
              let deviceModel = element.deviceModel ? element.deviceModel : '';
              device = deviceVendor + ' ' + deviceModel;
              deviceArr.push(device);
            });
            const deviceModelsView = deviceArr.toString();
            this.deviceModelsView = deviceModelsView.replace(/,/g, "\n");
          }
  
          this.viewCampaignData = res;
        }
      });
    }else if(this.isfirmware){
      this.spinnerService.toggleSpinner(1);
      this.cms.getFimrwareCampaignInfo(req, params).subscribe(result => {
        const res = result && result.data ? result.data : '';
        this.spinnerService.toggleSpinner(0);
        this.deviceModelView = true;
        if (res) {
          let deviceArr = [];
          let device = "";
          if (res && res.operations && res.operations.representationObjects && res.operations.representationObjects.length > 0) {
            res.operations.representationObjects.forEach(element => {
              let deviceVendor = element.deviceVendor ? element.deviceVendor : '-';
              let deviceModel = element.deviceModel ? element.deviceModel : '';
              device = deviceVendor + ' ' + deviceModel;
              deviceArr.push(device);
            });
            const deviceModelsView = deviceArr.toString();
            this.deviceModelsView = deviceModelsView.replace(/,/g, "\n");
          }
  
          this.viewCampaignData = res;
        }
      });
    }else if(this.isAppAutoCampaign){
      this.spinnerService.toggleSpinner(1);
      this.cms.getAppAutoCampaignInfo(req, params).subscribe(result => {
        const res = result && result.data ? result.data : '';
        this.spinnerService.toggleSpinner(0);
        this.deviceModelView = true;
        if (res) {
          let deviceArr = [];
          let device = "";
          if (res && res.operations && res.operations.representationObjects && res.operations.representationObjects.length > 0) {
            res.operations.representationObjects.forEach(element => {
              let deviceVendor = element.deviceVendor ? element.deviceVendor : '-';
              let deviceModel = element.deviceModel ? element.deviceModel : '';
              device = deviceVendor + ' ' + deviceModel;
              deviceArr.push(device);
            });
            const deviceModelsView = deviceArr.toString();
            this.deviceModelsView = deviceModelsView.replace(/,/g, "\n");
          }
  
          this.viewCampaignData = res;
        }
      });
    }else if(this.isFirmwarAutoCampaign){
      this.spinnerService.toggleSpinner(1);
      this.cms.getFimrwareCampaignInfo(req, params).subscribe(result => {
        const res = result && result.data ? result.data : '';
        this.spinnerService.toggleSpinner(0);
        this.deviceModelView = true;
        if (res) {
          let deviceArr = [];
          let device = "";
          if (res && res.operations && res.operations.representationObjects && res.operations.representationObjects.length > 0) {
            res.operations.representationObjects.forEach(element => {
              let deviceVendor = element.deviceVendor ? element.deviceVendor : '-';
              let deviceModel = element.deviceModel ? element.deviceModel : '';
              device = deviceVendor + ' ' + deviceModel;
              deviceArr.push(device);
            });
            const deviceModelsView = deviceArr.toString();
            this.deviceModelsView = deviceModelsView.replace(/,/g, "\n");
          }
  
          this.viewCampaignData = res;
        }
      });
    }
    else if(this.isConfigAutoCampaign){
      this.spinnerService.toggleSpinner(1);
      this.cms.getConfigCampaignInfo(req, params).subscribe(result => {
        const res = result && result.data ? result.data : '';
        this.spinnerService.toggleSpinner(0);
        this.deviceModelView = true;
        if (res) {
          let deviceArr = [];
          let device = "";
          if (res && res.operations && res.operations.representationObjects && res.operations.representationObjects.length > 0) {
            res.operations.representationObjects.forEach(element => {
              let deviceVendor = element.deviceVendor ? element.deviceVendor : '-';
              let deviceModel = element.deviceModel ? element.deviceModel : '';
              device = deviceVendor + ' ' + deviceModel;
              deviceArr.push(device);
            });
            const deviceModelsView = deviceArr.toString();
            this.deviceModelsView = deviceModelsView.replace(/,/g, "\n");
          }
  
          this.viewCampaignData = res;
        }
      });
    }
    

    this.openModel(this.campaignDetails, 'lg');
  }


  changeViewMore() {
    this.deviceModelView = !this.deviceModelView;
  }

  

  getSelectedCampaign(event) {
    let obj = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
    if (event && event === 'Provisioning') {
      this.isApplication = false;
      this.isfirmware = false;
      this.isConfig = false;
      this.isProvisioning = true;
      this.isAppAutoCampaign = false;
      this.isFirmwarAutoCampaign = false;
      this.isConfigAutoCampaign = false;
    }else if (event && event === 'Config Campaign') {
      this.isApplication = false;
      this.isfirmware = false;
      this.isConfig = true;
      this.isProvisioning = false;
      this.isAppAutoCampaign = false;
      this.isFirmwarAutoCampaign = false;
      this.isConfigAutoCampaign = false;
    }else if (event && event === 'Firmware Campaign') {
      this.isApplication = false;
      this.isfirmware = true;
      this.isConfig = false;
      this.isProvisioning = false;
      this.isAppAutoCampaign = false;
      this.isFirmwarAutoCampaign = false;
      this.isConfigAutoCampaign = false;
    } else if (event && event === 'App Campaign'){
      this.isApplication = true;
      this.isfirmware = false;
      this.isConfig = false;
      this.isProvisioning = false;
      this.isAppAutoCampaign = false;
      this.isFirmwarAutoCampaign = false;
      this.isConfigAutoCampaign = false;
    }
    else if (event && event === 'AppAutoCampaign'){
      this.isApplication = false;
      this.isfirmware = false;
      this.isConfig = false;
      this.isProvisioning = false;
      this.isAppAutoCampaign = true;
      this.isFirmwarAutoCampaign = false;
      this.isConfigAutoCampaign = false;
    }
    else if (event && event === 'ConfigAutoCampaign'){
      this.isApplication = false;
      this.isfirmware = false;
      this.isConfig = false;
      this.isProvisioning = false;
      this.isAppAutoCampaign = false;
      this.isFirmwarAutoCampaign = false;
      this.isConfigAutoCampaign = true;
    }
    else if (event && event === 'FirmwarAutoCampaign'){
      this.isApplication = false;
      this.isfirmware = false;
      this.isConfig = false;
      this.isProvisioning = false;
      this.isAppAutoCampaign = false;
      this.isFirmwarAutoCampaign = true;
      this.isConfigAutoCampaign = false;
    }
    this.getActions(event)
    this.getData(obj);
  }

  getProvisioningList(obj) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = {
        "limit": obj.limit, "offset": obj.offset,
        domainID: this.domainParams.id, domainName: this.domainParams.name
      };
    } else {
      params = { "limit": obj.limit, "offset": obj.offset }
    }
    this.cms.getCampaignProvisioningDetails(params).subscribe(result => {
      const res = this.successCase(result);
      this.spinnerService.toggleSpinner(0);
      res.items.map(campaign => {
        campaign['domain'] = campaign.domainRepresentation.name;
        campaign['campaignStatus'] = campaign.status;
        campaign['moduleType'] = 'campaign';
      })

      this.data = {
        page: obj.page,
        total: res.totalCount,
        data: res.items
      };
    }, error => {
      this.data = {
        page: 1,
        total: 0,
        data: []
      };
      this.failureCase(error);
    });
  };

  viewDeviceCampaignDetails(data) {
    this.viewDeviceCampaignData = data;
    this.openModel(this.deviceCampaignDetails, 'lg');
  }

  openModel(content, size) {
    this.deviceModelsView = "";
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: size,
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }

  /**
   * Close Popup Window
   */
  closeModel(close) {
    close('Cross click');
  }

  deleteCampaign(event) {
    this.event = event;
    this.openModel(this.deleteConfirmModalContent, 'sm');
  }
  ExecuteCampaign(event) {
    this.event = event;
    this.openModel(this.executeConfirmModalContent, 'sm');
  }
  getStopData(event) {
    this.event = event;
    this.openModel(this.stopConfirmModalContent, 'sm');
  }
  getRestartData(event) {
    this.event = event;
    this.diffDays = "";
    this.installSoftwareFormBlock();
    this.openModel(this.restartConfirmModalContent, 'md');
  }
  openDevices(event) {
    this.event = event;
    this.DeviceSoftwareFormBlock();
    this.openModel(this.deviceConfirmModalContent, 'sm');
  }
  stopCampaignData(close: any) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    const _req = { id: this.event.campaignId, domain: this.domainParams };
    if(this.isApplication){
      this.spinnerService.toggleSpinner(1);
      this.cms.stopCampaignData(_req).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Stop successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      });
    }else if(this.isConfig){
      this.spinnerService.toggleSpinner(1);
      this.cms.stopConfigCampaignData(_req).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Stop successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      });
    }else if(this.isfirmware){
      this.spinnerService.toggleSpinner(1);
      this.cms.stopFirmwareCampaignData(_req).subscribe((res: any) => {
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Stop successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      });
    }else if(this.isAppAutoCampaign){
      this.spinnerService.toggleSpinner(1);
      this.cms.stopAutoAppCampaignData(_req).subscribe((res: any) => {
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Stop successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      });
    }
    else if(this.isConfigAutoCampaign){
      this.spinnerService.toggleSpinner(1);
      this.cms.stopAutoConfigCampaignData(_req).subscribe((res: any) => {
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Stop successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      });
    }
    else if(this.isFirmwarAutoCampaign){
      this.spinnerService.toggleSpinner(1);
      this.cms.stopAutoFirmwareCampaignData(_req).subscribe((res: any) => {
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Stop successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      });
    }
    
  }


  changeServerStatus(event) {
    if (event && event.value && event.value === 'scheduled') {
      this.scheduleType = true;
    } else {
      this.scheduleType = false;
    }
  }


  installSoftwareWithDevices(close) {
    this.spinnerService.toggleSpinner(1);
    const req = { campaignId: this.event.campaignId };
    if (this.installSoftwareForm.value.isServerInitiated == 'None') {
      req['isServerInitiated'] = false;
    }
    if (this.installSoftwareForm.value.isServerInitiated == 'immediate') {
      req['isServerInitiated'] = true;
    }

    if (this.installSoftwareForm.value.isServerInitiated == 'scheduled') {
      req['isServerInitiated'] = true;
      req['serverInitiatedInTimeZone'] = this.installSoftwareForm.value.serverInitiatedInTimeZone;
      req['serverInitiatedFromTime'] = this.installSoftwareForm.value.serverInitiatedFromTime ? this.commonMethod.convertTime12to24(this.installSoftwareForm.value.serverInitiatedFromTime) : '';
      req['serverInitiatedToTime'] = this.installSoftwareForm.value.serverInitiatedToTime ? this.commonMethod.convertTime12to24(this.installSoftwareForm.value.serverInitiatedToTime) : '';
    }

    if (this.installSoftwareForm.value.campaignRetries) {
      req['maxRetryNumber'] = this.installSoftwareForm.value.campaignRetries;
    }


    if (this.installSoftwareForm.value.campaignPriority) {
      req['campaignPriority'] = this.installSoftwareForm.value.campaignPriority;
    }
    if (this.installSoftwareForm.value.campaignPriority === 'REGULAR') {
      req['isSilentUpdate'] = false;
      req['isCriticalUpdate'] = false;
    }else if (this.installSoftwareForm.value.campaignPriority === 'CRITICAL') {
      req['isSilentUpdate'] = false;
      req['isCriticalUpdate'] = true;
    }else if (this.installSoftwareForm.value.campaignPriority === 'SILENT') {
      req['isSilentUpdate'] = true;
      req['isCriticalUpdate'] = false;
    }
    if (this.installSoftwareForm.value.campaignStartTime) {
      req['campaignStartTime'] = this.commonMethod.getEpochTimeForInstallStartDay(this.installSoftwareForm.value.campaignStartTime);
    }

    if (this.installSoftwareForm.value.campaignEndTime) {
      req['campaignEndTime'] = this.commonMethod.getEpochTimeForInstallEndDay(this.installSoftwareForm.value.campaignEndTime);
    }
    if (this.installSoftwareForm.value.networkUsage) {
      req['networkUsage'] = this.installSoftwareForm.value.networkUsage;
    }

    if (this.installSoftwareForm.value.Timeframe) {

      if (this.installSoftwareForm.value.timeFrameType == 'hours') {
        req['Timeframe'] = this.installSoftwareForm.value.Timeframe * 60;
      } else {
        req['Timeframe'] = this.installSoftwareForm.value.Timeframe;
      }
    }
    this.domainParams = this.HeaderService.getSelectedDomain();
    if (this.domainParams) {
      req['domain'] = { id: this.domainParams.id, name: this.domainParams.name };
    }
    if(this.isApplication){
      this.cms.restartCampaignData(req).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          const res = this.successCase(result);
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Rerun successfully'
          });
          const obj = { limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 };
          this.getData(obj);
          this.closeModel(close);
        },
        error => {
          this.failureCase(error);
        }
      );
    }else if(this.isConfig){
      this.cms.restartConfigCampaignData(req).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          const res = this.successCase(result);
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Rerun successfully'
          });
          const obj = { limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 };
          this.getData(obj);
          this.closeModel(close);
        },
        error => {
          this.failureCase(error);
        }
      );
    }else if(this.isfirmware){
      this.cms.restartFirmwareCampaignData(req).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          const res = this.successCase(result);
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Rerun successfully'
          });
          const obj = { limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 };
          this.getData(obj);
          this.closeModel(close);
        },
        error => {
          this.failureCase(error);
        }
      );
    }else if(this.isAppAutoCampaign){
      this.cms.restartAppAutoCampaignData(req).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          const res = this.successCase(result);
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Rerun successfully'
          });
          const obj = { limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 };
          this.getData(obj);
          this.closeModel(close);
        },
        error => {
          this.failureCase(error);
        }
      );
    }else if(this.isConfigAutoCampaign){
      this.cms.restartConfigAutoCampaignData(req).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          const res = this.successCase(result);
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Rerun successfully'
          });
          const obj = { limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 };
          this.getData(obj);
          this.closeModel(close);
        },
        error => {
          this.failureCase(error);
        }
      );
    }
    else if(this.isFirmwarAutoCampaign){
      this.cms.restartFirmwareAutoCampaignData(req).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          const res = this.successCase(result);
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Rerun successfully'
          });
          const obj = { limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 };
          this.getData(obj);
          this.closeModel(close);
        },
        error => {
          this.failureCase(error);
        }
      );
    }
    
  }

  fileEvent($event) {
    this.uploadedFile = $event.target.files[0];
    this.uploadedFileName = this.uploadedFile.name;
    const dotPos = this.uploadedFile.name.lastIndexOf('.');
    if (this.uploadedFile.name.lastIndexOf('.') > 0) {
      this.fileExtension = this.uploadedFile.name.substring(
        dotPos + 1,
        this.uploadedFile.name.length
      );
    }
    if (this.fileExtension.toLowerCase() === 'txt') {
      this.deviceSoftwareForm.controls.uploadFile.setValue(
        this.uploadedFileName
      );
      this.fileSubmitReq = new FormData();
      this.fileSubmitReq.append('file', this.uploadedFile);
    }
  }

  uploadFile(form, close) {
    if (form.valid) {
      this.domainParams = this.HeaderService.getSelectedDomain();
      const params = {id:this.event.campaignId,
                      domain:this.domainParams,
                      fileName : this.deviceSoftwareForm.controls.file.value
      }
      this.spinnerService.toggleSpinner(1);
      const data = {
        "isApplication" : this.isApplication,
        "isfirmware" : this.isfirmware,
        "isConfig" : this.isConfig,
        "isProvisioning" : this.isProvisioning,
        "isAppAutoCampaign" : this.isAppAutoCampaign,
        "isFirmwarAutoCampaign" : this.isFirmwarAutoCampaign,
        "isConfigAutoCampaign" : this.isConfigAutoCampaign
      }
      this.cms.uploadFileData(this.fileSubmitReq, params,data).subscribe(
        result => {
          this.spinnerService.toggleSpinner(0);
          if(result){
            this.dataService.broadcast('alert', {
              type: 'success',
              message: 'Upload File successfully'
            });
            this.closeModel(close);
            this.showSuccessDevices = {
              alreadyInCampaignNumber : result.data.alreadyInCampaignNumber,
              devicesAdded: result.data.devicesAdded,
              resultMessage:result.data.resultMessage
            }
            this.openModel(this.deviceSuccessModalContent, 'sm');
          }
         
        },
        error => {
         
        }
      );
    }
  }


  successCloseModel(close){
    const obj = { limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 };
    this.getData(obj);
    this.closeModel(close);
  }

  DeviceSoftwareFormBlock() {
    this.deviceSoftwareForm = this.fb.group({
      uploadFile: [],
      file: ''
    });
  }

  installSoftwareFormBlock() {
    this.installSoftwareForm = this.fb.group({
      modal: [''],
      targetDevices: 'All',
      campaignRetries: ['3'],

      campaignPriority: 'REGULAR',

      successMessage: '',

      failureMessage: '',

      isDraft: false,

      isServerInitiated: false,

      serverInitiatedInTimeZone: 'Asia/Kolkata',//Default India

      serverInitiatedFromTime: '',

      serverInitiatedToTime: '',

      campaignStartTime: '',

      campaignEndTime: '',
      downloadFromTime: '',
      downloadToTime: '',
      networkUsage: '',
      wifiExpirationDate: '',
      wifiExpirationTime: '',
      Quota: '',
      Timeframe: '',
      quotaType: '',
      timeFrameType: ''
    });
  }

  differenceInDays() {
    if (this.installSoftwareForm.value.campaignStartTime && this.installSoftwareForm.value.campaignEndTime) {
      if (new Date(this.installSoftwareForm.value.campaignEndTime) > new Date(this.installSoftwareForm.value.campaignStartTime)) {
        this.diffDays = this.commonMethod.dateDiffIndays(this.installSoftwareForm.value.campaignStartTime, this.installSoftwareForm.value.campaignEndTime)
      } else {
        this.diffDays = "";
      }

    }
  }

  deleteCampaignData(close: any) {
    this.spinnerService.toggleSpinner(1);
    this.domainParams = this.HeaderService.getSelectedDomain();
    const _req = { id:this.event.campaignId };
    let params = {};
    if (this.domainParams) {
      params = { domain: this.domainParams };
    }
    if(this.isApplication){
      this.cms.deleteCampaignData(_req, params).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Delete successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      }, error => {
        this.displayErrorMsg(error);
      });
    }else if(this.isConfig){
      this.cms.deleteConfigCampaignData(_req, params).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Delete successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      }, error => {
        this.displayErrorMsg(error);
      });
    }else if(this.isfirmware){
      this.cms.deleteFirmwareCampaignData(_req, params).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Delete successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      }, error => {
        this.displayErrorMsg(error);
      });
    }else if(this.isAppAutoCampaign){
      this.cms.deleteAutoAppPushCampaignData(_req, params).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Delete successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      }, error => {
        this.displayErrorMsg(error);
      });
    }else if(this.isConfigAutoCampaign){
      this.cms.deleteAutoConfigPushCampaignData(_req, params).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Delete successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      }, error => {
        this.displayErrorMsg(error);
      });
    }else if(this.isFirmwarAutoCampaign){
      this.cms.deleteAutoFirmwarePushCampaignData(_req, params).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Delete successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      }, error => {
        this.displayErrorMsg(error);
      });
    }
    
  }

  ExecuteCampaignData(close: any) {
    this.spinnerService.toggleSpinner(1);
    this.domainParams = this.HeaderService.getSelectedDomain();
    const _req = { id:this.event.campaignId };
    let params = {};
    if (this.domainParams) {
      params = { domain: this.domainParams };
    }
    if(this.isApplication){
      this.cms.executeCampaignData(_req, params).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Execute successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      }, error => {
        this.displayErrorMsg(error);
      });
    }else if(this.isConfig){
      this.cms.executeConfigCampaignData(_req, params).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Execute successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      }, error => {
        this.displayErrorMsg(error);
      });
    }else if(this.isfirmware){
      this.cms.executeFirmwareCampaignData(_req, params).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Execute successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      }, error => {
        this.displayErrorMsg(error);
      });
    }else if(this.isAppAutoCampaign){
      this.cms.executeAutoAppPushCampaignData(_req, params).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Execute successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      }, error => {
        this.displayErrorMsg(error);
      });
    }else if(this.isConfigAutoCampaign){
      this.cms.executeAutoConfigPushCampaignData(_req, params).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Execute successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      }, error => {
        this.displayErrorMsg(error);
      });
    }else if(this.isFirmwarAutoCampaign){
      this.cms.executeAutoFirmwarePushCampaignData(_req, params).subscribe((res: any) => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Execute successfully'
        });
        const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
        this.getData(event);
        this.closeModel(close);
      }, error => {
        this.displayErrorMsg(error);
      });
    }
    
  }

}
