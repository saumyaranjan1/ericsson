import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CampaignManagementComponent } from './campaign-management.component';
import { SharedModule } from '../shared/shared.module';
import { CampaignManagementRoutingModule } from './campaign-management-routing.module';



@NgModule({
  declarations: [CampaignManagementComponent],
  imports: [
    CommonModule,
    SharedModule,
    CampaignManagementRoutingModule
  ]
})
export class CampaignManagementModule { }
