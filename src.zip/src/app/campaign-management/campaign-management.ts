export interface CampaignManagement {
}
