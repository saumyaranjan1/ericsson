import { TestBed } from '@angular/core/testing';

import { CampaignManagementEnumService } from './campaign-management-enum.service';

describe('CampaignManagementEnumService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CampaignManagementEnumService = TestBed.get(CampaignManagementEnumService);
    expect(service).toBeTruthy();
  });
});
