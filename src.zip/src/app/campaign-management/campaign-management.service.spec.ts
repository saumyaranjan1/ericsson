import { TestBed } from '@angular/core/testing';

import { CampaignManagementService } from './campaign-management.service';

describe('CampaignManagementService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CampaignManagementService = TestBed.get(CampaignManagementService);
    expect(service).toBeTruthy();
  });
});
