import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SoftwareManagementEnumService {
  public static DATA = {
    data: [],
    columns: [
      {
        displayName: 'Name',
        key: 'name',
        filter: ''
      },
      {
        displayName: 'Version Name',
        key: 'versionName',
        filter: ''
      },
      {
        displayName: 'OS',
        key: 'platformName',
        filter: ''
      },
      {
        displayName: 'Description',
        key: 'description',
        filter: ''
      },
      {
        displayName: 'Device Models',
        key: 'modals',
        filter: ''
      },
      {
        displayName: 'Domain',
        key: 'domain',
        filter: ''
      }
    ],
    actions: [
      // {
      //   type: 'edit',
      //   title: 'edit'
      // },
      // {
      //   type: 'view',
      //   title: 'view'
      // },
      // {
      //   type: 'install',
      //   title: 'install'
      // },
      // {
      //   type: 'delete',
      //   title: 'Delete'
      // }
    ],
    actionsLabel: 'Actions',
    tableHeader: 'Application Provision',
    infoIcon:'Applications Provision',
    deleteIcon:true,
    showGridCheckBox:true,
    tableActions: {
      add: false,
      provisionsearch: true,
      exportToCsv: false,
      provisiondropDown:true
    }
  };
  public static MODELS_COLUMNS =
    [
      {
        displayName: 'Vendor',
        key: 'name',
        filter: ''
      },
      {
        displayName: 'Model',
        key: 'model',
        filter: ''
      }
    ];

    public static ENTERPRISE_COLUMNS =
    [
      {
        displayName: 'Enterprise Name',
        key: 'model',
        filter: ''
      },
      {
        displayName: 'Id',
        key: 'name',
        filter: ''
      },
    ];  

  public static UPDATEFILE_COLUMNS = [
    {
      displayName: 'versions',
      key: 'name',
      filter: ''
    },
    {
      displayName: 'file',
      key: 'model',
      filter: ''
    },
    {
      displayName: 'size(kb)',
      key: 'model',
      filter: ''
    },
    {
      displayName: 'device models',
      key: 'model',
      filter: ''
    },
    {
      displayName: 'tools',
      key: 'model',
      filter: ''
    },
    {
      displayName: 'device details',
      key: 'model',
      filter: ''
    },
    {
      displayName: 'creation time',
      key: 'model',
      filter: ''
    }
  ];


  public static DEVICE_MODELS_COLUMNS =
    [
      {
        displayName: 'DEVICE IMEI',
        key: 'name',
        filter: ''
      },
      {
        displayName: 'Domain',
        key: 'model',
        filter: ''
      },
      {
        displayName: 'STATUS',
        key: 'model',
        filter: ''
      }
    ];
  public static VIEWDATA = {
    viewColumn: [
      {
        displayName: 'File',
        key: 'file',
        filter: ''
      },
      {
        displayName: 'Size(KB)',
        key: 'size',
        filter: ''
      },
      {
        displayName: 'Device Models',
        key: 'models',
        filter: ''
      },
      {
        displayName: 'Creation Time',
        key: 'time',
        filter: ''
      },
      {
        displayName: 'Created By',
        key: 'by',
        filter: ''
      }
    ],
    actions: [],
    actionsLabel: 'Actions',
    tableHeader: 'App Push Configuration',
    tableActions: {
      add: true,
      search: true
    }
  }
  public static ROUTE_NAME = "/main/psapps";
  constructor() { }
}


