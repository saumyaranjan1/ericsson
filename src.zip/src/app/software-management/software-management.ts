export interface SoftwareManagement {
}
