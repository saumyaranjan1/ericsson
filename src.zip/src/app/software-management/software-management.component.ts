import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { SoftwareManagementEnumService } from './software-management-enum.service';
import { SoftwareManagementService } from './software-management.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';

import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { SpinnerService } from '../shared/services/spinner.service';
import { DataService } from '../shared/services/data.service';
import { Router } from '@angular/router';
import { CommonMethodsService } from '../shared/methods/common-methods';
import { forkJoin } from 'rxjs';
import { VendorService } from './../vendor/vendor.service';
import { HeaderService } from './../main/header/header.service';

import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';

@Component({
  selector: 'app-software-management',
  templateUrl: './software-management.component.html',
  styleUrls: ['./software-management.component.less']
})
export class SoftwareManagementComponent implements OnInit {
  @ViewChild('mapModelsTemplate', { static: false }) mapModelsTemplate: ElementRef;
  @ViewChild('mapEnterpriseTemplate', { static: false }) mapEnterpriseTemplate: ElementRef;
  @ViewChild('devicesTemplate', { static: false }) devicesTemplate: ElementRef;
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('deleteVersionConfirmModalContent', { static: true }) deleteVersionConfirmModalContent: ElementRef;
  @ViewChild('changeAppStatusTemplate', { static: true }) changeAppStatusTemplate: ElementRef;
  columns = SoftwareManagementEnumService.DATA.columns;
  selectedValue;
  domainInfo = [];
  modelsColumns = SoftwareManagementEnumService.MODELS_COLUMNS;
  deleteFlag = SoftwareManagementEnumService.DATA.deleteIcon;
  infoIcon = SoftwareManagementEnumService.DATA.infoIcon;
  showGridCheckBox = SoftwareManagementEnumService.DATA.showGridCheckBox;
  enterpriseModelsColumns = SoftwareManagementEnumService.ENTERPRISE_COLUMNS;
  updateFileColumns = SoftwareManagementEnumService.UPDATEFILE_COLUMNS;
  deviceModalsColumns = SoftwareManagementEnumService.DEVICE_MODELS_COLUMNS;
  viewColumn = SoftwareManagementEnumService.VIEWDATA.viewColumn;
  actionsObj = {
    actionsLabel: SoftwareManagementEnumService.DATA.actionsLabel,
    actions: SoftwareManagementEnumService.DATA.actions
  };
  tableHeaderActions = SoftwareManagementEnumService.DATA.tableActions;
  data = {
    page: 1,
    total: 1,
    data: []
  };
  scheduleType = false;
  statusInfo = [{ name: 'Active' }, { name: 'Inactive' }];
  selectedStatusInfo = "";
  viewSoftwareEnterpriseData = [];
  enterpriseIdsArray;
  selectedEnterpriseCount;
  tableHeader = SoftwareManagementEnumService.DATA.tableHeader;
  createNewSoftwareForm: FormGroup;
  installSoftwareForm: FormGroup;
  selected = 'option2';
  startTime = '';
  endTime = '';
  softwareDisplyNames = {
    os: 'OPERATING SYSTEM',
    stype: 'SOFTWARE TYPE',
    supportRollback: 'Supports Rollback',
    uploadFile: 'UPLOAD FILE',
    mdsCheckSum: 'SOFTWARE FILE MD5 CHECKSUM',
    softwareName: 'SOFTWARE NAME',
    vName: 'VERSION NAME',
    vNumber: 'VERSION NUMBER',
    vendor: 'VENDOR',
    softwareId: 'SOFTWARE ID',
    dec: 'SHORT DESCRIPTION',
    lDec: 'LONG DESCRIPTION',
    estTime: 'EST INSTALLATION TIME (IN SEC)',
    whatsNew: `WHAT'S NEW`,
    deviceModels: 'DEVICE MODELS',
    applicableEnterprises: 'APPLICABLE ENTERPRISES',
    modal: 'Select Modal',
    campaignDescription: 'Campaign Description'
  };

  osList = [];
  //today's date   
  validSoftwareEnterprise = false;
  validDeviceModels = false;
  todayDate: Date = new Date();
  serverPlatformsList = [];
  platformList = [];
  installerList = [];
  hideListTable = false;
  isCreateNew = false;
  isInstallSoftware = false;
  isView = false;
  isEdit = false;
  isNewVersion = false;
  searchModel;
  deviceSearchModel;
  models = [];
  enterprisemodels = [];
  selectAll = false;
  selectEnterpriseAll = false;
  selectedModals = [];
  selectedEnterpriseModals = [];
  packageId;
  IsIndeterminate = false;
  selectedModelsCount = 0;
  uploadedFile;
  uploadedFileName;
  fileExtension;
  fileSubmitReq;
  installModels;
  deviceModelsList = [];
  deviceModelsListCount;
  enterpriseModelsListCount;
  currentPageOfDeviceModal = 1;
  currentPageOfEnterpriseModal = 1;
  selectedDeviceModal = [];
  selectAllDevices;
  notSelectAnyDevices;
  selectedDevicesCount = 0;
  selectedDeviceIds = [];
  selectedDeviceNames = [];
  installSoftwareDetails;
  domainParams;
  viewSoftwareData;
  event;
  selectedVersion = 0;
  headerDropdownList;
  updateSoftwareDetailsObj = {};
  isRoleAdd = true;
  isRoleEdit = true;
  isRoleDelete = true;
  isRoleInstall = true;
  newVersionPackageId;
  oldVersionNumber;
  // targetDevices = 'All';
  targetDevicesList = ['All', 'By Domain', 'By Device Group'];
  zones;
  diffDays;
  actionsArr: any;
  constructor(
    private sms: SoftwareManagementService,
    private http: HttpClient,
    private ngbModal: NgbModal,
    private fb: FormBuilder,
    private spinnerService: SpinnerService,
    private cms: CommonMethodsService,
    private dataService: DataService,
    public router: Router,
    private userService: UserService,
    private VendorService: VendorService,
    private HeaderService: HeaderService
  ) { }

  ngOnInit() {
    this.domainParams = this.HeaderService.getSelectedDomain();
    this.getDomainInfo();
  }

  changeDomain(event) {
    let domainValue;
    const domainData = this.domainInfo.filter(data => {
      return data.id === event.value;
    });
    if (domainData && domainData.length > 0) {
      domainValue = { id: domainData[0].id, name: domainData[0].name };
      this.domainParams = { id: domainData[0].id, name: domainData[0].name };
    }
    this.HeaderService.setDomain(domainValue);
    let params = { "limit": 10, "offset": 0, domain: this.domainParams };
    this.hideListTable = true;
    this.hideTable();
    this.getData(params);
    this.getPlatforms();
  }

  setStartTime(event) {
    this.startTime = event;
  }

  setEndTime(event) {
    this.endTime = event;
  }

  getDomainInfo() {
    this.HeaderService.getDomainInfo().subscribe(result => {
      let domainData = [];
      if (result) {
        domainData = result;
        if (domainData && domainData.length > 0) {
          const selectedDomain = this.HeaderService.getSelectedDomain();
          if (selectedDomain && selectedDomain.id) {
            this.selectedValue = selectedDomain.id;
            this.domainParams = { name: selectedDomain.name, id: selectedDomain.id }
          } else {
            const deviceData = { id: domainData[0].domainId, name: domainData[0].domainName };
            this.HeaderService.setToStorage('domain', deviceData);
            this.selectedValue = domainData[0].domainId;
            this.domainParams = { name: domainData[0].domainName, id: domainData[0].domainId }
          }
          domainData.forEach(value => {
            this.domainInfo.push({ id: value.domainId, name: value.domainName });
          });
          this.getDropDownData();
          this.getPlatforms();
        }
      }
    }, error => {
    });
  }

  /**
   * Get Actions for FirmWare module
   */

  getActions() {
    const _module = EnumsService.PSAPPS;
    // Form object to get the previliiages from server
    const obj = {
      moduleCode: _module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };

    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe(prev => {

      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );

      const actionsArray = this.actionsArr.actionsArray.filter((obj) => {
        return (
          obj.disableIconProp !== false &&
          obj.type !== 'add'
        );
      });
      if (this.actionsArr.headerRights) {
        this.isRoleAdd = this.actionsArr.headerRights['add'];
        this.isRoleInstall = this.actionsArr.headerRights['add'];
        this.isRoleDelete = this.actionsArr.headerRights['delete'];
        this.isRoleEdit = this.actionsArr.headerRights['edit'];
      }
      this.tableHeaderActions = this.actionsArr.headerRights;
      this.tableHeaderActions['exportToCsv'] = false;
      this.tableHeaderActions['provisiondropDown'] = true;
      this.tableHeaderActions['provisionsearch'] = true;
      this.tableHeaderActions['deleteAction'] = false;
      this.actionsObj.actions = actionsArray;

      this.actionsObj.actions.forEach(element => {
        if (element.type == "install") {
          element.title = 'Install app provisioning service';
        }
      });

    });

  }

  getDropDownData() {
    return new Promise((resolve, reject) => {
      this.http.get('assets/dropdown-json/dropdown.json').subscribe((response: any) => {
        this.headerDropdownList = response.apppushdropdown;
        resolve(true);
      });
    });
  }
  successCase(result) {
    if (
      result.status === 200 ||
      result.status === 201 ||
      result.status === 202
    ) {
      this.spinnerService.toggleSpinner(0);
      return result.body.data || result.body;
    }
  }

  displayErrorMsg(error) {
    this.spinnerService.toggleSpinner(0);
    this.dataService.broadcast('alert', {
      type: 'danger',
      message: error && error.error && error.error.errorDetails ? error.error.errorDetails :
        error && error.error && error.error.message ? error.error.message : 'Network error please try again'
    });
  }
  failureCase(error) {
    this.spinnerService.toggleSpinner(0);
    this.dataService.broadcast('alert', {
      type: 'danger',
      message: error && error.error && error.error.errorDetails ? error.error.errorDetails :
        error && error.error && error.error.message ? error.error.message :
          error ? error : 'Network error please try again'
    });
  }
  selectVersion(event) {
    let description = "";
    let number = "";
    let estimatedUpdateTime = "";
    let releaseNotes = "";
    let longDescription = "";
    let versionName = "";
    if (this.viewSoftwareData && this.viewSoftwareData.versions && this.viewSoftwareData.versions.length > 0
      && this.event.versions && this.event.versions.length > 0) {
      this.viewSoftwareData.versions.forEach((value, index) => {
        if (value.number === this.event.versions[index].number && value.description === this.event.versions[index].description) {
          this.viewSoftwareData.versions[index].name = this.event.versions[index].name;
          this.viewSoftwareData.versions[index].number = this.event.versions[index].number;
        }
      });
      this.selectedVersion = this.viewSoftwareData.versions.findIndex(version => version.name === event.value);
      this.oldVersionNumber = this.cms.deepCopyOfObject(this.viewSoftwareData.versions[this.selectedVersion].number);
      this.viewSoftwareData.versions.forEach((value, index) => {
        if (value.name === event.value) {
          description = this.viewSoftwareData.versions[index].description;
          number = this.viewSoftwareData.versions[index].number;
          estimatedUpdateTime = this.viewSoftwareData.versions[index].estimatedUpdateTime;
          releaseNotes = this.viewSoftwareData.versions[index].releaseNotes;
          longDescription = this.viewSoftwareData.versions[index].longDescription;
          versionName = this.viewSoftwareData.versions[index].name;
        }
      });
    }
    if (this.isEdit) {
      this.updateSoftwareDetailsObj['softwaredescription'] = description;
      this.updateSoftwareDetailsObj['softwarenumber'] = number;
      this.updateSoftwareDetailsObj['softwareestimatedUpdateTime'] = estimatedUpdateTime;
      this.updateSoftwareDetailsObj['softwarelongDescription'] = longDescription;
      this.updateSoftwareDetailsObj['softwarereleaseNotes'] = releaseNotes;
      this.updateSoftwareDetailsObj['name'] = versionName;
    } else if (this.isView) {
      this.viewSoftwareData.versions['softwaredescription'] = description;
      this.viewSoftwareData.versions['softwarenumber'] = number;
      this.viewSoftwareData.versions['softwareestimatedUpdateTime'] = estimatedUpdateTime;
      this.viewSoftwareData.versions['softwarelongDescription'] = longDescription;
      this.viewSoftwareData.versions['softwarereleaseNotes'] = releaseNotes;
      this.viewSoftwareData.versions['name'] = versionName;
    }

  }
  getInstallerDetails() {
    this.spinnerService.toggleSpinner(1);
    this.sms.getInstallerDetails().subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        this.osList = this.successCase(result);
      },
      error => {
        this.failureCase(error);
      }
    );
  }
  populateOtherFields(id) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let data = {};
    if (this.domainParams) {
      data = {
        id,
        appendValue: true,
        domain: this.domainParams
      };
    } else {
      data = {
        id,
        appendValue: true
      };
    }

    this.sms.populateOtherFields(data).subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        const res = result.data;
        this.createNewSoftwareForm.controls.softwareFileMdsCheckSum.setValue(
          res.versions[0].md5Checksum
        );
        if (res.versions[0].md5Checksum == null || res.versions[0].md5Checksum == undefined) {
          this.createNewSoftwareForm.controls['softwareFileMdsCheckSum'].enable();
        }
        this.createNewSoftwareForm.controls.softwareName.setValue(res.name);

        if (res.name == null || res.name == undefined) {
          this.createNewSoftwareForm.controls['softwareName'].enable();
        }

        if (res.versions[0].name == null || res.versions[0].name == undefined) {
          this.createNewSoftwareForm.controls['versionName'].enable();
        }

        this.createNewSoftwareForm.controls.versionName.setValue(
          res.versions[0].name
        );

        if (res.versions[0].number == null || res.versions[0].number == undefined) {
          this.createNewSoftwareForm.controls['versionNumber'].enable();
        }
        this.createNewSoftwareForm.controls.versionNumber.setValue(
          res.versions[0].number
        );
        this.createNewSoftwareForm.controls.softwareId.setValue(res.scomoId);

        if (res.versions[0].scomoId == null || res.versions[0].scomoId == undefined) {
          this.createNewSoftwareForm.controls['softwareId'].enable();
        }
      },
      error => {
        this.createNewSoftwareForm.controls['versionNumber'].enable();
        this.createNewSoftwareForm.controls['softwareId'].enable();
        this.createNewSoftwareForm.controls['versionName'].enable();
        this.createNewSoftwareForm.controls['softwareName'].enable();
        this.createNewSoftwareForm.controls['softwareFileMdsCheckSum'].enable();
        this.failureCase(error);
      }
    );
  }
  getPlatforms() {
    this.domainParams = this.HeaderService.getSelectedDomain();
    var param = {
      'softwareType': 'SCOTA',
      'domainName': this.domainParams && this.domainParams.name ? this.domainParams.name : ''
    }
    this.sms.getPlatforms(param).subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        const data = this.successCase(result);
        this.serverPlatformsList = data.platforms;
        this.platformList = [];
        this.serverPlatformsList.forEach(platform => {
          this.platformList.push({
            name: platform.name + ' [' + platform.vendor + ']',
            id: platform.id
          });
        });
      },
      error => {
        this.failureCase(error);
      }
    );
  }

  /**
   * Get EnterPrise Ids
   */
  getEnterPriseId(page?) {
    let obj = {};
    if (page) {
      this.currentPageOfEnterpriseModal = page;
      obj = { limit: 10, offset: (page - 1) * 10, page: page, pageNum: page, rpp: 10 };
    } else {
      this.currentPageOfEnterpriseModal = 1;
      obj = { limit: 10, offset: 1, page: 1, pageNum: 1, rpp: 10 };
    }
    const totalEnterPriseCount = this.sms.getTotalCountEnterprises();
    const totalEnterpriseResult = this.sms.getVendorList(obj);
    //this.selectedEnterpriseCount = 0;
    forkJoin([totalEnterPriseCount, totalEnterpriseResult]).subscribe(results => {
      this.spinnerService.toggleSpinner(0);
      if (results[1] && results[1].data && results[1].data.length > 0) {
        this.enterprisemodels = [];
        let count = 0;
        results[1].data.forEach(models => {
          let modelSelected = false;
          if (this.selectedEnterpriseModals && this.selectedEnterpriseModals.length > 0) {
            this.selectedEnterpriseModals.forEach(selctedData => {
              if (selctedData.id == models.hqBpId) {
                modelSelected = true;
              }
            })
          }
          count = this.selectedEnterpriseModals.length;
          // if (this.selectedEnterpriseModals.includes(models.hqBpName)) {
          //   modelSelected = true;
          //   count++;
          // }
          this.enterprisemodels.push({
            selected: modelSelected,
            id: models.hqBpId,
            name: models.hqBpName
          });
        });
        this.selectEnterpriseAll = this.enterprisemodels.every(model => {
          return model.selected === true;
        });
        this.selectedEnterpriseCount = count;
        this.enterpriseIdsArray = results[1].data;
      }
      if (results[0] && results[0].data) {
        this.enterpriseModelsListCount = results[0].data;
      }
    }, error => {
      this.enterpriseIdsArray = [];
      this.failureCase(error);
    });
    // return new Promise((resolve, reject) => {
    //   this.http.get('assets/dropdown-json/getEnterpriseIds.json').subscribe((response: any) => {
    //     if (response) {
    //       this.enterprisemodels = [];
    //       let count = 0;
    //       response.data.forEach(models => {
    //         let modelSelected = false;
    //         if (this.selectedEnterpriseModals.includes(models.hqBpName)) {
    //           modelSelected = true;
    //           count++;
    //         }
    //         this.enterprisemodels.push({
    //           selected: modelSelected,
    //           name: models.id,
    //           model: models.hqBpName
    //         });
    //       });
    //       this.selectEnterpriseAll = this.enterprisemodels.every(model => {
    //         return model.selected === true;
    //       });
    //       this.selectedEnterpriseCount = count;
    //       this.enterpriseIdsArray = response.data;
    //     }
    //     resolve(true);
    //   });
    // });
  }

  getInstallerTypes(event) {
    this.installerList = [];
    this.serverPlatformsList.forEach(platform => {
      if (platform.id === event.value) {
        this.installerList = platform.installerTypes;
      }
    });
  }

  checkFormat(type) {
    if (type === 'apk' || type === 'zip' || type === 'tar' || type === 'gz') {
      return true;
    } else {
      return false;
    }

  }

  fileEvent($event) {
    this.uploadedFile = $event.target.files[0];
    this.uploadedFileName = this.uploadedFile.name;
    const dotPos = this.uploadedFile.name.lastIndexOf('.');
    if (this.uploadedFile.name.lastIndexOf('.') > 0) {
      this.fileExtension = this.uploadedFile.name.substring(
        dotPos + 1,
        this.uploadedFile.name.length
      );
    }
    if (this.fileExtension.toLowerCase() === 'apk' || this.fileExtension.toLowerCase() === 'zip'
      || this.fileExtension.toLowerCase() === 'tar' || this.fileExtension.toLowerCase() === 'gz') {
      this.createNewSoftwareForm.controls.uploadFile.setValue(
        this.uploadedFileName
      );
      this.fileSubmitReq = new FormData();
      this.fileSubmitReq.append('file', this.uploadedFile);
    }
    // if (this.fileExtension.toLowerCase() === 'zip') {
    //   this.createNewSoftwareForm.controls.uploadFile.setValue(
    //     this.uploadedFileName
    //   );
    //   this.fileSubmitReq = new FormData();
    //   this.fileSubmitReq.append('file', this.uploadedFile);
    // }
  }
  getPlatFormName(id) {
    let platformName;
    this.serverPlatformsList.forEach(platform => {
      if (platform.id === id) {
        platformName = platform.name;
      }
    });
    return platformName;
  }

  uploadNewFileData() {
    this.searchModel = "";
    this.deviceSearchModel = "";
    this.domainParams = this.HeaderService.getSelectedDomain();
    this.spinnerService.toggleSpinner(1);

    this.fileSubmitReq.append(
      'type',
      this.createNewSoftwareForm.controls.instllerType.value
    );
    this.fileSubmitReq.append(
      'vendor',
      this.createNewSoftwareForm.controls.vendor.value
    );
    this.fileSubmitReq.append(
      'domainName',
      this.domainParams.name
    );

    if (this.createNewSoftwareForm.controls.description.value) {
      this.fileSubmitReq.append(
        'description',
        this.createNewSoftwareForm.controls.description.value
      );
    }
    if (this.createNewSoftwareForm.controls.longDescription.value) {
      this.fileSubmitReq.append(
        'longDescription', this.createNewSoftwareForm.controls.longDescription.value
      );
    }
    if (this.createNewSoftwareForm.controls.whatsnew.value) {
      this.fileSubmitReq.append(
        'releaseNotes',
        this.createNewSoftwareForm.controls.whatsnew.value
      );
    }
    this.fileSubmitReq.append(
      'platformType',
      this.isCreateNew ? this.createNewSoftwareForm.controls.platform.value : this.createNewSoftwareForm.controls.platFormType.value
    );
    this.fileSubmitReq.append(
      'platformName',
      this.isCreateNew ? this.getPlatFormName(this.createNewSoftwareForm.controls.platform.value) : this.createNewSoftwareForm.controls.platform.value
    );
    // this.fileSubmitReq.append(
    //   'estimatedUpdateTime', this.createNewSoftwareForm.controls.esttimeInSec.value
    // );

    this.fileSubmitReq.append(
      'applicableForRollback', this.createNewSoftwareForm.controls.supportRollback.value
    );
    /***** removed-enterprise ****/
    // let EnterpriseId = [];
    // if (this.viewSoftwareEnterpriseData && this.viewSoftwareEnterpriseData.length > 0) {
    //   this.viewSoftwareEnterpriseData.forEach(element => {
    //     EnterpriseId.push( element.id);
    //   });
    // }
    // this.fileSubmitReq.append(
    //   'enterpriseIds', EnterpriseId
    // );
    /***** removed-enterprise ****/
    if (this.isNewVersion) {
      this.fileSubmitReq.append(
        'packageId', this.createNewSoftwareForm.controls.packageId.value
      );
    }

    this.domainParams = this.HeaderService.getSelectedDomain();
    let domainRequestParams = {};
    if (this.domainParams) {
      domainRequestParams = this.domainParams;
    }
    this.sms.uploadNewFileData(this.fileSubmitReq, this.isNewVersion, domainRequestParams).subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        this.packageId = res.id;
        if (this.packageId) {
          this.createNewSoftwareForm.controls['uploadFile'].disable();

          this.createNewSoftwareForm.controls['instllerType'].disable();

          this.createNewSoftwareForm.controls['platform'].disable();

          this.createNewSoftwareForm.controls['vendor'].disable();

          this.createNewSoftwareForm.controls['description'].disable();

          this.createNewSoftwareForm.controls['description'].disable();

          this.createNewSoftwareForm.controls['longDescription'].disable();

          this.createNewSoftwareForm.controls['whatsnew'].disable();

          this.createNewSoftwareForm.controls['softwareId'].disable();

        }
        if (this.isNewVersion) {
          this.newVersionPackageId = res.id;
        }
        this.populateOtherFields(res.id);
      },
      error => {
        //this.packageId = false;
        this.spinnerService.toggleSpinner(0);
        this.fileSubmitReq = new FormData();
        this.fileSubmitReq.append('file', this.uploadedFile);
        this.failureCase(error);
      }
    );

  }


  uploadFileData() {
    this.domainParams = this.HeaderService.getSelectedDomain();
    this.searchModel = "";
    this.deviceSearchModel = "";
    let EnterpriseId = [];
    this.spinnerService.toggleSpinner(1);
    if (this.viewSoftwareEnterpriseData && this.viewSoftwareEnterpriseData.length > 0) {
      this.viewSoftwareEnterpriseData.forEach(element => {
        EnterpriseId.push({ id: element.id, name: element.name });
      });
    }
    this.fileSubmitReq.append(
      'type',
      this.createNewSoftwareForm.controls.instllerType.value
    );
    if (!this.isNewVersion) {
      this.fileSubmitReq.append(
        'vendor',
        this.createNewSoftwareForm.controls.vendor.value
      );
    }
    this.fileSubmitReq.append(
      'domainName',
      this.domainParams.name
    );
    if (this.createNewSoftwareForm.controls.description.value) {
      this.fileSubmitReq.append(
        'description',
        this.createNewSoftwareForm.controls.description.value
      );
    }
    if (this.createNewSoftwareForm.controls.longDescription.value) {
      this.fileSubmitReq.append(
        'longDescription', this.createNewSoftwareForm.controls.longDescription.value
      );
    }
    if (this.createNewSoftwareForm.controls.whatsnew.value) {
      this.fileSubmitReq.append(
        'releaseNotes',
        this.createNewSoftwareForm.controls.whatsnew.value
      );
    }
    if (this.createNewSoftwareForm.controls.whatsnew.value) {
      this.fileSubmitReq.append(
        'releaseNotes',
        this.createNewSoftwareForm.controls.whatsnew.value
      );
    }

    this.fileSubmitReq.append(
      'platformType',
      this.isCreateNew ? this.createNewSoftwareForm.controls.platform.value : this.createNewSoftwareForm.controls.platFormType.value
    );
    this.fileSubmitReq.append(
      'platformName',
      this.isCreateNew ? this.getPlatFormName(this.createNewSoftwareForm.controls.platform.value) : this.createNewSoftwareForm.controls.platform.value
    );
    // this.fileSubmitReq.append(
    //   'estimatedUpdateTime', this.createNewSoftwareForm.controls.esttimeInSec.value
    // );
    this.fileSubmitReq.append(
      'applicableForRollback', this.createNewSoftwareForm.controls.supportRollback.value
    );
    this.fileSubmitReq.append(
      'enterpriseIds', EnterpriseId
    );
    if (this.isNewVersion) {
      this.fileSubmitReq.append(
        'packageId', this.createNewSoftwareForm.controls.packageId.value
      );
    }

    let queryParan = {
      'type': this.createNewSoftwareForm.controls.instllerType.value,
      'vendor': this.createNewSoftwareForm.controls.vendor.value,
      'domainName': this.domainParams.name,
      'description': this.createNewSoftwareForm.controls.description.value,
      'longDescription': this.createNewSoftwareForm.controls.longDescription.value,
      'releaseNotes': this.createNewSoftwareForm.controls.whatsnew.value,
      'platformType': this.isCreateNew ? this.createNewSoftwareForm.controls.platform.value : this.createNewSoftwareForm.controls.platFormType.value,
      'platformName': this.isCreateNew ? this.getPlatFormName(this.createNewSoftwareForm.controls.platform.value) : this.createNewSoftwareForm.controls.platform.value,
      //'estimatedUpdateTime': this.createNewSoftwareForm.controls.esttimeInSec.value,
      'applicableForRollback': this.createNewSoftwareForm.controls.supportRollback.value,
      'packageId': this.createNewSoftwareForm.controls.packageId.value

    }
    this.domainParams = this.HeaderService.getSelectedDomain();
    let domainRequestParams = {};
    if (this.domainParams) {
      domainRequestParams = this.domainParams;
    }
    this.sms.uploadFileData(this.fileSubmitReq, this.isNewVersion, domainRequestParams, queryParan).subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        this.packageId = res.id;
        if (this.packageId) {
          this.createNewSoftwareForm.controls['uploadFile'].disable();
        }
        if (this.isNewVersion) {
          this.newVersionPackageId = res.id;
        }
        this.populateOtherFields(res.id);
      },
      error => {
        //this.packageId = false;
        this.spinnerService.toggleSpinner(0);
        this.fileSubmitReq = new FormData();
        this.fileSubmitReq.append('file', this.uploadedFile);
        this.failureCase(error);
      }
    );
  }
  getModalsData() {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let reqData = {
      platformId: this.createNewSoftwareForm
        ? this.createNewSoftwareForm.controls.platform.value
        : this.viewSoftwareData.platformType
    };
    if (this.isNewVersion) {
      reqData = {
        platformId: this.viewSoftwareData.platformType
      };
    }
    if (this.domainParams) {
      reqData['domainId'] = this.domainParams.id;
      reqData['domainName'] = this.domainParams.name;
    }
    this.openModal(this.mapModelsTemplate, 'lg');
    this.spinnerService.toggleSpinner(1);
    this.sms.getModalsData(reqData).subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        this.models = [];
        let count = 0;
        res.deviceModelRepresentation.forEach(models => {
          let modelSelected = false;
          if (this.selectedModals && this.selectedModals.length > 0) {
            this.selectedModals.forEach(selctedData => {
              if (selctedData.name == models.name) {
                modelSelected = true;
              }
            })
          }
          // if (this.selectedModals.includes(models.name)) {
          //   modelSelected = true;
          //   count++;
          //  }
          this.models.push({
            selected: modelSelected,
            name: models.vendor,
            model: models.name
          });
        });

        if (this.viewSoftwareData && this.viewSoftwareData.deviceModels) {
          this.models.forEach(element => {
            this.viewSoftwareData.deviceModels.forEach(innerElement => {
              if (element.model == innerElement.name) {
                element.selected = true;
              }
            });
          });
        }

        this.selectAll = this.models.every(model => {
          return model.selected === true;
        });
        //this.selectedModelsCount = count;
        this.selectedModelsCount = this.selectedModals.length;
      },
      error => {
        this.failureCase(error);
      }
    );
  }
  changeStatusData(event) {
    if (event && event.value) {
      this.selectedStatusInfo = event.value;
    }
  }

  setAppplicationStatus(close) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    const params = {
      "associatedId": this.viewSoftwareData.versions[this.selectedVersion].associatedId ?
        this.viewSoftwareData.versions[this.selectedVersion].associatedId : '',
      "domain": {
        "name": this.domainParams && this.domainParams.name ? this.domainParams.name : '',
        "id": this.domainParams && this.domainParams.id ? this.domainParams.id : ''
      },
      "packageId": this.viewSoftwareData && this.viewSoftwareData.id ? this.viewSoftwareData.id : '',
      "status": "ComponentVersionStatus." + this.selectedStatusInfo
    };
    this.spinnerService.toggleSpinner(1);
    this.sms.setAppplicationStatus(params).subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Status Update Successfully'
        });
        this.viewSoftwareData.versions[this.selectedVersion].status = this.selectedStatusInfo;
        this.closeModal(close);
      },
      error => {
        this.spinnerService.toggleSpinner(0);
      }
    );
  }

  changeAppStatus(statusData) {
    if (statusData) {
      this.selectedStatusInfo = statusData.versions && statusData.versions.length > 0 ?
        statusData.versions[this.selectedVersion].status : '';
    }
    this.openModal(this.changeAppStatusTemplate, 'sm');
  }

  saveSelectedEnterprise(close) {
    //this.checkEnterpriseAllSelectdOrNot()
    this.viewSoftwareEnterpriseData = this.selectedEnterpriseModals;
    this.closeModal(close);
  }

  saveSelectedModals(close) {
    this.checkAllSelectdOrNotForDevices();
    let selectedModal = {};
    if (this.installModels) {
      selectedModal = this.installModels[this.installModels.findIndex(deviceModal => deviceModal.name == this.selectedDeviceModal[0])];
      const selcetedDevicesCount = this.selectedDeviceNames.filter(data => {
        return data.model === selectedModal['name'];
      });

      if (this.notSelectAnyDevices) {
        selectedModal['indeterminate'] = false;
        selectedModal['checked'] = false;
      } else if (this.selectAllDevices) {
        if (selcetedDevicesCount.length === this.deviceModelsListCount) {
          selectedModal['indeterminate'] = false;
          selectedModal['checked'] = true;
        } else {
          selectedModal['indeterminate'] = true;
          selectedModal['checked'] = false;
        }
      } else {
        selectedModal['indeterminate'] = true;
        selectedModal['checked'] = false;
      }
    }

    this.closeModal(close);
  }

  // if (this.viewSoftwareEnterpriseData && this.viewSoftwareEnterpriseData.length > 0) {
  //   this.viewSoftwareEnterpriseData.forEach(element => {
  //     EnterpriseId.push(element.name);
  //   });
  // } viewSoftwareData.deviceModels.length

  openModelPopup(form, button) {
    // if (form.valid) {
    //   if (button === 'openModal') {
    //     this.getModalsData();
    //   }
    //   else if (button === 'openEnterpriseModal') {
    //     this.openEnterpriseModal();
    //   }
    // } else {
    //   this.cms.validateAllFormFields(form);
    // }

    if (button === 'openModal') {
      this.searchModel = "";
      this.getModalsData();
    }
    else if (button === 'openEnterpriseModal') {
      this.deviceSearchModel = "";
      this.openEnterpriseModal();
    }
  }

  submitExecuteForm(form, button) {
    if (form.valid) {
      if (button === 'execute' || button === 'executeSave') {
        this.searchModel = "";
        this.installSoftwareWithDevices(button);
      }
    }
  }

  submitForm(form, button) {
    // if (button === 'upload') {
    //   if (this.viewSoftwareEnterpriseData && this.viewSoftwareEnterpriseData.length <= 0) {
    //     this.validSoftwareEnterprise = true;
    //   }
    // }
    if (button === 'save') {
      if (this.viewSoftwareEnterpriseData && this.viewSoftwareEnterpriseData.length <= 0) {
        this.validSoftwareEnterprise = true;
      }
    }
    if (form.valid && (button !== 'execute' || button !== 'executeSave') &&
      (this.viewSoftwareEnterpriseData && this.viewSoftwareEnterpriseData.length > 0
        && (this.isNewVersion || (this.selectedModals && this.selectedModals.length > 0)) || button === 'upload' || button === 'uploadVersion')) {

      this.validSoftwareEnterprise = false;
      this.validDeviceModels = false;
      this.selectAll = false;
      this.selectEnterpriseAll = false;
      this.selectAllDevices = "";
      if (button === 'save') {
        if (this.isCreateNew) {
          this.saveSoftware();
        } else {
          this.hideTable();
          this.router
            .navigateByUrl('../main', { skipLocationChange: true })
            .then(() => this.router.navigate(['../main/psapps']));
        }
      } else if (button === 'upload') {
        this.uploadNewFileData();
      } else if (button === 'execute' || button === 'executeSave') {
        this.installSoftwareWithDevices(button);
      }
      else if (button === 'openModal') {
        this.getModalsData();
      }
      else if (button === 'openEnterpriseModal') {
        this.openEnterpriseModal();
      } else if (button === 'uploadVersion') {
        this.uploadFileData();
      }

    } else {
      if (this.viewSoftwareEnterpriseData && this.viewSoftwareEnterpriseData.length > 0) {
        this.validSoftwareEnterprise = false;
      } else {
        if (button === 'save') {
          this.validSoftwareEnterprise = true;
        }
      }
      if (this.selectedModals && this.selectedModals.length > 0) {
        this.validDeviceModels = false;
      } else {
        if (button === 'save') {
          this.validDeviceModels = true;
        }
      }
      this.cms.validateAllFormFields(form);
    }
  }
  openEnterpriseModal() {
    this.selectEnterpriseAll = false;
    let count = 0;
    if (this.enterprisemodels && this.enterprisemodels.length > 0) {
      this.enterprisemodels.map(model => {
        model.selected = false;
      });
    }
    if (this.viewSoftwareEnterpriseData) {
      this.enterprisemodels.forEach(element => {
        this.viewSoftwareEnterpriseData.forEach(innerelement => {
          if (this.isEdit) {
            if (element.id == innerelement.id) {
              element.selected = true;
              count++;
            }
          } else {
            if (element.id == innerelement.id) {
              element.selected = true;
              count++;
            }
          }

        });
      });
      this.selectedEnterpriseCount = this.selectedEnterpriseModals && this.selectedEnterpriseModals.length > 0 ?
        this.selectedEnterpriseModals.length : count;
      this.selectEnterpriseAll = this.enterprisemodels.every(model => {
        return model.selected === true;
      });
    }
    this.openModal(this.mapEnterpriseTemplate, 'lg');
  }
  addNewVersionSoftware() {
    this.updateSoftware(this.createNewSoftwareForm.value);
  }
  getAllPackages() {
    this.spinnerService.toggleSpinner(1);
    this.sms.getAllPackages().subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        this.osList = this.successCase(result);
      },
      error => {
        this.failureCase(error);
      }
    );
  }
  getEmptyData(obj) {
    this.data = {
      page: 1,
      total: 1,
      data: []
    };
  }
  getData(obj) {
    this.getActions();
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = {
        "limit": obj.limit,
        "offset": obj.offset,
        domainName: this.domainParams.name,
      };
    } else {
      params = { "limit": obj.limit, "offset": obj.offset }
    }
    let packages = [];
    this.spinnerService.toggleSpinner(1);
    this.sms.getSoftwareDetails(params).subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        packages = res.items.map(data => {
          if (data.versions && data.versions.length > 0) {
            let versionArr = [];
            const versionLength = data.versions.length - 1;
            //const versionLength = this.selectedVersion;
            data.versionName = data.versions[data.versions.length - 1].name;
            //data.versionName = data.versions[this.selectedVersion].name;
            data.versions.forEach((value, index) => {
              if (versionLength === index) {
                versionArr.push({ name: value.name, number: value.number, description: value.description, verionIndex: index, versionStatus: true });
              } else {
                versionArr.push({ name: value.name, number: value.number, description: value.description, verionIndex: index, versionStatus: false });
              }

            });
            //data.versionName =  data.versions[data.versions.length - 1].name + ((data.versions && data.versions.length > 1) ? '(' + (data.versions.length - 1) + ')' : '');
            data.versions = versionArr;
            data.description = data.versions[data.versions.length - 1].description;
            //data.description = data.versions[this.selectedVersion].description;
          } else {
            data.versionName = '-';
            data.description = "-";
          }
          data.modals = data.deviceModels;
          data.elementType = "select";
          return data;
        });
        this.data = {
          page: obj.page,
          total: res.totalCount,
          data: packages
        };
      },
      error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.displayErrorMsg(error);
      }
    );
  }

  getDataBySearch(data) {
    this.getActions();
    let obj;
    obj = this.sms.getObject(data);
    obj.limit = 10;
    obj.offset = 0;
    this.domainParams = this.HeaderService.getSelectedDomain();
    if (this.domainParams) {
      obj.domainName = this.domainParams.name;
    }
    this.spinnerService.toggleSpinner(1);
    this.sms.getSoftwareDetails(obj).subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        const packages = res.items.map(data => {
          if (data.versions && data.versions.length > 0) {
            let versionArr = [];
            const versionLength = data.versions.length - 1;
            //const versionLength = this.selectedVersion;
            data.versionName = data.versions[data.versions.length - 1].name;
            //data.versionName = data.versions[this.selectedVersion].name;
            data.versions.forEach((value, index) => {
              if (versionLength === index) {
                versionArr.push({ name: value.name, number: value.number, description: value.description, verionIndex: index, versionStatus: true });
              } else {
                versionArr.push({ name: value.name, number: value.number, description: value.description, verionIndex: index, versionStatus: false });
              }

            });
            //data.versionName =  data.versions[data.versions.length - 1].name + ((data.versions && data.versions.length > 1) ? '(' + (data.versions.length - 1) + ')' : '');
            data.versions = versionArr;
            data.description = data.versions[data.versions.length - 1].description;
            //data.description = data.versions[this.selectedVersion].description;
          } else {
            data.versionName = '-';
            data.description = "-";
          }
          data.elementType = "select";
          data.modals = data.deviceModels;
          return data;
        });
        this.data = {
          page: obj.page,
          total: res.totalCount,
          data: packages
        };

      },
      error => {
        this.data = {
          page: 1,
          total: 0,
          data: []
        };
        this.displayErrorMsg(error);
      }
    );
  }

  updateSoftware(data?) {
    if (this.viewSoftwareEnterpriseData && this.viewSoftwareEnterpriseData.length > 0
      && this.viewSoftwareData && this.viewSoftwareData.deviceModels && this.viewSoftwareData.deviceModels.length > 0) {
      let EnterpriseId = [];
      this.viewSoftwareEnterpriseData.forEach(element => {
        EnterpriseId.push({ id: element.id, name: element.name });
      });
      this.domainParams = this.HeaderService.getSelectedDomain();
      const req = {

        id: data ? data.packageId : this.event.id,

        packageName: data ? data.softwareId : this.viewSoftwareData.name ? this.viewSoftwareData.name : this.event.name,

        versionNumber: data ? data.versionNumber : this.updateSoftwareDetailsObj['softwarenumber'],

        versionName: data ? data.versionName : this.updateSoftwareDetailsObj['name'],

        description: data ? data.description : this.updateSoftwareDetailsObj['softwaredescription'],

        longDescription: data ? data.longDescription : this.updateSoftwareDetailsObj['softwarelongDescription'],

        releaseNotes: data ? data.whatsnew : this.updateSoftwareDetailsObj['softwarereleaseNotes'],

        //estimatedUpdateTime: data ? data.esttimeInSec : this.updateSoftwareDetailsObj['softwareestimatedUpdateTime'],

        deviceModels: data ? this.selectedModals : this.viewSoftwareData.deviceModels,
        oldVersionNumber: this.oldVersionNumber,
        applicableForRollback: data ? data.applicableForRollback : this.updateSoftwareDetailsObj['applicableForRollback'],
        enterpriseIds: EnterpriseId ? EnterpriseId : this.event.enterpriseIds,
        domain: this.domainParams ? this.domainParams : ''
      };
      this.spinnerService.toggleSpinner(1);
      this.sms.updateSoftware(req).subscribe(
        result => {
          this.searchModel = "";
          this.deviceSearchModel = "";
          this.spinnerService.toggleSpinner(0);
          this.hideTable();
          this.router
            .navigateByUrl('../main', { skipLocationChange: true })
            .then(() => this.router.navigate(['../main/psapps']));
        },
        error => {
          this.failureCase(error);
        }
      );
    }
  }
  saveSoftware() {
    let EnterpriseId = [];
    if (this.viewSoftwareEnterpriseData && this.viewSoftwareEnterpriseData.length <= 0) {
      this.validSoftwareEnterprise = true;
      return false;
    }
    this.spinnerService.toggleSpinner(1);
    if (this.viewSoftwareEnterpriseData && this.viewSoftwareEnterpriseData.length > 0) {
      this.viewSoftwareEnterpriseData.forEach(element => {
        EnterpriseId.push({ id: element.id, name: element.name });
      });
    }
    const req = {
      id: !this.isEdit ? this.packageId : this.viewSoftwareData.id,
      versionNumber: !this.isEdit
        ? this.createNewSoftwareForm.controls.versionNumber.value
        : this.viewSoftwareData.versions[0].number,
      packageName: !this.isEdit ? this.createNewSoftwareForm.controls['softwareName'].value : this.viewSoftwareData.name,
      versionName: !this.isEdit ? this.createNewSoftwareForm.controls['versionName'].value : this.viewSoftwareData.versions[0].name,
      scomId: !this.isEdit ? this.createNewSoftwareForm.controls['softwareId'].value : this.viewSoftwareData.versions[0].scomId,
      deviceModels: this.selectedModals,
      enterpriseIds: EnterpriseId
    };
    if (this.isCreateNew) {
      req['platformType'] = !this.isEdit
        ? this.createNewSoftwareForm.controls.platform.value
        : this.viewSoftwareData.platformType;
    }
    if (req.deviceModels.length === 0) {
      this.hideTable();
      this.spinnerService.toggleSpinner(0);
      this.router
        .navigateByUrl('../main', { skipLocationChange: true })
        .then(() => this.router.navigate(['../main/psapps']));
    } else {
      this.domainParams = this.HeaderService.getSelectedDomain();
      req['domain'] = this.domainParams ? this.domainParams : '';
      this.sms.saveSoftware(req).subscribe(
        result => {
          this.searchModel = "";
          this.deviceSearchModel = "";
          this.hideTable();
          this.spinnerService.toggleSpinner(0);
          this.router
            .navigateByUrl('../main', { skipLocationChange: true })
            .then(() => this.router.navigate(['../main/psapps']));
        },
        error => {
          this.displayErrorMsg(error);
        }
      );
    }

  }

  openModal(content, size) {
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal user-onboard',
        size,
        backdrop: 'static',
        keyboard: false
      })
      .result.then(
        result => { },
        reason => { }
      );
  }
  closeModal(close) {
    close('Cross click');
  }
  createSoftwareFormBlock() {
    this.createNewSoftwareForm = this.fb.group({
      platform: [''],
      platFormType: [''],
      packageId: [''],
      instllerType: [''],
      supportsRollback: [''],
      uploadFile: [{
        value: '',
        disabled: false
      }],
      softwareFileMdsCheckSum: [
        {
          value: '',
          disabled: true
        }
      ],
      softwareName: [{
        value: '',
        disabled: true
      }],
      versionName: [{
        value: '',
        disabled: true
      }],
      versionNumber: [{
        value: '',
        disabled: true
      }],
      vendor: [''],
      softwareId: [{
        value: '',
        disabled: true
      }],
      description: [''],
      longDescription: [''],
      //esttimeInSec: [''],
      whatsnew: [''],
      deviceModals: [''],
      supportRollback: [false]
    });
  }

  addNewSoftware() {
    this.viewSoftwareEnterpriseData = [];
    this.selectedEnterpriseCount = 0;
    this.selectedEnterpriseModals = [];
    this.searchModel = "";
    this.deviceSearchModel = "";
    this.selectEnterpriseAll = false;
    if (this.enterprisemodels && this.enterprisemodels.length > 0) {
      this.enterprisemodels.map(model => {
        model.selected = false;
      });
    }
    if (this.models && this.models.length > 0) {
      this.models.map(model => {
        model.selected = false;
      });
    }
    this.createSoftwareFormBlock();
    this.hideTable();
    this.isCreateNew = !this.isCreateNew;
    this.isInstallSoftware = false;
    this.isEdit = false;
    this.isView = false;
    this.getEnterPriseId();
  }
  deleteSoftware(event) {
    this.event = event;
    this.openModal(this.deleteConfirmModalContent, 'sm');
  }
  deleteVersion(event) {
    this.event = event;
    this.openModal(this.deleteVersionConfirmModalContent, 'sm');
  }
  deleteApp(close) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = { "ids": this.event.id, "domainName": this.domainParams.name };
    } else {
      params = { "ids": this.event.id, "domainName": this.domainParams.name };
    }
    this.sms.deleteApp(params).subscribe(result => {
      this.spinnerService.toggleSpinner(0);
      this.dataService.broadcast('alert', {
        type: 'success',
        message: 'Delete successfully'
      });
      const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
      this.getData(event);
      this.closeModal(close);
    },
      error => {
        this.failureCase(error);
      });
  }

  deleteAppVersion(close) {
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    const versionNumber = this.event && this.event.versions && this.event.versions && this.event.versions[this.selectedVersion] &&
      this.event.versions[this.selectedVersion].number ?
      this.event.versions[this.selectedVersion].number : this.event.versions[0].number;
    if (this.domainParams) {
      params = { "id": this.event.id, "domainName": this.domainParams.name, "versionNumber": versionNumber };
    } else {
      params = { "id": this.event.id, "domainName": this.domainParams.name, "versionNumber": versionNumber };
    }
    this.spinnerService.toggleSpinner(1);
    this.sms.deleteAppVersion(params).subscribe(result => {
      this.spinnerService.toggleSpinner(0);
      this.dataService.broadcast('alert', {
        type: 'success',
        message: 'Delete App Version Successfully'
      });
      this.hideTable();
      this.spinnerService.toggleSpinner(0);
      const event = { appendUserId: true, limit: 10, offset: 0, page: 1, pageNum: 1, rpp: 10 }
      this.getData(event);
      this.closeModal(close);
    },
      error => {
        this.failureCase(error);
      });
  }

  changeServerStatus(event) {
    if (event && event.value && event.value === 'scheduled') {
      this.scheduleType = true;
    } else {
      this.scheduleType = false;
    }
  }

  installSoftware(event, value?) {
    this.searchModel = "";
    this.deviceSearchModel = "";
    this.event = event;
    this.diffDays = "";
    this.selectedDeviceNames = [];
    this.installSoftwareFormBlock();
    if (!value) {
      this.hideTable();
    }
    this.selectedDeviceIds = [];
    this.isInstallSoftware = !this.isInstallSoftware;
    this.isCreateNew = false;
    this.scheduleType = false;
    this.isEdit = false;
    this.isView = false;
    this.isNewVersion = false;
    if (event.deviceModels) {
      this.installModels = event.deviceModels.map(element => {
        element['indeterminate'] = false;
        element['checked'] = false;
        return element;
      });
    } else {
      this.installModels = [];
    }
    if (this.deviceModelsList && this.deviceModelsList.length > 0) {
      this.deviceModelsList.map(element => {
        element['selected'] = false;
        element['checked'] = false;
        return element;
      });
    }


    this.installSoftwareDetails = event;

    this.domainParams = this.HeaderService.getSelectedDomain();
    let param = {
      'domainName': this.domainParams.name
    }
    this.sms.getDefaultTimeZones(param).subscribe(result => {
      this.spinnerService.toggleSpinner(0);
      const res = this.successCase(result);
      this.zones = res;
    },
      error => {
        this.failureCase(error);
      }
    );
  }
  installSoftwareFormBlock() {
    this.installSoftwareForm = this.fb.group({
      modal: [''],
      targetDevices: 'All',
      campaignRetries: ['3'],

      campaignPriority: 'REGULAR',

      successMessage: '',

      failureMessage: '',

      isDraft: false,

      isServerInitiated: false,

      serverInitiatedInTimeZone: 'Asia/Kolkata',//Default India

      serverInitiatedFromTime: '',

      serverInitiatedToTime: '',

      campaignStartTime: '',
      campaignEndTime: '',
      downloadFromTime: '',
      downloadToTime: '',
      networkUsage: '',
      wifiExpirationDate: '',
      wifiExpirationTime: '',
      Quota: '',
      Timeframe: '',
      quotaType: '',
      timeFrameType: ''
    });
  }

  getDeviceModels(page) {
    this.currentPageOfDeviceModal = page;
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = {
        deviceModelNames: this.selectedDeviceModal,
        limit: 5,
        offset: (page - 1) * 5,
        // domainId: this.domainParams.id,
        domainName: this.domainParams.name
      };
    } else {
      params = {
        deviceModelNames: this.selectedDeviceModal,
        limit: 5,
        offset: (page - 1) * 5
      };
    }
    this.getDeviceDetailsAssociatedWithDeviceModel(params);
  }

  getDeviceDetailsAssociatedWithDeviceModel(req) {
    // this.domainParams=this.HeaderService.getSelectedDomain();
    // let params= {};
    // if (this.domainParams) {
    //   params=this.domainParams;
    // }
    req['action'] = "install";
    this.spinnerService.toggleSpinner(1);
    this.sms.getDeviceDetailsAssociatedWithDeviceModel(req).subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        this.deviceModelsList = res.deviceRepresentationInfo.map(device => {
          const deviceArray = device.status.terminal.split('.');
          device.status = deviceArray[1];
          if (this.selectedDeviceIds.includes(device.deviceDescription.deviceId)) {
            device.selected = true;
          } else {
            device.selected = false;
          }
          return device;
        });
        this.deviceModelsListCount = res.totalCount;
        this.selectAllDevices = this.deviceModelsList.every(device => {
          return device.selected === true;
        });
        this.notSelectAnyDevices = this.deviceModelsList.every(device => {
          return device.selected !== true;
        });
      },
      error => {
        this.failureCase(error);
      }
    );
  }

  openDevicesModel(event, data) {
    if (event.checked) {
      this.selectedDeviceModal = [];
      this.selectedDeviceModal.push(data.name);

      const selcetedDevicesIds = this.selectedDeviceNames.filter(selectedDevice => {
        return selectedDevice.model === data.name;
      });
      this.selectedDevicesCount = selcetedDevicesIds.length;
      this.deviceModelsList = [];
      // this.selectedDeviceIds = [];
      // this.selectedDeviceNames = [];
      this.openModal(this.devicesTemplate, 'lg');
      this.getDeviceModels(1);
    } else {

    }

  }
  modifyDevicesList() {
    this.openModal(this.devicesTemplate, 'lg');
    this.getDeviceModels(1);
  }

  viewData(event) {
    this.event = event;
    this.searchModel = "";
    this.deviceSearchModel = "";
    let enterpriseModel = [];
    this.selectedStatusInfo = "";
    // if (this.enterpriseIdsArray && this.enterpriseIdsArray.length > 0 && event.enterpriseIds && event.enterpriseIds.length > 0) {
    //   this.enterpriseIdsArray.forEach(value => {
    //     event.enterpriseIds.forEach(enterPriseId => {
    //       if (value.id === enterPriseId) {
    //         enterpriseModel.push({
    //           name: value.id,
    //           model: value.hqBpName
    //         })
    //       }
    //     });
    //   })
    // }
    if (event && event.enterpriseIds && event.enterpriseIds.length > 0) {
      event.enterpriseIds.forEach(value => {
        enterpriseModel.push({
          id: value.id,
          name: value.name
        })
      });
    }


    this.viewSoftwareEnterpriseData = enterpriseModel;
    this.domainParams = this.HeaderService.getSelectedDomain();
    let params = {};
    if (this.domainParams) {
      params = { "id": event.id, domainId: this.domainParams.id, domainName: this.domainParams.name };
    } else {
      params = { "id": event.id };
    }
    this.sms.getViewData(params).subscribe(result => {
      this.spinnerService.toggleSpinner(0);
      const res = result && result.data ? result.data : '';
      this.viewSoftwareData = res;
      if (this.viewSoftwareData && this.viewSoftwareData.versions && this.viewSoftwareData.versions.length > 0) {
        const selcetedVersionCount = this.event.versions.filter(data => {
          return data.versionStatus === true;
        });
        if (selcetedVersionCount && selcetedVersionCount.length > 0) {
          this.viewSoftwareData.versions.forEach((element, index) => {
            if (element.name === selcetedVersionCount[0].name && element.number === selcetedVersionCount[0].number) {
              this.selectedVersion = index;
            }
          });
        }
      }
      this.updateSoftwareDetailsObj = this.viewSoftwareData.versions[this.selectedVersion];
      this.updateSoftwareDetailsObj['softwaredescription'] = this.viewSoftwareData.versions[this.selectedVersion].description;
      this.updateSoftwareDetailsObj['softwarenumber'] = this.viewSoftwareData.versions[this.selectedVersion].number;
      this.updateSoftwareDetailsObj['softwareestimatedUpdateTime'] = this.viewSoftwareData.versions[this.selectedVersion].estimatedUpdateTime;
      this.updateSoftwareDetailsObj['softwarereleaseNotes'] = this.viewSoftwareData.versions[this.selectedVersion].releaseNotes;
      this.updateSoftwareDetailsObj['softwarelongDescription'] = this.viewSoftwareData.versions[this.selectedVersion].longDescription;
      this.updateSoftwareDetailsObj['name'] = this.viewSoftwareData.versions[this.selectedVersion].name;
      this.updateSoftwareDetailsObj['applicableForRollback'] = this.viewSoftwareData['applicableForRollback'];
      this.oldVersionNumber = this.cms.deepCopyOfObject(this.viewSoftwareData.versions[this.selectedVersion].number);
      this.updateSoftwareDetailsObj = this.viewSoftwareData.versions[this.selectedVersion];
      this.hideTable();
      this.isInstallSoftware = false;
      this.isCreateNew = false;
      this.isEdit = false;
      this.isNewVersion = false;
      this.isView = !this.isView;
    },
      error => {
        this.failureCase(error);
      });
  }

  editData(event, value?) {
    this.event = event;
    this.selectedEnterpriseCount = 0;
    this.selectedEnterpriseModals = [];
    this.searchModel = "";
    this.deviceSearchModel = "";
    if (!value) {
      this.hideTable();
    }
    this.isInstallSoftware = false;
    this.isCreateNew = false;
    this.isView = false;
    this.isNewVersion = false;
    this.isEdit = true;
    let enterpriseModel = [];
    this.selectedEnterpriseCount = 0;
    // if (this.enterpriseIdsArray && this.enterpriseIdsArray.length > 0 && event.enterpriseIds && event.enterpriseIds.length > 0) {
    //   this.enterpriseIdsArray.forEach(value => {
    //     event.enterpriseIds.forEach(enterPriseId => {
    //       if (value.id === enterPriseId) {
    //         enterpriseModel.push({
    //           name: value.id,
    //           model: value.hqBpName
    //         });
    //         this.selectedEnterpriseCount++;
    //       }
    //     });
    //   })
    // }
    if (event && event.enterpriseIds && event.enterpriseIds.length > 0) {
      event.enterpriseIds.forEach(value => {
        enterpriseModel.push({
          id: value.id,
          name: value.name
        });
        this.selectedEnterpriseModals.push({
          name: value.name,
          id: value.id
        })
        this.selectedEnterpriseCount++;
      });
    }
    this.getEnterPriseId();
    let params = {};
    if (this.domainParams) {
      params = { "id": event.id, domainName: this.domainParams.name };
    } else {
      params = { "id": event.id, "appendValue": true };
    }
    this.viewSoftwareEnterpriseData = enterpriseModel;
    this.sms.getEditData(params).subscribe(result => {
      this.spinnerService.toggleSpinner(0);
      const res = this.successCase(result);
      this.viewSoftwareData = res;
      if (!this.viewSoftwareData['deviceModels']) {
        this.viewSoftwareData['deviceModels'] = [];
      }
      if (this.viewSoftwareData && this.viewSoftwareData.versions && this.viewSoftwareData.versions.length > 0) {
        const selcetedVersionCount = this.event.versions.filter(data => {
          return data.versionStatus === true;
        });
        if (selcetedVersionCount && selcetedVersionCount.length > 0) {
          this.viewSoftwareData.versions.forEach((element, index) => {
            if (element.name === selcetedVersionCount[0].name && element.number === selcetedVersionCount[0].number) {
              this.selectedVersion = index;
            }
          });
        }
      }
      this.oldVersionNumber = this.cms.deepCopyOfObject(this.viewSoftwareData.versions[this.selectedVersion].number);
      this.updateSoftwareDetailsObj = this.viewSoftwareData.versions[this.selectedVersion];
      this.updateSoftwareDetailsObj['softwaredescription'] = this.viewSoftwareData.versions[this.selectedVersion].description;
      this.updateSoftwareDetailsObj['softwarenumber'] = this.viewSoftwareData.versions[this.selectedVersion].number;
      this.updateSoftwareDetailsObj['softwareestimatedUpdateTime'] = this.viewSoftwareData.versions[this.selectedVersion].estimatedUpdateTime;
      this.updateSoftwareDetailsObj['softwarereleaseNotes'] = this.viewSoftwareData.versions[this.selectedVersion].releaseNotes;
      this.updateSoftwareDetailsObj['name'] = this.viewSoftwareData.versions[this.selectedVersion].name;
      this.updateSoftwareDetailsObj['softwarelongDescription'] = this.viewSoftwareData.versions[this.selectedVersion].longDescription;
      this.updateSoftwareDetailsObj['applicableForRollback'] = this.viewSoftwareData['applicableForRollback'];
      this.packageId = res.id;
    },
      error => {
        this.failureCase(error);
      });
  }
  newVersion(event) {
    this.createSoftwareFormBlock();
    this.event = event;
    this.isInstallSoftware = false;
    this.isCreateNew = false;
    this.isView = false;
    this.isEdit = false;
    this.isNewVersion = true;
    this.createNewSoftwareForm.controls.platform.setValue(event.platformName);
    this.createNewSoftwareForm.controls.platFormType.setValue(event.platformType);
    this.createNewSoftwareForm.controls.instllerType.setValue(event.installerType);
    this.createNewSoftwareForm.controls.packageId.setValue(event.id);
    this.createNewSoftwareForm.controls.softwareId.setValue(event.scomoId);
  }
  goToEditScreen() {
    this.hideTable();
    this.editData(this.event);
  }
  goToInstallScreen() {
    this.hideTable();
    this.installSoftware(this.event);
  }
  hideTable() {
    this.hideListTable = !this.hideListTable;
    if (!this.hideListTable) {
      this.isInstallSoftware = false;
      this.isCreateNew = false;
      this.isView = false;
      this.isEdit = false;
      this.packageId = false;
      this.isNewVersion = false;
      this.selectedModals = [];
      this.viewSoftwareEnterpriseData = [];
      this.selectedModelsCount = 0;
      this.viewSoftwareEnterpriseData = [];
      this.selectedEnterpriseCount = 0;
    }
  }

  removeDataFromTable() {
    if (this.packageId) {
      this.domainParams = this.HeaderService.getSelectedDomain();
      let params = {};
      if (this.domainParams) {
        params = { "ids": this.packageId, "domainName": this.domainParams.name };
      } else {
        params = { "ids": this.packageId, "domainName": this.domainParams.name };
      }
      this.sms.deleteApp(params).subscribe(result => {
        this.hideTable();
        this.spinnerService.toggleSpinner(0);
        this.dataService.broadcast('alert', {
          type: 'success',
          message: 'Delete successfully'
        });

      },
        error => {
          this.failureCase(error);
        });
    } else {
      this.hideTable();
    }

  }

  unselectAll() {
    this.selectAll = false;
    this.models.map(model => {
      model.selected = false;
    });
    this.checkAllSelectdOrNot();
  }
  unselectEnterpriseAll() {
    this.selectEnterpriseAll = false;
    this.enterprisemodels.map(model => {
      model.selected = false;
    });
    //this.checkEnterpriseAllSelectdOrNot();
  }
  searchEnterprise() {
    this.selectEnterpriseAll = false;
    if (this.searchModel) {
      this.searchWithEnterpriseName();
    } else {
      this.getEnterPriseId();
    }
  }
  searchWithEnterpriseName(page?) {
    const obj = { hqBpName: this.searchModel };
    if (page) {
      this.currentPageOfEnterpriseModal = page;
    } else {
      this.currentPageOfEnterpriseModal = 1;
    }
    this.spinnerService.toggleSpinner(0);
    const totalEnterpriseResult = this.sms.getEnterpriseSearchName(obj);
    //this.selectedEnterpriseCount = 0;
    forkJoin([totalEnterpriseResult]).subscribe(results => {
      this.spinnerService.toggleSpinner(0);
      if (results[0] && results[0].data && results[0].data.length > 0) {
        this.enterprisemodels = [];
        this.enterpriseModelsListCount = results[0].data.length;
        let count = 0;
        results[0].data.forEach(models => {
          let modelSelected = false;
          if (this.selectedEnterpriseModals && this.selectedEnterpriseModals.length > 0) {
            this.selectedEnterpriseModals.forEach(selctedData => {
              if (selctedData.id == models.hqBpId) {
                modelSelected = true;
              }
            })
          }
          count = this.selectedEnterpriseModals.length;
          // if (this.selectedEnterpriseModals.includes(models.hqBpName)) {
          //   modelSelected = true;
          //   count++;
          // }
          this.enterprisemodels.push({
            selected: modelSelected,
            id: models.hqBpId,
            name: models.hqBpName
          });
        });
        this.selectEnterpriseAll = this.enterprisemodels.every(model => {
          return model.selected === true;
        });
        this.selectedEnterpriseCount = count;
        this.enterpriseIdsArray = results[0].data;
      } else {
        this.enterpriseIdsArray = [];
      }
    }, error => {
      this.enterpriseIdsArray = [];
      this.failureCase(error);
    });
  }
  checkEnterpriseAllSelectdOrNot() {
    this.selectedEnterpriseCount = 0;
    //this.selectedEnterpriseModals = [];
    this.selectedEnterpriseCount = this.selectedEnterpriseModals.length;
    this.enterprisemodels.forEach((model, index) => {
      if (model.selected) {
        //this.selectedEnterpriseCount++;
        this.selectedEnterpriseModals.push({
          name: model.name,
          id: model.id
        })
      } else {
        const index = this.selectedEnterpriseModals.findIndex(item => item.name === model.name);
        this.selectedEnterpriseModals.splice(index, 1);
      }
    });
    this.selectEnterpriseAll = this.enterprisemodels.every(model => {
      return model.selected === true;
    });
    // this.IsIndeterminate = allSelected === true ? false : true;
  }
  selcetAllModels(event) {
    this.models.map(model => {
      model.selected = event.checked;
    });
    this.checkAllSelectdOrNot();
  }

  selectAllEnterpriseModels(event) {
    this.selectedEnterpriseCount = 0;
    this.enterprisemodels.map(model => {
      model.selected = event.checked;
    });
    this.selectedEnterpriseCount = this.enterprisemodels.length;
    this.checkEnterpriseAllSelectdOrNot();
  }
  selcetAllDevices(event) {
    this.deviceModelsList.map(device => {
      device.selected = event.checked;
    });
    this.checkAllSelectdOrNotForDevices();
  }

  selectSingleOne(event, model) {
    model.selected = event.checked;
    this.selectedDevicesCount = 0;
    this.deviceModelsList.forEach(device => {
      if (device.selected) {
        this.selectedDevicesCount++;
      }
    });
    this.selectAllDevices = this.deviceModelsList.every(device => {
      return device.selected === true;
    });
    this.notSelectAnyDevices = this.deviceModelsList.every(device => {
      return device.selected !== true;
    });
    return (model.selected = event.checked);
  }

  selectSingleEnterpriseOne(event, model) {
    model.selected = event.checked;
    //this.selectedEnterpriseCount = 0;
    //this.selectedEnterpriseModals = [];
    // this.enterprisemodels.forEach(model => {
    //   if (model.selected) {
    //     this.selectedEnterpriseCount++;
    //   }
    // });
    if (event.checked) {
      this.selectedEnterpriseModals.push({
        name: model.name,
        id: model.id
      })
    } else {
      if (this.selectedEnterpriseModals && this.selectedEnterpriseModals.length > 0) {
        const index = this.selectedEnterpriseModals.findIndex(item => item.id === model.id);
        this.selectedEnterpriseModals.splice(index, 1);
      }
    }
    this.selectedEnterpriseCount = this.selectedEnterpriseModals.length;
    // this.viewSoftwareEnterpriseData = this.selectedEnterpriseModals;
    this.selectEnterpriseAll = this.enterprisemodels.every(model => {
      return model.selected === true;
    });
    return (model.selected = event.checked);
  }

  checkAllSelectdOrNot() {
    this.selectedModelsCount = 0;
    this.selectedModals = [];
    this.models.forEach(model => {
      if (model.selected) {
        this.selectedModelsCount++;
        //  this.selectedModals.push(model.model);
        this.selectedModals.push({
          name: model.model,
          vendor: model.name
        })
      }
    });
    this.viewSoftwareData['deviceModels'] = this.selectedModals;
    this.selectAll = this.models.every(model => {
      return model.selected === true;
    });
    // this.IsIndeterminate = allSelected === true ? false : true;
  }
  checkAllSelectdOrNotForDevices() {
    this.deviceModelsList.forEach(device => {
      if (device.selected) {
        if (!this.selectedDeviceIds.includes(device.deviceDescription.deviceId)) {
          this.selectedDevicesCount++;
          this.selectedDeviceIds.push(device.deviceDescription.deviceId);
          this.selectedDeviceNames.push({ model: device.deviceDescription.model, id: device.deviceDescription.deviceId });
        }
      } else {
        if (this.selectedDeviceIds.includes(device.deviceDescription.deviceId)) {
          this.selectedDevicesCount--;
          const index = this.selectedDeviceIds.indexOf(device.deviceDescription.deviceId);
          const deviceNameIndex = this.selectedDeviceNames.findIndex(selectedDevice => selectedDevice.id === device.deviceDescription.deviceId);
          this.selectedDeviceIds.splice(index, 1);
          this.selectedDeviceNames.splice(deviceNameIndex, 1);
        }
      }
    });
    this.selectAllDevices = this.deviceModelsList.every(device => {
      return device.selected === true;
    });
    this.notSelectAnyDevices = this.deviceModelsList.every(device => {
      return device.selected !== true;
    });
  }



  installSoftwareWithDevices(button) {
    let versionNumber = '';
    if (this.selectedVersion) {
      versionNumber = this.installSoftwareDetails.versions[this.selectedVersion].number;
    } else {
      versionNumber = this.installSoftwareDetails.versions[0].number;
    }

    if (this.installSoftwareDetails && this.installSoftwareDetails.versions && this.installSoftwareDetails.versions.length > 0) {
      const selectedVersionNumber = this.installSoftwareDetails.versions.filter(data => {
        return data.versionStatus === true;
      });
      if (selectedVersionNumber && selectedVersionNumber.length > 0) {
        versionNumber = selectedVersionNumber[0].number;
      }
    }
    const req = {
      deviceIds: this.selectedDeviceIds,
      packages: [
        {
          id: this.installSoftwareDetails.id,
          versionNumber: versionNumber
        }
      ],

      isDraft: (button == 'executeSave' ? true : false),

      description: 'AppInstall_' + this.event.domain + '_' + this.dataService.getParseAndAtob('loginMember') + '_' + new Date()
    };
    if (this.installSoftwareForm.value.isServerInitiated == 'None') {
      req['isServerInitiated'] = false;
    }
    if (this.installSoftwareForm.value.isServerInitiated == 'immediate') {
      req['isServerInitiated'] = true;
    }

    if (this.installSoftwareForm.value.isServerInitiated == 'scheduled') {
      req['isServerInitiated'] = true;
      req['serverInitiatedInTimeZone'] = this.installSoftwareForm.value.serverInitiatedInTimeZone;
      req['serverInitiatedFromTime'] = this.installSoftwareForm.value.serverInitiatedFromTime ? this.cms.convertTime12to24(this.installSoftwareForm.value.serverInitiatedFromTime) : '';
      req['serverInitiatedToTime'] = this.installSoftwareForm.value.serverInitiatedToTime ? this.cms.convertTime12to24(this.installSoftwareForm.value.serverInitiatedToTime) : '';
    }

    if (this.installSoftwareForm.value.campaignRetries) {
      req['campaignRetries'] = this.installSoftwareForm.value.campaignRetries;
    }


    if (this.installSoftwareForm.value.campaignPriority) {
      req['campaignPriority'] = this.installSoftwareForm.value.campaignPriority;
    }

    if (this.installSoftwareForm.value.successMessage) {
      req['successMessage'] = this.installSoftwareForm.value.successMessage;
    }
    if (this.installSoftwareForm.value.failureMessage) {

      req['failureMessage'] = this.installSoftwareForm.value.failureMessage;
    }

    if (this.installSoftwareForm.value.campaignStartTime) {
      req['campaignStartTime'] = this.cms.getEpochTimeForInstallStartDayAndTime(this.installSoftwareForm.value.campaignStartTime, this.startTime);
    }

    if (this.installSoftwareForm.value.campaignEndTime) {
      req['campaignEndTime'] = this.cms.getEpochTimeForInstallStartDayAndTime(this.installSoftwareForm.value.campaignEndTime, this.endTime);
    }
    if (this.installSoftwareForm.value.downloadFromTime) {
      req['downloadFromTime'] = this.cms.convertTime12to24(this.installSoftwareForm.value.downloadFromTime);
    }
    if (this.installSoftwareForm.value.downloadToTime) {
      req['downloadToTime'] = this.cms.convertTime12to24(this.installSoftwareForm.value.downloadToTime);
    }
    if (this.installSoftwareForm.value.networkUsage) {
      req['networkUsage'] = this.installSoftwareForm.value.networkUsage;
    }
    if (this.installSoftwareForm.value.wifiExpirationDate) {
      req['wifiExpirationDate'] = this.cms.getEpochTimeForInstallStartDay(this.installSoftwareForm.value.wifiExpirationDate);
      if (this.installSoftwareForm.value.wifiExpirationTime) {
        let dateTimeepoch = this.cms.getEpochFromDateAndTime(this.installSoftwareForm.value.wifiExpirationDate, this.installSoftwareForm.value.wifiExpirationTime);
        req['wifiExpirationDate'] = dateTimeepoch;
      }
    }
    if (this.installSoftwareForm.value.Quota) {
      if (this.installSoftwareForm.value.quotaType == 'MB') {
        req['Quota'] = this.installSoftwareForm.value.Quota * 1024;
      } else {
        req['Quota'] = this.installSoftwareForm.value.Quota;
      }

    }
    if (this.installSoftwareForm.value.Timeframe) {

      if (this.installSoftwareForm.value.timeFrameType == 'hours') {
        req['Timeframe'] = this.installSoftwareForm.value.Timeframe * 60;
      } else {
        req['Timeframe'] = this.installSoftwareForm.value.Timeframe;
      }
    }
    this.domainParams = this.HeaderService.getSelectedDomain();
    if (this.domainParams) {
      req['domain'] = this.domainParams;
    }
    this.spinnerService.toggleSpinner(1);
    this.sms.installSoftwareWithDevices(req).subscribe(
      result => {
        this.spinnerService.toggleSpinner(0);
        const res = this.successCase(result);
        if (!req.isDraft) {
          this.hideTable();
        } else {
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Saved successfully'
          });
          this.hideTable();
        }
      },
      error => {
        this.failureCase(error);
      }
    );
  }
  differenceInDays() {
    if (this.installSoftwareForm.value.campaignStartTime && this.installSoftwareForm.value.campaignEndTime) {
      if (new Date(this.installSoftwareForm.value.campaignEndTime) > new Date(this.installSoftwareForm.value.campaignStartTime)) {
        this.diffDays = this.cms.dateDiffIndays(this.installSoftwareForm.value.campaignStartTime, this.installSoftwareForm.value.campaignEndTime)
      } else {
        this.diffDays = "";
      }
    }
  }
}
