import { Injectable } from '@angular/core';

import { InterceptorService } from '../shared/services/interceptor.service';
import { DataService } from '../shared/services/data.service';

@Injectable({
  providedIn: 'root'
})
export class SoftwareManagementService {

  constructor(private interceptor: InterceptorService,
    private dataService: DataService) { }

  getSoftwareDetails(request) {
    return this.interceptor.httpCallReturn('get', 'getAllPackagesList', request);
  }
  getInstallerDetails() {
    return this.interceptor.httpCallReturn('get', 'getInstallerDetails');
  }
  populateOtherFields(request) {
    let parmas = {};
    if (request.domain && request.domain.name) {
      parmas['extraParams'] = '?id=' + request.id + '&domainName=' + request.domain.name;
    } else {
      parmas['extraParams'] = '?id=' + request.id;
    }
    return this.interceptor.httpCall('get', 'getAppDetails', parmas);
  }
  getModalsData(request) {
    if (request.domain) {
      request.extraParams = '?domainId=' + request.domainId + '?domainName=' + request.domainName;
    }
    return this.interceptor.httpCallReturn('get', 'getModalsData', request);
  }
  getAllPackages() {
    return this.interceptor.httpCallReturn('get', 'getAllPackages');
  }
  getDefaultTimeZones(request) {
    return this.interceptor.httpCallReturn('get', 'defaultTimeZones', request);
  }
  getPlatforms(request) {
    return this.interceptor.httpCallReturn('get', 'getPlatforms', request);
  }
  setAppplicationStatus(request) {
    return this.interceptor.httpCall('put', 'setAppplicationStatus', request);
  }
  uploadFileData(request, newVersion, domainData, queryParan) {
    if (domainData.id && domainData.name) {
      // request['extraParams'] = "?domainName=" + domainData.name +
      //  '&domainId='+domainData.id+
      //  '&description='+ queryParan.description +
      //  '&longDescription='+queryParan.longDescription +'&packageId='+queryParan.packageId+'&releaseNotes='+queryParan.releaseNotes+'&type='+queryParan.type;

      request['extraParams'] = "?domainName=" + domainData.name +
        '&domainId=' + domainData.id +
        '&description=' + queryParan.description +
        '&longDescription=' + queryParan.longDescription + '&packageId=' + queryParan.packageId + '&releaseNotes=' + queryParan.releaseNotes + '&type=' + queryParan.type;
    }
    return this.interceptor.httpCallReturn('post', newVersion ? 'updateSoftwareByVersion' : 'uploadFileDetails', request, false, true);
  }


  uploadNewFileData(request, newVersion, domainData) {
    if (domainData.id && domainData.name) {
      request['extraParams'] = "?domainName=" + domainData.name + '&domainId=' + domainData.id
    }
    return this.interceptor.httpCallReturn('post', newVersion ? 'updateSoftwareByVersion' : 'uploadFileDetails', request, false, true);
  }


  saveSoftware(request) {
    return this.interceptor.httpCallReturn('post', 'createApp', request);
  }
  updateSoftware(request) {
    if (request && (request.description === "" || request.description == null)) {
      delete request.description;
    } if (request && (request.longDescription === "" || request.longDescription == null)) {
      delete request.longDescription;
    }
    if (request && (request.releaseNotes === "" || request.releaseNotes == null)) {
      delete request.releaseNotes;
    }
    request['extraParams'] = '?versionNumber=' + request.oldVersionNumber;
    return this.interceptor.httpCallReturn('patch', 'updateSoftwareByVersion', request);
  }
  getPackageDetails(request) {
    return this.interceptor.httpCallReturn('get', 'getPackageDetails', request);
  }
  getDeviceDetailsAssociatedWithDeviceModel(request) {
    //request['extraParams'] = "&action="+'install';
    return this.interceptor.httpCallReturn('get', 'getDevices', request);
  }
  installSoftwareWithDevices(request) {
    request['extraParams'] = "?action=" + 'install';
    return this.interceptor.httpCallReturn('post', 'installPackage', request);
  }
  getViewData(request) {
    // if (request.domainId && request.domainName) {
    //   request.extraParams = '?domainId=' + request.domainId + '?domainName=' + request.domainName;
    // }
    return this.interceptor.httpCall('get', 'getAllPackages', request);
  }
  getEditData(request) {
    if (request.domainId && request.domainName) {
      request.extraParams = '?domainId=' + request.domainId + '?domainName=' + request.domainName;
    }
    return this.interceptor.httpCallReturn('get', 'getAllPackages', request);

  }
  deleteApp(request) {
    let params = {};
    if (request.domainName) {
      params['extraParams'] = "?ids=" + request.ids + "&domainName=" + request.domainName;
    } else {
      params['extraParams'] = "?ids=" + request.ids;
    }
    return this.interceptor.httpCallReturn('delete', 'deleteSoftware', params);

  }

  deleteAppVersion(request) {
    let params = {};
    if (request.domainName) {
      params['extraParams'] = "?id=" + request.id + "&domainName=" + request.domainName + "&versionNumber=" + request.versionNumber;
    } else {
      params['extraParams'] = "?id=" + request.id + "&versionNumber=" + request.versionNumber;
    }
    return this.interceptor.httpCallReturn('delete', 'deleteSoftwareVersion', params);

  }
  getObject(request) {
    const key = request['dropDownValue'].trim();
    const value = request['searchKey'].trim();
    const dataObj = {};
    if (request.dropDownValue.trim() === 'osname') {
      dataObj['platformName'] = new Array(request.searchKey);
    } else if (request.dropDownValue === 'domain') {
      dataObj['domains'] = new Array(request.searchKey);
    } else if (request.dropDownValue.trim() === 'devicemodel') {
      let deviceSpace = request.searchKey.split(" ");
      let deviceName = "";
      let vendorName = "";
      let deviceModalParams = {};
      if (deviceSpace && deviceSpace[0]) {
        deviceName = deviceSpace[0];
      } if (deviceSpace && deviceSpace[1]) {
        vendorName = deviceSpace[1];
      }
      deviceModalParams = { name: vendorName, vendor: deviceName };
      //dataObj['deviceModels'] = new Array(deviceModalParams);
      dataObj['deviceModels'] = request['searchKey'].trim();
    } else {
      dataObj[key] = new Array(value);
    }
    return dataObj;
  }
  getTotalCountEnterprises() {
    return this.interceptor.httpCall('get', 'getSoftwareTotalCountEnterprises');
  }

  getVendorList(request) {
    return this.interceptor.httpCall('get', 'getSoftwateEnterpriseList', request);
  }
  getEnterpriseSearchName(request) {
    return this.interceptor.httpCall('get', 'getEnterpriseSearchName', request);
  }
}
