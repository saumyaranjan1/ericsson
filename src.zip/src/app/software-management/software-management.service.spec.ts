import { TestBed } from '@angular/core/testing';

import { SoftwareManagementService } from './software-management.service';

describe('SoftwareManagementService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SoftwareManagementService = TestBed.get(SoftwareManagementService);
    expect(service).toBeTruthy();
  });
});
