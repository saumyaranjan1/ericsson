import { TestBed } from '@angular/core/testing';

import { SoftwareManagementEnumService } from './software-management-enum.service';

describe('SoftwareManagementEnumService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SoftwareManagementEnumService = TestBed.get(SoftwareManagementEnumService);
    expect(service).toBeTruthy();
  });
});
