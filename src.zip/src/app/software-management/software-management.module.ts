import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SoftwareManagementComponent } from './software-management.component';
import { SoftwareManagementRoutingModule } from './software-management-routing.module';
import { SharedModule } from '../shared/shared.module';
import { VendorService } from './../vendor/vendor.service';

@NgModule({
  declarations: [SoftwareManagementComponent],
  imports: [
    CommonModule,
    SoftwareManagementRoutingModule,
    SharedModule
  ],
  providers: [VendorService],
})
export class SoftwareManagementModule { }
