import { B2cDeviceModule } from './b2c-device.module';

describe('B2cDeviceModule', () => {
  let b2cDeviceModule: B2cDeviceModule;

  beforeEach(() => {
    b2cDeviceModule = new B2cDeviceModule();
  });

  it('should create an instance', () => {
    expect(b2cDeviceModule).toBeTruthy();
  });
});
