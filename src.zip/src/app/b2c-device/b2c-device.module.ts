import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from '../shared/shared.module';
import { B2cDeviceRoutingModule } from './b2c-device-routing.module';
import { B2cDeviceComponent } from './b2c-device.component';
import { B2cDeviceService } from './b2c-device.service';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    B2cDeviceRoutingModule
  ],
  declarations: [B2cDeviceComponent],
  providers: [B2cDeviceService]
})
export class B2cDeviceModule { }
