import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { B2cDeviceService } from './b2c-device.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { EnumsService } from './../shared/services/enums.service';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import { UserService } from '../shared/services/user.service';
import { DataService } from '../shared/services/data.service';

@Component({
  selector: 'app-b2c-device',
  templateUrl: './b2c-device.component.html',
  styleUrls: ['./b2c-device.component.less']
})
export class B2cDeviceComponent implements OnInit {
  @ViewChild('deleteConfirmModalContent',{ static: false }) deleteConfirmModalContent: ElementRef;
  @ViewChild('deActivateDeviceModalContent',{ static: false }) deActivateDeviceModalContent: ElementRef;
  domainData;
  data = {
    data: [],
    columns: [
      {
        displayName: 'MSISDN',
        key: 'msisdn',
        filter: ''
      },
      {
        displayName: 'IMEI',
        key: 'imei',
        filter: 'lowercase'
      },
      {
        displayName: 'IMSI',
        key: 'imsi',
        filter: 'lowercase'
      },
      {
        displayName: 'service status',
        key: 'activeStatus',
        filter: ''
      }
    ],
  
    tableHeader: 'Devices',
    tableActions: {
      search: false,
      add: false,
      dropDown: false,
      refreshData: false,
      refreshPage: true
    },
    totalCount: 0
  };

  actionsObj={
     actions: [
      // {
      //   type: 'edit',
      //   title: 'Edit Device',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      //  {
      //   type: 'activateOrDeActivate',
      //   title: 'Change Device Status',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // }
    ],
    actionsLabel: 'Actions',
  }
  actionsArr;


  deviceInfo;
  bpid;
  deActivateDevice: FormGroup;
  serviceStatusArray = ['ACTIVE', 'SUSPEND', 'BLACKLIST'];
  tableHeaderActions;
  constructor(private router: Router,
    private route: ActivatedRoute,
    private b2cDeviceService: B2cDeviceService,
    private ngbModal: NgbModal,
    private fb: FormBuilder,
    private userService: UserService,
    private dataService: DataService) { }

  ngOnInit() {
    this.domainData = JSON.parse(this.route.snapshot.queryParams['event']);
    this.data.tableHeader='Devices List : customer'+' '+this.domainData.bpid ;
  }

  getPaginatedData(event) {
    this.getActions();
    //event.appendUserId = true;
    event.userId = this.domainData.userId;
    this.b2cDeviceService.getDeviceList(event).subscribe((res) => {
       this.data.data = res.data;
       this.data.totalCount = res.data.length;
    });
  }
  getActions() {
    const _module = EnumsService.B2C_DEVICES;
    const _parentModule = EnumsService.B2C_UI_API;

   // Form object to get the previliiages from server
   const obj = {
    moduleCode: _parentModule,
    roleId: this.dataService.getAtobLocalStorage('roleId'),
    previliages: true
  };

  // API to get Previliages
this.userService.getPreViliages(obj).subscribe( prev => {
  this.actionsArr = this.userService.getModulePermission(
    //  _parentModule,
      EnumsService.ACTIONS[_module],
      prev.data.privilege // Passing privilege to the methos to get thr actions array
    );
  

    if(this.actionsArr.actionsArray) {
      this.actionsObj.actions = this.actionsArr.actionsArray.filter((obj) => {
       return (
           obj.type === 'edit' || obj.type === 'activateOrDeActivate'
        );
      });
    } else {
      this.actionsObj.actions = [];
    }  
    this.tableHeaderActions = this.actionsArr.headerRights;

    this.tableHeaderActions['deviceRequest'] = false;
    this.actionsObj.actions.forEach(element => {
        if(element.type === 'activateOrDeActivate') {
          this.tableHeaderActions['deviceRequest'] = true;
        }
    });
   });
}

   
   
  goBack() {
    this.router.navigate(['../main/b2c_ui_api'],
    { queryParams: { domainData: JSON.stringify(this.domainData)}, skipLocationChange: true});
  }

  deleteDeviceModal(event) {
    this.deviceInfo = event;
    this.bpid = event.bpid;
    this.ngbModal
      .open(this.deleteConfirmModalContent, {
        windowClass: 'jio-modal jio-small-modal',
        size: 'sm'
      })
      .result.then(result => {
        this.closeModel(close);
        this.router.navigate(['../main/b2c-devices'],
        { queryParams: { event: JSON.stringify(this.domainData)}, skipLocationChange: true});
      }, reason => {});
  }
  deleteDevice() {
    this.b2cDeviceService.deleteDevice(event).subscribe((res) => {
      this.data.data = res;
      this.data.totalCount = res.length;
    });
  }

  closeModel(close) {
    close('Cross click');
 }

 activateOrDeActivate(event) {
  this.deActivateDevice = this.fb.group({
    serviceStatus: [event ? event.activeStatus : '', Validators.required],
  });

  if(event !==null && event !==undefined ){
    this.openModal(event, this.deActivateDeviceModalContent);
  }else{
    this.dataService.broadcast('alert',
    { type: 'danger', message: 'Please select Device' });
  }
}

openModal(event, content) {
  this.deviceInfo = event;
  this.bpid = event.bpid;
  this.ngbModal
    .open(content, {
      windowClass: 'jio-modal jio-small-modal',
      size: 'sm'
    })
    .result.then(result => {}, reason => {});
}

 editDevice(event) {
  this.router.navigate(['../main/b2c_ui_api'],
  { queryParams: { deviceData: JSON.stringify(event), domainData: JSON.stringify(this.domainData)}, skipLocationChange: true});
 }

 activateDevice(close) {
  const _req = {
    deviceStatus: this.deActivateDevice.controls['serviceStatus'].value,
    devices: [{imei: this.deviceInfo.imei}]
  };
  this.b2cDeviceService.changeDeviceStatus(_req).subscribe(
    res => {
       this.closeModel(close);
       // // Refreshing the component
        this.router.navigateByUrl('../main/b2c_ui_api', {skipLocationChange: true}).then(() =>
        this.router.navigate(['../main/b2c-devices'],
          { queryParams: { event: JSON.stringify(this.domainData)}, skipLocationChange: true}));

    },
    error => {}
  );
}

}
