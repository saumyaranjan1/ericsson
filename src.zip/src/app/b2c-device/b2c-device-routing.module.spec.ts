import { B2cDeviceRoutingModule } from './b2c-device-routing.module';

describe('B2cDeviceRoutingModule', () => {
  let b2cDeviceRoutingModule: B2cDeviceRoutingModule;

  beforeEach(() => {
    b2cDeviceRoutingModule = new B2cDeviceRoutingModule();
  });

  it('should create an instance', () => {
    expect(b2cDeviceRoutingModule).toBeTruthy();
  });
});
