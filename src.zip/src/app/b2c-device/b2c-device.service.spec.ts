import { TestBed } from '@angular/core/testing';

import { B2cDeviceService } from './b2c-device.service';

describe('B2cDeviceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: B2cDeviceService = TestBed.get(B2cDeviceService);
    expect(service).toBeTruthy();
  });
});
