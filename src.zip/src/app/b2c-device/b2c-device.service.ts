import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';
import { DeleteIntercepterService } from '../shared/services/delete-ajax-method.service';

@Injectable({
  providedIn: 'root'
})
export class B2cDeviceService {

  constructor(private interceptor: InterceptorService, private deleteIntercepterService: DeleteIntercepterService) { }

  getDeviceList(request) {
    return this.interceptor.httpCall('get', 'domainB2cDeviceList', request);
  }
  deleteDevice(request) {
    return this.deleteIntercepterService.httpDelete('delete', 'b2cDeleteDevice', request);
  }
  changeDeviceStatus(request) {
    return this.interceptor.httpCall('post', 'changeDeviceStatus', request);
  }
}
