import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { B2cDeviceComponent } from './b2c-device.component';

const routes: Routes = [{ path: '', component: B2cDeviceComponent }];

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ],
  declarations: [],
  exports: [RouterModule]
})
export class B2cDeviceRoutingModule { }
