import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { B2cDeviceComponent } from './b2c-device.component';

describe('B2cDeviceComponent', () => {
  let component: B2cDeviceComponent;
  let fixture: ComponentFixture<B2cDeviceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ B2cDeviceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(B2cDeviceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
