import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RuleGroupEngineComponent } from './rule-group-engine.component';

const routes: Routes = [{ path: '', component: RuleGroupEngineComponent }];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RuleGroupEngineRoutingModule { }
