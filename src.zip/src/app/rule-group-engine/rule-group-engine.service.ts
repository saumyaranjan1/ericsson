import { Injectable } from '@angular/core';
import { InterceptorService } from '../shared/services/interceptor.service';
import { DeleteIntercepterService } from '../shared/services/delete-ajax-method.service';

@Injectable()
export class RuleGroupEngineService {

  constructor(
    private interceptor: InterceptorService,
    private deleteIntercepterService: DeleteIntercepterService
  ) { }
  /**
   * Get Rule Group Data
   */
  getRuleGroupData() {
    const request = { responseType: 'json' };
    return this.interceptor.httpCall('get', 'getRuleGroup', request);
  }

  getconfigPushRuleGroupData() {
    const request = { responseType: 'json' };
    return this.interceptor.httpCall('get', 'getConfigPushRuleGroup', request);
  }

  getFirmWareRuleGroupData() {
    const request = { responseType: 'json' };
    return this.interceptor.httpCall('get', 'getFirmWareRuleGroup', request);
  }


  getTotalCountEnterprises() {
    return this.interceptor.httpCall('get', 'getRuleGroupTotalCountEnterprises');
  }

  getVendorList(request) {
    return this.interceptor.httpCall('get', 'getRuleGroupEnterpriseList', request);
  }

  /**
   * Get Purpose Data
   */
  getPurposeGroupData(type) {
    const request = { responseType: 'json' };
    if(type == 'ap'){
      return this.interceptor.httpCall('get', 'getPurposeData', request);
    }else if(type == 'cp'){
      return this.interceptor.httpCall('get', 'getConfigPurposeData', request);
    }else if(type == 'fp'){
      return this.interceptor.httpCall('get', 'getFirmwarePurposeData', request);
    }
    
  }
  /**
  * Get EnterPrise Ids
  */
  getEnterpriseIds() {
    const request = { responseType: 'json' };
    return this.interceptor.httpCall('get', 'getEnterPriseIds', request);
  }
  /**
   * Create Rule Group
   */
  createRuleGroup(method, request, type) {
    var url;
    if (type == 'app') {
      url = 'createRuleGroup'
    } else if (type == 'profile') {
      url = 'createConfigRuleGroup'
    } else if (type == 'firmware') {
      url = 'createFirmwareRuleGroup'
    }
    request.responseType = 'text';
    return this.interceptor.httpCall(method, url, request);
  }
  /**
   * Delete Rule Group
   */
  deleteRuleGroup(request,type) {
    var url;
    if (type == 'app') {
      url = 'createRuleGroup'
    } else if (type == 'profile') {
      url = 'createConfigRuleGroup'
    } else if (type == 'firmware') {
      url = 'createFirmwareRuleGroup'
    }
    request.responseType = 'text'
    request['extraParams']='?rule-group-id='+request.ruleGroupId;
    return this.interceptor.httpCall('delete', url, request.extraParams);
  }
  /**
   * Update Rule Group
   */
  updateRuleGroup(method: string, request: any,type) {
    var url;
    if (type == 'app') {
      url = 'createRuleGroup'
    } else if (type == 'profile') {
      url = 'createConfigRuleGroup'
    } else if (type == 'firmware') {
      url = 'createFirmwareRuleGroup'
    }
    request.responseType = 'text'
    request['extraParams']='?rule-group-id='+request.ruleGroupId;
    return this.interceptor.httpCall(method, url , request);
  }

  getEnterpriseSearchName(request) {
    return this.interceptor.httpCall('get', 'getRuleEngineEnterpriseSearchName', request);
  }
}
