import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AngularMultiSelectModule } from 'angular2-multiselect-dropdown';
import { SharedModule } from '../shared/shared.module';
import { RuleGroupEngineRoutingModule } from './rule-group-engine-routing.module';
import { RuleGroupEngineComponent } from './rule-group-engine.component';
import { RuleGroupEngineService } from './rule-group-engine.service';
import {VendorService} from './../vendor/vendor.service'

@NgModule({
  imports: [
    CommonModule,
    RuleGroupEngineRoutingModule,
    AngularMultiSelectModule,
    SharedModule
  ],
  providers: [RuleGroupEngineService,VendorService],
  declarations: [RuleGroupEngineComponent]
})
export class RuleGroupEngineModule { }
