import {
  Component,
  OnInit,
  ViewChild,
  ElementRef,
  ChangeDetectorRef,
  ChangeDetectionStrategy
} from '@angular/core';
import { NgbModal, NgbPopover } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router';
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl
} from '@angular/forms';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders
} from '@angular/common/http';
import { RuleGroupEngineService } from './rule-group-engine.service';
import { RuleGroupEngineEnumService } from './rule-group-engine-enum.service';
import { DataService } from '../shared/services/data.service';
import { forkJoin } from 'rxjs';
import { VendorService } from './../vendor/vendor.service';
import { SpinnerService } from '../shared/services/spinner.service';
import { EnumsService } from '../shared/services/enums.service';
import { UserService } from '../shared/services/user.service';
import { HeaderService } from './../main/header/header.service';


@Component({
  selector: 'app-rule-group-engine',
  templateUrl: './rule-group-engine.component.html',
  styleUrls: ['./rule-group-engine.component.less']
})
export class RuleGroupEngineComponent implements OnInit {
  @ViewChild('deleteConfirmModalContent', { static: true }) deleteConfirmModalContent: ElementRef;
  @ViewChild('addRuleEngineGroupContent', { static: true }) addRuleEngineGroupContent: ElementRef;
  constructor(
    private ngbModal: NgbModal,
    public router: Router,
    private fb: FormBuilder,
    private RuleGroupEngineService: RuleGroupEngineService,
    private dataService: DataService,
    private userService: UserService,
    private VendorService: VendorService,
    private SpinnerService: SpinnerService,
    private http: HttpClient,
    private HeaderService: HeaderService
  ) { }

  ruleGroupData = RuleGroupEngineEnumService.RULEGROUPDATA;
  viewenterpriseIds; //View enterprise ID
  domainParams;
  selectedValue;
  domainInfo = [];
  puposeArray = []; // Purpose Dropdown
  puposeValue = '';
  enterpriseIdsArray = []; //EnterPrise Dropdown
  purposeModelValue = ''; // Purpose dropdown modal initial value
  ruleEngineGroupInfo: any = {};
  headerDropdownList: any;
  createRuleGroupForm: FormGroup;
  modalConfig = {
    create: { headerText: 'Create Rule Group', primeBtnText: 'Save' },
    edit: { headerText: 'Edit Rule Group', primeBtnText: 'Update' },
    view: { headerText: 'View Rule Group', primeBtnText: 'View' }
  };
  configModalOptionMode = null;
  searchFilter: any;
  filterSearch: any;
  actionsArr: any;
  apRead = false;
  cpRead = false;
  fpRead = false;
  pageSize = 1;
  selectedEnterpriseList = [];
  showEnterpriseList = false;
  /**
   * Redirect Rule Engine List
   */
  ruleEngineList(value) {
    this.router.navigate(['../main/rule-engine'],
      { queryParams: { ruleEngineId: value.ruleGroupId, ruleEngineType: value.purpose } });
  }

  /**
   * Redirect Rule Group Engine List
   */
  ruleGroupEngineList() {
    this.router.navigate(['../main/autops']);
  }

  /**
  * Click Edit button
  */
  updateRuleGroupEngine(event) {
    event.mode = 'edit';
    this.selectedEnterpriseList = [];
    this.showEnterpriseList = false;
    this.filterSearch = "";
    this.enterpriseIdsArray = [];
    this.getEnterPriseId(event, 'edit', 'lg');
    event.enterpriseIds.map((value) => {
      value.hqBpId = value.id;
      value.hqBpName = value.name;
      return value;
    });
    this.openAddRuleEngineGroupModal(this.addRuleEngineGroupContent, { mode: 'edit' }, 'lg', event);
    this.purposeModelValue = event.purpose;
  }
  /**
   * Click View button
   */
  viewRuleGroupEngine(event: any) {
    event.mode = 'view';
    this.selectedEnterpriseList = [];
    this.showEnterpriseList = false;
    this.filterSearch = "";
    this.enterpriseIdsArray = [];
    this.getEnterPriseId(event, 'view', 'sm');
    event.enterpriseIds.map((value) => {
      value.hqBpId = value.id;
      value.hqBpName = value.name;
      return value;
    });
    this.openAddRuleEngineGroupModal(this.addRuleEngineGroupContent, { mode: 'view' }, 'sm', event);
    this.purposeModelValue = event.purpose;
  }

  addRuleGroupForm(content, option, modalClass) {
    this.selectedEnterpriseList = [];
    this.showEnterpriseList = false;
    this.filterSearch = "";
    this.enterpriseIdsArray = [];
    this.getEnterPriseId('', 'create', 'lg');
    this.openAddRuleEngineGroupModal(this.addRuleEngineGroupContent, { mode: 'create' }, 'lg', '');
  }

  /**
   * Create Add / Edit rule group form
   */
  openAddRuleEngineGroupModal(content, option, modalClass, event) {
    this.resetModelValue();
    this.configModalOptionMode = option.mode;
    this.initalForms(event);

    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: modalClass,
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }
  /**
   * Reset Selected Modal Value
   */
  resetModelValue() {
    this.purposeModelValue = '';
    this.filterSearch = '';
  }

  /*
  **Create form method
  */
  initalForms(event?) {
    this.createRuleEngineGroupForm(event);
  }

  /**
   * Create form rules with validation
   */
  createRuleEngineGroupForm(event?) {
    if (event && event.mode === 'view') {
      let enterpriseIdsArr = [];
      event.enterpriseIds.forEach(enterPriseId => {
        enterpriseIdsArr.push(enterPriseId.hqBpName);
      });
      const enterpriseView = enterpriseIdsArr.toString();
      this.viewenterpriseIds = enterpriseView.replace(/,/g, "\n");
    }
    if (event && event.mode === 'edit') {
      let enterpriseIdsArr = [];
      this.selectedEnterpriseList = [];
      event.enterpriseIds.forEach(enterPriseId => {
        enterpriseIdsArr.push({
          hqBpId: enterPriseId.hqBpId,
          hqBpName: enterPriseId.hqBpName
        })
        this.selectedEnterpriseList.push({ hqBpId: enterPriseId.hqBpId, hqBpName: enterPriseId.hqBpName,
                                           id:enterPriseId.hqBpId,name:enterPriseId.hqBpName})
      });
      event.enterpriseIds = this.selectedEnterpriseList;
    }
    this.createRuleGroupForm = this.fb.group({
      ruleGroupId: [{ value: event && event.ruleGroupId ? event.ruleGroupId : '', disabled: event && event.mode === 'view' ? true : false }],
      groupName: [{ value: event && event.name ? event.name : '', disabled: event && event.mode === 'view' ? true : false },
      [Validators.required, this.noWhitespaceValidator]],
      description: [{ value: event && event.description ? event.description : '', disabled: event && event.mode === 'view' ? true : false },
      [Validators.required, this.noWhitespaceValidator]],
      purpose: [{ value: event && event.purpose ? event.purpose : '', disabled: event && event.mode === 'view' ? true : false }],
      enterpriseIds: [{ value: event && event.enterpriseIds ? event.enterpriseIds : '', disabled: event && event.mode === 'view' ? true : false }, Validators.required]
    })
  }


  /**
   * White space validation
   */
  public noWhitespaceValidator(control: FormControl) {
    if (control.value) {
      const isWhitespace = (control.value || '').trim().length === 0;
      const isValid = !isWhitespace;
      return isValid ? null : { 'whitespace': true };
    }
    return { 'whitespace': false };
  }

  /***
   * Submit Add / Edit Form
   */
  submitForm(form, close, formName) {
    const formData = form.value;
    if (form.valid) {
      if (formData.ruleGroupId) {
        this.updateRuleGroup(formData, close);
      } else {
        this.addRuleGroup(formData, close);
      }

    }
  }

  /**
   * Add Rule Group
   */
  addRuleGroup(params, close) {
    let enterpriseIds = [];
    if (this.createRuleGroupForm.controls.enterpriseIds && this.createRuleGroupForm.controls.enterpriseIds.value
      && this.createRuleGroupForm.controls.enterpriseIds.value.length > 0) {
      this.createRuleGroupForm.controls.enterpriseIds.value.forEach(element => {
        enterpriseIds.push({ id: element.hqBpId, name: element.hqBpName });
      });
    }
    const postParams = {
      "name": params.groupName.trim(),
      "purpose": this.puposeValue,
      "description": params.description.trim(),
      "enterpriseIds": enterpriseIds,
      "version": {
        "name": "rule-version-1"
      }
    }
    this.SpinnerService.toggleSpinner(1);
    this.RuleGroupEngineService.createRuleGroup('post', postParams, this.puposeValue).subscribe(
      res => {
        if (res) {
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Create Rule Group Successfully'
          });
          const type = this.getRuleGroupType(this.puposeValue);
          if (type) {
            this.getInitialData(type);
          } else {
            this.getInitialData('ap');
          }
          this.closeModel(close);
        }
        this.SpinnerService.toggleSpinner(0);
      },
      error => { 
        //this.failureCase(error);
        this.SpinnerService.toggleSpinner(0); 
      }
    );
  }

  /**
   * Update Rule Group
   */
  updateRuleGroup(formData, close) {
    let enterpriseIds = [];
    if (this.createRuleGroupForm.controls.enterpriseIds && this.createRuleGroupForm.controls.enterpriseIds.value
      && this.createRuleGroupForm.controls.enterpriseIds.value.length > 0) {
      this.createRuleGroupForm.controls.enterpriseIds.value.forEach(element => {
        enterpriseIds.push({ id: element.hqBpId, name: element.hqBpName });
      });
    }
    const params = {
      'ruleGroupId': formData.ruleGroupId,
      "name": formData.groupName.trim(),
      "purpose": this.puposeValue,
      "description": formData.description.trim(),
      "enterpriseIds": enterpriseIds,
      "version": {
        "name": "rule-version-1-updated"
      }
    }
    this.SpinnerService.toggleSpinner(1);
    this.RuleGroupEngineService.updateRuleGroup('put', params, this.puposeValue).subscribe(
      res => {
        if (res) {
          this.dataService.broadcast('alert', {
            type: 'success',
            message: 'Update Rule Group successfully'
          });
          const type = this.getRuleGroupType(this.puposeValue);
          if (type) {
            this.getInitialData(type);
          } else {
            this.getInitialData('ap');
          }
          this.closeModel(close);
        }
        this.SpinnerService.toggleSpinner(0);
      },
      error => {
        this.failureCase(error);
      }
    );
  }

  /**
   * Error Response
   */
  failureCase(error) {
    this.SpinnerService.toggleSpinner(0);
    this.dataService.broadcast('alert', {
      type: 'danger',
      message: error.error && error.error.errorDetails ? error.error.errorDetails : error.error && error.error.error
        ? error.error.error : 'Network error please try again'
    });
  }

  /**
   * Close Popup Window
   */
  closeModel(close) {
    close('Cross click');
  }
  /**
   * Click On Delete open delete Popup
   */
  deleteItem(event) {
    this.openModel(this.deleteConfirmModalContent, event);
  }

  /**
   * Open Model Popup
   */
  openModel(content, event) {
    this.ruleEngineGroupInfo = event;
    this.ngbModal
      .open(content, {
        windowClass: 'jio-modal',
        size: 'sm',
        keyboard: false
      })
      .result.then(result => { }, reason => { });
  }

  /**
   * Delete Rule Engine Group
   */
  deleteRuleEngineGroup(close: any) {
    const _req = { 'ruleGroupId': this.ruleEngineGroupInfo.ruleGroupId };
    this.RuleGroupEngineService.deleteRuleGroup(_req, this.puposeValue).subscribe((res: any) => {
      this.dataService.broadcast('alert', {
        type: 'success',
        message: 'Delete Rule Group successfully'
      });
      const type = this.getRuleGroupType(this.puposeValue);
      if (type) {
        this.getInitialData(type);
      } else {
        this.getInitialData('ap');
      }
      this.closeModel(close);
    });
  }

  /**
   * Get Initial Data
   **/
  ngOnInit() {
    this.searchFilter = [{ key: 'hqBpName', }];
    this.getInitialData('ap');
  }



  getPurposeCode(type) {
    this.RuleGroupEngineService.getPurposeGroupData(type).subscribe(results => {
      if (results) {
        this.puposeArray = results;
      }
    }, error => {
      this.puposeArray = [];
      this.failureCase(error);
    });
  }

  /**
   * 
   * Get Actions previliges for Auto Provison
   */
  getActions(type) {
    let _module;
    if (type == 'ap') {
      _module = EnumsService.AUTOPS_APP;
    } else if (type == 'cp') {
      _module = EnumsService.AUTOPS_CONFIG;
    } else {
      _module = EnumsService.AUTOPS_FIRMWARE;
    }

    const main_module = EnumsService.AUTOPS;
    // Form object to get the previliiages from server
    const obj = {
      moduleCode: main_module,
      roleId: this.dataService.getAtobLocalStorage('roleId'),
      previliages: true
    };
    // API to get Previliages
    this.userService.getPreViliages(obj).subscribe(prev => {

      const headerActions = this.userService.getModulePermission(
        // EnumsService.ACTIONS[_module],
        EnumsService.ACTIONS[main_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );
      headerActions.actionsArray.forEach(element => {
        if (element.type === 'apRead') {
          this.apRead = true;
        }
        if (element.type === 'cpRead') {
          this.cpRead = true;
        }
        if (element.type === 'fpRead') {
          this.fpRead = true;
        }
      });
      this.actionsArr = this.userService.getModulePermission(
        EnumsService.ACTIONS[_module],
        prev.data.privilege // Passing privilege to the methos to get thr actions array
      );
      if (this.actionsArr && this.actionsArr.actionsArray && this.actionsArr.actionsArray.length > 0) {
        this.actionsArr.actionsArray.forEach(element => {
          if (element.type == 'add') {
            element.title = 'Create Rule Group';
          } if (element.type == 'edit') {
            element.title = 'Edit Rule Group';
          } if (element.type == 'delete') {
            element.title = 'Delete Rule Group';
          } if (element.type == 'redirecturl') {
            element.title = 'Redirect to create rule';
          }
        });
      }
      this.ruleGroupData.tableActions = this.actionsArr;
      this.ruleGroupData.tableActions.search = this.actionsArr.headerRights.search;
      this.ruleGroupData.tableActions.add = this.actionsArr.headerRights.add;
      this.ruleGroupData.actions = this.actionsArr.actionsArray;
    });


  }

  getRuleGroupType(type) {
    let returnValue = "";
    if (type == 'app') {
      returnValue = "ap";
    } else if (type == 'profile') {
      returnValue = "cp";
    } else if (type == 'firmware') {
      returnValue = "fp";
    }
    return returnValue;
  }

  /**
   * Get Initial load All data
   */
  getInitialData(type) {
    this.getActions(type);
    this.getPurposeCode(type);
    const obj = { limit: 500, offset: 0, page: 1, pageNum: 1, rpp: 500 }
    if (type == 'ap') {
      this.puposeValue = 'app';
      var ruleGroupData = this.RuleGroupEngineService.getRuleGroupData();
    } else if (type == 'cp') {
      this.puposeValue = 'profile';
      var ruleGroupData = this.RuleGroupEngineService.getconfigPushRuleGroupData();
    } else if (type == 'fp') {
      this.puposeValue = 'firmware';
      var ruleGroupData = this.RuleGroupEngineService.getFirmWareRuleGroupData();
    }
    forkJoin([ruleGroupData]).subscribe(results => {
      if (results[0]) {
        this.ruleGroupData.data = results[0].data;
        this.ruleGroupData.data.map((value) => {
          value.ruleName = value.name;
          return value;
        });
        this.ruleGroupData.data.length = results[0].data.length;
        this.ruleGroupData.total = results[0].data.length;
        this.ruleGroupData.page = 1
      }
    }, error => {
      this.ruleGroupData.data = [];
      this.ruleGroupData.data.length = 0;
      this.ruleGroupData.total = 0;
      this.ruleGroupData.page = 1
      //this.failureCase(error);
    });
  }


  /**
   * Get EnterPrise Ids
   */
  getEnterPriseId(event, mode, modelView, page?) {
    let obj;
    if (page) {
      let pageOffset = this.pageSize * 200;
      this.pageSize = this.pageSize + 1;
      obj = { limit: 200, offset: pageOffset, page: this.pageSize, pageNum: this.pageSize, rpp: 200 };
    } else {
      obj = { limit: 200, offset: 0, page: 1, pageNum: 1, rpp: 200 };
    }
    const totalEnterPriseCount = this.RuleGroupEngineService.getTotalCountEnterprises();
    const totalEnterpriseResult = this.RuleGroupEngineService.getVendorList(obj);
    this.SpinnerService.toggleSpinner(0);
    forkJoin([totalEnterPriseCount, totalEnterpriseResult]).subscribe(results => {
      this.SpinnerService.toggleSpinner(0);
      if (results[1] && results[1].data && results[1].data.length > 0) {
        this.enterpriseIdsArray = this.enterpriseIdsArray.concat(results[1].data);
        this.enterpriseIdsArray.forEach(element => {
          if (this.selectedEnterpriseList && this.selectedEnterpriseList.length > 0) {
            this.selectedEnterpriseList.forEach(inneerElement => {
              if (element.hqBpId == inneerElement.hqBpId) {
                element['isCheck'] = true;
              }
            });
          }
        });
        this.SpinnerService.toggleSpinner(0);
      } else {
        this.SpinnerService.toggleSpinner(0);
      }
    }, error => {
      this.SpinnerService.toggleSpinner(0);
      this.enterpriseIdsArray = [];
    });

  }

  searchWithEnterpriseName(evt) {
    if (evt.target.value) {
      this.filterSearch = evt.target.value;
      const obj = { hqBpName: evt.target.value };
      this.enterpriseIdsArray = [];
      const totalEnterpriseResult = this.RuleGroupEngineService.getEnterpriseSearchName(obj);
      this.SpinnerService.toggleSpinner(1);
      forkJoin([totalEnterpriseResult]).subscribe(results => {
        this.SpinnerService.toggleSpinner(0);
        if (results[0] && results[0].data && results[0].data.length > 0) {
          this.enterpriseIdsArray = results[0].data;
          this.enterpriseIdsArray.forEach(element => {
            if (this.selectedEnterpriseList && this.selectedEnterpriseList.length > 0) {
              this.selectedEnterpriseList.forEach(inneerElement => {
                if (element.hqBpId == inneerElement.hqBpId) {
                  element['isCheck'] = true;
                }
              });
            }
          });
          this.SpinnerService.toggleSpinner(0);
        } else {
          this.SpinnerService.toggleSpinner(0);
        }
      }, error => {
        this.SpinnerService.toggleSpinner(0);
        this.enterpriseIdsArray = [];
      });
    } else {
      this.enterpriseIdsArray = [];
      this.filterSearch = '';
      this.pageSize = 1;
      this.getEnterPriseId('', '', '');
    }
  }

  showCheckList() {
    this.enterpriseIdsArray.forEach(element => {
      this.selectedEnterpriseList.forEach(inneerElement => {
        if (element.hqBpId == inneerElement.hqBpId) {
          element.isCheck = true;
        }
      });
    });
    // this.filterSearch = '';
    this.showEnterpriseList = !this.showEnterpriseList;
  }

  onItemDeSelect(event) {
    this.enterpriseIdsArray.forEach(element => {
      if (event == element.hqBpId) {
        element.isCheck = false;
      }
    });

    this.selectedEnterpriseList.forEach((element, keyId) => {
      if (event == element.hqBpId) {
        this.selectedEnterpriseList.splice(keyId, 1);
      }
    });
    this.setEnterpriseValue();
  }

  setEnterpriseValue() {
    this.createRuleGroupForm.patchValue({
      enterpriseIds: this.selectedEnterpriseList,
      ruleGroupId: this.createRuleGroupForm.controls['ruleGroupId'].value,
      groupName: this.createRuleGroupForm.controls['groupName'].value,
      description: this.createRuleGroupForm.controls['description'].value,
      purpose: this.createRuleGroupForm.controls['purpose'].value
    });
  }

  closeMultiselectField(event) {
    if (event.target) {
      if (event.target.id !== 'multiselectList' && event.target.id !== 'multiselecthevron') {
        this.showEnterpriseList = false;
      }
    }
  }

  checkEnterprise(event, hqBpId) {
    if (event.checked) {
      this.enterpriseIdsArray.forEach((element, keyId) => {
        if (hqBpId == element.hqBpId) {
          if (this.enterpriseIdsArray && this.enterpriseIdsArray[keyId] && this.enterpriseIdsArray[keyId].isCheck) {
            this.enterpriseIdsArray[keyId].isCheck = true;
          }
          this.selectedEnterpriseList.push(element);
        }
      });
    } else {
      this.selectedEnterpriseList.forEach((element, keyId) => {
        if (hqBpId == element.hqBpId) {
          if (this.enterpriseIdsArray && this.enterpriseIdsArray[keyId] && this.enterpriseIdsArray[keyId].isCheck) {
            this.enterpriseIdsArray[keyId].isCheck = false;
          }
          this.selectedEnterpriseList.splice(keyId, 1);
        }
      });
    }
    this.setEnterpriseValue();
  }
  fetchMore(event) {
    if (event > 0 && this.filterSearch == '') {
      if (this.enterpriseIdsArray.length == this.pageSize * 200) {
        this.getEnterPriseId('', '', '', event);
      }
    }
  }
}
