import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RuleGroupEngineEnumService {
  public static RULEGROUPDATA = {
    data: [],
    page: 1,
    total: 10,
    columns: [
      {
        displayName: 'Rule Group Name',
        key: 'ruleName',
        filter: ''
      },
      {
        displayName: 'Rule Purpose',
        key: 'purpose',
        filter: ''
      },
      {
        displayName: 'Rule Description',
        key: 'description',
        filter: ''
      }
    ],
    tableHeader: 'Rule Group Engine',
    actions: [
      // {
      //   type: 'edit',
      //   title: 'Edit Rule Group',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'delete',
      //   title: 'Delete Rule Group',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // },
      // {
      //   type: 'redirecturl',
      //   title: 'View Rule',
      //   showIconProp: null,
      //   disableIconProp: true,
      //   negate: null
      // }
    ],
    actionsLabel: 'Actions',
    tableActions: {
      search: false,
      searchActiom: false,
      add: false,
      edit: false,
      dropDown: false,
      refreshData: false,
      showCheck: false,
      deleteAction: false,
    },
    dropDownsList: [],
    totalCount: 0,
    tabelTooltip: 'This is the index page which shows list of Rule Group'
  }



}



